<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('reports.view');

$type=(string)param('type','attendance');
$from=(string)param('from',date('Y-m-01'));
$to=(string)param('to',date('Y-m-d'));
$month=(string)param('month',date('Y-m'));
$export=param('export','');

function report_data(string $type,string $from,string $to,string $month): array {
    switch ($type) {
      case 'payroll':
        return [['Employee','Code','Gross','Deductions','Net','Paid','Pending','Status'],
          array_map(fn($r)=>[$r['full_name'],$r['emp_code'],$r['gross_earnings'],$r['total_deductions'],$r['net_salary'],$r['paid_amount'],$r['pending_amount'],$r['status']],
          fetch_all("SELECT p.*,e.full_name,e.emp_code FROM payroll p JOIN employees e ON e.id=p.employee_id WHERE p.pay_month=? ORDER BY e.full_name",[$month]))];
      case 'leave':
        return [['Employee','Type','From','To','Days','Status'],
          array_map(fn($r)=>[$r['full_name'],$r['type_name'],$r['start_date'],$r['end_date'],$r['total_days'],$r['status']],
          fetch_all("SELECT lr.*,e.full_name,lt.name AS type_name FROM leave_requests lr JOIN employees e ON e.id=lr.employee_id JOIN leave_types lt ON lt.id=lr.leave_type_id WHERE lr.start_date BETWEEN ? AND ? ORDER BY lr.start_date DESC",[$from,$to]))];
      case 'overtime':
        return [['Date','Employee','Day Type','Actual Hrs','Approved Hrs','Rate','Mult','Amount','Status'],
          array_map(fn($r)=>[$r['ot_date'],$r['full_name'],$r['day_type'],$r['actual_hours'],$r['approved_hours'],$r['hourly_rate'],$r['multiplier'],$r['amount'],$r['status']],
          fetch_all("SELECT o.*,e.full_name FROM overtime o JOIN employees e ON e.id=o.employee_id WHERE o.ot_date BETWEEN ? AND ? ORDER BY o.ot_date DESC",[$from,$to]))];
      case 'emi':
        return [['Employee','Type','Total','EMI','Recovered','Balance','Status'],
          array_map(fn($r)=>[$r['full_name'],$r['advance_type'],$r['total_amount'],$r['emi_amount'],$r['recovered_amount'],$r['balance_amount'],$r['status']],
          fetch_all("SELECT ea.*,e.full_name FROM employee_advances ea JOIN employees e ON e.id=ea.employee_id ORDER BY ea.created_at DESC"))];
      case 'employee':
        return [['Code','Name','Department','Designation','Mobile','Joining','Basic','Status'],
          array_map(fn($r)=>[$r['emp_code'],$r['full_name'],$r['dept_name'],$r['desig_name'],$r['mobile'],$r['joining_date'],$r['basic_salary'],$r['status']],
          fetch_all("SELECT e.*,d.name AS dept_name,ds.name AS desig_name FROM employees e LEFT JOIN departments d ON d.id=e.department_id LEFT JOIN designations ds ON ds.id=e.designation_id ORDER BY e.full_name"))];
      default: // attendance
        return [['Date','Employee','Check In','Check Out','Working Hrs','Late(min)','Early(min)','Status'],
          array_map(fn($r)=>[$r['att_date'],$r['full_name'],$r['check_in'],$r['check_out'],round($r['working_minutes']/60,2),$r['late_minutes'],$r['early_minutes'],$r['status_name']],
          fetch_all("SELECT a.*,e.full_name,s.name AS status_name FROM attendance a JOIN employees e ON e.id=a.employee_id LEFT JOIN attendance_statuses s ON s.id=a.status_id WHERE a.att_date BETWEEN ? AND ? ORDER BY a.att_date DESC,e.full_name",[$from,$to]))];
    }
}

[$headers,$data]=report_data($type,$from,$to,$month);

if ($export==='csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="'.$type.'_report.csv"');
    $out=fopen('php://output','w'); fputcsv($out,$headers);
    foreach($data as $row) fputcsv($out,$row); fclose($out); exit;
}
$pageTitle='Reports'; $activeNav='reports';
require __DIR__ . '/../templates/header.php';
$types=['attendance'=>'Attendance','payroll'=>'Payroll','leave'=>'Leave','overtime'=>'Overtime','emi'=>'EMI / Advance','employee'=>'Employee'];
?>
<div class="page-head"><div><h2>Reports</h2></div>
  <div class="flex gap no-print">
    <a class="btn btn-outline" href="?<?= e(http_build_query(array_merge($_GET,['export'=>'csv']))) ?>">⬇️ Export CSV</a>
    <button class="btn btn-outline" onclick="window.print()">🖨️ Print / PDF</button>
  </div></div>
<form method="get" class="filters no-print">
  <div class="form-group"><label>Report</label><select name="type" onchange="this.form.submit()">
    <?php foreach($types as $k=>$v): ?><option value="<?= $k ?>" <?= $type===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?></select></div>
  <?php if($type==='payroll'): ?>
    <div class="form-group"><label>Month</label><input type="month" name="month" value="<?= e($month) ?>"></div>
  <?php elseif(in_array($type,['attendance','leave','overtime'])): ?>
    <div class="form-group"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
    <div class="form-group"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
  <?php endif; ?>
  <div class="form-group"><button class="btn btn-outline">Run</button></div>
</form>
<div class="card"><div class="card-head"><h3><?= e($types[$type]) ?> Report — <?= count($data) ?> rows</h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><?php foreach($headers as $h): ?><th><?= e($h) ?></th><?php endforeach; ?></tr></thead>
  <tbody><?php foreach($data as $row): ?><tr><?php foreach($row as $c): ?><td><?= e($c ?? '—') ?></td><?php endforeach; ?></tr><?php endforeach; ?>
  <?php if(!$data): ?><tr><td colspan="<?= count($headers) ?>" class="empty">No data.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
