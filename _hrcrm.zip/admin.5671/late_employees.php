<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('attendance.view');
$from = (string)param('from', date('Y-m-01'));
$to   = (string)param('to', date('Y-m-d'));
$rows = fetch_all(
  "SELECT a.*, e.full_name, e.emp_code FROM attendance a JOIN employees e ON e.id=a.employee_id
   WHERE a.late_minutes>0 AND e.is_staff=0 AND a.att_date BETWEEN ? AND ? ORDER BY a.att_date DESC, a.late_minutes DESC",
  [$from,$to]);
$pageTitle='Late Employees'; $activeNav='att_late';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Late Employees</h2></div></div>
<form method="get" class="filters">
  <div class="form-group"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
  <div class="form-group"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Date</th><th>Employee</th><th>Check In</th><th>Minutes Late</th><th>Reason</th><th>Admin Remark</th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><?= fmt_date($r['att_date']) ?></td><td><b><?= e($r['full_name']) ?></b> <span class="text-muted">(<?= e($r['emp_code']) ?>)</span></td>
    <td><?= fmt_date($r['check_in'],'h:i A') ?></td><td><span class="pill pill-warning"><?= $r['late_minutes'] ?> min</span></td>
    <td><?= e($r['late_reason'] ?: '—') ?></td><td><?= e($r['admin_remark'] ?: '—') ?></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No late records in range 🎉</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
