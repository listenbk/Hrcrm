<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_super_admin();   // Manager oversees HR / Team-Leader attendance

$date  = (string)param('date', date('Y-m-d'));
$month = (string)param('month', date('Y-m'));
$mStart = $month.'-01'; $mEnd = date('Y-m-t', strtotime($mStart));

$staff = fetch_all(
  "SELECT e.id, e.emp_code, e.full_name, r.name AS role_name,
          a.check_in, a.check_out, a.working_minutes, a.late_minutes, a.early_minutes, a.admin_remark,
          s.name AS status_name, s.color
   FROM employees e
   LEFT JOIN users u ON u.id=e.user_id
   LEFT JOIN roles r ON r.id=u.role_id
   LEFT JOIN attendance a ON a.employee_id=e.id AND a.att_date=?
   LEFT JOIN attendance_statuses s ON s.id=a.status_id
   WHERE e.is_staff=1 AND e.status='Active'
   ORDER BY r.name, e.full_name", [$date]);

// Monthly rollup per staff member
function staff_month(int $eid, string $start, string $end): array {
    $rows = fetch_all("SELECT a.*, s.name AS status_name, s.is_leave FROM attendance a
        LEFT JOIN attendance_statuses s ON s.id=a.status_id
        WHERE a.employee_id=? AND a.att_date BETWEEN ? AND ?", [$eid,$start,$end]);
    $p=0;$abs=0;$lv=0;$late=0;$early=0;$mins=0;
    foreach($rows as $r){
        if($r['is_leave'])$lv++; elseif(($r['status_name']??'')==='Absent')$abs++; elseif($r['check_in'])$p++;
        if($r['late_minutes']>0)$late++; if($r['early_minutes']>0)$early++; $mins+=(int)$r['working_minutes'];
    }
    $ot=(float)fetch_col("SELECT COALESCE(SUM(actual_hours),0) FROM overtime WHERE employee_id=? AND ot_date BETWEEN ? AND ?", [$eid,$start,$end]);
    return ['present'=>$p,'absent'=>$abs,'leave'=>$lv,'late'=>$late,'early'=>$early,'minutes'=>$mins,'ot'=>$ot];
}

$pageTitle='HR Attendance'; $activeNav='hr_att';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>HR &amp; Team-Leader Attendance</h2>
  <div class="breadcrumb">Staff self-attendance — only you (Manager) can correct it.</div></div></div>

<form method="get" class="filters">
  <div class="form-group"><label>Date (today's view)</label><input type="date" name="date" value="<?= e($date) ?>"></div>
  <div class="form-group"><label>Month (summary)</label><input type="month" name="month" value="<?= e($month) ?>"></div>
  <div class="form-group"><button class="btn btn-outline">Apply</button></div>
</form>

<div class="card mb-2"><div class="card-head"><h3>Today — <?= fmt_date($date,'d M Y') ?></h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Staff</th><th>Role</th><th>Check-In</th><th>Check-Out</th><th>Status</th><th>Late</th><th>Early</th><th>Working</th><th></th></tr></thead>
  <tbody><?php foreach($staff as $r): ?>
    <tr>
      <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
      <td><span class="pill pill-info"><?= e($r['role_name']) ?></span></td>
      <td><?= $r['check_in']?fmt_date($r['check_in'],'h:i A'):'—' ?></td>
      <td><?= $r['check_out']?fmt_date($r['check_out'],'h:i A'):($r['check_in']?'<span class="text-muted">Working</span>':'—') ?></td>
      <td><?= $r['status_name']?'<span class="badge" style="background:'.e($r['color']).'">'.e($r['status_name']).'</span>':'<span class="pill pill-muted">Not in</span>' ?></td>
      <td><?= $r['late_minutes']>0?'<span class="pill pill-warning">'.$r['late_minutes'].'m</span>':'No' ?></td>
      <td><?= $r['early_minutes']>0?'<span class="pill pill-info">'.$r['early_minutes'].'m</span>':'No' ?></td>
      <td><?= $r['working_minutes']?fmt_hm((int)$r['working_minutes']):'—' ?></td>
      <td class="text-right"><a class="btn btn-sm btn-outline" href="<?= url('admin/attendance_manual.php?employee='.$r['id'].'&date='.$date) ?>">Correct</a></td>
    </tr>
  <?php endforeach; if(!$staff): ?><tr><td colspan="9" class="empty">No HR / Team-Leader staff yet. They appear here after their first login.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="card"><div class="card-head"><h3>Monthly Summary — <?= fmt_date($mStart,'F Y') ?></h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Staff</th><th>Present</th><th>Absent</th><th>Leave</th><th>Late</th><th>Early</th><th>OT Hrs</th><th>Total Working</th></tr></thead>
  <tbody><?php foreach($staff as $r): $m=staff_month((int)$r['id'],$mStart,$mEnd); ?>
    <tr><td><b><?= e($r['full_name']) ?></b></td>
      <td><?= $m['present'] ?></td><td><?= $m['absent'] ?></td><td><?= $m['leave'] ?></td>
      <td><?= $m['late'] ?></td><td><?= $m['early'] ?></td>
      <td><?= rtrim(rtrim(number_format($m['ot'],1),'0'),'.') ?></td><td><?= fmt_hm($m['minutes']) ?></td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
