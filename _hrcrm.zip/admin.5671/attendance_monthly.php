<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('attendance.view');

$month = (string)param('month', date('Y-m'));
[$y,$mn] = array_map('intval', explode('-', $month));
$dept = (int)param('department', 0);
$dim = (int)date('t', strtotime($month.'-01'));
$export = param('export','');

$where = ["e.status='Active'", "e.is_staff=0"]; $args=[];
if ($dept) { $where[]="e.department_id=?"; $args[]=$dept; }
$emps = fetch_all("SELECT e.id,e.emp_code,e.full_name FROM employees e WHERE ".implode(' AND ',$where)." ORDER BY e.full_name", $args);

// Build map: emp_id => [day => row]
$start=$month.'-01'; $end=date('Y-m-t',strtotime($start));
$attRows = fetch_all(
  "SELECT a.employee_id,a.att_date,a.late_minutes,a.check_in,s.short_code,s.color,s.name AS status_name,s.is_leave
   FROM attendance a LEFT JOIN attendance_statuses s ON s.id=a.status_id
   WHERE a.att_date BETWEEN ? AND ?", [$start,$end]);
$map=[];
foreach ($attRows as $r) { $map[$r['employee_id']][(int)date('j',strtotime($r['att_date']))]=$r; }

function month_summary(array $days,int $dim,string $month): array {
  $p=0;$a=0;$l=0;$late=0;
  foreach($days as $d=>$r){
    if($r['is_leave'])$l++; elseif(($r['status_name']??'')==='Absent')$a++; elseif($r['check_in'])$p++;
    if($r['late_minutes']>0)$late++;
  }
  return [$p,$a,$l,$late];
}

if ($export === 'csv') {
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="attendance_'.$month.'.csv"');
    $out=fopen('php://output','w');
    $head=['Employee','Code']; for($d=1;$d<=$dim;$d++)$head[]=$d; array_push($head,'Present','Absent','Leave','Late');
    fputcsv($out,$head);
    foreach($emps as $em){
      $days=$map[$em['id']]??[]; $line=[$em['full_name'],$em['emp_code']];
      for($d=1;$d<=$dim;$d++){ $line[]=$days[$d]['short_code']??(is_weekly_off(sprintf('%s-%02d',$month,$d),$em['id'])?'WO':''); }
      [$p,$a,$l,$lt]=month_summary($days,$dim,$month); array_push($line,$p,$a,$l,$lt);
      fputcsv($out,$line);
    }
    fclose($out); exit;
}

$depts = fetch_all("SELECT id,name FROM departments WHERE is_active=1 ORDER BY name");
$statuses = att_statuses_active();
$pageTitle='Monthly Attendance'; $activeNav='att_monthly';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Monthly Attendance — <?= fmt_date($month.'-01','F Y') ?></h2></div>
  <div class="flex gap no-print">
    <a class="btn btn-outline" href="?<?= e(http_build_query(array_merge($_GET,['export'=>'csv']))) ?>">⬇️ CSV</a>
    <button class="btn btn-outline" onclick="window.print()">🖨️ Print</button>
  </div></div>

<form method="get" class="filters no-print">
  <div class="form-group"><label>Month</label><input type="month" name="month" value="<?= e($month) ?>"></div>
  <div class="form-group"><label>Department</label><select name="department"><option value="0">All</option>
    <?php foreach($depts as $d): ?><option value="<?= $d['id'] ?>" <?= $dept==$d['id']?'selected':'' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><button class="btn btn-outline">Apply</button></div>
</form>

<div class="flex gap wrap mb-2 no-print">
  <?php foreach($statuses as $s): ?>
  <span class="pill" style="background:<?= e($s['color']) ?>22;color:<?= e($s['color']) ?>"><?= e($s['short_code']) ?> = <?= e($s['name']) ?></span>
  <?php endforeach; ?>
</div>

<div class="card"><div class="table-wrap"><table class="data att-cal">
  <thead><tr><th>Employee</th>
    <?php for($d=1;$d<=$dim;$d++): ?><th class="text-center" style="padding:6px"><?= $d ?></th><?php endfor; ?>
    <th>P</th><th>A</th><th>L</th><th>Late</th></tr></thead>
  <tbody><?php foreach($emps as $em): $days=$map[$em['id']]??[]; [$p,$a,$l,$lt]=month_summary($days,$dim,$month); ?>
    <tr><td style="white-space:nowrap"><b><?= e($em['full_name']) ?></b><div class="text-muted" style="font-size:10px"><?= e($em['emp_code']) ?></div></td>
      <?php for($d=1;$d<=$dim;$d++): $r=$days[$d]??null; $date=sprintf('%s-%02d',$month,$d); $off=is_weekly_off($date,$em['id']); ?>
        <td class="day <?= $off&&!$r?'off':'' ?>" style="<?= $r&&$r['color']?'background:'.e($r['color']):'' ?>"
            title="<?= e($r['status_name']??($off?'Weekly Off':'')) ?>"><?= e($r['short_code']??($off?'WO':'·')) ?></td>
      <?php endfor; ?>
      <td class="text-center"><b><?= $p ?></b></td><td class="text-center"><?= $a ?></td>
      <td class="text-center"><?= $l ?></td><td class="text-center"><?= $lt ?></td>
    </tr>
  <?php endforeach; if(!$emps): ?><tr><td colspan="99" class="empty">No employees.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
