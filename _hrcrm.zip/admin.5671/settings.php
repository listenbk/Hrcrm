<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('settings.manage');

$keys = ['company_name','company_address','company_phone','company_email','currency_symbol','timezone',
  'office_login_time','office_logout_time','grace_minutes','half_day_after_minutes','full_day_minutes',
  'weekly_offs','late_deduction_per_day','salary_month_start_day','emp_code_prefix',
  'login_max_attempts','login_lockout_minutes','min_checkout_minutes','auto_checkout_grace_minutes'];

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    // logo upload
    if (!empty($_FILES['company_logo']['name'])) {
        $up=handle_upload($_FILES['company_logo'],'logo',['jpg','jpeg','png','gif','svg']);
        if ($up) set_setting('company_logo',$up);
    }
    // weekly offs (checkbox array)
    $offs=param('weekly_offs',[],'POST'); if(!is_array($offs))$offs=[];
    set_setting('weekly_offs', implode(',', array_map('intval',$offs)));
    // auto-absent toggle (checkbox)
    set_setting('auto_absent_enabled', param('auto_absent_enabled',0,'POST') ? '1' : '0');
    set_setting('auto_checkout_enabled', param('auto_checkout_enabled',0,'POST') ? '1' : '0');
    set_setting('ot_manual_sessions', param('ot_manual_sessions',0,'POST') ? '1' : '0');
    foreach ($keys as $k) {
        if ($k==='weekly_offs') continue;
        if (array_key_exists($k,$_POST)) set_setting($k, trim((string)$_POST[$k]));
    }
    audit_log('settings_updated','settings',null,'Updated company settings');
    flash_success('Settings saved.');
    redirect('admin/settings.php');
}
$s = settings_all(true);
$curOffs = array_filter(array_map('trim',explode(',',$s['weekly_offs']??'')),'strlen');
$weekdays=[0=>'Sunday',1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday'];
$pageTitle='Settings'; $activeNav='settings';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Company &amp; System Settings</h2>
  <div class="breadcrumb">Configure attendance rules, payroll, leave policy and security — no code needed.</div></div></div>

<form method="post" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="grid cols-2">
    <div class="card"><div class="card-head"><h3>🏢 Company</h3></div><div class="card-body">
      <div class="form-group"><label>Company Name</label><input type="text" name="company_name" value="<?= e($s['company_name']??'') ?>"></div>
      <div class="form-group"><label>Address</label><textarea name="company_address"><?= e($s['company_address']??'') ?></textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Phone</label><input type="text" name="company_phone" value="<?= e($s['company_phone']??'') ?>"></div>
        <div class="form-group"><label>Email</label><input type="email" name="company_email" value="<?= e($s['company_email']??'') ?>"></div>
      </div>
      <div class="form-group"><label>Logo</label><input type="file" name="company_logo" accept="image/*">
        <?php if(!empty($s['company_logo'])): ?><div class="mt-1"><img src="<?= url('uploads/'.$s['company_logo']) ?>" style="height:44px"></div><?php endif; ?></div>
      <div class="form-row">
        <div class="form-group"><label>Currency Symbol</label><input type="text" name="currency_symbol" value="<?= e($s['currency_symbol']??'₹') ?>"></div>
        <div class="form-group"><label>Timezone</label><input type="text" name="timezone" value="<?= e($s['timezone']??'Asia/Kolkata') ?>"></div>
      </div>
      <div class="form-group"><label>Employee Code Prefix</label><input type="text" name="emp_code_prefix" value="<?= e($s['emp_code_prefix']??'RG') ?>"></div>
    </div></div>

    <div class="card"><div class="card-head"><h3>🕐 Attendance Rules</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Office Login Time</label><input type="time" name="office_login_time" value="<?= e($s['office_login_time']??'10:30') ?>"></div>
        <div class="form-group"><label>Office Logout Time</label><input type="time" name="office_logout_time" value="<?= e($s['office_logout_time']??'19:00') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Grace Period (minutes)</label><input type="number" name="grace_minutes" value="<?= e($s['grace_minutes']??'10') ?>">
          <div class="help">e.g. 10 → check-in until 10:40 is not late.</div></div>
        <div class="form-group"><label>Half-Day After (min worked)</label><input type="number" name="half_day_after_minutes" value="<?= e($s['half_day_after_minutes']??'120') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Full Day Minutes</label><input type="number" name="full_day_minutes" value="<?= e($s['full_day_minutes']??'480') ?>"></div>
        <div class="form-group"><label>Min. Checkout Wait (minutes)</label><input type="number" name="min_checkout_minutes" value="<?= e($s['min_checkout_minutes']??'30') ?>">
          <div class="help">Checkout is disabled for this long after check-in.</div></div>
      </div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="auto_absent_enabled" value="1" <?= ($s['auto_absent_enabled']??'1')==='1'?'checked':'' ?>> Auto-mark Absent after office closing time (runs via daily cron)</label>
        <div class="help">Employees who never check in on a working day are marked Absent. Leave, weekly offs and holidays are skipped.</div></div>
      <div class="form-row">
        <div class="form-group"><label>Auto Check-Out Grace (minutes)</label><input type="number" name="auto_checkout_grace_minutes" value="<?= e($s['auto_checkout_grace_minutes']??'30') ?>">
          <div class="help">Grace after logout time. e.g. 19:00 + 30 → auto check-out at 7:30 PM.</div></div>
        <div class="form-group" style="align-self:end"><label class="switch"><input type="checkbox" name="auto_checkout_enabled" value="1" <?= ($s['auto_checkout_enabled']??'1')==='1'?'checked':'' ?>> Auto Check-Out still-checked-in employees (daily cron)</label></div>
      </div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="ot_manual_sessions" value="1" <?= ($s['ot_manual_sessions']??'1')==='1'?'checked':'' ?>> Overtime requires a separate Overtime Check-In (do not auto-count OT from checkout)</label>
        <div class="help">When on, overtime is counted only from a manual OT Check-In / Check-Out session after normal hours end.</div></div>
      <div class="form-group"><label>Weekly Offs</label>
        <div class="form-row-3">
          <?php foreach($weekdays as $n=>$wd): ?>
          <label class="switch"><input type="checkbox" name="weekly_offs[]" value="<?= $n ?>" <?= in_array((string)$n,$curOffs,true)?'checked':'' ?>> <?= $wd ?></label>
          <?php endforeach; ?>
        </div></div>
    </div></div>
  </div>

  <div class="grid cols-2 mt-2">
    <div class="card"><div class="card-head"><h3>💰 Payroll &amp; Leave</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Salary Month Start Day</label><input type="number" name="salary_month_start_day" value="<?= e($s['salary_month_start_day']??'1') ?>"></div>
        <div class="form-group"><label>Late Deduction per Occurrence (₹)</label><input type="number" step="0.01" name="late_deduction_per_day" value="<?= e($s['late_deduction_per_day']??'0') ?>">
          <div class="help">0 = no automatic late penalty.</div></div>
      </div>
      <p class="help">Leave types &amp; quotas are managed in <a href="<?= url('admin/leave_types.php') ?>">Leave Types</a>. Salary components in <a href="<?= url('admin/salary_components.php') ?>">Salary Components</a>.</p>
    </div></div>

    <div class="card"><div class="card-head"><h3>🔒 Security</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Max Login Attempts</label><input type="number" name="login_max_attempts" value="<?= e($s['login_max_attempts']??'5') ?>"></div>
        <div class="form-group"><label>Lockout Window (minutes)</label><input type="number" name="login_lockout_minutes" value="<?= e($s['login_lockout_minutes']??'15') ?>"></div>
      </div>
      <p class="help">After the maximum failed attempts within the window, further logins from that email/IP are blocked until the window passes.</p>
    </div></div>
  </div>

  <div class="mt-3"><button class="btn btn-lg" style="width:auto">💾 Save All Settings</button></div>
</form>
<?php require __DIR__ . '/../templates/footer.php'; ?>
