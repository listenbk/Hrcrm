<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('payroll.view');
$id=(int)param('id',0);
$p=fetch_one("SELECT p.*, e.full_name,e.emp_code FROM payroll p JOIN employees e ON e.id=p.employee_id WHERE p.id=?", [$id]);
if(!$p){ flash_error('Payroll not found.'); redirect('admin/payroll.php'); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    if (!has_perm('payroll.manage')) { http_response_code(403); exit; }
    $act=param('do','','POST');
    if ($act==='pay') {
        $amt=(float)param('amount',0,'POST');
        $mode=trim((string)param('payment_mode','','POST'));
        $ref=trim((string)param('reference_no','','POST'));
        $pdate=param('payment_date',date('Y-m-d'),'POST');
        if ($amt>0) {
            q("INSERT INTO salary_payments (payroll_id,amount,payment_date,payment_mode,reference_no,created_by) VALUES (?,?,?,?,?,?)",
              [$id,$amt,$pdate,$mode,$ref,current_user()['id']]);
            $paid=(float)$p['paid_amount']+$amt;
            $pending=max(0,(float)$p['net_salary']-$paid);
            $status=$pending<=0?'Paid':'Partially Paid';
            q("UPDATE payroll SET paid_amount=?,pending_amount=?,status=?,payment_date=?,payment_mode=?,reference_no=? WHERE id=?",
              [$paid,$pending,$status,$pdate,$mode,$ref,$id]);
            audit_log('salary_paid','payroll',$id,"Paid ".money($amt)." to {$p['full_name']}");
            $emp=fetch_one("SELECT user_id FROM employees WHERE id=?",[$p['employee_id']]);
            if(!empty($emp['user_id'])) notify((int)$emp['user_id'],'salary_paid','Salary paid',money($amt).' credited for '.$p['pay_month'],url('employee/salary_slips.php'));
            flash_success('Payment recorded.');
        }
    } elseif ($act==='status') {
        $st=param('status','Pending','POST');
        if (in_array($st,['Draft','Pending','Partially Paid','Paid','On Hold','Unpaid'],true)) {
            q("UPDATE payroll SET status=? WHERE id=?",[$st,$id]); flash_success('Status updated.');
        }
    } elseif ($act==='finalize') {
        q("UPDATE payroll SET is_finalized=1 WHERE id=?",[$id]);
        // Lock in approved overtime for this month as Paid against this payroll
        $start=$p['pay_month'].'-01'; $end=date('Y-m-t',strtotime($start));
        q("UPDATE overtime SET status='Paid', payroll_id=?
           WHERE employee_id=? AND ot_date BETWEEN ? AND ?
             AND status IN ('Approved','Partially Approved') AND include_in_payroll=1 AND payroll_id IS NULL",
          [$id,$p['employee_id'],$start,$end]);
        audit_log('payroll_finalized','payroll',$id,"Finalized {$p['full_name']} {$p['pay_month']}");
        flash_success('Payroll finalized and locked. Approved overtime marked as paid.');
    }
    redirect('admin/payroll_view.php?id='.$id);
}

$items=fetch_all("SELECT * FROM payroll_items WHERE payroll_id=? ORDER BY type DESC, id",[$id]);
$earnings=array_filter($items,fn($i)=>$i['type']==='earning');
$deductions=array_filter($items,fn($i)=>$i['type']==='deduction');
$payments=fetch_all("SELECT * FROM salary_payments WHERE payroll_id=? ORDER BY payment_date DESC",[$id]);
$pageTitle='Payroll · '.$p['full_name']; $activeNav='payroll';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2><?= e($p['full_name']) ?> — <?= fmt_date($p['pay_month'].'-01','F Y') ?></h2>
  <div class="breadcrumb"><a href="<?= url('admin/payroll.php?month='.$p['pay_month']) ?>">Payroll</a> / <?= e($p['emp_code']) ?></div></div>
  <div class="flex gap"><a class="btn btn-outline" href="<?= url('admin/salary_slip.php?id='.$id) ?>">🧾 Salary Slip</a></div></div>

<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>Earnings</h3></div><div class="table-wrap"><table class="data">
    <tbody><?php foreach($earnings as $it): ?><tr><td><?= e($it['label']) ?></td><td class="num"><?= money($it['amount']) ?></td></tr><?php endforeach; ?>
    <tr style="font-weight:800;background:#f8fafc"><td>Gross Earnings</td><td class="num"><?= money($p['gross_earnings']) ?></td></tr></tbody>
  </table></div></div>
  <div class="card"><div class="card-head"><h3>Deductions</h3></div><div class="table-wrap"><table class="data">
    <tbody><?php foreach($deductions as $it): ?><tr><td><?= e($it['label']) ?></td><td class="num" style="color:var(--danger)">− <?= money($it['amount']) ?></td></tr><?php endforeach; if(!$deductions): ?><tr><td colspan="2" class="text-muted">No deductions.</td></tr><?php endif; ?>
    <tr style="font-weight:800;background:#f8fafc"><td>Total Deductions</td><td class="num">− <?= money($p['total_deductions']) ?></td></tr></tbody>
  </table></div></div>
</div>

<div class="card mt-2"><div class="card-body flex between items-center wrap gap">
  <div><div class="text-muted">Net Payable</div><div class="hours-big"><?= money($p['net_salary']) ?></div></div>
  <div class="text-right">
    <div>Paid: <b><?= money($p['paid_amount']) ?></b> · Pending: <b style="color:var(--danger)"><?= money($p['pending_amount']) ?></b></div>
    <div class="text-muted">Attendance: <?= $p['present_days'] ?> present · <?= $p['absent_days'] ?> absent · <?= $p['leave_days'] ?> leave · <?= $p['late_count'] ?> late</div>
  </div>
</div></div>

<?php if (has_perm('payroll.manage')): ?>
<div class="grid cols-2 mt-2">
  <div class="card"><div class="card-head"><h3>Record Payment</h3></div><div class="card-body">
    <?php if($p['is_finalized'] && $p['pending_amount']<=0): ?><div class="empty">Fully paid.</div><?php else: ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="pay">
      <div class="form-row">
        <div class="form-group"><label>Amount (₹)</label><input type="number" step="0.01" name="amount" value="<?= e($p['pending_amount']) ?>" required></div>
        <div class="form-group"><label>Date</label><input type="date" name="payment_date" value="<?= date('Y-m-d') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Mode</label><select name="payment_mode"><option>Bank Transfer</option><option>UPI</option><option>Cash</option><option>Cheque</option></select></div>
        <div class="form-group"><label>Reference No.</label><input type="text" name="reference_no"></div>
      </div>
      <button class="btn btn-success">💵 Record Payment</button>
    </form>
    <?php endif; ?>
  </div></div>

  <div class="card"><div class="card-head"><h3>Status & Finalize</h3></div><div class="card-body">
    <form method="post" class="flex gap items-center mb-2"><?= csrf_field() ?><input type="hidden" name="do" value="status">
      <select name="status" style="max-width:200px">
        <?php foreach(['Draft','Pending','Partially Paid','Paid','On Hold','Unpaid'] as $s): ?>
        <option <?= $p['status']===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select>
      <button class="btn btn-outline">Update Status</button>
    </form>
    <?php if(!$p['is_finalized']): ?>
    <form method="post" data-confirm="Finalize this payroll? It will be locked from re-generation."><?= csrf_field() ?>
      <input type="hidden" name="do" value="finalize"><button class="btn btn-warning">🔒 Finalize Payroll</button></form>
    <?php else: ?><span class="pill pill-muted">🔒 Finalized</span><?php endif; ?>

    <h4 class="mt-3">Payment History</h4>
    <table class="data"><tbody>
    <?php foreach($payments as $pay): ?><tr><td><?= fmt_date($pay['payment_date']) ?></td><td><?= e($pay['payment_mode']) ?></td><td class="num"><?= money($pay['amount']) ?></td></tr><?php endforeach; if(!$payments): ?><tr><td class="text-muted">No payments yet.</td></tr><?php endif; ?>
    </tbody></table>
  </div></div>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
