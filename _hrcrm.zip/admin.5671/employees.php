<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('employees.view');

$search = trim((string)param('q', ''));
$dept   = (int)param('department', 0);
$status = (string)param('status', '');

$where = ['e.is_staff=0']; $args = [];   // hide HR/TL self-attendance profiles
if ($search !== '') {
    $where[] = "(e.full_name LIKE ? OR e.emp_code LIKE ? OR e.mobile LIKE ? OR e.email LIKE ?)";
    $like = "%$search%"; array_push($args, $like, $like, $like, $like);
}
if ($dept > 0) { $where[] = "e.department_id = ?"; $args[] = $dept; }
if ($status !== '') { $where[] = "e.status = ?"; $args[] = $status; }
$whereSql = implode(' AND ', $where);

[$limit, $offset, $page] = paginate(15);
$total = (int)fetch_col("SELECT COUNT(*) FROM employees e WHERE $whereSql", $args);
$rows = fetch_all(
    "SELECT e.*, d.name AS dept_name, ds.name AS desig_name
     FROM employees e
     LEFT JOIN departments d ON d.id=e.department_id
     LEFT JOIN designations ds ON ds.id=e.designation_id
     WHERE $whereSql ORDER BY e.full_name LIMIT $limit OFFSET $offset", $args);
$depts = fetch_all("SELECT id,name FROM departments WHERE is_active=1 ORDER BY name");
$pages = max(1, (int)ceil($total / $limit));

$pageTitle = 'Employees'; $activeNav = 'employees';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>Employees</h2><div class="breadcrumb"><?= $total ?> record(s)</div></div>
  <?php if (has_perm('employees.create')): ?>
  <a class="btn" href="<?= url('admin/employee_edit.php') ?>">➕ Add Employee</a>
  <?php endif; ?>
</div>

<form method="get" class="filters">
  <div class="form-group"><label>Search</label>
    <input type="search" name="q" value="<?= e($search) ?>" placeholder="Name, ID, mobile, email"></div>
  <div class="form-group"><label>Department</label>
    <select name="department"><option value="0">All</option>
      <?php foreach ($depts as $d): ?>
      <option value="<?= $d['id'] ?>" <?= $dept==$d['id']?'selected':'' ?>><?= e($d['name']) ?></option>
      <?php endforeach; ?></select></div>
  <div class="form-group"><label>Status</label>
    <select name="status"><option value="">All</option>
      <?php foreach (['Active','Inactive','Resigned','Terminated'] as $s): ?>
      <option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= $s ?></option>
      <?php endforeach; ?></select></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>

<div class="card">
  <div class="table-wrap">
    <table class="data">
      <thead><tr><th>Employee</th><th>Department</th><th>Designation</th><th>Mobile</th>
        <th class="num">Basic</th><th>Status</th><th></th></tr></thead>
      <tbody>
      <?php if (!$rows): ?>
        <tr><td colspan="7" class="empty">No employees found.</td></tr>
      <?php else: foreach ($rows as $r):
        $pill = ['Active'=>'pill-success','Inactive'=>'pill-muted','Resigned'=>'pill-warning','Terminated'=>'pill-danger'][$r['status']] ?? 'pill-muted'; ?>
        <tr>
          <td><div class="flex items-center gap">
            <div class="avatar"><?php if($r['photo']): ?><img src="<?= url('uploads/'.$r['photo']) ?>" alt=""><?php else: ?><?= e(strtoupper(substr($r['full_name'],0,1))) ?><?php endif; ?></div>
            <div><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?> · <?= e($r['email']) ?></div></div>
          </div></td>
          <td><?= e($r['dept_name'] ?: '—') ?></td>
          <td><?= e($r['desig_name'] ?: '—') ?></td>
          <td><?= e($r['mobile'] ?: '—') ?></td>
          <td class="num"><?= money($r['basic_salary']) ?></td>
          <td><span class="pill <?= $pill ?>"><?= e($r['status']) ?></span></td>
          <td class="text-right">
            <a class="btn btn-sm btn-outline" href="<?= url('admin/employee_view.php?id='.$r['id']) ?>">View</a>
            <?php if (has_perm('employees.edit')): ?>
            <a class="btn btn-sm" href="<?= url('admin/employee_edit.php?id='.$r['id']) ?>">Edit</a>
            <?php endif; ?>
          </td>
        </tr>
      <?php endforeach; endif; ?>
      </tbody>
    </table>
  </div>
</div>

<?php if ($pages > 1): ?>
<div class="flex gap mt-2" style="justify-content:center">
  <?php for ($p=1;$p<=$pages;$p++): $qs=http_build_query(array_merge($_GET,['page'=>$p])); ?>
    <a class="btn btn-sm <?= $p==$page?'':'btn-outline' ?>" href="?<?= e($qs) ?>"><?= $p ?></a>
  <?php endfor; ?>
</div>
<?php endif; ?>

<?php require __DIR__ . '/../templates/footer.php'; ?>
