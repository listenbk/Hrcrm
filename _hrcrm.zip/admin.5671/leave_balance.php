<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('leaves.view');
$year=(int)param('year',date('Y'));
$emps=fetch_all("SELECT id,emp_code,full_name FROM employees WHERE status='Active' ORDER BY full_name");
$types=fetch_all("SELECT * FROM leave_types WHERE is_active=1 ORDER BY name");
// balances map
$bal=[];
foreach(fetch_all("SELECT * FROM leave_balances WHERE year=?",[$year]) as $b){ $bal[$b['employee_id']][$b['leave_type_id']]=$b; }
$pageTitle='Leave Balance'; $activeNav='leave_bal';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Leave Balance — <?= $year ?></h2></div>
  <form method="get"><input type="number" name="year" value="<?= $year ?>" onchange="this.form.submit()" style="width:110px"></form></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th>
    <?php foreach($types as $t): ?><th style="text-align:center"><?= e($t['name']) ?></th><?php endforeach; ?>
  </tr></thead>
  <tbody><?php foreach($emps as $em): ?>
    <tr><td><b><?= e($em['full_name']) ?></b> <span class="text-muted">(<?= e($em['emp_code']) ?>)</span></td>
      <?php foreach($types as $t): $b=$bal[$em['id']][$t['id']]??null;
        $ent=(float)($b['entitlement']??$t['annual_quota']); $used=(float)($b['used']??0); $rem=$ent-$used; ?>
        <td class="text-center"><b><?= rtrim(rtrim(number_format($rem,1),'0'),'.') ?></b>
          <div class="text-muted" style="font-size:11px"><?= rtrim(rtrim(number_format($used,1),'0'),'.') ?> used / <?= rtrim(rtrim(number_format($ent,1),'0'),'.') ?></div></td>
      <?php endforeach; ?>
    </tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<p class="help mt-2">Remaining = Entitlement − Used. Entitlement defaults to each leave type's annual quota until adjusted per employee.</p>
<?php require __DIR__ . '/../templates/footer.php'; ?>
