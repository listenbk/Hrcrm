<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('config.salary_components');   // Super Admin configuration
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='save') {
        $id=(int)param('id',0,'POST'); $name=trim((string)param('name','','POST'));
        $type=param('type','earning','POST')==='deduction'?'deduction':'earning';
        $calc=param('calc_type','fixed','POST')==='percentage'?'percentage':'fixed';
        $amt=(float)param('default_amount',0,'POST');
        $recurring=param('is_recurring',0,'POST')?1:0; $active=param('is_active',0,'POST')?1:0;
        if ($name!=='') {
            if ($id) q("UPDATE salary_components SET name=?,type=?,calc_type=?,default_amount=?,is_recurring=?,is_active=? WHERE id=?",[$name,$type,$calc,$amt,$recurring,$active,$id]);
            else     q("INSERT INTO salary_components (name,slug,type,calc_type,default_amount,is_recurring,is_active) VALUES (?,?,?,?,?,?,?)",[$name,slugify($name).'_'.substr(md5($name.microtime()),0,4),$type,$calc,$amt,$recurring,$active]);
            flash_success('Component saved.');
        }
    } elseif ($act==='delete') { q("DELETE FROM salary_components WHERE id=?",[(int)param('id',0,'POST')]); flash_success('Deleted.'); }
    redirect('admin/salary_components.php');
}
$rows=fetch_all("SELECT * FROM salary_components ORDER BY type DESC, sort_order, name");
$pageTitle='Salary Components'; $activeNav='components';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Salary Components</h2>
  <div class="breadcrumb">Customizable earnings &amp; deductions — no code changes needed.</div></div>
  <button class="btn" data-modal="scModal" onclick="scForm()">➕ Add Component</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Name</th><th>Type</th><th>Calculation</th><th class="num">Default</th><th>Recurring</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><b><?= e($r['name']) ?></b></td>
    <td><span class="pill <?= $r['type']==='earning'?'pill-success':'pill-danger' ?>"><?= ucfirst($r['type']) ?></span></td>
    <td><?= $r['calc_type']==='percentage'?'% of Basic':'Fixed' ?></td>
    <td class="num"><?= $r['calc_type']==='percentage'?e($r['default_amount']).'%':money($r['default_amount']) ?></td>
    <td><?= $r['is_recurring']?'Yes':'One-time' ?></td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Inactive' ?></span></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="scModal" onclick='scForm(<?= json_encode($r) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<div class="modal-overlay" id="scModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="scTitle">Add Component</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="sc_id">
    <div class="form-group"><label>Name <span class="req">*</span></label><input type="text" name="name" id="sc_name" required></div>
    <div class="form-row">
      <div class="form-group"><label>Type</label><select name="type" id="sc_type"><option value="earning">Earning</option><option value="deduction">Deduction</option></select></div>
      <div class="form-group"><label>Calculation</label><select name="calc_type" id="sc_calc"><option value="fixed">Fixed amount</option><option value="percentage">% of Basic</option></select></div>
    </div>
    <div class="form-group"><label>Default Amount / %</label><input type="number" step="0.01" name="default_amount" id="sc_amt" value="0"></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_recurring" id="sc_rec" checked> Recurring (auto-added every payroll)</label></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="sc_act" checked> Active</label></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function scForm(d){d=d||{};scTitle.textContent=d.id?'Edit Component':'Add Component';
  sc_id.value=d.id||'';sc_name.value=d.name||'';sc_type.value=d.type||'earning';sc_calc.value=d.calc_type||'fixed';
  sc_amt.value=d.default_amount||0;sc_rec.checked=d.id?d.is_recurring==1:true;sc_act.checked=d.id?d.is_active==1:true;}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
