<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('geofence.manage');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');

    if ($act === 'save_location') {
        $lid  = (int)param('id', 0, 'POST');
        $name = trim((string)param('location_name', '', 'POST'));
        $lat  = param('latitude', '', 'POST');
        $lng  = param('longitude', '', 'POST');
        $rad  = (int)param('radius', 100, 'POST');
        $st   = param('status', 0, 'POST') ? 1 : 0;
        $eIn  = param('enforce_check_in', 0, 'POST') ? 1 : 0;
        $eOut = param('enforce_check_out', 0, 'POST') ? 1 : 0;
        $eOt  = param('enforce_ot', 0, 'POST') ? 1 : 0;
        $errs = [];
        if ($name === '') $errs[] = 'Location name is required.';
        if (!is_numeric($lat) || (float)$lat < -90 || (float)$lat > 90) $errs[] = 'Latitude must be between -90 and 90.';
        if (!is_numeric($lng) || (float)$lng < -180 || (float)$lng > 180) $errs[] = 'Longitude must be between -180 and 180.';
        if ($rad < 10 || $rad > 5000) $errs[] = 'Radius must be between 10 and 5000 metres.';
        $dup = (int)fetch_col("SELECT COUNT(*) FROM geofence_locations WHERE location_name=? AND id<>?", [$name, $lid]);
        if ($dup) $errs[] = 'A location with this name already exists.';
        if ($errs) {
            flash_error(implode(' ', $errs));
        } elseif ($lid) {
            q("UPDATE geofence_locations SET location_name=?, latitude=?, longitude=?, radius=?, status=?,
                 enforce_check_in=?, enforce_check_out=?, enforce_ot=? WHERE id=?",
              [$name, (float)$lat, (float)$lng, $rad, $st, $eIn, $eOut, $eOt, $lid]);
            audit_log('geofence_location_edited', 'geofence', $lid, "Edited site {$name} ({$rad}m)");
            flash_success('Location updated.');
        } else {
            q("INSERT INTO geofence_locations (location_name, latitude, longitude, radius, status, enforce_check_in, enforce_check_out, enforce_ot) VALUES (?,?,?,?,?,?,?,?)",
              [$name, (float)$lat, (float)$lng, $rad, $st, $eIn, $eOut, $eOt]);
            audit_log('geofence_location_created', 'geofence', insert_id(), "Created site {$name} ({$rad}m)");
            flash_success('Location added.');
        }
    } elseif ($act === 'save_settings') {
        set_setting('geofence_enabled',   param('geofence_enabled', 0, 'POST') ? '1' : '0');
        set_setting('geofence_check_in',  param('geofence_check_in', 0, 'POST') ? '1' : '0');
        set_setting('geofence_check_out', param('geofence_check_out', 0, 'POST') ? '1' : '0');
        set_setting('geofence_ot',        param('geofence_ot', 0, 'POST') ? '1' : '0');
        $maxAcc = max(10, min(1000, (int)param('geofence_max_accuracy', 100, 'POST')));
        set_setting('geofence_max_accuracy', (string)$maxAcc);
        audit_log('geofence_settings_updated', 'settings', null, 'Updated geofence settings');
        flash_success('Geofence settings saved.');
    } elseif ($act === 'assign_exempt') {
        // Quick exemption toggle for an employee.
        $eid = (int)param('employee_id', 0, 'POST');
        q("UPDATE employees SET geofence_exempt=? WHERE id=?", [param('exempt', 0, 'POST') ? 1 : 0, $eid]);
        audit_log('geofence_exempt_changed', 'employee', $eid, 'Changed geofence exemption');
        flash_success('Exemption updated.');
    }
    redirect('admin/geofence.php');
}

// CSV export of the check-in / check-out location log (for HR / Excel).
if (param('export', '') === 'csv') {
    $from = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)param('from','')) ? param('from') : date('Y-m-01');
    $to   = preg_match('/^\d{4}-\d{2}-\d{2}$/', (string)param('to',''))   ? param('to')   : date('Y-m-d');
    $rows = fetch_all(
      "SELECT e.emp_code, e.full_name, a.att_date, a.check_in, a.check_out,
              g.location_name, a.checkin_latitude, a.checkin_longitude, a.checkin_accuracy,
              a.checkin_distance_m, a.checkin_geofence_status,
              a.checkout_latitude, a.checkout_longitude, a.checkout_accuracy,
              a.checkout_distance_m, a.checkout_geofence_status
       FROM attendance a
       JOIN employees e ON e.id=a.employee_id
       LEFT JOIN geofence_locations g ON g.id=a.geofence_location_id
       WHERE a.att_date BETWEEN ? AND ?
       ORDER BY a.att_date DESC, e.full_name", [$from, $to]);
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="geofence_attendance_'.$from.'_to_'.$to.'.csv"');
    $out = fopen('php://output', 'w');
    fputcsv($out, ['Employee ID','Employee','Date','Check-In','Check-Out','Site',
                   'Check-In Lat','Check-In Lng','Check-In Accuracy (m)','Check-In Distance (m)','Check-In Status',
                   'Check-Out Lat','Check-Out Lng','Check-Out Accuracy (m)','Check-Out Distance (m)','Check-Out Status']);
    foreach ($rows as $r) {
        fputcsv($out, [$r['emp_code'], $r['full_name'], $r['att_date'], $r['check_in'], $r['check_out'], $r['location_name'],
                       $r['checkin_latitude'], $r['checkin_longitude'], $r['checkin_accuracy'], $r['checkin_distance_m'], $r['checkin_geofence_status'],
                       $r['checkout_latitude'], $r['checkout_longitude'], $r['checkout_accuracy'], $r['checkout_distance_m'], $r['checkout_geofence_status']]);
    }
    fclose($out);
    exit;
}

$locations = fetch_all(
  "SELECT g.*, (SELECT COUNT(*) FROM employees e WHERE e.geofence_location_id=g.id AND e.status='Active') AS staff
   FROM geofence_locations g ORDER BY g.status DESC, g.location_name");
$exempt = fetch_all(
  "SELECT id, emp_code, full_name, geofence_exempt FROM employees
   WHERE status='Active' AND is_staff=0 AND geofence_exempt=1 ORDER BY full_name");
$rejected = fetch_all(
  "SELECT a.created_at, a.description, u.name AS user_name FROM audit_logs a
   LEFT JOIN users u ON u.id=a.user_id WHERE a.action='geofence_rejected'
   ORDER BY a.created_at DESC LIMIT 50");
$rejectedToday = (int)fetch_col("SELECT COUNT(*) FROM audit_logs WHERE action='geofence_rejected' AND DATE(created_at)=CURDATE()");

$enabled = geofence_enabled();
$pageTitle='Geofence & Sites'; $activeNav='geofence';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Geofence &amp; Attendance Sites</h2>
  <div class="breadcrumb">Check-in and check-out are allowed only within each site's radius.
    Status: <span class="pill <?= $enabled?'pill-success':'pill-muted' ?>"><?= $enabled?'ON':'OFF (no enforcement)' ?></span></div></div>
  <button class="btn" data-modal="locModal" onclick="locForm()">➕ Add Site</button></div>

<div class="grid cols-2 mb-2">
  <div class="card"><div class="card-head"><h3>⚙️ Enforcement</h3></div><div class="card-body">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="save_settings">
      <div class="form-group"><label class="switch"><input type="checkbox" name="geofence_enabled" value="1" <?= $enabled?'checked':'' ?>> Enable geofence (master switch)</label>
        <div class="help">Keep OFF until sites are set up and checked. When OFF, nothing changes for employees.</div></div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="geofence_check_in" value="1" <?= setting('geofence_check_in','1')==='1'?'checked':'' ?>> Enforce on Check-In</label></div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="geofence_check_out" value="1" <?= setting('geofence_check_out','1')==='1'?'checked':'' ?>> Enforce on Check-Out</label></div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="geofence_ot" value="1" <?= setting('geofence_ot','1')==='1'?'checked':'' ?>> Enforce on Overtime Check-In/Out</label></div>
      <div class="form-group"><label>Max GPS error (metres)</label>
        <input type="number" name="geofence_max_accuracy" min="10" max="1000" value="<?= e(setting('geofence_max_accuracy','100')) ?>">
        <div class="help">Readings less precise than this are rejected. 50–100m is typical.</div></div>
      <button class="btn">💾 Save Settings</button>
    </form>
  </div></div>

  <div class="card"><div class="card-head"><h3>📊 Rejected attempts</h3><span class="pill pill-danger">Today: <?= $rejectedToday ?></span></div>
  <div class="table-wrap" style="max-height:330px;overflow:auto"><table class="data">
    <thead><tr><th>When</th><th>Details</th></tr></thead>
    <tbody><?php foreach($rejected as $r): ?>
      <tr><td class="text-muted" style="white-space:nowrap"><?= fmt_date($r['created_at'],'d M h:i A') ?></td>
        <td><?= e($r['description']) ?></td></tr>
    <?php endforeach; if(!$rejected): ?><tr><td colspan="2" class="empty">No rejected attempts yet.</td></tr><?php endif; ?></tbody>
  </table></div></div>
</div>

<div class="card mb-2"><div class="card-head"><h3>📍 Sites</h3>
  <form method="get" class="flex gap" style="align-items:center">
    <input type="hidden" name="export" value="csv">
    <input type="date" name="from" value="<?= date('Y-m-01') ?>" aria-label="From">
    <input type="date" name="to" value="<?= date('Y-m-d') ?>" aria-label="To">
    <button class="btn btn-sm btn-outline">⬇️ Export Location Log (CSV)</button>
  </form></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Site</th><th>Latitude</th><th>Longitude</th><th class="num">Radius</th><th>Staff</th><th>Enforced</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($locations as $l): ?>
    <tr>
      <td><b><?= e($l['location_name']) ?></b></td>
      <td><?= e($l['latitude']) ?></td><td><?= e($l['longitude']) ?></td>
      <td class="num"><?= (int)$l['radius'] ?> m</td>
      <td><?= (int)$l['staff'] ?> assigned</td>
      <td style="font-size:12px"><?= $l['enforce_check_in']?'In ':'' ?><?= $l['enforce_check_out']?'Out ':'' ?><?= $l['enforce_ot']?'OT':'' ?></td>
      <td><span class="pill <?= $l['status']?'pill-success':'pill-muted' ?>"><?= $l['status']?'Active':'Inactive' ?></span></td>
      <td class="text-right"><button class="btn btn-sm btn-outline" data-modal="locModal"
        onclick='locForm(<?= json_encode(["id"=>$l["id"],"name"=>$l["location_name"],"lat"=>$l["latitude"],"lng"=>$l["longitude"],"radius"=>$l["radius"],"status"=>$l["status"],"eIn"=>$l["enforce_check_in"],"eOut"=>$l["enforce_check_out"],"eOt"=>$l["enforce_ot"]]) ?>)'>Edit</button></td>
    </tr>
  <?php endforeach; if(!$locations): ?><tr><td colspan="8" class="empty">No sites yet. Add your office and site locations.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="card mb-2"><div class="card-head"><h3>🛡️ Geofence-exempt employees</h3></div><div class="card-body">
  <?php if($exempt): ?>
    <p class="text-muted">These employees can check in from anywhere (e.g. roaming field staff).</p>
    <?php foreach($exempt as $x): ?>
      <form method="post" style="display:inline-block;margin:4px"><?= csrf_field() ?>
        <input type="hidden" name="do" value="assign_exempt"><input type="hidden" name="employee_id" value="<?= $x['id'] ?>"><input type="hidden" name="exempt" value="0">
        <span class="pill pill-info"><?= e($x['full_name']) ?> (<?= e($x['emp_code']) ?>)</span>
        <button class="btn btn-sm btn-outline">Remove exemption</button></form>
    <?php endforeach; else: ?><p class="text-muted">No exempt employees. Mark exemptions from Employee → Edit.</p><?php endif; ?>
</div></div>

<div class="modal-overlay" id="locModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="locTitle">Add Site</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save_location"><input type="hidden" name="id" id="loc_id">
    <div class="form-group"><label>Site Name <span class="req">*</span></label><input type="text" name="location_name" id="loc_name" required placeholder="e.g. RG Realty Main Office"></div>
    <div class="form-row">
      <div class="form-group"><label>Latitude <span class="req">*</span></label><input type="text" name="latitude" id="loc_lat" required placeholder="19.0760000"></div>
      <div class="form-group"><label>Longitude <span class="req">*</span></label><input type="text" name="longitude" id="loc_lng" required placeholder="72.8777000"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Allowed Radius (metres)</label><input type="number" name="radius" id="loc_rad" min="10" max="5000" value="100"></div>
      <div class="form-group"><label class="switch" style="margin-top:28px"><input type="checkbox" name="status" id="loc_status" value="1" checked> Active</label></div>
    </div>
    <div class="form-group"><label>Enforce at this site</label>
      <div class="form-row-3">
        <label class="switch"><input type="checkbox" name="enforce_check_in" id="loc_eIn" value="1" checked> Check-In</label>
        <label class="switch"><input type="checkbox" name="enforce_check_out" id="loc_eOut" value="1" checked> Check-Out</label>
        <label class="switch"><input type="checkbox" name="enforce_ot" id="loc_eOt" value="1" checked> Overtime</label>
      </div></div>
    <div class="help">Tip: in Google Maps, right-click the exact spot and click the coordinates to copy them.</div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save Site</button></div>
</form></div></div>
<script>
function locForm(l){l=l||{};
  document.getElementById('locTitle').textContent=l.id?'Edit Site':'Add Site';
  document.getElementById('loc_id').value=l.id||'';
  document.getElementById('loc_name').value=l.name||'';
  document.getElementById('loc_lat').value=l.lat||'';
  document.getElementById('loc_lng').value=l.lng||'';
  document.getElementById('loc_rad').value=l.radius||100;
  document.getElementById('loc_status').checked=l.id?l.status==1:true;
  document.getElementById('loc_eIn').checked=l.id?l.eIn==1:true;
  document.getElementById('loc_eOut').checked=l.id?l.eOut==1:true;
  document.getElementById('loc_eOt').checked=l.id?l.eOt==1:true;
}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
