<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('employees.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!is_admin()) { http_response_code(403); exit; }
    $act = param('do', '', 'POST');
    if ($act === 'save') {
        $did = (int)param('id', 0, 'POST');
        $name = trim((string)param('name', '', 'POST'));
        $dept = param('department_id', null, 'POST') ?: null;
        $active = param('is_active', 0, 'POST') ? 1 : 0;
        if ($name !== '') {
            if ($did) q("UPDATE designations SET name=?,department_id=?,is_active=? WHERE id=?", [$name,$dept,$active,$did]);
            else      q("INSERT INTO designations (name,department_id,is_active) VALUES (?,?,?)", [$name,$dept,$active]);
            flash_success('Designation saved.');
        }
    } elseif ($act === 'delete') {
        q("DELETE FROM designations WHERE id=?", [(int)param('id',0,'POST')]);
        flash_success('Designation deleted.');
    }
    redirect('admin/designations.php');
}
$depts = fetch_all("SELECT id,name FROM departments ORDER BY name");
$rows = fetch_all("SELECT ds.*, d.name AS dept_name FROM designations ds LEFT JOIN departments d ON d.id=ds.department_id ORDER BY ds.name");
$pageTitle='Designations'; $activeNav='designations';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Designations</h2></div>
  <button class="btn" data-modal="desigModal" onclick="desigForm()">➕ Add Designation</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Name</th><th>Department</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach ($rows as $r): ?>
    <tr><td><b><?= e($r['name']) ?></b></td><td><?= e($r['dept_name'] ?: '—') ?></td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Inactive' ?></span></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="desigModal" onclick='desigForm(<?= json_encode($r) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete?"><?= csrf_field() ?>
        <input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
        <button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="4" class="empty">No designations.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="desigModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="desigTitle">Add Designation</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="desig_id">
    <div class="form-group"><label>Name <span class="req">*</span></label><input type="text" name="name" id="desig_name" required></div>
    <div class="form-group"><label>Department</label><select name="department_id" id="desig_dept"><option value="">—</option>
      <?php foreach ($depts as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="desig_active" checked> Active</label></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>
function desigForm(d){d=d||{};
  document.getElementById('desigTitle').textContent=d.id?'Edit Designation':'Add Designation';
  document.getElementById('desig_id').value=d.id||'';
  document.getElementById('desig_name').value=d.name||'';
  document.getElementById('desig_dept').value=d.department_id||'';
  document.getElementById('desig_active').checked=d.id?d.is_active==1:true;
}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
