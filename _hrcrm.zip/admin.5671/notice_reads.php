<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('notices.manage');
$me = current_user();
$id = (int)param('id', 0);
$n = fetch_one("SELECT n.*, u.name AS creator FROM notices n LEFT JOIN users u ON u.id=n.created_by WHERE n.id=?", [$id]);
if (!$n) { flash_error('Notice not found.'); redirect('admin/notices.php'); }
if (!is_super_admin() && (int)$n['created_by'] !== (int)$me['id']) {
    flash_error('You can only view read-status of your own notices.'); redirect('admin/notices.php');
}

$audience = notice_audience_user_ids($n);
$readAt = [];
if ($audience) {
    $in = implode(',', array_fill(0, count($audience), '?'));
    foreach (fetch_all("SELECT user_id, read_at FROM notice_reads WHERE notice_id=? AND user_id IN ($in)",
             array_merge([$id], $audience)) as $r) {
        $readAt[(int)$r['user_id']] = $r['read_at'];
    }
}
$users = [];
if ($audience) {
    $in = implode(',', array_fill(0, count($audience), '?'));
    foreach (fetch_all("SELECT u.id, u.name, r.name AS role_name FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id IN ($in) ORDER BY u.name", $audience) as $us) {
        $users[] = $us;
    }
}
$readCount = count($readAt);
$total = count($users);

$pageTitle = 'Notice Reads'; $activeNav = 'notices_manage';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Read Status — <?= e($n['title']) ?></h2>
  <div class="breadcrumb"><a href="<?= url('admin/notices.php') ?>">Notices</a> / Read tracking · <?= e(notice_audience_label($n)) ?></div></div></div>

<div class="grid cols-3 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-slate">👥</div><div><div class="label">Audience</div><div class="value"><?= $total ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div><div><div class="label">Read</div><div class="value"><?= $readCount ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">📭</div><div><div class="label">Not Read</div><div class="value"><?= $total-$readCount ?></div></div></div></div>
</div>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>User</th><th>Role</th><th>Status</th><th>Read At</th></tr></thead>
  <tbody><?php foreach($users as $us): $read = isset($readAt[(int)$us['id']]); ?>
    <tr><td><b><?= e($us['name']) ?></b></td><td><span class="pill pill-info"><?= e($us['role_name']) ?></span></td>
    <td><?= $read?'<span class="pill pill-success">Read</span>':'<span class="pill pill-danger">Not read</span>' ?></td>
    <td class="text-muted"><?= $read?fmt_date($readAt[(int)$us['id']],'d M Y h:i A'):'—' ?></td></tr>
  <?php endforeach; if(!$users): ?><tr><td colspan="4" class="empty">This audience has no login users.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
