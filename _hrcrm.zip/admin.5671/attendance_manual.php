<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('attendance.manual');

$empId = (int)param('employee', 0);
$date  = (string)param('date', date('Y-m-d'));

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $empId = (int)param('employee_id', 0, 'POST');
    $date  = (string)param('att_date', date('Y-m-d'), 'POST');
    $statusId = (int)param('status_id', 0, 'POST') ?: null;
    $checkIn  = trim((string)param('check_in','','POST'));
    $checkOut = trim((string)param('check_out','','POST'));
    $reason   = trim((string)param('reason','','POST'));
    $adminRemark = trim((string)param('admin_remark','','POST'));
    $earlyStatus = param('early_status','','POST') ?: null;
    $locked = param('is_locked',0,'POST') ? 1 : 0;

    $emp = fetch_one("SELECT * FROM employees WHERE id=?", [$empId]);
    if (!$emp) { flash_error('Select a valid employee.'); redirect('admin/attendance_manual.php'); }

    // Staff (HR / Team Leader) attendance may only be corrected by the Manager,
    // and requires the Manager's own password — HR cannot edit its own attendance.
    if ($emp['is_staff']) {
        if (!is_super_admin()) {
            flash_error('Only the Manager can correct HR / Team-Leader attendance.');
            redirect("admin/attendance_manual.php?employee=$empId&date=$date");
        }
        if (!verify_current_password((string)param('confirm_password','','POST'))) {
            flash_error('Incorrect Manager password — attendance not changed.');
            redirect("admin/attendance_manual.php?employee=$empId&date=$date");
        }
    }

    $ciDt = $checkIn  ? "$date $checkIn:00" : null;
    $coDt = $checkOut ? "$date $checkOut:00" : null;
    $workMin = 0; $lateMin = 0; $earlyMin = 0;
    [$officeIn,$officeOut] = office_times($date);
    if ($ciDt) {
        $grace = (int)setting('grace_minutes',10);
        $ci = new DateTime($ciDt);
        $graceLimit=(clone $officeIn)->modify("+$grace minutes");
        if ($ci > $graceLimit) $lateMin = (int)round(($ci->getTimestamp()-$officeIn->getTimestamp())/60);
    }
    if ($ciDt && $coDt) {
        $co=new DateTime($coDt); $ci=new DateTime($ciDt);
        $workMin = max(0,(int)round(($co->getTimestamp()-$ci->getTimestamp())/60));
        if ($co < $officeOut) $earlyMin=(int)round(($officeOut->getTimestamp()-$co->getTimestamp())/60);
    }

    $old = fetch_one("SELECT * FROM attendance WHERE employee_id=? AND att_date=?", [$empId,$date]);
    if ($old && $old['is_locked'] && !is_super_admin()) {
        flash_error('This attendance is locked. Only a Super Admin can modify it.');
        redirect("admin/attendance_manual.php?employee=$empId&date=$date");
    }

    if ($old) {
        q("UPDATE attendance SET check_in=?,check_out=?,status_id=?,working_minutes=?,late_minutes=?,early_minutes=?,
             early_status=?,admin_remark=?,is_locked=?,is_manual=1 WHERE id=?",
          [$ciDt,$coDt,$statusId,$workMin,$lateMin,$earlyMin,$earlyStatus,$adminRemark,$locked,$old['id']]);
        $attId=$old['id'];
    } else {
        q("INSERT INTO attendance (employee_id,att_date,check_in,check_out,status_id,working_minutes,late_minutes,
             early_minutes,early_status,admin_remark,is_locked,is_manual)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,1)",
          [$empId,$date,$ciDt,$coDt,$statusId,$workMin,$lateMin,$earlyMin,$earlyStatus,$adminRemark,$locked]);
        $attId=insert_id();
    }
    $new = fetch_one("SELECT * FROM attendance WHERE id=?", [$attId]);
    q("INSERT INTO attendance_audit (attendance_id,employee_id,att_date,old_value,new_value,reason,changed_by)
       VALUES (?,?,?,?,?,?,?)",
      [$attId,$empId,$date, $old?json_encode($old):null, json_encode($new), $reason, current_user()['id']]);
    audit_log('attendance_modified','attendance',$attId,"Manual edit {$emp['full_name']} {$date}",$old,$new);
    flash_success('Attendance saved.');
    redirect("admin/attendance_manual.php?employee=$empId&date=$date");
}

// HR only sees regular employees; the Manager also sees staff (HR/TL) profiles.
$staffFilter = is_super_admin() ? '' : ' AND is_staff=0';
$emps = fetch_all("SELECT id,emp_code,full_name,is_staff FROM employees WHERE status='Active'$staffFilter ORDER BY is_staff, full_name");
$statuses = att_statuses_active();
$selEmp = ($empId) ? fetch_one("SELECT is_staff, full_name FROM employees WHERE id=?", [$empId]) : null;
$current = ($empId) ? fetch_one("SELECT * FROM attendance WHERE employee_id=? AND att_date=?", [$empId,$date]) : null;
$history = ($empId) ? fetch_all(
   "SELECT aa.*, u.name AS by_name FROM attendance_audit aa LEFT JOIN users u ON u.id=aa.changed_by
    WHERE aa.employee_id=? AND aa.att_date=? ORDER BY aa.created_at DESC", [$empId,$date]) : [];

$pageTitle='Manual Attendance'; $activeNav='att_manual';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Manual Attendance Editor</h2>
  <div class="breadcrumb">Add or correct check-in/out, mark status, lock finalized records.</div></div></div>

<form method="get" class="filters">
  <div class="form-group"><label>Employee</label><select name="employee" onchange="this.form.submit()">
    <option value="0">— Select —</option>
    <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>" <?= $empId==$em['id']?'selected':'' ?>><?= e($em['full_name'].' ('.$em['emp_code'].')'.($em['is_staff']?' — Staff':'')) ?></option><?php endforeach; ?>
  </select></div>
  <div class="form-group"><label>Date</label><input type="date" name="date" value="<?= e($date) ?>" onchange="this.form.submit()"></div>
</form>

<?php if ($empId): ?>
<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>Edit Attendance</h3>
    <?php if($current && $current['is_locked']): ?><span class="pill pill-danger">🔒 Locked</span><?php endif; ?></div>
    <div class="card-body"><form method="post">
      <?= csrf_field() ?>
      <input type="hidden" name="employee_id" value="<?= $empId ?>">
      <input type="hidden" name="att_date" value="<?= e($date) ?>">
      <div class="form-row">
        <div class="form-group"><label>Check In</label>
          <input type="time" name="check_in" value="<?= $current&&$current['check_in']?date('H:i',strtotime($current['check_in'])):'' ?>"></div>
        <div class="form-group"><label>Check Out</label>
          <input type="time" name="check_out" value="<?= $current&&$current['check_out']?date('H:i',strtotime($current['check_out'])):'' ?>"></div>
      </div>
      <div class="form-group"><label>Status</label><select name="status_id">
        <option value="">— Auto —</option>
        <?php foreach($statuses as $s): ?><option value="<?= $s['id'] ?>" <?= ($current['status_id']??'')==$s['id']?'selected':'' ?>><?= e($s['name']) ?></option><?php endforeach; ?>
      </select></div>
      <div class="form-group"><label>Early-Leave Status</label><select name="early_status">
        <option value="">—</option>
        <?php foreach(['Pending','Approved','Rejected'] as $es): ?><option <?= ($current['early_status']??'')===$es?'selected':'' ?>><?= $es ?></option><?php endforeach; ?>
      </select></div>
      <div class="form-group"><label>Admin Remark</label><input type="text" name="admin_remark" value="<?= e($current['admin_remark'] ?? '') ?>"></div>
      <div class="form-group"><label>Reason for Change <span class="req">*</span></label><input type="text" name="reason" required placeholder="e.g. Missed check-out correction"></div>
      <?php if (!empty($selEmp['is_staff'])): ?>
      <div class="form-group"><label>Confirm with your Manager password <span class="req">*</span></label>
        <div class="pwd-wrap"><input type="password" name="confirm_password" required autocomplete="off" placeholder="Your own password">
        <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div>
        <div class="help">Correcting HR / Team-Leader attendance requires your password.</div></div>
      <?php endif; ?>
      <div class="form-group"><label class="switch"><input type="checkbox" name="is_locked" value="1" <?= ($current['is_locked']??0)?'checked':'' ?>> 🔒 Lock this attendance (finalize)</label></div>
      <button class="btn">💾 Save Attendance</button>
    </form></div>
  </div>

  <div class="card"><div class="card-head"><h3>Change Audit Log</h3></div>
    <div class="card-body">
      <?php if(!$history): ?><div class="empty">No manual changes recorded.</div><?php else: foreach($history as $h):
        $ov=json_decode($h['old_value']??'null',true); $nv=json_decode($h['new_value']??'null',true); ?>
        <div style="border:1px solid var(--border);border-radius:8px;padding:12px;margin-bottom:10px">
          <div class="flex between"><b><?= e($h['by_name'] ?: 'System') ?></b><span class="text-muted"><?= fmt_date($h['created_at'],'d M Y h:i A') ?></span></div>
          <div class="text-muted" style="font-size:12px;margin:4px 0"><?= e($h['reason'] ?: '') ?></div>
          <div style="font-size:12px">
            <span class="text-muted">In:</span> <?= $ov['check_in']??'—' ?> → <b><?= $nv['check_in']??'—' ?></b> &nbsp;
            <span class="text-muted">Out:</span> <?= $ov['check_out']??'—' ?> → <b><?= $nv['check_out']??'—' ?></b>
          </div>
        </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
<?php else: ?>
  <div class="card"><div class="empty">Select an employee and date to edit attendance.</div></div>
<?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
