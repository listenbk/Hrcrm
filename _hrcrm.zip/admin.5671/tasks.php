<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('tasks.manage');
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    if ($act === 'save') {
        $tid    = (int)param('id', 0, 'POST');
        $title  = trim((string)param('title', '', 'POST'));
        $empId  = (int)param('assigned_to', 0, 'POST');
        $desc   = trim((string)param('description', '', 'POST'));
        $prio   = in_array(param('priority','Medium','POST'), task_priorities(), true) ? param('priority','Medium','POST') : 'Medium';
        $assign = param('assign_date', date('Y-m-d'), 'POST') ?: date('Y-m-d');
        $due    = param('due_date', '', 'POST') ?: null;
        $remark = trim((string)param('admin_remark', '', 'POST'));
        $status = in_array(param('status','Pending','POST'), task_statuses(), true) ? param('status','Pending','POST') : 'Pending';

        // Validate the target employee exists and is not resigned/terminated.
        $emp = $empId ? fetch_one("SELECT id, full_name, user_id FROM employees WHERE id=? AND (status IS NULL OR status NOT IN ('Resigned','Terminated'))", [$empId]) : null;
        if ($title === '' || !$emp) {
            flash_error('A task title and a valid employee are required.');
        } else {
            if ($tid) {
                q("UPDATE tasks SET title=?, description=?, priority=?, status=?, assigned_to=?, assign_date=?, due_date=?, admin_remark=?,
                     completed_at=IF(status='Completed' AND completed_at IS NULL, NOW(), IF(status<>'Completed', NULL, completed_at)) WHERE id=?",
                  [$title,$desc,$prio,$status,$emp['id'],$assign,$due,$remark,$tid]);
                audit_log('task_updated','task',$tid,"Updated task: {$title}");
                flash_success('Task updated.');
            } else {
                q("INSERT INTO tasks (title,description,priority,status,assigned_to,assigned_by,assign_date,due_date,admin_remark)
                   VALUES (?,?,?,?,?,?,?,?,?)",
                  [$title,$desc,$prio,$status,$emp['id'],(int)$me['id'],$assign,$due,$remark]);
                $tid = (int)insert_id();
                audit_log('task_assigned','task',$tid,"Assigned '{$title}' to {$emp['full_name']}");
                if (!empty($emp['user_id'])) {
                    notify((int)$emp['user_id'],'task_assigned','New task assigned',
                        "You have a new task: {$title}".($due?" (due ".fmt_date($due).")":'').".", url('employee/tasks.php'));
                }
                flash_success("Task assigned to {$emp['full_name']}.");
            }
        }
    } elseif ($act === 'delete') {
        $tid = (int)param('id', 0, 'POST');
        q("DELETE FROM tasks WHERE id=?", [$tid]);
        audit_log('task_deleted','task',$tid,'Deleted task');
        flash_success('Task deleted.');
    }
    $qs = http_build_query(array_intersect_key($_GET, array_flip(['emp','status','priority','from','to'])));
    redirect('admin/tasks.php'.($qs?('?'.$qs):''));
}

// Filters
$fEmp    = (int)param('emp', 0);
$fStatus = (string)param('status', '');
$fPrio   = (string)param('priority', '');
$fFrom   = (string)param('from', '');
$fTo     = (string)param('to', '');

$where = []; $args = [];
if ($fEmp > 0)      { $where[] = "t.assigned_to = ?"; $args[] = $fEmp; }
if (in_array($fStatus, task_statuses(), true)) { $where[] = "t.status = ?"; $args[] = $fStatus; }
if (in_array($fPrio, task_priorities(), true)) { $where[] = "t.priority = ?"; $args[] = $fPrio; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$fFrom)) { $where[] = "t.assign_date >= ?"; $args[] = $fFrom; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$fTo))   { $where[] = "t.assign_date <= ?"; $args[] = $fTo; }
$whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

$tasks = fetch_all(
  "SELECT t.*, e.full_name, e.emp_code, u.name AS assigned_by_name
   FROM tasks t
   JOIN employees e ON e.id=t.assigned_to
   LEFT JOIN users u ON u.id=t.assigned_by
   $whereSql ORDER BY (t.status='Completed'), t.due_date IS NULL, t.due_date ASC, t.id DESC
   LIMIT 500", $args);

$emps = fetch_all(
  "SELECT e.id, e.emp_code, e.full_name, e.status, d.name AS dept
   FROM employees e LEFT JOIN departments d ON d.id=e.department_id
   WHERE (e.status IS NULL OR e.status NOT IN ('Resigned','Terminated'))
   ORDER BY e.full_name");

$sum = ['Pending'=>0,'In Progress'=>0,'Completed'=>0,'overdue'=>0];
foreach ($tasks as $t) { $sum[$t['status']]++; if (task_is_overdue($t)) $sum['overdue']++; }

$pageTitle='Task Board'; $activeNav='tasks';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Task Board</h2><div class="breadcrumb"><?= count($tasks) ?> task(s)</div></div>
  <button class="btn" data-modal="taskModal" onclick="taskForm()">➕ Assign Task</button></div>

<div class="grid cols-4 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-amber">🕗</div><div><div class="label">Pending</div><div class="value"><?= $sum['Pending'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🔄</div><div><div class="label">In Progress</div><div class="value"><?= $sum['In Progress'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div><div><div class="label">Completed</div><div class="value"><?= $sum['Completed'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">⚠️</div><div><div class="label">Overdue</div><div class="value"><?= $sum['overdue'] ?></div></div></div></div>
</div>

<form method="get" class="filters">
  <div class="form-group"><label>Employee</label><select name="emp"><option value="0">All</option>
    <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>" <?= $fEmp==$em['id']?'selected':'' ?>><?= e($em['full_name'].' — '.$em['emp_code']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>Status</label><select name="status"><option value="">All</option>
    <?php foreach(task_statuses() as $s): ?><option value="<?= $s ?>" <?= $fStatus===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>Priority</label><select name="priority"><option value="">All</option>
    <?php foreach(task_priorities() as $p): ?><option value="<?= $p ?>" <?= $fPrio===$p?'selected':'' ?>><?= $p ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>From</label><input type="date" name="from" value="<?= e($fFrom) ?>"></div>
  <div class="form-group"><label>To</label><input type="date" name="to" value="<?= e($fTo) ?>"></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button>
    <a class="btn btn-sm" href="<?= url('admin/tasks.php') ?>" style="margin-left:6px">Reset</a></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Task</th><th>Employee</th><th>Priority</th><th>Assigned</th><th>Due</th><th>Status</th><th>By</th><th></th></tr></thead>
  <tbody><?php foreach($tasks as $t): ?>
    <tr>
      <td><b><?= e($t['title']) ?></b><?php if($t['description']): ?><div class="text-muted" style="font-size:11px"><?= e(mb_strimwidth($t['description'],0,80,'…')) ?></div><?php endif; ?>
        <?php if($t['employee_remark']): ?><div class="text-muted" style="font-size:11px">💬 <?= e($t['employee_remark']) ?></div><?php endif; ?></td>
      <td><?= e($t['full_name']) ?><div class="text-muted" style="font-size:11px"><?= e($t['emp_code']) ?></div></td>
      <td><?= task_priority_pill($t['priority']) ?></td>
      <td class="text-muted"><?= fmt_date($t['assign_date']) ?></td>
      <td><?= $t['due_date'] ? (task_is_overdue($t) ? '<span class="pill pill-danger">'.fmt_date($t['due_date']).'</span>' : fmt_date($t['due_date'])) : '—' ?></td>
      <td><?= task_status_pill($t['status']) ?></td>
      <td class="text-muted" style="font-size:11px"><?= e($t['assigned_by_name'] ?: '—') ?></td>
      <td class="text-right">
        <button class="btn btn-sm btn-outline" data-modal="taskModal" onclick='taskForm(<?= json_encode($t, JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'>Edit</button>
        <form method="post" style="display:inline" data-confirm="Delete this task?">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $t['id'] ?>">
          <button class="btn btn-sm btn-danger">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; if(!$tasks): ?><tr><td colspan="8" class="empty">No tasks match your filters.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="taskModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="taskTitle">Assign Task</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="task_id">
    <div class="form-group"><label>Task Title <span class="req">*</span></label><input type="text" name="title" id="task_title_i" required></div>
    <div class="form-group"><label>Employee <span class="req">*</span></label><select name="assigned_to" id="task_emp" required>
      <option value="">— Select —</option>
      <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>"><?= e($em['full_name'].' — '.$em['emp_code'].' — '.($em['dept'] ?: 'No Dept')) ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Description</label><textarea name="description" id="task_desc"></textarea></div>
    <div class="form-row">
      <div class="form-group"><label>Priority</label><select name="priority" id="task_prio"><?php foreach(task_priorities() as $p): ?><option><?= $p ?></option><?php endforeach; ?></select></div>
      <div class="form-group"><label>Status</label><select name="status" id="task_status"><?php foreach(task_statuses() as $s): ?><option><?= $s ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Assigned Date</label><input type="date" name="assign_date" id="task_assign" value="<?= date('Y-m-d') ?>"></div>
      <div class="form-group"><label>Due Date</label><input type="date" name="due_date" id="task_due"></div>
    </div>
    <div class="form-group"><label>Remark (to employee)</label><input type="text" name="admin_remark" id="task_remark"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save Task</button></div>
</form></div></div>
<script>
function taskForm(t){t=t||{};
  document.getElementById('taskTitle').textContent=t.id?'Edit Task':'Assign Task';
  document.getElementById('task_id').value=t.id||'';
  document.getElementById('task_title_i').value=t.title||'';
  document.getElementById('task_emp').value=t.assigned_to||'';
  document.getElementById('task_desc').value=t.description||'';
  document.getElementById('task_prio').value=t.priority||'Medium';
  document.getElementById('task_status').value=t.status||'Pending';
  document.getElementById('task_assign').value=t.assign_date||'<?= date('Y-m-d') ?>';
  document.getElementById('task_due').value=t.due_date||'';
  document.getElementById('task_remark').value=t.admin_remark||'';
}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
