<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('payroll.view');

$month=(string)param('month',date('Y-m'));
$statusF=(string)param('status','');
$search=trim((string)param('q',''));
$where=["p.pay_month=?"]; $args=[$month];
if ($statusF){ $where[]="p.status=?"; $args[]=$statusF; }
if ($search){ $where[]="(e.full_name LIKE ? OR e.emp_code LIKE ?)"; $args[]="%$search%"; $args[]="%$search%"; }
$rows=fetch_all(
  "SELECT p.*, e.full_name,e.emp_code FROM payroll p JOIN employees e ON e.id=p.employee_id
   WHERE ".implode(' AND ',$where)." ORDER BY e.full_name", $args);
$tot=['gross'=>0,'ded'=>0,'net'=>0,'paid'=>0,'pending'=>0];
foreach($rows as $r){ $tot['gross']+=$r['gross_earnings'];$tot['ded']+=$r['total_deductions'];$tot['net']+=$r['net_salary'];$tot['paid']+=$r['paid_amount'];$tot['pending']+=$r['pending_amount']; }
$pageTitle='Salary Management'; $activeNav='payroll';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Salary Management — <?= fmt_date($month.'-01','F Y') ?></h2></div>
  <a class="btn" href="<?= url('admin/payroll_generate.php?month='.$month) ?>">⚙️ Generate Payroll</a></div>

<div class="grid cols-4 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-brand">💰</div><div><div class="label">Total Net</div><div class="value" style="font-size:17px"><?= money($tot['net']) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✔️</div><div><div class="label">Paid</div><div class="value" style="font-size:17px"><?= money($tot['paid']) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">⌛</div><div><div class="label">Pending</div><div class="value" style="font-size:17px"><?= money($tot['pending']) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-slate">📉</div><div><div class="label">Deductions</div><div class="value" style="font-size:17px"><?= money($tot['ded']) ?></div></div></div></div>
</div>

<form method="get" class="filters">
  <div class="form-group"><label>Month</label><input type="month" name="month" value="<?= e($month) ?>"></div>
  <div class="form-group"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Name / ID"></div>
  <div class="form-group"><label>Status</label><select name="status"><option value="">All</option>
    <?php foreach(['Draft','Pending','Partially Paid','Paid','On Hold','Unpaid'] as $s): ?>
    <option <?= $statusF===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th class="num">Gross</th><th class="num">Deductions</th><th class="num">Net</th><th class="num">Paid</th><th class="num">Pending</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r):
    $pill=['Paid'=>'pill-success','Pending'=>'pill-warning','Partially Paid'=>'pill-info','On Hold'=>'pill-danger','Unpaid'=>'pill-danger','Draft'=>'pill-muted'][$r['status']]??'pill-muted'; ?>
    <tr><td><b><?= e($r['full_name']) ?></b> <span class="text-muted">(<?= e($r['emp_code']) ?>)</span> <?= $r['is_finalized']?'<span class="pill pill-muted">🔒</span>':'' ?></td>
    <td class="num"><?= money($r['gross_earnings']) ?></td><td class="num"><?= money($r['total_deductions']) ?></td>
    <td class="num"><b><?= money($r['net_salary']) ?></b></td><td class="num"><?= money($r['paid_amount']) ?></td>
    <td class="num"><?= money($r['pending_amount']) ?></td>
    <td><span class="pill <?= $pill ?>"><?= e($r['status']) ?></span></td>
    <td class="text-right"><a class="btn btn-sm btn-outline" href="<?= url('admin/payroll_view.php?id='.$r['id']) ?>">Open</a></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="8" class="empty">No payroll for this month. <a href="<?= url('admin/payroll_generate.php?month='.$month) ?>">Generate now</a>.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
