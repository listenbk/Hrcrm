<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('advances.view');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    if (!has_perm('advances.manage')) { http_response_code(403); exit; }
    $act=param('do','','POST');
    if ($act==='create') {
        $emp=(int)param('employee_id',0,'POST');
        $type=trim((string)param('advance_type','Salary Advance','POST'));
        $total=(float)param('total_amount',0,'POST');
        $emi=(float)param('emi_amount',0,'POST');
        $first=trim((string)param('first_emi_month',date('Y-m'),'POST'));
        $issued=param('date_issued',date('Y-m-d'),'POST');
        if ($emp && $total>0 && $emi>0) {
            $installments=(int)ceil($total/$emi);
            q("INSERT INTO employee_advances (employee_id,advance_type,total_amount,emi_amount,installments,first_emi_month,date_issued,balance_amount,status,created_by)
               VALUES (?,?,?,?,?,?,?,?, 'Active', ?)",
              [$emp,$type,$total,$emi,$installments,$first,$issued,$total,current_user()['id']]);
            $advId=(int)insert_id();
            // build schedule
            $remaining=$total; $m=new DateTime($first.'-01');
            for ($i=1;$i<=$installments;$i++) {
                $amt=min($emi,$remaining); $remaining-=$amt;
                q("INSERT INTO emi_schedules (advance_id,installment_no,due_month,amount) VALUES (?,?,?,?)",
                  [$advId,$i,$m->format('Y-m'),$amt]);
                $m->modify('+1 month');
            }
            audit_log('advance_created','advance',$advId,"Advance ".money($total));
            flash_success('Advance created with EMI schedule.');
        }
    } elseif ($act==='status') {
        $id=(int)param('id',0,'POST'); $st=param('status','Active','POST');
        if (in_array($st,['Active','Completed','Paused','Cancelled'],true)) {
            q("UPDATE employee_advances SET status=? WHERE id=?",[$st,$id]);
            audit_log('advance_status','advance',$id,"Status $st"); flash_success('Advance updated.');
        }
    }
    redirect('admin/advances.php'.($empFilter=param('employee')?'?employee='.(int)$empFilter:''));
}

$empFilter=(int)param('employee',0);
$where=$empFilter?"WHERE ea.employee_id=?":""; $args=$empFilter?[$empFilter]:[];
$rows=fetch_all(
  "SELECT ea.*, e.full_name,e.emp_code FROM employee_advances ea JOIN employees e ON e.id=ea.employee_id
   $where ORDER BY ea.created_at DESC",$args);
$emps=fetch_all("SELECT id,emp_code,full_name FROM employees WHERE status='Active' ORDER BY full_name");
$pageTitle='Employee Advances'; $activeNav='advances';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Employee Advances &amp; Loans</h2></div>
  <?php if(has_perm('advances.manage')): ?><button class="btn" data-modal="advModal">➕ New Advance / Loan</button><?php endif; ?></div>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Type</th><th class="num">Total</th><th class="num">EMI</th><th>Installments</th>
    <th class="num">Recovered</th><th class="num">Balance</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><b><?= e($r['full_name']) ?></b> <span class="text-muted">(<?= e($r['emp_code']) ?>)</span></td>
    <td><?= e($r['advance_type']) ?></td><td class="num"><?= money($r['total_amount']) ?></td>
    <td class="num"><?= money($r['emi_amount']) ?></td><td><?= $r['installments'] ?></td>
    <td class="num"><?= money($r['recovered_amount']) ?></td><td class="num"><b><?= money($r['balance_amount']) ?></b></td>
    <td><span class="pill <?= ['Active'=>'pill-info','Completed'=>'pill-success','Paused'=>'pill-warning','Cancelled'=>'pill-danger'][$r['status']] ?>"><?= e($r['status']) ?></span></td>
    <td class="text-right"><a class="btn btn-sm btn-outline" href="<?= url('admin/emi_schedule.php?advance='.$r['id']) ?>">EMI</a></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="9" class="empty">No advances.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="advModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>New Advance / Loan</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="create">
    <div class="form-group"><label>Employee <span class="req">*</span></label><select name="employee_id" required>
      <option value="">— Select —</option>
      <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>" <?= $empFilter==$em['id']?'selected':'' ?>><?= e($em['full_name'].' ('.$em['emp_code'].')') ?></option><?php endforeach; ?></select></div>
    <div class="form-row">
      <div class="form-group"><label>Type</label><select name="advance_type"><option>Salary Advance</option><option>Employee Loan</option><option>Internal Loan</option></select></div>
      <div class="form-group"><label>Date Issued</label><input type="date" name="date_issued" value="<?= date('Y-m-d') ?>"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Total Amount (₹) <span class="req">*</span></label><input type="number" step="0.01" name="total_amount" required></div>
      <div class="form-group"><label>Monthly EMI (₹) <span class="req">*</span></label><input type="number" step="0.01" name="emi_amount" required></div>
    </div>
    <div class="form-group"><label>First EMI Month</label><input type="month" name="first_emi_month" value="<?= date('Y-m',strtotime('+1 month')) ?>"></div>
    <p class="help">Number of installments and the schedule are generated automatically. Payroll deducts each EMI until the balance reaches zero.</p>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Create</button></div>
</form></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
