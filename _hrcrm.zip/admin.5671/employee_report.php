<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/employee_report_render.php';
require_perm('reports.view');
render_employee_report((int)param('id', 0));
