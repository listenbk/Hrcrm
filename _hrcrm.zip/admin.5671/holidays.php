<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('holidays.manage');
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='save') {
        $id=(int)param('id',0,'POST'); $name=trim((string)param('name','','POST'));
        $date=param('holiday_date','','POST'); $desc=trim((string)param('description','','POST'));
        $scope=trim((string)param('scope','All','POST')) ?: 'All';
        if ($name!=='' && $date) {
            if ($id) q("UPDATE holidays SET name=?,holiday_date=?,description=?,scope=? WHERE id=?",[$name,$date,$desc,$scope,$id]);
            else     q("INSERT INTO holidays (name,holiday_date,description,scope) VALUES (?,?,?,?)",[$name,$date,$desc,$scope]);
            flash_success('Holiday saved.');
        }
    } elseif ($act==='delete') { q("DELETE FROM holidays WHERE id=?",[(int)param('id',0,'POST')]); flash_success('Deleted.'); }
    redirect('admin/holidays.php');
}
$year=(int)param('year',date('Y'));
$rows=fetch_all("SELECT * FROM holidays WHERE YEAR(holiday_date)=? ORDER BY holiday_date",[$year]);
$pageTitle='Holidays'; $activeNav='holidays';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Holiday Calendar — <?= $year ?></h2></div>
  <div class="flex gap"><form method="get"><input type="number" name="year" value="<?= $year ?>" onchange="this.form.submit()" style="width:100px"></form>
  <button class="btn" data-modal="hdModal" onclick="hdForm()">➕ Add Holiday</button></div></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Date</th><th>Holiday</th><th>Applies To</th><th>Description</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><?= fmt_date($r['holiday_date'],'d M Y (D)') ?></td><td><b><?= e($r['name']) ?></b></td>
    <td><?= e($r['scope']) ?></td><td class="text-muted"><?= e($r['description'] ?: '—') ?></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="hdModal" onclick='hdForm(<?= json_encode($r) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="5" class="empty">No holidays for <?= $year ?>.</td></tr><?php endif; ?></tbody>
</table></div></div>
<div class="modal-overlay" id="hdModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="hdTitle">Add Holiday</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="hd_id">
    <div class="form-group"><label>Holiday Name <span class="req">*</span></label><input type="text" name="name" id="hd_name" required></div>
    <div class="form-row">
      <div class="form-group"><label>Date <span class="req">*</span></label><input type="date" name="holiday_date" id="hd_date" required></div>
      <div class="form-group"><label>Applies To</label><input type="text" name="scope" id="hd_scope" value="All"></div>
    </div>
    <div class="form-group"><label>Description</label><textarea name="description" id="hd_desc"></textarea></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function hdForm(d){d=d||{};hdTitle.textContent=d.id?'Edit Holiday':'Add Holiday';
  hd_id.value=d.id||'';hd_name.value=d.name||'';hd_date.value=d.holiday_date||'';hd_scope.value=d.scope||'All';hd_desc.value=d.description||'';}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
