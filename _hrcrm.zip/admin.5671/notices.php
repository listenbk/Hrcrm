<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('notices.manage');
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');

    if ($act === 'save') {
        $id       = (int)param('id', 0, 'POST');
        $title    = trim((string)param('title', '', 'POST'));
        $message  = trim((string)param('message', '', 'POST'));
        $priority = in_array(param('priority','Normal','POST'), ['Normal','Important','Urgent'], true) ? param('priority','Normal','POST') : 'Normal';
        $aType    = in_array(param('audience_type','all','POST'), ['all','employees','hr','department','branch','selected'], true) ? param('audience_type','all','POST') : 'all';
        $aValue   = null;
        if ($aType === 'department') $aValue = (string)(int)param('department_id', 0, 'POST');
        if ($aType === 'branch')     $aValue = trim((string)param('branch', '', 'POST'));
        $pub      = param('publish_date','','POST') ?: date('Y-m-d');
        $exp      = param('expiry_date','','POST') ?: null;
        $pinned   = param('is_pinned',0,'POST') ? 1 : 0;
        $targets  = param('targets', [], 'POST'); if (!is_array($targets)) $targets = [];

        $errors = [];
        if ($title === '') $errors[] = 'Title is required.';
        if ($message === '') $errors[] = 'Message is required.';

        // Edit permission: creator or Super Admin
        $existing = $id ? fetch_one("SELECT * FROM notices WHERE id=?", [$id]) : null;
        if ($id && $existing && !is_super_admin() && (int)$existing['created_by'] !== (int)$me['id']) {
            flash_error('You can only edit notices you created.'); redirect('admin/notices.php');
        }

        // Attachment
        $attachment = $existing['attachment'] ?? null;
        if (!empty($_FILES['attachment']['name'])) {
            $up = handle_upload($_FILES['attachment'], 'notices', ['jpg','jpeg','png','gif','pdf','doc','docx','xls','xlsx']);
            if ($up) $attachment = $up;
        }

        if (!$errors) {
            if ($id && $existing) {
                q("UPDATE notices SET title=?, message=?, priority=?, audience_type=?, audience_value=?, attachment=?, is_pinned=?, publish_date=?, expiry_date=? WHERE id=?",
                  [$title,$message,$priority,$aType,$aValue,$attachment,$pinned,$pub,$exp,$id]);
                $nid = $id;
                q("DELETE FROM notice_targets WHERE notice_id=?", [$nid]);
                audit_log('notice_edited','notice',$nid,"Edited notice: $title");
            } else {
                q("INSERT INTO notices (title,message,priority,audience_type,audience_value,attachment,is_pinned,publish_date,expiry_date,created_by)
                   VALUES (?,?,?,?,?,?,?,?,?,?)",
                  [$title,$message,$priority,$aType,$aValue,$attachment,$pinned,$pub,$exp,$me['id']]);
                $nid = (int)insert_id();
                audit_log('notice_created','notice',$nid,"Created notice: $title (".$aType.")");
            }
            if ($aType === 'selected') {
                foreach ($targets as $uid) {
                    q("INSERT IGNORE INTO notice_targets (notice_id,user_id) VALUES (?,?)", [$nid, (int)$uid]);
                }
            }
            // In-app notifications to the audience (email / WhatsApp hooks can extend notify()).
            $notice = fetch_one("SELECT * FROM notices WHERE id=?", [$nid]);
            if (notice_is_active($notice)) {
                foreach (notice_audience_user_ids($notice) as $uid) {
                    if ($uid === (int)$me['id']) continue;
                    notify($uid, 'notice', ($priority==='Urgent'?'🔴 URGENT: ':'').'New notice: '.$title,
                        mb_substr($message,0,120), url('noticeboard.php'));
                }
            }
            flash_success('Notice saved and published to the target audience.');
        } else {
            flash_error(implode(' ', $errors));
        }
        redirect('admin/notices.php');
    }

    // Soft-delete → move to Trash (reason + password required)
    if ($act === 'trash') {
        $id = (int)param('id', 0, 'POST');
        $reason = trim((string)param('reason', '', 'POST'));
        $pw = (string)param('confirm_password', '', 'POST');
        $n = fetch_one("SELECT n.*, cu.name AS creator FROM notices n LEFT JOIN users cu ON cu.id=n.created_by WHERE n.id=?", [$id]);
        if (!$n || $n['deleted_at']) { flash_error('Notice not found.'); redirect('admin/notices.php'); }
        if (!can_manage_notice($n, $me)) {
            flash_error('You can only delete notices you created. A notice created by a Super Admin can only be deleted by a Manager.');
        } elseif ($reason === '') {
            flash_error('A reason is required to delete a notice.');
        } elseif (!verify_current_password($pw)) {
            flash_error('Incorrect password — notice not deleted.');
        } else {
            q("UPDATE notices SET deleted_at=NOW(), deleted_by=?, delete_reason=? WHERE id=?", [$me['id'], $reason, $id]);
            audit_log('notice_trashed','notice',$id,
                "Trashed notice \"{$n['title']}\" (creator: ".($n['creator'] ?: '—').") — Reason: {$reason}", $n, null);
            flash_success('Notice moved to Trash.');
        }
        redirect('admin/notices.php?view=trash');
    }

    // Restore from Trash (Super Admin only)
    if ($act === 'restore') {
        if (!is_super_admin()) { http_response_code(403); require __DIR__.'/../templates/403.php'; exit; }
        $id = (int)param('id', 0, 'POST');
        $n = fetch_one("SELECT * FROM notices WHERE id=?", [$id]);
        if ($n && $n['deleted_at']) {
            q("UPDATE notices SET deleted_at=NULL, deleted_by=NULL, delete_reason=NULL WHERE id=?", [$id]);
            audit_log('notice_restored','notice',$id,"Restored notice \"{$n['title']}\" from Trash");
            flash_success('Notice restored.');
        }
        redirect('admin/notices.php');
    }

    // Permanent delete (Super Admin only, password-confirmed)
    if ($act === 'purge') {
        if (!is_super_admin()) { http_response_code(403); require __DIR__.'/../templates/403.php'; exit; }
        $id = (int)param('id', 0, 'POST');
        $pw = (string)param('confirm_password', '', 'POST');
        $n = fetch_one("SELECT n.*, cu.name AS creator FROM notices n LEFT JOIN users cu ON cu.id=n.created_by WHERE n.id=?", [$id]);
        if (!$n) { flash_error('Notice not found.'); redirect('admin/notices.php?view=trash'); }
        if (!verify_current_password($pw)) {
            flash_error('Incorrect password — notice not permanently deleted.');
        } else {
            q("DELETE FROM notices WHERE id=?", [$id]);
            audit_log('notice_deleted_permanent','notice',$id,
                "Permanently deleted notice \"{$n['title']}\" (creator: ".($n['creator'] ?: '—').")", $n, null);
            flash_success('Notice permanently deleted.');
        }
        redirect('admin/notices.php?view=trash');
    }

    // Manual archive / unarchive (creator or Super Admin)
    if ($act === 'archive') {
        $id = (int)param('id', 0, 'POST');
        $n = fetch_one("SELECT * FROM notices WHERE id=?", [$id]);
        if ($n && !$n['deleted_at'] && can_manage_notice($n, $me)) {
            $new = $n['is_archived'] ? 0 : 1;
            q("UPDATE notices SET is_archived=? WHERE id=?", [$new, $id]);
            audit_log($new ? 'notice_archived' : 'notice_unarchived','notice',$id,($new?'Archived':'Unarchived')." notice \"{$n['title']}\"");
            flash_success($new ? 'Notice archived.' : 'Notice unarchived.');
        }
        redirect('admin/notices.php');
    }

    if ($act === 'pin') {
        $id = (int)param('id', 0, 'POST');
        $n = fetch_one("SELECT * FROM notices WHERE id=?", [$id]);
        if ($n && (is_super_admin() || (int)$n['created_by'] === (int)$me['id'])) {
            q("UPDATE notices SET is_pinned=? WHERE id=?", [$n['is_pinned'] ? 0 : 1, $id]);
            flash_success($n['is_pinned'] ? 'Notice unpinned.' : 'Notice pinned.');
        }
        redirect('admin/notices.php');
    }
}

$edit = null;
if (($eid = (int)param('edit', 0)) > 0) {
    $edit = fetch_one("SELECT * FROM notices WHERE id=?", [$eid]);
    if ($edit && !is_super_admin() && (int)$edit['created_by'] !== (int)$me['id']) $edit = null;
}
$editTargets = [];
if ($edit && $edit['audience_type'] === 'selected') {
    foreach (fetch_all("SELECT user_id FROM notice_targets WHERE notice_id=?", [$edit['id']]) as $t) $editTargets[(int)$t['user_id']] = true;
}

$depts    = fetch_all("SELECT id,name FROM departments WHERE is_active=1 ORDER BY name");
$branches = fetch_all("SELECT DISTINCT office_location FROM employees WHERE office_location<>'' AND office_location IS NOT NULL ORDER BY office_location");
$users    = fetch_all("SELECT u.id, u.name, r.name AS role_name FROM users u JOIN roles r ON r.id=u.role_id WHERE u.is_active=1 ORDER BY r.id, u.name");
$today = date('Y-m-d');
$view = param('view','manage') === 'trash' ? 'trash' : 'manage';
$mine = is_super_admin() ? '' : ' AND n.created_by='.(int)$me['id'];
if ($view === 'trash') {
    $notices = fetch_all(
      "SELECT n.*, u.name AS creator, du.name AS deleted_by_name
       FROM notices n LEFT JOIN users u ON u.id=n.created_by LEFT JOIN users du ON du.id=n.deleted_by
       WHERE n.deleted_at IS NOT NULL$mine ORDER BY n.deleted_at DESC");
} else {
    $notices = fetch_all(
      "SELECT n.*, u.name AS creator FROM notices n LEFT JOIN users u ON u.id=n.created_by
       WHERE n.deleted_at IS NULL ORDER BY n.is_pinned DESC, n.created_at DESC");
}
$trashCount = is_super_admin()
    ? (int)fetch_col("SELECT COUNT(*) FROM notices WHERE deleted_at IS NOT NULL")
    : (int)fetch_col("SELECT COUNT(*) FROM notices WHERE deleted_at IS NOT NULL AND created_by=?", [$me['id']]);

$pageTitle = 'Notices'; $activeNav = 'notices_manage';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Manage Notices</h2>
  <div class="breadcrumb">Create and send announcements to your teams.</div></div></div>

<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3><?= $edit?'Edit Notice':'New Notice' ?></h3>
    <?php if($edit): ?><a class="btn btn-sm btn-outline" href="<?= url('admin/notices.php') ?>">Cancel edit</a><?php endif; ?></div>
    <div class="card-body">
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="do" value="save">
      <input type="hidden" name="id" value="<?= (int)($edit['id'] ?? 0) ?>">
      <div class="form-group"><label>Title <span class="req">*</span></label>
        <input type="text" name="title" value="<?= e($edit['title'] ?? '') ?>" required></div>
      <div class="form-group"><label>Message <span class="req">*</span></label>
        <textarea name="message" required style="min-height:120px"><?= e($edit['message'] ?? '') ?></textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Priority</label><select name="priority">
          <?php foreach(['Normal','Important','Urgent'] as $p): ?><option <?= ($edit['priority']??'Normal')===$p?'selected':'' ?>><?= $p ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label>Audience</label><select name="audience_type" id="aud" onchange="audChange()">
          <?php $atypes=['all'=>'All Users','employees'=>'All Employees','hr'=>'All HR / Admins','department'=>'Specific Department','branch'=>'Specific Branch','selected'=>'Selected Users'];
          foreach($atypes as $k=>$v): ?><option value="<?= $k ?>" <?= ($edit['audience_type']??'all')===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?>
        </select></div>
      </div>

      <div class="form-group" id="audDept" style="display:none"><label>Department</label>
        <select name="department_id"><option value="">— Select —</option>
        <?php foreach($depts as $d): ?><option value="<?= $d['id'] ?>" <?= (($edit['audience_type']??'')==='department' && (string)$edit['audience_value']===(string)$d['id'])?'selected':'' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>

      <div class="form-group" id="audBranch" style="display:none"><label>Branch / Office</label>
        <input list="branchList" name="branch" value="<?= ($edit['audience_type']??'')==='branch'?e($edit['audience_value']):'' ?>" placeholder="Office / location">
        <datalist id="branchList"><?php foreach($branches as $b): ?><option value="<?= e($b['office_location']) ?>"><?php endforeach; ?></datalist></div>

      <div class="form-group" id="audSel" style="display:none"><label>Selected Users</label>
        <select name="targets[]" multiple size="6" style="height:auto">
        <?php foreach($users as $us): ?><option value="<?= $us['id'] ?>" <?= isset($editTargets[(int)$us['id']])?'selected':'' ?>><?= e($us['name'].' — '.$us['role_name']) ?></option><?php endforeach; ?>
        </select><div class="help">Ctrl/Cmd-click to select multiple.</div></div>

      <div class="form-row">
        <div class="form-group"><label>Publish Date</label><input type="date" name="publish_date" value="<?= e($edit['publish_date'] ?? $today) ?>"></div>
        <div class="form-group"><label>Expiry Date</label><input type="date" name="expiry_date" value="<?= e($edit['expiry_date'] ?? '') ?>">
          <div class="help">After this date it moves to archive.</div></div>
      </div>
      <div class="form-group"><label>Attachment</label><input type="file" name="attachment">
        <?php if(!empty($edit['attachment'])): ?><div class="help">Current: <?= e($edit['attachment']) ?></div><?php endif; ?></div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="is_pinned" value="1" <?= ($edit['is_pinned']??0)?'checked':'' ?>> 📌 Pin to top</label></div>
      <button class="btn"><?= $edit?'💾 Update &amp; Send':'📢 Publish &amp; Send' ?></button>
    </form>
  </div></div>

  <div class="card"><div class="card-head">
    <div class="flex gap">
      <a class="btn btn-sm <?= $view==='manage'?'':'btn-outline' ?>" href="<?= url('admin/notices.php') ?>">Notices</a>
      <a class="btn btn-sm <?= $view==='trash'?'':'btn-outline' ?>" href="<?= url('admin/notices.php?view=trash') ?>">🗑️ Trash<?= $trashCount?' ('.$trashCount.')':'' ?></a>
    </div>
    <a class="btn btn-sm btn-outline" href="<?= url('noticeboard.php') ?>" target="_blank">View Board</a></div>
    <div class="table-wrap"><table class="data">
    <?php if ($view==='trash'): ?>
    <thead><tr><th>Notice</th><th>Creator</th><th>Deleted By</th><th>Reason</th><th></th></tr></thead>
    <tbody><?php foreach($notices as $n): ?>
      <tr>
        <td><b><?= e($n['title']) ?></b><div class="text-muted" style="font-size:11px"><?= fmt_date($n['deleted_at'],'d M Y h:i A') ?></div></td>
        <td style="font-size:12px"><?= e($n['creator'] ?: '—') ?></td>
        <td style="font-size:12px"><?= e($n['deleted_by_name'] ?: '—') ?></td>
        <td class="text-muted" style="font-size:12px;max-width:180px"><?= e($n['delete_reason'] ?: '—') ?></td>
        <td class="text-right" style="white-space:nowrap"><?php if(is_super_admin()): ?>
          <form method="post" style="display:inline" data-confirm="Restore this notice?"><?= csrf_field() ?><input type="hidden" name="do" value="restore"><input type="hidden" name="id" value="<?= $n['id'] ?>"><button class="btn btn-sm btn-success">↩ Restore</button></form>
          <button class="btn btn-sm btn-danger" data-modal="purgeModal" onclick='purgeForm(<?= (int)$n['id'] ?>,<?= json_encode($n['title']) ?>)'>Delete forever</button>
        <?php else: ?><span class="text-muted" style="font-size:11px">Ask a Manager to restore</span><?php endif; ?></td>
      </tr>
    <?php endforeach; if(!$notices): ?><tr><td colspan="5" class="empty">Trash is empty.</td></tr><?php endif; ?></tbody>
    <?php else: ?>
    <thead><tr><th>Notice</th><th>Audience</th><th>Read</th><th>Status</th><th></th></tr></thead>
    <tbody><?php foreach($notices as $n):
      [$aud,$rd] = notice_read_stats($n);
      $active = notice_is_active($n);
      $expired = !empty($n['expiry_date']) && $n['expiry_date'] < $today;
      $canManage = can_manage_notice($n, $me); ?>
      <tr>
        <td><?= $n['is_pinned']?'📌 ':'' ?><b><?= e($n['title']) ?></b>
          <div class="text-muted" style="font-size:11px"><span class="pill <?= notice_priority_pill($n['priority']) ?>"><?= e($n['priority']) ?></span> · <?= e($n['creator'] ?: 'Admin') ?> · <?= fmt_date($n['publish_date']) ?></div></td>
        <td style="font-size:12px"><?= e(notice_audience_label($n)) ?></td>
        <td><b><?= $rd ?></b><span class="text-muted">/<?= $aud ?></span></td>
        <td><?php if($n['publish_date']>$today): ?><span class="pill pill-info">Scheduled</span>
            <?php elseif($n['is_archived']): ?><span class="pill pill-muted">Archived</span>
            <?php elseif($expired): ?><span class="pill pill-muted">Expired</span>
            <?php else: ?><span class="pill pill-success">Active</span><?php endif; ?></td>
        <td class="text-right" style="white-space:nowrap"><?php if($canManage): ?>
          <a class="btn btn-sm btn-outline" href="<?= url('admin/notice_reads.php?id='.$n['id']) ?>">Reads</a>
          <a class="btn btn-sm btn-outline" href="<?= url('admin/notices.php?edit='.$n['id']) ?>">Edit</a>
          <form method="post" style="display:inline"><?= csrf_field() ?><input type="hidden" name="do" value="archive"><input type="hidden" name="id" value="<?= $n['id'] ?>">
            <button class="btn btn-sm btn-outline"><?= $n['is_archived']?'Unarchive':'Archive' ?></button></form>
          <button class="btn btn-sm btn-danger" data-modal="delNoticeModal" onclick='delNotice(<?= (int)$n['id'] ?>,<?= json_encode($n['title']) ?>)'>Delete</button>
        <?php else: echo '<span class="text-muted">—</span>'; endif; ?></td>
      </tr>
    <?php endforeach; if(!$notices): ?><tr><td colspan="5" class="empty">No notices yet.</td></tr><?php endif; ?></tbody>
    <?php endif; ?>
    </table></div>
  </div>
</div>

<!-- Delete (to Trash) modal: reason + password -->
<div class="modal-overlay" id="delNoticeModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Delete Notice</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="trash"><input type="hidden" name="id" id="del_notice_id">
    <div class="alert alert-info">Moving <b id="del_notice_title"></b> to Trash. It disappears from all dashboards immediately and can be restored by a Super Admin.</div>
    <div class="form-group"><label>Reason for deletion <span class="req">*</span></label><input type="text" name="reason" required placeholder="e.g. Published by mistake"></div>
    <div class="form-group"><label>Confirm with your password <span class="req">*</span></label>
      <div class="pwd-wrap"><input type="password" name="confirm_password" required autocomplete="off" placeholder="Your own password">
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-danger">Move to Trash</button></div>
</form></div></div>

<?php if(is_super_admin()): ?>
<!-- Permanent delete modal: password -->
<div class="modal-overlay" id="purgeModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Delete Permanently</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="purge"><input type="hidden" name="id" id="purge_notice_id">
    <div class="alert alert-error">Permanently delete <b id="purge_notice_title"></b>? This cannot be undone.</div>
    <div class="form-group"><label>Confirm with your password <span class="req">*</span></label>
      <div class="pwd-wrap"><input type="password" name="confirm_password" required autocomplete="off" placeholder="Your own password">
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-danger">Delete Forever</button></div>
</form></div></div>
<?php endif; ?>

<script>
function delNotice(id,t){document.getElementById('del_notice_id').value=id;document.getElementById('del_notice_title').textContent=t;}
function purgeForm(id,t){document.getElementById('purge_notice_id').value=id;document.getElementById('purge_notice_title').textContent=t;}
</script>
<script>
function audChange(){var v=document.getElementById('aud').value;
  document.getElementById('audDept').style.display=(v==='department')?'block':'none';
  document.getElementById('audBranch').style.display=(v==='branch')?'block':'none';
  document.getElementById('audSel').style.display=(v==='selected')?'block':'none';}
audChange();
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
