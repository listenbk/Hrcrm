<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('leaves.view');

/**
 * Parallel leave approval:
 *   - A Team Leader and HR (Managers act on the HR channel) each hold a
 *     decision slot on every request.
 *   - If EITHER approves, the leave is Approved (allowed) immediately.
 *   - A single rejection leaves the request Pending, awaiting the other
 *     approver; only when BOTH reject is the leave finally Rejected.
 */

/** Apply an approved leave to attendance rows + leave balance (runs once). */
function apply_leave_approval(array $lr): void
{
    $statusSlug = $lr['is_paid'] ? 'paid_leave' : 'unpaid_leave';
    $ls = att_status($statusSlug) ?: att_status('paid_leave');
    $cur = new DateTime($lr['start_date']); $endD = new DateTime($lr['end_date']);
    while ($cur <= $endD) {
        $d = $cur->format('Y-m-d');
        q("INSERT INTO attendance (employee_id,att_date,status_id,employee_remark,is_manual)
           VALUES (?,?,?,?,1)
           ON DUPLICATE KEY UPDATE status_id=VALUES(status_id)",
          [$lr['employee_id'], $d, $ls['id'] ?? null, 'Approved leave']);
        $cur->modify('+1 day');
    }
    $yr = (int)date('Y', strtotime($lr['start_date']));
    q("INSERT INTO leave_balances (employee_id,leave_type_id,year,entitlement,used)
       VALUES (?,?,?,0,?)
       ON DUPLICATE KEY UPDATE used=used+VALUES(used)",
      [$lr['employee_id'], $lr['leave_type_id'], $yr, $lr['total_days']]);
}

// Which decision slot does the current user own?
$myChannel = is_team_leader() ? 'tl' : 'hr';                 // hr_admin & super_admin -> hr
$myLabel   = is_team_leader() ? 'Team Leader' : 'HR / Manager';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!has_perm('leaves.approve')) { http_response_code(403); exit; }
    $id       = (int)param('id', 0, 'POST');
    $decision = (string)param('decision', '', 'POST');
    $remark   = trim((string)param('admin_remark', '', 'POST'));

    $lr = fetch_one(
        "SELECT lr.*, lt.slug AS type_slug, lt.is_paid, e.user_id, e.full_name, e.is_staff
         FROM leave_requests lr
         JOIN leave_types lt ON lt.id=lr.leave_type_id
         JOIN employees e ON e.id=lr.employee_id
         WHERE lr.id=?", [$id]);

    if ($lr && in_array($decision, ['Approved', 'Rejected'], true)) {
        // Accountability: no one approves their own request; staff (HR / TL)
        // leave can only be decided by the Manager (Super Admin).
        if (!empty($lr['user_id']) && (int)$lr['user_id'] === (int)current_user()['id']) {
            flash_error('You cannot approve or reject your own leave request.');
            redirect('admin/leaves.php');
        }
        if ($lr['is_staff'] && !is_super_admin()) {
            flash_error('Staff (HR / Team Leader) leave can only be decided by the Manager.');
            redirect('admin/leaves.php');
        }
        if ($lr['status'] === 'Approved') {
            flash_error('This leave was already approved — no further action needed.');
            redirect('admin/leaves.php');
        }
        if ($lr['status'] === 'Rejected') {
            flash_error('This leave was already rejected by both approvers.');
            redirect('admin/leaves.php');
        }

        $uid = (int)current_user()['id'];
        // Record this approver's decision in their own slot
        q("UPDATE leave_requests
             SET {$myChannel}_decision=?, {$myChannel}_by=?, {$myChannel}_at=NOW(), {$myChannel}_remark=?
             WHERE id=?", [$decision, $uid, $remark, $id]);

        if ($decision === 'Approved') {
            // Either approver approving allows the leave immediately.
            q("UPDATE leave_requests SET status='Approved', approved_by=?, approved_at=NOW(), admin_remark=? WHERE id=?",
              [$uid, $remark, $id]);
            apply_leave_approval($lr);
            if (!empty($lr['user_id'])) {
                notify((int)$lr['user_id'], 'leave_approved', 'Leave Approved',
                    "Your leave request was approved by the {$myLabel}.", url('employee/leave_history.php'));
            }
            audit_log('leave_approved', 'leave', $id, "{$lr['full_name']} leave approved by {$myLabel}");
            flash_success("Leave approved (as {$myLabel}). The employee has been notified.");
        } else {
            // Rejection: only final if the OTHER approver already rejected.
            $otherDecision = $myChannel === 'tl' ? $lr['hr_decision'] : $lr['tl_decision'];
            if ($otherDecision === 'Rejected') {
                q("UPDATE leave_requests SET status='Rejected', approved_by=?, approved_at=NOW(), admin_remark=? WHERE id=?",
                  [$uid, $remark, $id]);
                if (!empty($lr['user_id'])) {
                    notify((int)$lr['user_id'], 'leave_rejected', 'Leave Rejected',
                        'Your leave request was rejected by both approvers.', url('employee/leave_history.php'));
                }
                audit_log('leave_rejected', 'leave', $id, "{$lr['full_name']} leave rejected (both approvers)");
                flash_error('Leave rejected — both approvers have now declined it.');
            } else {
                // Stays pending; the other approver can still allow it.
                audit_log('leave_reject_recorded', 'leave', $id, "{$lr['full_name']} rejected by {$myLabel} (awaiting other approver)");
                flash_success("Your rejection is recorded. The leave stays pending — the other approver can still allow it.");
            }
        }
    }
    redirect('admin/leaves.php');
}

$statusF = (string)param('status', 'Pending');
$where = $statusF ? "WHERE lr.status=?" : "WHERE 1=1"; $args = $statusF ? [$statusF] : [];
$rows = fetch_all(
  "SELECT lr.*, e.full_name, e.emp_code, lt.name AS type_name, lt.color,
          tu.name AS tl_name, hu.name AS hr_name
   FROM leave_requests lr
   JOIN employees e ON e.id=lr.employee_id
   JOIN leave_types lt ON lt.id=lr.leave_type_id
   LEFT JOIN users tu ON tu.id=lr.tl_by
   LEFT JOIN users hu ON hu.id=lr.hr_by
   $where ORDER BY lr.created_at DESC", $args);

function decision_pill(string $d): string
{
    $map = ['Approved' => 'pill-success', 'Rejected' => 'pill-danger', 'Pending' => 'pill-muted'];
    return '<span class="pill ' . ($map[$d] ?? 'pill-muted') . '">' . e($d) . '</span>';
}

$pageTitle = 'Leave Requests'; $activeNav = 'leave_req';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>Leave Requests</h2>
    <div class="breadcrumb">You review as <b><?= e($myLabel) ?></b>. Either the Team Leader <b>or</b> HR approving allows the leave; both must reject to deny it.</div></div>
</div>
<form method="get" class="filters">
  <div class="form-group"><label>Status</label><select name="status" onchange="this.form.submit()">
    <?php foreach(['Pending','Approved','Rejected',''] as $s): ?>
    <option value="<?= $s ?>" <?= $statusF===$s?'selected':'' ?>><?= $s?:'All' ?></option><?php endforeach; ?>
  </select></div>
</form>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th><th>Team Leader</th><th>HR</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr>
      <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div>
          <?php if($r['reason']): ?><div class="text-muted" style="font-size:11px;max-width:200px">“<?= e($r['reason']) ?>”</div><?php endif; ?>
          <?php if($r['document']): ?><a href="<?= url('uploads/'.$r['document']) ?>" target="_blank" style="font-size:11px">📎 Document</a><?php endif; ?></td>
      <td><span class="badge" style="background:<?= e($r['color']) ?>"><?= e($r['type_name']) ?></span></td>
      <td><?= fmt_date($r['start_date']) ?> → <?= fmt_date($r['end_date']) ?><?= $r['is_half_day']?' <span class="pill pill-muted">Half</span>':'' ?></td>
      <td><?= e($r['total_days']) ?></td>
      <td><?= decision_pill($r['tl_decision']) ?><?php if($r['tl_name']): ?><div class="text-muted" style="font-size:10px"><?= e($r['tl_name']) ?></div><?php endif; ?></td>
      <td><?= decision_pill($r['hr_decision']) ?><?php if($r['hr_name']): ?><div class="text-muted" style="font-size:10px"><?= e($r['hr_name']) ?></div><?php endif; ?></td>
      <td><?php $p=['Approved'=>'pill-success','Rejected'=>'pill-danger','Pending'=>'pill-warning'][$r['status']]; ?>
        <span class="pill <?= $p ?>"><?= e($r['status']) ?></span></td>
      <td class="text-right"><?php if($r['status']==='Pending' && has_perm('leaves.approve')): ?>
        <button class="btn btn-sm btn-success" data-modal="lvModal" onclick='lvForm(<?= (int)$r['id'] ?>,"Approved")'>Approve</button>
        <button class="btn btn-sm btn-danger" data-modal="lvModal" onclick='lvForm(<?= (int)$r['id'] ?>,"Rejected")'>Reject</button>
        <?php else: echo '—'; endif; ?></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="8" class="empty">No requests.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="lvModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="lvTitle">Review Leave</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="id" id="lv_id"><input type="hidden" name="decision" id="lv_decision">
    <p class="text-muted">Acting as <b><?= e($myLabel) ?></b>.</p>
    <p id="lvMsg"></p>
    <div class="form-group"><label><?= e($myLabel) ?> Remark</label><input type="text" name="admin_remark" placeholder="Optional comment for this decision"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button>
    <button class="btn" id="lvBtn">Confirm</button></div>
</form></div></div>
<script>function lvForm(id,dec){document.getElementById('lv_id').value=id;document.getElementById('lv_decision').value=dec;
  document.getElementById('lvTitle').textContent=dec==='Approved'?'Approve Leave':'Reject Leave';
  document.getElementById('lvMsg').textContent=dec==='Approved'
    ?'Approving allows this leave immediately (either approver can allow it).'
    :'Rejecting is final only if the other approver also rejects; otherwise the request stays pending.';
  var b=document.getElementById('lvBtn');b.textContent=dec;b.className='btn '+(dec==='Approved'?'btn-success':'btn-danger');}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
