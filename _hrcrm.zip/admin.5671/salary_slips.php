<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('payroll.view');
$month=(string)param('month',date('Y-m'));
$rows=fetch_all("SELECT p.*, e.full_name,e.emp_code FROM payroll p JOIN employees e ON e.id=p.employee_id
  WHERE p.pay_month=? ORDER BY e.full_name",[$month]);
$pageTitle='Salary Slips'; $activeNav='slips';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Salary Slips — <?= fmt_date($month.'-01','F Y') ?></h2></div>
  <form method="get"><input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()"></form></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th class="num">Net Salary</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><b><?= e($r['full_name']) ?></b> <span class="text-muted">(<?= e($r['emp_code']) ?>)</span></td>
    <td class="num"><?= money($r['net_salary']) ?></td>
    <td><span class="pill <?= $r['status']==='Paid'?'pill-success':'pill-warning' ?>"><?= e($r['status']) ?></span></td>
    <td class="text-right"><a class="btn btn-sm" href="<?= url('admin/salary_slip.php?id='.$r['id']) ?>" target="_blank">🧾 View / Print</a></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="4" class="empty">No payroll generated for this month.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
