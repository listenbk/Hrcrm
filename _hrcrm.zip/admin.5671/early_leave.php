<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('attendance.view');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    if (!has_perm('attendance.manage')) { http_response_code(403); exit; }
    $id=(int)param('id',0,'POST'); $st=param('early_status','Pending','POST');
    $remark=trim((string)param('admin_remark','','POST'));
    // Accountability: no one approves their own early-leave.
    $ownerUid=(int)fetch_col("SELECT e.user_id FROM attendance a JOIN employees e ON e.id=a.employee_id WHERE a.id=?", [$id]);
    if ($ownerUid && $ownerUid === (int)current_user()['id']) {
        flash_error('You cannot decide your own early-leave.'); redirect('admin/early_leave.php');
    }
    if (in_array($st,['Pending','Approved','Rejected'],true)) {
        q("UPDATE attendance SET early_status=?, admin_remark=? WHERE id=?", [$st,$remark,$id]);
        audit_log('early_leave_updated','attendance',$id,"Early leave $st");
        flash_success('Early-leave status updated.');
    }
    redirect('admin/early_leave.php');
}
$from=(string)param('from',date('Y-m-01')); $to=(string)param('to',date('Y-m-d'));
$rows=fetch_all(
  "SELECT a.*, e.full_name,e.emp_code FROM attendance a JOIN employees e ON e.id=a.employee_id
   WHERE a.early_minutes>0 AND e.is_staff=0 AND a.att_date BETWEEN ? AND ? ORDER BY a.att_date DESC",[$from,$to]);
$pageTitle='Early Leave'; $activeNav='att_early';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Early Leave</h2></div></div>
<form method="get" class="filters">
  <div class="form-group"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
  <div class="form-group"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Date</th><th>Employee</th><th>Check Out</th><th>Left Early</th><th>Reason</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><?= fmt_date($r['att_date']) ?></td><td><b><?= e($r['full_name']) ?></b></td>
    <td><?= $r['check_out']?fmt_date($r['check_out'],'h:i A'):'—' ?></td>
    <td><span class="pill pill-info"><?= $r['early_minutes'] ?> min</span></td>
    <td><?= e($r['early_reason'] ?: '—') ?></td>
    <td><?php $p=['Approved'=>'pill-success','Rejected'=>'pill-danger','Pending'=>'pill-warning'][$r['early_status']]??'pill-muted'; ?>
      <span class="pill <?= $p ?>"><?= e($r['early_status'] ?: 'Pending') ?></span></td>
    <td class="text-right"><?php if(has_perm('attendance.manage')): ?>
      <button class="btn btn-sm btn-outline" data-modal="elModal"
        onclick='elForm(<?= json_encode(["id"=>$r["id"],"early_status"=>$r["early_status"],"admin_remark"=>$r["admin_remark"]]) ?>)'>Review</button>
      <?php endif; ?></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="7" class="empty">No early-leave records.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="elModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Review Early Leave</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="id" id="el_id">
    <div class="form-group"><label>Status</label><select name="early_status" id="el_status">
      <option>Pending</option><option>Approved</option><option>Rejected</option></select></div>
    <div class="form-group"><label>Admin Remark</label><input type="text" name="admin_remark" id="el_remark"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function elForm(d){document.getElementById('el_id').value=d.id;document.getElementById('el_status').value=d.early_status||'Pending';document.getElementById('el_remark').value=d.admin_remark||'';}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
