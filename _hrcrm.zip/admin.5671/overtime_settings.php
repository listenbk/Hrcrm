<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('overtime.config');   // Super Admin

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    if ($act === 'settings') {
        foreach (['ot_enabled','ot_min_minutes','ot_rate_mode','ot_fixed_hourly','ot_monthly_standard_hours',
                  'ot_rounding','ot_max_daily_hours','ot_max_monthly_hours','ot_checkin_after'] as $k) {
            if ($k === 'ot_enabled') { set_setting($k, param('ot_enabled',0,'POST') ? '1' : '0'); continue; }
            if (array_key_exists($k, $_POST)) set_setting($k, trim((string)$_POST[$k]));
        }
        audit_log('overtime_settings_updated','settings',null,'Updated overtime settings');
        flash_success('Overtime settings saved.');
    } elseif ($act === 'rates') {
        $ids = param('rate_id', [], 'POST'); $mults = param('mult', [], 'POST'); $active = param('active', [], 'POST');
        if (is_array($ids)) {
            foreach ($ids as $i => $rid) {
                $rid=(int)$rid; $m=(float)($mults[$i] ?? 1); $a=!empty($active[$rid]) ? 1 : 0;
                q("UPDATE overtime_rates SET multiplier=?, is_active=? WHERE id=?", [$m,$a,$rid]);
            }
            audit_log('overtime_rates_updated','settings',null,'Updated overtime multipliers');
            flash_success('Overtime multipliers saved.');
        }
    }
    redirect('admin/overtime_settings.php');
}

$s = settings_all(true);
$rates = fetch_all("SELECT * FROM overtime_rates ORDER BY sort_order");
$pageTitle='Overtime Settings'; $activeNav='ot_settings';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Overtime Settings</h2>
  <div class="breadcrumb">Configure overtime eligibility, rate method, rounding and per-day-type multipliers.</div></div></div>

<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>⚙️ Rules</h3></div><div class="card-body">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="settings">
      <div class="form-group"><label class="switch"><input type="checkbox" name="ot_enabled" <?= ($s['ot_enabled']??'1')==='1'?'checked':'' ?>> Overtime enabled</label></div>
      <div class="form-row">
        <div class="form-group"><label>Minimum OT (minutes)</label><input type="number" name="ot_min_minutes" value="<?= e($s['ot_min_minutes']??'30') ?>">
          <div class="help">Below this, no overtime is counted.</div></div>
        <div class="form-group"><label>Rounding</label><select name="ot_rounding">
          <?php foreach(['exact'=>'Exact minutes','nearest15'=>'Nearest 15 min','nearest30'=>'Nearest 30 min','down'=>'Round down (hour)','up'=>'Round up (hour)'] as $k=>$v): ?>
          <option value="<?= $k ?>" <?= ($s['ot_rounding']??'nearest30')===$k?'selected':'' ?>><?= $v ?></option><?php endforeach; ?>
        </select></div>
      </div>
      <div class="form-group"><label>Rate Method</label><select name="ot_rate_mode">
        <option value="salary" <?= ($s['ot_rate_mode']??'salary')==='salary'?'selected':'' ?>>Salary-based (Monthly Salary ÷ Standard Hours)</option>
        <option value="fixed" <?= ($s['ot_rate_mode']??'')==='fixed'?'selected':'' ?>>Fixed hourly rate</option>
      </select></div>
      <div class="form-row">
        <div class="form-group"><label>Fixed Hourly Rate (₹)</label><input type="number" step="0.01" name="ot_fixed_hourly" value="<?= e($s['ot_fixed_hourly']??'150') ?>"></div>
        <div class="form-group"><label>Monthly Standard Hours</label><input type="number" name="ot_monthly_standard_hours" value="<?= e($s['ot_monthly_standard_hours']??'200') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Max OT / Day (hrs)</label><input type="number" step="0.5" name="ot_max_daily_hours" value="<?= e($s['ot_max_daily_hours']??'5') ?>"></div>
        <div class="form-group"><label>Max OT / Month (hrs)</label><input type="number" step="0.5" name="ot_max_monthly_hours" value="<?= e($s['ot_max_monthly_hours']??'60') ?>"></div>
      </div>
      <div class="form-group"><label>Overtime Check-In Allowed From</label><input type="time" name="ot_checkin_after" value="<?= e($s['ot_checkin_after']??'20:00') ?>">
        <div class="help">Employees cannot start an Overtime Check-In before this time, regardless of when normal attendance ended.</div></div>
      <button class="btn">💾 Save Rules</button>
    </form>
  </div></div>

  <div class="card"><div class="card-head"><h3>📊 Day-Type Multipliers</h3></div><div class="card-body">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="rates">
      <table class="data"><thead><tr><th>Day Type</th><th>Multiplier</th><th>Active</th></tr></thead>
      <tbody><?php foreach($rates as $rt): ?>
        <tr><td><b><?= e($rt['label']) ?></b><input type="hidden" name="rate_id[]" value="<?= $rt['id'] ?>"></td>
        <td><input type="number" step="0.05" name="mult[]" value="<?= e($rt['multiplier']) ?>" style="width:90px">×</td>
        <td><label class="switch"><input type="checkbox" name="active[<?= $rt['id'] ?>]" value="1" <?= $rt['is_active']?'checked':'' ?>></label></td></tr>
      <?php endforeach; ?></tbody></table>
      <button class="btn mt-2">💾 Save Multipliers</button>
    </form>
    <p class="help mt-2">Example: Regular 1.0× · Sunday 1.5× · Public Holiday 2.0×.</p>
  </div></div>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
