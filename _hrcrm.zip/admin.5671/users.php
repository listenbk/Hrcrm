<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('users.manage');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='save') {
        $id=(int)param('id',0,'POST'); $name=trim((string)param('name','','POST'));
        $email=strtolower(trim((string)param('email','','POST'))); $role=(int)param('role_id',3,'POST');
        $active=param('is_active',0,'POST')?1:0; $pw=trim((string)param('password','','POST'));
        if ($name!=='' && valid_email($email)) {
            if ($id) {
                q("UPDATE users SET name=?,email=?,role_id=?,is_active=? WHERE id=?",[$name,$email,$role,$active,$id]);
                if ($pw!=='') { q("UPDATE users SET password_hash=?, failed_attempts=0, locked_until=NULL WHERE id=?",[password_hash($pw,PASSWORD_DEFAULT),$id]); bump_auth_version($id); audit_log('password_reset','user',$id,"Reset password for $email"); }
                audit_log('user_edited','user',$id,$email);
            } else {
                if (fetch_col("SELECT COUNT(*) FROM users WHERE email=?",[$email])==0 && $pw!=='') {
                    q("INSERT INTO users (role_id,name,email,password_hash,is_active) VALUES (?,?,?,?,?)",[$role,$name,$email,password_hash($pw,PASSWORD_DEFAULT),$active]);
                    audit_log('user_created','user',insert_id(),$email);
                } else { flash_error('Email exists or password missing.'); redirect('admin/users.php'); }
            }
            flash_success('User saved.');
        }
    } elseif ($act==='delete') {
        $id=(int)param('id',0,'POST');
        $pw=(string)param('confirm_password','','POST');
        $reason=trim((string)param('reason','','POST'));
        $target=fetch_one("SELECT u.*, r.slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?",[$id]);
        if (!verify_current_password($pw)) {
            flash_error('Incorrect password — account not deleted.');
        } elseif (!$target) {
            flash_error('User not found.');
        } elseif ($id === (int)current_user()['id']) {
            flash_error('You cannot delete your own account.');
        } elseif ($target['slug']==='super_admin'
                  && (int)fetch_col("SELECT COUNT(*) FROM users WHERE role_id=(SELECT id FROM roles WHERE slug='super_admin') AND is_active=1") <= 1) {
            flash_error('Cannot delete the last active Super Admin.');
        } else {
            q("DELETE FROM users WHERE id=?",[$id]);
            audit_log('user_deleted','user',$id,
                "Deleted account {$target['email']} ({$target['slug']})".($reason?" — Reason: {$reason}":''),$target,null);
            flash_success('User account deleted.');
        }
    }
    redirect('admin/users.php');
}
$rows=fetch_all("SELECT u.*, r.name AS role_name FROM users u JOIN roles r ON r.id=u.role_id ORDER BY u.id");
$roles=fetch_all("SELECT id,name FROM roles ORDER BY id");
$pageTitle='Users'; $activeNav='users';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>User Accounts</h2></div>
  <button class="btn" data-modal="usModal" onclick="usForm()">➕ Add User</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Last Login</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><b><?= e($r['name']) ?></b></td><td><?= e($r['email']) ?></td>
    <td><span class="pill pill-info"><?= e($r['role_name']) ?></span></td>
    <td class="text-muted"><?= $r['last_login_at']?fmt_date($r['last_login_at'],'d M Y h:i A'):'Never' ?></td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Disabled' ?></span></td>
    <td class="text-right" style="white-space:nowrap">
      <button class="btn btn-sm btn-outline" data-modal="usModal" onclick='usForm(<?= json_encode(["id"=>$r["id"],"name"=>$r["name"],"email"=>$r["email"],"role_id"=>$r["role_id"],"is_active"=>$r["is_active"]]) ?>)'>Edit</button>
      <?php if ($r['id'] !== (int)current_user()['id']): ?>
      <button class="btn btn-sm btn-danger" data-modal="delUserModal" onclick='delUser(<?= (int)$r['id'] ?>,<?= json_encode($r['name'].' ('.$r['role_name'].')') ?>)'>Delete</button>
      <?php endif; ?>
    </td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<div class="modal-overlay" id="usModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="usTitle">Add User</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="us_id">
    <div class="form-group"><label>Name <span class="req">*</span></label><input type="text" name="name" id="us_name" required></div>
    <div class="form-group"><label>Email <span class="req">*</span></label><input type="email" name="email" id="us_email" required></div>
    <div class="form-group"><label>Role</label><select name="role_id" id="us_role">
      <?php foreach($roles as $ro): ?><option value="<?= $ro['id'] ?>"><?= e($ro['name']) ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Password <span id="us_pwhint" class="help" style="display:inline"></span></label><input type="text" name="password" id="us_pw" placeholder="Leave blank to keep current"></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="us_act" checked> Active</label></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<div class="modal-overlay" id="delUserModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Delete User Account</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" id="del_user_id">
    <div class="alert alert-error">You are about to permanently delete <b id="del_user_name"></b>. This cannot be undone.</div>
    <div class="form-group"><label>Enter your <?= is_super_admin()?'Manager':'admin' ?> password <span class="req">*</span></label>
      <div class="pwd-wrap"><input type="password" name="confirm_password" required autocomplete="off" placeholder="Your own password">
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
    <div class="form-group"><label>Reason</label><input type="text" name="reason" placeholder="e.g. Employee resigned"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-danger">Confirm Delete</button></div>
</form></div></div>
<script>
function delUser(id,label){document.getElementById('del_user_id').value=id;document.getElementById('del_user_name').textContent=label;}
function usForm(d){d=d||{};usTitle.textContent=d.id?'Edit User':'Add User';
  us_id.value=d.id||'';us_name.value=d.name||'';us_email.value=d.email||'';us_role.value=d.role_id||3;
  us_act.checked=d.id?d.is_active==1:true;us_pw.value='';us_pw.placeholder=d.id?'Leave blank to keep current':'Required for new user';}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
