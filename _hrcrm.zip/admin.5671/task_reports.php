<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('tasks.manage');

$fEmp  = (int)param('emp', 0);
$fFrom = (string)param('from', date('Y-m-01'));
$fTo   = (string)param('to', date('Y-m-d'));

$where = []; $args = [];
if ($fEmp > 0) { $where[] = "r.employee_id = ?"; $args[] = $fEmp; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$fFrom)) { $where[] = "r.report_date >= ?"; $args[] = $fFrom; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$fTo))   { $where[] = "r.report_date <= ?"; $args[] = $fTo; }
$whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

$reports = fetch_all(
  "SELECT r.*, e.full_name, e.emp_code
   FROM daily_reports r JOIN employees e ON e.id=r.employee_id
   $whereSql ORDER BY r.report_date DESC, e.full_name LIMIT 500", $args);

$emps = fetch_all(
  "SELECT id, emp_code, full_name FROM employees
   WHERE (status IS NULL OR status NOT IN ('Resigned','Terminated')) ORDER BY full_name");

$pageTitle='Daily Reports'; $activeNav='task_reports';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>End-of-Day Reports</h2><div class="breadcrumb"><?= count($reports) ?> report(s)</div></div></div>

<form method="get" class="filters">
  <div class="form-group"><label>Employee</label><select name="emp"><option value="0">All</option>
    <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>" <?= $fEmp==$em['id']?'selected':'' ?>><?= e($em['full_name'].' — '.$em['emp_code']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>From</label><input type="date" name="from" value="<?= e($fFrom) ?>"></div>
  <div class="form-group"><label>To</label><input type="date" name="to" value="<?= e($fTo) ?>"></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button>
    <a class="btn btn-sm" href="<?= url('admin/task_reports.php') ?>" style="margin-left:6px">Reset</a></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Date</th><th>Employee</th><th>Summary</th><th>Blockers</th><th class="num">Hours</th></tr></thead>
  <tbody><?php foreach($reports as $r): ?>
    <tr>
      <td class="text-muted"><?= fmt_date($r['report_date']) ?></td>
      <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
      <td style="white-space:pre-wrap;max-width:420px"><?= e($r['summary']) ?></td>
      <td class="text-muted" style="white-space:pre-wrap;max-width:220px"><?= e($r['blockers'] ?: '—') ?></td>
      <td class="num"><?= $r['hours_worked']!==null ? e(rtrim(rtrim(number_format((float)$r['hours_worked'],1),'0'),'.')).'h' : '—' ?></td>
    </tr>
  <?php endforeach; if(!$reports): ?><tr><td colspan="5" class="empty">No reports for this range.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
