<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('overtime.view');
$me = current_user();

// Team Leaders only act on overtime for employees assigned to them; Super
// Admin (and, for review only, HR) are unrestricted.
$isTL = is_team_leader();
$canApprove = has_perm('overtime.approve');   // Team Leader (own team) / Super Admin

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    $id  = (int)param('id', 0, 'POST');
    $ot  = fetch_one("SELECT o.*, e.full_name, e.user_id, e.team_leader_id FROM overtime o JOIN employees e ON e.id=o.employee_id WHERE o.id=?", [$id]);
    if (!$ot) { flash_error('Overtime record not found.'); redirect('admin/overtime.php'); }
    // Accountability: no one reviews/approves their own overtime.
    if (!empty($ot['user_id']) && (int)$ot['user_id'] === (int)current_user()['id']) {
        flash_error('You cannot review or approve your own overtime.');
        redirect('admin/overtime.php');
    }
    // A Team Leader may only act on their own assigned team's overtime.
    if ($isTL && (int)($ot['team_leader_id'] ?? 0) !== (int)$me['id']) {
        flash_error('This employee is not on your team.');
        redirect('admin/overtime.php');
    }

    if ($act === 'hr_review') {
        // HR recommendation / forward to Manager (no final approval)
        $remark = trim((string)param('hr_remark', '', 'POST'));
        if (in_array($ot['status'], ['Detected','Pending Approval','HR Reviewed'], true)) {
            q("UPDATE overtime SET hr_remark=?, hr_by=?, hr_at=NOW(), status='HR Reviewed' WHERE id=?",
              [$remark, current_user()['id'], $id]);
            audit_log('overtime_hr_reviewed','overtime',$id,"HR reviewed OT for {$ot['full_name']}");
            flash_success('Recommendation saved and forwarded to Manager.');
        }
    } elseif ($act === 'approve' && $canApprove) {
        $approvedHours = max(0, (float)param('approved_hours', $ot['actual_hours'], 'POST'));
        $mult = (float)param('multiplier', $ot['multiplier'], 'POST');
        $rate = (float)param('hourly_rate', $ot['hourly_rate'], 'POST');
        $dayType = trim((string)param('day_type', $ot['day_type'], 'POST'));
        $remark = trim((string)param('manager_remark', '', 'POST'));
        $include = param('include_in_payroll', 0, 'POST') ? 1 : 0;
        $amount = ot_recalc_amount($approvedHours, $rate, $mult);
        $status = $approvedHours < (float)$ot['actual_hours'] ? 'Partially Approved' : 'Approved';
        q("UPDATE overtime SET approved_hours=?, multiplier=?, hourly_rate=?, day_type=?, amount=?,
             manager_remark=?, approved_by=?, approved_at=NOW(), include_in_payroll=?, status=? WHERE id=?",
          [$approvedHours,$mult,$rate,$dayType,$amount,$remark,current_user()['id'],$include,$status,$id]);
        if (!empty($ot['user_id'])) {
            notify((int)$ot['user_id'],'overtime_approved','Overtime approved',
                "Your overtime on ".fmt_date($ot['ot_date'])." was approved: {$approvedHours}h = ".money($amount).".",
                url('employee/overtime.php'));
        }
        audit_log('overtime_approved','overtime',$id,"OT {$status} for {$ot['full_name']}: {$approvedHours}h = ".money($amount),
            ['actual_hours'=>$ot['actual_hours']],['approved_hours'=>$approvedHours,'amount'=>$amount]);
        flash_success("Overtime {$status} — ".money($amount).".");
    } elseif ($act === 'reject' && $canApprove) {
        $remark = trim((string)param('manager_remark', '', 'POST'));
        q("UPDATE overtime SET status='Rejected', manager_remark=?, approved_by=?, approved_at=NOW(), amount=0 WHERE id=?",
          [$remark, current_user()['id'], $id]);
        if (!empty($ot['user_id'])) {
            notify((int)$ot['user_id'],'overtime_rejected','Overtime rejected',
                "Your overtime on ".fmt_date($ot['ot_date'])." was not approved.", url('employee/overtime.php'));
        }
        audit_log('overtime_rejected','overtime',$id,"OT rejected for {$ot['full_name']}");
        flash_error('Overtime rejected.');
    }
    redirect('admin/overtime.php?' . http_build_query(['month'=>param('month','','POST'),'status'=>param('status_f','','POST')]));
}

$month  = (string)param('month', date('Y-m'));
$statusF= (string)param('status', '');
$start = $month.'-01'; $end = date('Y-m-t', strtotime($start));
$where = ['o.ot_date BETWEEN ? AND ?']; $args=[$start,$end];
if ($statusF !== '') { $where[]='o.status=?'; $args[]=$statusF; }
// Team Leaders only see overtime for employees assigned to them.
if ($isTL) { $where[]='e.team_leader_id=?'; $args[]=$me['id']; }

$rows = fetch_all(
  "SELECT o.*, e.full_name, e.emp_code FROM overtime o JOIN employees e ON e.id=o.employee_id
   WHERE ".implode(' AND ',$where)." ORDER BY o.ot_date DESC, e.full_name", $args);

$teamScope = $isTL ? " AND e.team_leader_id={$me['id']}" : '';
$costApproved = (float)fetch_col("SELECT COALESCE(SUM(amount),0) FROM overtime o JOIN employees e ON e.id=o.employee_id WHERE o.ot_date BETWEEN ? AND ? AND o.status IN ('Approved','Partially Approved','Paid')$teamScope", [$start,$end]);
$pendingCount = (int)fetch_col("SELECT COUNT(*) FROM overtime o JOIN employees e ON e.id=o.employee_id WHERE o.status IN ('Detected','Pending Approval','HR Reviewed')$teamScope");
$rates = fetch_all("SELECT * FROM overtime_rates WHERE is_active=1 ORDER BY sort_order");

$pageTitle='Overtime'; $activeNav='overtime';
require __DIR__ . '/../templates/header.php';

function ot_status_pill(string $s): string {
    $m=['Detected'=>'pill-muted','Pending Approval'=>'pill-warning','HR Reviewed'=>'pill-info',
        'Approved'=>'pill-success','Partially Approved'=>'pill-info','Rejected'=>'pill-danger','Paid'=>'pill-success'];
    return '<span class="pill '.($m[$s]??'pill-muted').'">'.e($s).'</span>';
}
?>
<div class="page-head">
  <div><h2>Overtime <?= $canApprove?'Management':'Review' ?><?= $isTL?' — My Team':'' ?></h2>
    <div class="breadcrumb"><?= $canApprove
        ? ($isTL ? 'Approve overtime for your assigned team.' : 'Approve, modify hours/rate and mark overtime for payroll.')
        : 'Review overtime and forward recommendations (final approval is the employee\'s assigned Team Leader\'s, or Super Admin\'s).' ?></div></div>
</div>

<div class="grid cols-3 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-brand">💵</div><div><div class="label">OT Cost — <?= fmt_date($start,'M Y') ?></div><div class="value" style="font-size:18px"><?= money($costApproved) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏳</div><div><div class="label">Awaiting Approval</div><div class="value"><?= $pendingCount ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-slate">📄</div><div><div class="label">Records This Month</div><div class="value"><?= count($rows) ?></div></div></div></div>
</div>

<form method="get" class="filters">
  <div class="form-group"><label>Month</label><input type="month" name="month" value="<?= e($month) ?>"></div>
  <div class="form-group"><label>Status</label><select name="status"><option value="">All</option>
    <?php foreach(['Detected','Pending Approval','HR Reviewed','Approved','Partially Approved','Rejected','Paid'] as $s): ?>
    <option <?= $statusF===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Date</th><th>Day Type</th><th>Out (std → actual)</th><th class="num">Actual</th>
    <th class="num">Approved</th><th class="num">Rate×Mult</th><th class="num">Amount</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr>
      <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div>
        <?php if($r['employee_reason']): ?><div class="text-muted" style="font-size:11px;max-width:180px">“<?= e($r['employee_reason']) ?>”</div><?php endif; ?>
        <?php if($r['project_name']): ?><div class="text-muted" style="font-size:11px">📁 <?= e($r['project_name']) ?></div><?php endif; ?></td>
      <td><?= fmt_date($r['ot_date']) ?></td>
      <td><span class="pill pill-muted"><?= e(ot_day_type_label($r['day_type'])) ?></span></td>
      <td class="text-muted" style="font-size:12px"><?= $r['standard_out']?fmt_date($r['standard_out'],'h:i A'):'—' ?> → <?= $r['actual_out']?fmt_date($r['actual_out'],'h:i A'):'—' ?></td>
      <td class="num"><?= rtrim(rtrim(number_format($r['actual_hours'],2),'0'),'.') ?>h</td>
      <td class="num"><?= $r['approved_hours']>0?rtrim(rtrim(number_format($r['approved_hours'],2),'0'),'.').'h':'—' ?></td>
      <td class="num"><?= money($r['hourly_rate'],false) ?>×<?= rtrim(rtrim(number_format($r['multiplier'],2),'0'),'.') ?></td>
      <td class="num"><b><?= $r['amount']>0?money($r['amount']):'—' ?></b></td>
      <td><?= ot_status_pill($r['status']) ?><?php if($r['status']==='Paid'&&$r['payroll_id']): ?><div class="text-muted" style="font-size:10px">payroll #<?= $r['payroll_id'] ?></div><?php endif; ?></td>
      <td class="text-right" style="white-space:nowrap">
        <?php if(!in_array($r['status'],['Paid','Rejected'],true)): ?>
          <?php if($canApprove): ?>
            <button class="btn btn-sm btn-success" data-modal="apprModal" onclick='apprForm(<?= json_encode($r) ?>)'>Approve</button>
            <button class="btn btn-sm btn-danger" data-modal="rejModal" onclick='document.getElementById("rej_id").value=<?= (int)$r['id'] ?>'>Reject</button>
          <?php else: ?>
            <button class="btn btn-sm btn-outline" data-modal="hrModal" onclick='document.getElementById("hr_id").value=<?= (int)$r['id'] ?>'>Review</button>
          <?php endif; ?>
        <?php else: echo '—'; endif; ?>
      </td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="10" class="empty">No overtime records for this month.</td></tr><?php endif; ?></tbody>
</table></div></div>

<!-- HR review modal -->
<div class="modal-overlay" id="hrModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>HR Recommendation</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="hr_review"><input type="hidden" name="id" id="hr_id">
    <input type="hidden" name="month" value="<?= e($month) ?>"><input type="hidden" name="status_f" value="<?= e($statusF) ?>">
    <div class="form-group"><label>HR Remark</label><textarea name="hr_remark" placeholder="Recommendation / comment for the Manager"></textarea></div>
    <p class="help">This forwards the record to the Manager for final approval.</p>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Forward to Manager</button></div>
</form></div></div>

<?php if($canApprove): ?>
<!-- Approve modal -->
<div class="modal-overlay" id="apprModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Approve Overtime</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="approve"><input type="hidden" name="id" id="ap_id">
    <input type="hidden" name="month" value="<?= e($month) ?>"><input type="hidden" name="status_f" value="<?= e($statusF) ?>">
    <p class="text-muted">Employee: <b id="ap_emp"></b> · Recorded OT: <b id="ap_actual"></b></p>
    <div class="form-row">
      <div class="form-group"><label>Approved Hours</label><input type="number" step="0.25" name="approved_hours" id="ap_hours"></div>
      <div class="form-group"><label>Day Type</label><select name="day_type" id="ap_daytype" onchange="apRate()">
        <?php foreach($rates as $rt): ?><option value="<?= e($rt['day_type']) ?>" data-mult="<?= e($rt['multiplier']) ?>"><?= e($rt['label']) ?> (<?= rtrim(rtrim(number_format($rt['multiplier'],2),'0'),'.') ?>×)</option><?php endforeach; ?>
      </select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Hourly Rate (₹)</label><input type="number" step="0.01" name="hourly_rate" id="ap_rate" oninput="apAmt()"></div>
      <div class="form-group"><label>Multiplier</label><input type="number" step="0.05" name="multiplier" id="ap_mult" oninput="apAmt()"></div>
    </div>
    <div class="alert alert-info">Payable overtime: <b id="ap_amount">₹0.00</b></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="include_in_payroll" id="ap_incl" value="1" checked> Include in payroll</label></div>
    <div class="form-group"><label>Manager Remark</label><input type="text" name="manager_remark"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-success">Approve</button></div>
</form></div></div>

<!-- Reject modal -->
<div class="modal-overlay" id="rejModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Reject Overtime</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="reject"><input type="hidden" name="id" id="rej_id">
    <input type="hidden" name="month" value="<?= e($month) ?>"><input type="hidden" name="status_f" value="<?= e($statusF) ?>">
    <div class="form-group"><label>Reason</label><input type="text" name="manager_remark" placeholder="Why is this overtime rejected?"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-danger">Reject</button></div>
</form></div></div>
<script>
function apprForm(o){
  document.getElementById('ap_id').value=o.id;
  document.getElementById('ap_emp').textContent=o.full_name;
  document.getElementById('ap_actual').textContent=(+o.actual_hours)+'h';
  document.getElementById('ap_hours').value=(+o.approved_hours>0?+o.approved_hours:+o.actual_hours);
  document.getElementById('ap_daytype').value=o.day_type;
  document.getElementById('ap_rate').value=(+o.hourly_rate).toFixed(2);
  document.getElementById('ap_mult').value=(+o.multiplier);
  apAmt();
}
function apRate(){var s=document.getElementById('ap_daytype');var m=s.options[s.selectedIndex].getAttribute('data-mult');if(m)document.getElementById('ap_mult').value=m;apAmt();}
function apAmt(){var h=+document.getElementById('ap_hours').value||0,r=+document.getElementById('ap_rate').value||0,m=+document.getElementById('ap_mult').value||0;
  document.getElementById('ap_amount').textContent='₹'+(h*r*m).toLocaleString('en-IN',{minimumFractionDigits:2,maximumFractionDigits:2});}
document.getElementById('ap_hours').addEventListener('input',apAmt);
</script>
<?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
