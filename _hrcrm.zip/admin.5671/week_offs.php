<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('weekoff.manage');
$me = current_user();
$weekdays = [0=>'Sunday',1=>'Monday',2=>'Tuesday',3=>'Wednesday',4=>'Thursday',5=>'Friday',6=>'Saturday'];
$weekShort = [0=>'Sun',1=>'Mon',2=>'Tue',3=>'Wed',4=>'Thu',5=>'Fri',6=>'Sat'];

$companyDefault = array_filter(array_map('trim', explode(',', (string)setting('weekly_offs', ''))), 'strlen');
$companyDefaultLabel = $companyDefault
    ? implode(', ', array_map(fn($n) => $weekShort[(int)$n] ?? $n, $companyDefault))
    : 'None set';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    $eid = (int)param('id', 0, 'POST');
    $emp = fetch_one("SELECT id, full_name, emp_code FROM employees WHERE id=? AND is_staff=0", [$eid]);
    if (!$emp) {
        flash_error('Employee not found.');
    } elseif ($act === 'save') {
        $days = param('days', [], 'POST');
        if (!is_array($days)) $days = [];
        $days = array_values(array_unique(array_filter(array_map('intval', $days), fn($n) => $n >= 0 && $n <= 6)));
        sort($days);
        $value = $days ? implode(',', $days) : null;
        q("UPDATE employees SET week_off_days=? WHERE id=?", [$value, $eid]);
        $label = $days ? implode(', ', array_map(fn($n) => $weekShort[$n], $days)) : '(no weekly off)';
        audit_log('weekoff_updated', 'employee', $eid,
            "Set custom week-off for {$emp['full_name']} ({$emp['emp_code']}) to {$label}");
        if (!empty($eid)) {
            $u = fetch_col("SELECT user_id FROM employees WHERE id=?", [$eid]);
            if ($u) notify((int)$u, 'weekoff_updated', 'Weekly off updated',
                "Your weekly off has been set to {$label} by {$me['name']}.", url('employee/attendance.php'));
        }
        flash_success("Week-off updated for {$emp['full_name']}.");
    } elseif ($act === 'reset') {
        q("UPDATE employees SET week_off_days=NULL WHERE id=?", [$eid]);
        audit_log('weekoff_reset', 'employee', $eid,
            "Reset {$emp['full_name']} ({$emp['emp_code']}) to the company default week-off");
        flash_success("Week-off reset to company default for {$emp['full_name']}.");
    }
    redirect('admin/week_offs.php');
}

$search = trim((string)param('q', ''));
$where = ['is_staff=0']; $args = [];
if ($search !== '') {
    $where[] = "(full_name LIKE ? OR emp_code LIKE ?)";
    $like = "%$search%"; array_push($args, $like, $like);
}
$emps = fetch_all(
  "SELECT id, emp_code, full_name, week_off_days FROM employees
   WHERE ".implode(' AND ', $where)."
   ORDER BY full_name", $args);

$pageTitle='Week-Off Management'; $activeNav='week_offs';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Week-Off Management</h2>
  <div class="breadcrumb">Company default: <b><?= e($companyDefaultLabel) ?></b> &middot; set custom days per employee below</div></div></div>

<form method="get" class="filters"><div class="form-group"><label>Search</label>
  <input type="search" name="q" value="<?= e($search) ?>" placeholder="Employee name or ID"></div>
  <div class="form-group"><button class="btn btn-outline">Search</button></div></form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Weekly Off</th><th>Source</th><th></th></tr></thead>
  <tbody><?php foreach($emps as $em):
    $custom = $em['week_off_days'] !== null && trim((string)$em['week_off_days']) !== '';
    $days = $custom ? array_filter(array_map('trim', explode(',', $em['week_off_days'])), 'strlen') : $companyDefault;
    $label = $days ? implode(', ', array_map(fn($n) => $weekShort[(int)$n] ?? $n, $days)) : 'None';
  ?>
    <tr>
      <td><b><?= e($em['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($em['emp_code']) ?></div></td>
      <td><?= e($label) ?></td>
      <td><?php if($custom): ?><span class="pill pill-info">Custom</span><?php else: ?><span class="pill pill-muted">Company Default</span><?php endif; ?></td>
      <td class="text-right">
        <button class="btn btn-sm btn-outline" data-modal="woModal"
          onclick='woForm(<?= json_encode(["id"=>$em["id"],"name"=>$em["full_name"],"days"=>array_map("intval",$days)]) ?>)'>Manage</button>
        <?php if($custom): ?>
        <form method="post" style="display:inline" data-confirm="Reset <?= e($em['full_name']) ?> to the company default week-off?">
          <?= csrf_field() ?><input type="hidden" name="do" value="reset"><input type="hidden" name="id" value="<?= $em['id'] ?>">
          <button class="btn btn-sm btn-danger">Reset</button></form>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; if(!$emps): ?><tr><td colspan="4" class="empty">No employees found.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="woModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="woTitle">Set Weekly Off</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="wo_id">
    <p class="text-muted" id="wo_info"></p>
    <div class="form-group"><label>Weekly Off Day(s)</label>
      <div class="form-row-3" id="wo_days">
        <?php foreach($weekdays as $n=>$wd): ?>
        <label class="switch"><input type="checkbox" name="days[]" value="<?= $n ?>" class="wo_day_cb" data-day="<?= $n ?>"> <?= $wd ?></label>
        <?php endforeach; ?>
      </div>
      <div class="help">Adjustable anytime by HR or the employee's Team Leader. Leave all unchecked for no weekly off.</div>
    </div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>
function woForm(o){
  document.getElementById('woTitle').textContent='Set Weekly Off — '+o.name;
  document.getElementById('wo_id').value=o.id;
  document.getElementById('wo_info').textContent='Choose which day(s) of the week are off for '+o.name+'.';
  document.querySelectorAll('.wo_day_cb').forEach(function(cb){
    cb.checked = o.days.indexOf(parseInt(cb.getAttribute('data-day'),10)) !== -1;
  });
}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
