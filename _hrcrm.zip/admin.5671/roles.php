<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('roles.manage');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='save_role') {
        $id=(int)param('id',0,'POST'); $name=trim((string)param('name','','POST'));
        $desc=trim((string)param('description','','POST'));
        if ($name!=='') {
            if ($id) q("UPDATE roles SET name=?,description=? WHERE id=?",[$name,$desc,$id]);
            else     q("INSERT INTO roles (name,slug,description) VALUES (?,?,?)",[$name,slugify($name).'_'.substr(md5($name.microtime()),0,4),$desc]);
            audit_log('role_saved','role',$id?:insert_id(),$name); flash_success('Role saved.');
        }
    } elseif ($act==='save_perms') {
        $roleId=(int)param('role_id',0,'POST');
        $perms=param('perms',[],'POST'); if(!is_array($perms))$perms=[];
        $role=fetch_one("SELECT * FROM roles WHERE id=?",[$roleId]);
        if ($role && $role['slug']!=='super_admin') {
            q("DELETE FROM role_permissions WHERE role_id=?",[$roleId]);
            foreach ($perms as $pid) q("INSERT IGNORE INTO role_permissions (role_id,permission_id) VALUES (?,?)",[$roleId,(int)$pid]);
            audit_log('permissions_changed','role',$roleId,"Updated permissions for {$role['name']}");
            flash_success('Permissions updated.');
        } else { flash_error('Super Admin permissions cannot be changed.'); }
    } elseif ($act==='delete') {
        $id=(int)param('id',0,'POST'); $role=fetch_one("SELECT * FROM roles WHERE id=?",[$id]);
        if ($role && !$role['is_system']) { q("DELETE FROM roles WHERE id=?",[$id]); flash_success('Role deleted.'); }
        else flash_error('System roles cannot be deleted.');
    }
    redirect('admin/roles.php'.($sel=param('role')?'?role='.(int)$sel:''));
}
$roles=fetch_all("SELECT * FROM roles ORDER BY id");
$selId=(int)param('role', $roles[0]['id'] ?? 0);
$selRole=fetch_one("SELECT * FROM roles WHERE id=?",[$selId]);
$perms=fetch_all("SELECT * FROM permissions ORDER BY module,name");
$assigned=[];
foreach(fetch_all("SELECT permission_id FROM role_permissions WHERE role_id=?",[$selId]) as $rp) $assigned[(int)$rp['permission_id']]=true;
$byModule=[]; foreach($perms as $p) $byModule[$p['module']][]=$p;
$pageTitle='Roles & Permissions'; $activeNav='roles';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Roles &amp; Permissions</h2></div>
  <button class="btn" data-modal="roModal" onclick="roForm()">➕ Add Role</button></div>
<div class="grid cols-3">
  <div class="card"><div class="card-head"><h3>Roles</h3></div><div class="card-body" style="padding:0">
    <?php foreach($roles as $r): ?>
      <a href="?role=<?= $r['id'] ?>" class="list-row" style="border-left-color:<?= $r['id']==$selId?'var(--brand)':'transparent' ?>;background:<?= $r['id']==$selId?'#f0fdfa':'#fff' ?>">
        <span><b><?= e($r['name']) ?></b><?php if($r['is_system']): ?> <span class="pill pill-muted">system</span><?php endif; ?><br><span class="text-muted" style="font-size:11px"><?= e($r['description'] ?: '') ?></span></span>
      </a>
    <?php endforeach; ?>
  </div></div>

  <div class="card" style="grid-column:span 2"><div class="card-head">
    <h3>Permissions — <?= e($selRole['name'] ?? '') ?></h3>
    <?php if($selRole && !$selRole['is_system']): ?>
      <form method="post" data-confirm="Delete this role?"><?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $selId ?>"><button class="btn btn-sm btn-danger">Delete Role</button></form>
    <?php endif; ?>
  </div><div class="card-body">
    <?php if($selRole && $selRole['slug']==='super_admin'): ?>
      <div class="alert alert-info">Super Admin always has full access to every module.</div>
    <?php else: ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="save_perms"><input type="hidden" name="role_id" value="<?= $selId ?>">
      <?php foreach($byModule as $mod=>$list): ?>
        <div style="margin-bottom:14px"><div class="nav-group-title" style="color:var(--brand);padding-left:0"><?= e($mod) ?></div>
        <div class="form-row-3">
        <?php foreach($list as $p): ?>
          <label class="switch"><input type="checkbox" name="perms[]" value="<?= $p['id'] ?>" <?= isset($assigned[(int)$p['id']])?'checked':'' ?>> <?= e($p['name']) ?></label>
        <?php endforeach; ?>
        </div></div>
      <?php endforeach; ?>
      <button class="btn mt-2">💾 Save Permissions</button>
    </form>
    <?php endif; ?>
  </div></div>
</div>
<div class="modal-overlay" id="roModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Add Role</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save_role">
    <div class="form-group"><label>Role Name <span class="req">*</span></label><input type="text" name="name" required></div>
    <div class="form-group"><label>Description</label><input type="text" name="description"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Create</button></div>
</form></div></div>
<script>function roForm(){document.getElementById('roModal').classList.add('open');}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
