<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('payroll.manage');

$month = (string)param('month', date('Y-m'));

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $month = (string)param('month', date('Y-m'), 'POST');
    $target = param('target','all','POST');
    $count=0;
    $emps = $target==='all'
        ? fetch_all("SELECT id FROM employees WHERE status='Active' AND is_staff=0")
        : [['id'=>(int)$target]];
    foreach ($emps as $em) {
        $calc = calculate_payroll((int)$em['id'], $month);
        if ($calc) { save_payroll($calc, (int)current_user()['id']); $count++; }
    }
    audit_log('payroll_generated','payroll',null,"Generated $count payroll(s) for $month");
    flash_success("Payroll generated / refreshed for $count employee(s) for ".fmt_date($month.'-01','F Y').".");
    redirect('admin/payroll.php?month='.$month);
}

$emps = fetch_all("SELECT e.id,e.emp_code,e.full_name,e.basic_salary,
    (SELECT status FROM payroll p WHERE p.employee_id=e.id AND p.pay_month=?) AS pstatus
    FROM employees e WHERE e.status='Active' AND e.is_staff=0 ORDER BY e.full_name", [$month]);
$pageTitle='Generate Payroll'; $activeNav='payroll_gen';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Generate Payroll</h2>
  <div class="breadcrumb">Automatic calculation from salary components, attendance and EMI. You keep final control before finalizing.</div></div></div>

<div class="card mb-2"><div class="card-body">
  <form method="post" class="flex gap wrap items-center">
    <?= csrf_field() ?><input type="hidden" name="target" value="all">
    <div class="form-group" style="margin:0"><label>Payroll Month</label>
      <input type="month" name="month" value="<?= e($month) ?>"></div>
    <div class="form-group" style="margin:0"><label>&nbsp;</label>
      <button class="btn" data-confirm="Generate/refresh payroll for all active employees for this month?">⚙️ Generate for All Active Employees</button></div>
    <div class="form-group" style="margin:0"><label>&nbsp;</label>
      <a class="btn btn-outline" href="<?= url('admin/payroll.php?month='.$month) ?>">View Payroll →</a></div>
  </form>
  <p class="help mt-2">Finalized payrolls are never overwritten by re-generation.</p>
</div></div>

<div class="card"><div class="card-head"><h3>Preview — <?= fmt_date($month.'-01','F Y') ?></h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th class="num">Basic</th><th class="num">Gross</th><th class="num">Deductions</th><th class="num">Net Payable</th><th>State</th><th></th></tr></thead>
  <tbody><?php foreach($emps as $em): $c=calculate_payroll((int)$em['id'],$month); ?>
    <tr><td><b><?= e($em['full_name']) ?></b> <span class="text-muted">(<?= e($em['emp_code']) ?>)</span></td>
    <td class="num"><?= money($c['basic']) ?></td>
    <td class="num"><?= money($c['gross']) ?></td>
    <td class="num" style="color:var(--danger)"><?= money($c['total_deductions']) ?></td>
    <td class="num"><b><?= money($c['net']) ?></b></td>
    <td><?= $em['pstatus']?'<span class="pill pill-info">'.e($em['pstatus']).'</span>':'<span class="pill pill-muted">Not generated</span>' ?></td>
    <td class="text-right">
      <form method="post" style="display:inline"><?= csrf_field() ?>
        <input type="hidden" name="month" value="<?= e($month) ?>"><input type="hidden" name="target" value="<?= $em['id'] ?>">
        <button class="btn btn-sm">Generate</button></form>
    </td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
