<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('employees.view');
$id = (int)param('id', 0);
$emp = fetch_one(
    "SELECT e.*, d.name AS dept_name, ds.name AS desig_name,
            CONCAT(m.name, ' — ', mr.name) AS mgr_name, u.email AS login_email
     FROM employees e
     LEFT JOIN departments d ON d.id=e.department_id
     LEFT JOIN designations ds ON ds.id=e.designation_id
     LEFT JOIN users m ON m.id=e.reporting_manager_id
     LEFT JOIN roles mr ON mr.id=m.role_id
     LEFT JOIN users u ON u.id=e.user_id
     WHERE e.id=?", [$id]);
if (!$emp) { flash_error('Employee not found.'); redirect('admin/employees.php'); }

// ---- Delete employee data (Super Admin, password-confirmed) ------------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && param('do', '', 'POST') === 'delete_employee') {
    csrf_verify();
    if (!has_perm('employees.delete')) { http_response_code(403); require __DIR__.'/../templates/403.php'; exit; }
    $pw = (string)param('confirm_password', '', 'POST');
    $reason = trim((string)param('reason', '', 'POST'));
    if (!verify_current_password($pw)) {
        flash_error('Incorrect password — employee not deleted.');
        redirect('admin/employee_view.php?id=' . $id);
    }
    db()->beginTransaction();
    try {
        $snapshot = ['emp_code'=>$emp['emp_code'],'full_name'=>$emp['full_name'],'email'=>$emp['email']];
        $linkedUser = (int)($emp['user_id'] ?? 0);
        // Deleting the employee cascades attendance, leave, payroll, advances/EMI,
        // overtime, documents and salary components via foreign keys.
        q("DELETE FROM employees WHERE id=?", [$id]);
        // Remove the linked login account too (an employee login without a
        // profile is useless); never a Super Admin.
        if ($linkedUser) {
            $lu = fetch_one("SELECT u.id, r.slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?", [$linkedUser]);
            if ($lu && $lu['slug'] !== 'super_admin') q("DELETE FROM users WHERE id=?", [$linkedUser]);
        }
        db()->commit();
    } catch (Throwable $ex) {
        db()->rollBack();
        flash_error('Could not delete employee: ' . (APP_ENV==='development' ? $ex->getMessage() : 'database error'));
        redirect('admin/employee_view.php?id=' . $id);
    }
    audit_log('employee_deleted','employee',$id,
        "Deleted employee {$emp['emp_code']} ({$emp['full_name']})".($reason?" — Reason: {$reason}":''), $snapshot, null);
    flash_success("Employee {$emp['emp_code']} and all related data were permanently deleted.");
    redirect('admin/employees.php');
}

// ---- Employee login credential management (HR + Super Admin) ----------
if ($_SERVER['REQUEST_METHOD'] === 'POST' && param('do', '', 'POST') === 'credentials') {
    csrf_verify();
    if (!has_perm('employees.credentials')) { http_response_code(403); exit; }
    $act = param('cred_action', '', 'POST');
    $loginEmail = strtolower(trim((string)param('login_email', '', 'POST')));
    $pw = trim((string)param('login_password', '', 'POST'));

    if ($act === 'create' && !$emp['user_id']) {
        if (valid_email($loginEmail) && strlen($pw) >= 6
            && (int)fetch_col("SELECT COUNT(*) FROM users WHERE email=?", [$loginEmail]) === 0) {
            q("INSERT INTO users (role_id,name,email,password_hash,is_active) VALUES (3,?,?,?,1)",
              [$emp['full_name'], $loginEmail, password_hash($pw, PASSWORD_DEFAULT)]);
            $newUid = (int)insert_id();
            q("UPDATE employees SET user_id=? WHERE id=?", [$newUid, $id]);
            audit_log('employee_login_created', 'user', $newUid, "Login created for {$emp['full_name']}");
            flash_success('Employee login created.');
        } else {
            flash_error('Provide a unique valid email and a password of at least 6 characters.');
        }
    } elseif ($act === 'reset' && $emp['user_id']) {
        // guard: only employee-role accounts can be managed here, never HR/Manager
        $target = fetch_one("SELECT u.*, r.slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?", [$emp['user_id']]);
        if ($target && $target['slug'] === 'employee' && strlen($pw) >= 6) {
            q("UPDATE users SET password_hash=?, failed_attempts=0, locked_until=NULL WHERE id=?",
              [password_hash($pw, PASSWORD_DEFAULT), $emp['user_id']]);
            bump_auth_version((int)$emp['user_id']);
            audit_log('employee_password_reset', 'user', (int)$emp['user_id'], "Password reset for {$emp['full_name']}");
            flash_success('Employee password reset. Their other sessions were signed out.');
        } else {
            flash_error('Cannot reset this account here.');
        }
    } elseif ($act === 'toggle' && $emp['user_id']) {
        $target = fetch_one("SELECT u.*, r.slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?", [$emp['user_id']]);
        if ($target && $target['slug'] === 'employee') {
            $new = $target['is_active'] ? 0 : 1;
            q("UPDATE users SET is_active=? WHERE id=?", [$new, $emp['user_id']]);
            audit_log('employee_login_toggled', 'user', (int)$emp['user_id'], "Login " . ($new ? 'enabled' : 'disabled'));
            flash_success('Login ' . ($new ? 'enabled' : 'disabled') . '.');
        }
    }
    redirect('admin/employee_view.php?id=' . $id);
}

$month = (string)param('month', date('Y-m'));
[$y,$mn] = array_map('intval', explode('-', $month));
$mAtt = monthly_attendance($id, $y, $mn);
$advances = fetch_all("SELECT * FROM employee_advances WHERE employee_id=? ORDER BY created_at DESC", [$id]);
$payrolls = fetch_all("SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_month DESC LIMIT 6", [$id]);
$cfValues = custom_field_values('employee', $id);
$cfFields = custom_fields('employee', false);
$loginAccount = $emp['user_id']
    ? fetch_one("SELECT u.*, r.slug FROM users u JOIN roles r ON r.id=u.role_id WHERE u.id=?", [$emp['user_id']])
    : null;

$pageTitle = $emp['full_name']; $activeNav = 'employees';
require __DIR__ . '/../templates/header.php';

function row_kv($k, $v) { echo '<div style="padding:8px 0;border-bottom:1px solid var(--border)"><div class="text-muted" style="font-size:11px">'.e($k).'</div><div style="font-weight:600">'.e($v ?: '—').'</div></div>'; }
?>
<div class="page-head">
  <div><h2><?= e($emp['full_name']) ?></h2>
    <div class="breadcrumb"><a href="<?= url('admin/employees.php') ?>">Employees</a> / <?= e($emp['emp_code']) ?></div></div>
  <div class="flex gap">
    <?php if (has_perm('employees.edit')): ?><a class="btn" href="<?= url('admin/employee_edit.php?id='.$id) ?>">✏️ Edit</a><?php endif; ?>
    <a class="btn btn-outline" href="<?= url('admin/advances.php?employee='.$id) ?>">🏦 Advance/EMI</a>
    <?php if (has_perm('reports.view')): ?><a class="btn btn-outline" href="<?= url('admin/employee_report.php?id='.$id) ?>" target="_blank">📄 Download Report</a><?php endif; ?>
    <?php if (has_perm('employees.delete')): ?><button class="btn btn-danger" data-modal="delEmpModal">🗑️ Delete</button><?php endif; ?>
  </div>
</div>

<?php if (has_perm('employees.delete')): ?>
<div class="modal-overlay" id="delEmpModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Delete Employee</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="delete_employee">
    <div class="alert alert-error">
      <div>Permanently delete <b><?= e($emp['full_name']) ?> (<?= e($emp['emp_code']) ?>)</b> and <b>all related data</b> —
      attendance, leave, payroll &amp; salary slips, advances/EMI, overtime, documents<?= $emp['user_id']?' and their login account':'' ?>. This cannot be undone.</div>
    </div>
    <div class="form-group"><label>Enter your <?= is_super_admin()?'Manager':'admin' ?> password <span class="req">*</span></label>
      <div class="pwd-wrap"><input type="password" name="confirm_password" required autocomplete="off" placeholder="Your own password">
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
    <div class="form-group"><label>Reason</label><input type="text" name="reason" placeholder="e.g. Employee terminated"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-danger">Confirm Delete</button></div>
</form></div></div>
<?php endif; ?>

<div class="grid cols-3">
  <div class="card"><div class="card-body text-center">
    <div class="avatar" style="width:88px;height:88px;font-size:34px;margin:0 auto 12px">
      <?php if($emp['photo']): ?><img src="<?= url('uploads/'.$emp['photo']) ?>" alt=""><?php else: ?><?= e(strtoupper(substr($emp['full_name'],0,1))) ?><?php endif; ?></div>
    <h3 style="margin:0"><?= e($emp['full_name']) ?></h3>
    <div class="text-muted"><?= e($emp['desig_name'] ?: '—') ?></div>
    <div class="mt-1"><span class="pill pill-success"><?= e($emp['status']) ?></span></div>
    <div class="mt-2 text-muted" style="font-size:13px"><?= e($emp['emp_code']) ?></div>
  </div></div>

  <div class="card"><div class="card-head"><h3>Contact</h3></div><div class="card-body">
    <?php row_kv('Mobile', $emp['mobile']); row_kv('Email', $emp['email']);
    row_kv('Login Email', $emp['login_email']); row_kv('Address', $emp['address']);
    row_kv('Emergency', trim(($emp['emergency_name']?:'').' '.($emp['emergency_phone']?'· '.$emp['emergency_phone']:''))); ?>
  </div></div>

  <div class="card"><div class="card-head"><h3>Job & Salary</h3></div><div class="card-body">
    <?php row_kv('Department', $emp['dept_name']); row_kv('Reporting Manager', $emp['mgr_name']);
    row_kv('Employment Type', $emp['employment_type']); row_kv('Joining Date', fmt_date($emp['joining_date']));
    row_kv('Basic Salary', money($emp['basic_salary'])); ?>
  </div></div>
</div>

<div class="grid cols-2 mt-2">
  <div class="card"><div class="card-head"><h3>Bank & IDs</h3></div><div class="card-body">
    <div class="form-row">
      <div><?php row_kv('Bank', $emp['bank_name']); row_kv('Account', $emp['bank_account']); row_kv('IFSC', $emp['bank_ifsc']); ?></div>
      <div><?php row_kv('UPI', $emp['upi_id']); row_kv('PAN', $emp['pan']); row_kv('Aadhaar/Ref', $emp['aadhaar']); ?></div>
    </div>
    <?php foreach ($cfFields as $cf): if (isset($cfValues[(int)$cf['id']])) row_kv($cf['label'], $cfValues[(int)$cf['id']]); endforeach; ?>
  </div></div>

  <div class="card"><div class="card-head"><h3>Advances & EMI</h3>
    <a class="btn btn-sm btn-outline" href="<?= url('admin/advances.php?employee='.$id) ?>">Manage</a></div>
    <div class="table-wrap"><table class="data">
      <thead><tr><th>Type</th><th class="num">Total</th><th class="num">EMI</th><th class="num">Balance</th><th>Status</th></tr></thead>
      <tbody><?php if(!$advances): ?><tr><td colspan="5" class="empty">No advances.</td></tr><?php else:
        foreach ($advances as $a): ?>
        <tr><td><?= e($a['advance_type']) ?></td><td class="num"><?= money($a['total_amount']) ?></td>
        <td class="num"><?= money($a['emi_amount']) ?></td><td class="num"><?= money($a['balance_amount']) ?></td>
        <td><span class="pill <?= $a['status']==='Active'?'pill-info':($a['status']==='Completed'?'pill-success':'pill-muted') ?>"><?= e($a['status']) ?></span></td></tr>
      <?php endforeach; endif; ?></tbody>
    </table></div>
  </div>
</div>

<?php if (has_perm('employees.credentials')): ?>
<div class="card mt-2"><div class="card-head"><h3>🔑 Login Account</h3>
  <?php if ($loginAccount): ?><span class="pill <?= $loginAccount['is_active']?'pill-success':'pill-danger' ?>"><?= $loginAccount['is_active']?'Active':'Disabled' ?></span><?php endif; ?>
</div><div class="card-body">
  <?php if (!$loginAccount): ?>
    <p class="text-muted">This employee has no login account yet.</p>
    <form method="post" class="form-row"><?= csrf_field() ?>
      <input type="hidden" name="do" value="credentials"><input type="hidden" name="cred_action" value="create">
      <div class="form-group"><label>Login Email</label><input type="email" name="login_email" value="<?= e($emp['email']) ?>" required></div>
      <div class="form-group"><label>Temporary Password</label>
        <div class="flex gap"><input type="text" name="login_password" required minlength="6" placeholder="min 6 chars">
        <button class="btn">Create Login</button></div></div>
    </form>
  <?php elseif ($loginAccount['slug'] !== 'employee'): ?>
    <div class="alert alert-info">This profile is linked to a <b><?= e($loginAccount['slug']) ?></b> account. Staff/admin accounts are managed only from <a href="<?= url('admin/users.php') ?>">Users</a> by a Super Admin.</div>
  <?php else: ?>
    <div class="form-row">
      <div><?php row_kv('Login Email', $loginAccount['email']); row_kv('Last Login', $loginAccount['last_login_at']?fmt_date($loginAccount['last_login_at'],'d M Y h:i A'):'Never'); ?></div>
      <div>
        <form method="post" class="mb-2"><?= csrf_field() ?>
          <input type="hidden" name="do" value="credentials"><input type="hidden" name="cred_action" value="reset">
          <label>Reset Password</label>
          <div class="flex gap"><input type="text" name="login_password" required minlength="6" placeholder="new password">
          <button class="btn btn-warning">Reset</button></div>
        </form>
        <form method="post" data-confirm="Toggle this employee's login access?"><?= csrf_field() ?>
          <input type="hidden" name="do" value="credentials"><input type="hidden" name="cred_action" value="toggle">
          <button class="btn <?= $loginAccount['is_active']?'btn-danger':'btn-success' ?>"><?= $loginAccount['is_active']?'Disable Login':'Enable Login' ?></button>
        </form>
      </div>
    </div>
  <?php endif; ?>
</div></div>
<?php endif; ?>

<div class="card mt-2">
  <div class="card-head"><h3>Attendance — <?= fmt_date($month.'-01','F Y') ?></h3>
    <form method="get" class="flex gap"><input type="hidden" name="id" value="<?= $id ?>">
      <input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()"></form></div>
  <div class="card-body">
    <div class="flex gap wrap mb-2">
      <span class="pill pill-success">Present: <?= $mAtt['totals']['present'] ?></span>
      <span class="pill pill-danger">Absent: <?= $mAtt['totals']['absent'] ?></span>
      <span class="pill pill-info">Leave: <?= $mAtt['totals']['leave'] ?></span>
      <span class="pill pill-warning">Late: <?= $mAtt['totals']['late'] ?></span>
    </div>
    <div class="table-wrap"><table class="data att-cal"><tbody><tr>
      <?php $dim = (int)date('t', strtotime($month.'-01'));
      for ($d=1;$d<=$dim;$d++):
        $cell = $mAtt['days'][$d] ?? null; $date = sprintf('%s-%02d',$month,$d);
        $off = is_weekly_off($date, $id); ?>
        <td class="day <?= $off && !$cell ? 'off':'' ?>" style="<?= $cell && $cell['color'] ? 'background:'.e($cell['color']) : '' ?>"
            title="<?= $d.' — '.e($cell['status_name'] ?? ($off?'Weekly Off':'')) ?>">
          <?= $d ?><br><?= e($cell['short_code'] ?? ($off?'WO':'')) ?>
        </td>
      <?php endfor; ?>
    </tr></tbody></table></div>
  </div>
</div>

<?php require __DIR__ . '/../templates/footer.php'; ?>
