<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('advances.view');

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    if (!has_perm('advances.manage')) { http_response_code(403); exit; }
    $act=param('do','','POST'); $eid=(int)param('id',0,'POST');
    $emi=fetch_one("SELECT * FROM emi_schedules WHERE id=?",[$eid]);
    if ($emi) {
        if ($act==='skip' && $emi['status']==='Pending') {
            q("UPDATE emi_schedules SET status='Skipped' WHERE id=?",[$eid]);
            audit_log('emi_skipped','emi',$eid,"EMI skipped");
            flash_success('EMI marked as skipped.');
        } elseif ($act==='adjust') {
            $amt=(float)param('amount',$emi['amount'],'POST');
            $month=trim((string)param('due_month',$emi['due_month'],'POST'));
            if ($emi['status']==='Pending') {
                q("UPDATE emi_schedules SET amount=?, due_month=? WHERE id=?",[$amt,$month,$eid]);
                audit_log('emi_adjusted','emi',$eid,"EMI adjusted to ".money($amt));
                flash_success('EMI adjusted.');
            }
        }
    }
    redirect('admin/emi_schedule.php?advance='.(int)param('advance_id',0,'POST'));
}

$advId=(int)param('advance',0);
$adv=$advId?fetch_one("SELECT ea.*, e.full_name,e.emp_code FROM employee_advances ea JOIN employees e ON e.id=ea.employee_id WHERE ea.id=?",[$advId]):null;
$schedules=$advId?fetch_all("SELECT * FROM emi_schedules WHERE advance_id=? ORDER BY installment_no",[$advId]):[];
$allAdvances=fetch_all("SELECT ea.id,ea.advance_type,ea.balance_amount,e.full_name FROM employee_advances ea JOIN employees e ON e.id=ea.employee_id WHERE ea.status='Active' ORDER BY e.full_name");
$pageTitle='EMI Schedule'; $activeNav='emi';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>EMI Schedule</h2></div>
  <form method="get"><select name="advance" onchange="this.form.submit()">
    <option value="0">— Select advance —</option>
    <?php foreach($allAdvances as $a): ?><option value="<?= $a['id'] ?>" <?= $advId==$a['id']?'selected':'' ?>><?= e($a['full_name'].' · '.$a['advance_type'].' · Bal '.money($a['balance_amount'])) ?></option><?php endforeach; ?>
  </select></form></div>

<?php if($adv): ?>
<div class="card mb-2"><div class="card-body flex between wrap gap">
  <div><b><?= e($adv['full_name']) ?></b> (<?= e($adv['emp_code']) ?>) · <?= e($adv['advance_type']) ?></div>
  <div>Total <b><?= money($adv['total_amount']) ?></b> · Recovered <b><?= money($adv['recovered_amount']) ?></b> · Balance <b style="color:var(--danger)"><?= money($adv['balance_amount']) ?></b></div>
</div></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>#</th><th>Due Month</th><th class="num">Amount</th><th>Status</th><th>Paid At</th><th></th></tr></thead>
  <tbody><?php foreach($schedules as $s): ?>
    <tr><td><?= $s['installment_no'] ?></td><td><?= fmt_date($s['due_month'].'-01','M Y') ?></td>
    <td class="num"><?= money($s['amount']) ?></td>
    <td><span class="pill <?= ['Pending'=>'pill-warning','Paid'=>'pill-success','Skipped'=>'pill-muted'][$s['status']] ?>"><?= e($s['status']) ?></span></td>
    <td><?= $s['paid_at']?fmt_date($s['paid_at'],'d M Y'):'—' ?></td>
    <td class="text-right"><?php if($s['status']==='Pending' && has_perm('advances.manage')): ?>
      <button class="btn btn-sm btn-outline" data-modal="emiModal" onclick='emiForm(<?= json_encode($s) ?>,<?= $advId ?>)'>Adjust</button>
      <form method="post" style="display:inline" data-confirm="Skip this EMI?"><?= csrf_field() ?>
        <input type="hidden" name="do" value="skip"><input type="hidden" name="id" value="<?= $s['id'] ?>"><input type="hidden" name="advance_id" value="<?= $advId ?>">
        <button class="btn btn-sm btn-warning">Skip</button></form>
    <?php endif; ?></td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="emiModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Adjust EMI</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="adjust"><input type="hidden" name="id" id="emi_id"><input type="hidden" name="advance_id" value="<?= $advId ?>">
    <div class="form-group"><label>Amount (₹)</label><input type="number" step="0.01" name="amount" id="emi_amt"></div>
    <div class="form-group"><label>Due Month</label><input type="month" name="due_month" id="emi_month"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function emiForm(s){emi_id.value=s.id;emi_amt.value=s.amount;emi_month.value=s.due_month;}</script>
<?php else: ?>
  <div class="card"><div class="empty">Select an advance to view its EMI schedule.</div></div>
<?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
