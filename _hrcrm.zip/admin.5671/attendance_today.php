<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('attendance.view');

$date   = (string)param('date', date('Y-m-d'));
$dept   = (int)param('department', 0);
$statusF= (int)param('status', 0);
$search = trim((string)param('q',''));

$where = ["e.status='Active'", "e.is_staff=0"]; $args=[$date];
if ($dept)   { $where[]="e.department_id=?"; $args[]=$dept; }
if ($search) { $where[]="(e.full_name LIKE ? OR e.emp_code LIKE ?)"; $args[]="%$search%"; $args[]="%$search%"; }
if ($statusF){ $where[]="a.status_id=?"; $args[]=$statusF; }
$whereSql = implode(' AND ', $where);

$rows = fetch_all(
  "SELECT e.id,e.emp_code,e.full_name, a.id AS att_id, a.check_in,a.check_out,a.working_minutes,
          a.late_minutes,a.early_minutes,a.admin_remark, s.name AS status_name,s.color
   FROM employees e
   LEFT JOIN attendance a ON a.employee_id=e.id AND a.att_date=?
   LEFT JOIN attendance_statuses s ON s.id=a.status_id
   WHERE $whereSql ORDER BY e.full_name", $args);
$c = attendance_dashboard($date);
$depts = fetch_all("SELECT id,name FROM departments WHERE is_active=1 ORDER BY name");
$statuses = att_statuses_active();

$pageTitle="Today's Attendance"; $activeNav='att_today';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Attendance — <?= fmt_date($date,'d M Y') ?></h2></div>
  <a class="btn btn-outline" href="<?= url('admin/attendance_manual.php') ?>">✏️ Manual Entry</a></div>

<div class="grid cols-4 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-green">🟢</div><div><div class="label">Present</div><div class="value"><?= $c['present'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏰</div><div><div class="label">Late</div><div class="value"><?= $c['late'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🌴</div><div><div class="label">On Leave</div><div class="value"><?= $c['leave'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">🔴</div><div><div class="label">Not In</div><div class="value"><?= $c['not_checked_in'] ?></div></div></div></div>
</div>

<form method="get" class="filters">
  <div class="form-group"><label>Date</label><input type="date" name="date" value="<?= e($date) ?>"></div>
  <div class="form-group"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Name / ID"></div>
  <div class="form-group"><label>Department</label><select name="department"><option value="0">All</option>
    <?php foreach($depts as $d): ?><option value="<?= $d['id'] ?>" <?= $dept==$d['id']?'selected':'' ?>><?= e($d['name']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>Status</label><select name="status"><option value="0">All</option>
    <?php foreach($statuses as $s): ?><option value="<?= $s['id'] ?>" <?= $statusF==$s['id']?'selected':'' ?>><?= e($s['name']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Check In</th><th>Status</th><th>Working Hours</th><th>Check Out</th><th>Early/Late</th><th>Remarks</th><th></th></tr></thead>
  <tbody><?php foreach ($rows as $r): ?>
    <tr>
      <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
      <td><?= $r['check_in']?fmt_date($r['check_in'],'h:i A'):'—' ?></td>
      <td><?= $r['status_name']?'<span class="badge" style="background:'.e($r['color']).'">'.e($r['status_name']).'</span>':'<span class="pill pill-muted">—</span>' ?></td>
      <td><?= $r['working_minutes']?fmt_hm((int)$r['working_minutes']):($r['check_in']&&!$r['check_out']?'<span class="text-muted">Working…</span>':'—') ?></td>
      <td><?= $r['check_out']?fmt_date($r['check_out'],'h:i A'):'—' ?></td>
      <td><?php if($r['late_minutes']>0): ?><span class="pill pill-warning">Late <?= $r['late_minutes'] ?>m</span><?php endif;
              if($r['early_minutes']>0): ?><span class="pill pill-info">Early <?= $r['early_minutes'] ?>m</span><?php endif;
              if(!$r['late_minutes'] && !$r['early_minutes']) echo '—'; ?></td>
      <td class="text-muted"><?= e($r['admin_remark'] ?: '—') ?></td>
      <td class="text-right"><?php if(has_perm('attendance.manual')): ?>
        <a class="btn btn-sm btn-outline" href="<?= url('admin/attendance_manual.php?employee='.$r['id'].'&date='.$date) ?>">Edit</a><?php endif; ?></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="8" class="empty">No records.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
