<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('audit.view');
$search=trim((string)param('q',''));
$where=$search?"WHERE (a.action LIKE ? OR a.description LIKE ? OR u.name LIKE ?)":"";
$args=$search?["%$search%","%$search%","%$search%"]:[];
[$limit,$offset,$page]=paginate(30);
$total=(int)fetch_col("SELECT COUNT(*) FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id $where",$args);
$rows=fetch_all("SELECT a.*, u.name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
  $where ORDER BY a.created_at DESC LIMIT $limit OFFSET $offset",$args);
$pages=max(1,(int)ceil($total/$limit));
$pageTitle='Audit Logs'; $activeNav='audit';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Audit Logs</h2><div class="breadcrumb"><?= $total ?> entries</div></div></div>
<form method="get" class="filters"><div class="form-group"><label>Search</label>
  <input type="search" name="q" value="<?= e($search) ?>" placeholder="Action, user, description"></div>
  <div class="form-group"><button class="btn btn-outline">Search</button></div></form>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>User</th><th>Action</th><th>Entity</th><th>Description</th><th>IP</th><th>Date/Time</th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><?= e($r['user_name'] ?: 'System') ?></td>
    <td><span class="pill pill-info"><?= e($r['action']) ?></span></td>
    <td><?= e($r['entity'] ?: '—') ?><?= $r['entity_id']?' #'.$r['entity_id']:'' ?></td>
    <td class="text-muted"><?= e($r['description'] ?: '—') ?></td>
    <td class="text-muted"><?= e($r['ip_address'] ?: '—') ?></td>
    <td class="text-muted"><?= fmt_date($r['created_at'],'d M Y h:i A') ?></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No logs.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php if($pages>1): ?><div class="flex gap mt-2" style="justify-content:center">
  <?php for($p=max(1,$page-3);$p<=min($pages,$page+3);$p++): ?>
    <a class="btn btn-sm <?= $p==$page?'':'btn-outline' ?>" href="?<?= e(http_build_query(array_merge($_GET,['page'=>$p]))) ?>"><?= $p ?></a>
  <?php endfor; ?></div><?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
