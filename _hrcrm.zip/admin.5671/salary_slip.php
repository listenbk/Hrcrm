<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/slip_render.php';
require_perm('payroll.view');
render_salary_slip((int)param('id', 0));
