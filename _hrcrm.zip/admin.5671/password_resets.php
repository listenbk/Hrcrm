<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('users.manage');   // Super Admin only

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');

    if ($act === 'generate') {
        $uid = (int)param('user_id', 0, 'POST');
        $target = fetch_one("SELECT id, name, email FROM users WHERE id = ? AND is_active = 1", [$uid]);
        if ($target) {
            $combined = create_password_reset_for_user($uid);
            if ($combined) {
                $_SESSION['_reset_link'] = [
                    'url'   => reset_link_url($combined),
                    'name'  => $target['name'],
                    'email' => $target['email'],
                ];
                audit_log('password_reset_link_issued', 'user', $uid,
                    'Super Admin generated a reset link for ' . $target['email']);
            }
        } else {
            flash_error('User not found or inactive.');
        }
        redirect('admin/password_resets.php');
    }

    if ($act === 'revoke') {
        $rid = (int)param('reset_id', 0, 'POST');
        $row = fetch_one("SELECT user_id FROM password_resets WHERE id = ?", [$rid]);
        if ($row) {
            q("DELETE FROM password_resets WHERE id = ?", [$rid]);
            audit_log('password_reset_revoked', 'user', (int)$row['user_id'], 'Pending reset revoked');
            flash_success('Pending reset link revoked.');
        }
        redirect('admin/password_resets.php');
    }
}

// Housekeeping: drop clearly-stale rows (used, or expired for over a day)
q("DELETE FROM password_resets WHERE used_at IS NOT NULL OR expires_at < (NOW() - INTERVAL 1 DAY)");

$issued = $_SESSION['_reset_link'] ?? null;
unset($_SESSION['_reset_link']);

$search = trim((string)param('q', ''));
$where = ['u.is_active = 1']; $args = [];
if ($search !== '') {
    $where[] = "(u.name LIKE ? OR u.email LIKE ? OR u.username LIKE ?)";
    $like = "%$search%"; array_push($args, $like, $like, $like);
}
$users = fetch_all(
    "SELECT u.id, u.name, u.email, u.last_login_at, r.name AS role_name, r.slug,
            (SELECT expires_at FROM password_resets pr WHERE pr.user_id = u.id AND pr.used_at IS NULL AND pr.expires_at > NOW() LIMIT 1) AS pending_expires
     FROM users u JOIN roles r ON r.id = u.role_id
     WHERE " . implode(' AND ', $where) . "
     ORDER BY r.id, u.name", $args);

$pending = fetch_all(
    "SELECT pr.*, u.name, u.email, r.name AS role_name
     FROM password_resets pr
     JOIN users u ON u.id = pr.user_id
     JOIN roles r ON r.id = u.role_id
     WHERE pr.used_at IS NULL AND pr.expires_at > NOW()
     ORDER BY pr.created_at DESC");

$pageTitle = 'Password Resets'; $activeNav = 'pwresets';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>Password Resets</h2>
    <div class="breadcrumb">Generate a one-hour reset link for any account and hand it to the user securely.</div></div>
</div>

<?php if ($issued): ?>
<div class="card mb-2" style="border-color:var(--brand)">
  <div class="card-head"><h3>🔗 Reset link for <?= e($issued['name']) ?> (<?= e($issued['email']) ?>)</h3></div>
  <div class="card-body">
    <div class="alert alert-info">Share this link with the user over a trusted channel. It is valid for <b>1 hour</b> and can be used once. It is shown here only now — it cannot be retrieved again.</div>
    <div class="flex gap" style="align-items:stretch">
      <input type="text" id="resetLink" readonly value="<?= e($issued['url']) ?>" style="flex:1;font-family:monospace">
      <button class="btn" type="button" onclick="copyResetLink(this)">📋 Copy</button>
    </div>
  </div>
</div>
<script>
function copyResetLink(btn){
  var inp=document.getElementById('resetLink'); inp.select(); inp.setSelectionRange(0,99999);
  navigator.clipboard.writeText(inp.value).then(function(){btn.textContent='✓ Copied';setTimeout(function(){btn.textContent='📋 Copy';},1500);})
    .catch(function(){document.execCommand('copy');btn.textContent='✓ Copied';});
}
</script>
<?php endif; ?>

<?php if ($pending): ?>
<div class="card mb-2">
  <div class="card-head"><h3>Active pending resets (<?= count($pending) ?>)</h3></div>
  <div class="table-wrap"><table class="data">
    <thead><tr><th>User</th><th>Role</th><th>Requested</th><th>Expires</th><th></th></tr></thead>
    <tbody><?php foreach ($pending as $p): ?>
      <tr>
        <td><b><?= e($p['name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($p['email']) ?></div></td>
        <td><span class="pill pill-info"><?= e($p['role_name']) ?></span></td>
        <td class="text-muted"><?= fmt_date($p['created_at'], 'd M Y h:i A') ?></td>
        <td class="text-muted"><?= fmt_date($p['expires_at'], 'd M Y h:i A') ?></td>
        <td class="text-right">
          <form method="post" style="display:inline" data-confirm="Revoke this pending reset link?">
            <?= csrf_field() ?><input type="hidden" name="do" value="revoke"><input type="hidden" name="reset_id" value="<?= $p['id'] ?>">
            <button class="btn btn-sm btn-danger">Revoke</button></form>
        </td>
      </tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<form method="get" class="filters">
  <div class="form-group"><label>Search account</label>
    <input type="search" name="q" value="<?= e($search) ?>" placeholder="Name, email or username"></div>
  <div class="form-group"><button class="btn btn-outline">Search</button></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>User</th><th>Role</th><th>Last Login</th><th>Pending Reset</th><th></th></tr></thead>
  <tbody>
  <?php foreach ($users as $u2): ?>
    <tr>
      <td><b><?= e($u2['name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($u2['email']) ?></div></td>
      <td><span class="pill <?= $u2['slug']==='super_admin'?'pill-danger':($u2['slug']==='hr_admin'?'pill-warning':'pill-muted') ?>"><?= e($u2['role_name']) ?></span></td>
      <td class="text-muted"><?= $u2['last_login_at'] ? fmt_date($u2['last_login_at'],'d M Y h:i A') : 'Never' ?></td>
      <td><?= $u2['pending_expires'] ? '<span class="pill pill-warning">Active until '.fmt_date($u2['pending_expires'],'h:i A').'</span>' : '<span class="text-muted">—</span>' ?></td>
      <td class="text-right">
        <form method="post" style="display:inline" data-confirm="Generate a new 1-hour reset link for <?= e($u2['name']) ?>? Any existing pending link for them will be replaced.">
          <?= csrf_field() ?><input type="hidden" name="do" value="generate"><input type="hidden" name="user_id" value="<?= $u2['id'] ?>">
          <button class="btn btn-sm">🔗 Generate Reset Link</button></form>
      </td>
    </tr>
  <?php endforeach; ?>
  <?php if (!$users): ?><tr><td colspan="5" class="empty">No matching accounts.</td></tr><?php endif; ?>
  </tbody>
</table></div></div>

<p class="help mt-2">Reset links are stored only as a one-way hash, so an issued link is displayed a single time here. Generating a new link automatically replaces any previous pending link for that user.</p>
<?php require __DIR__ . '/../templates/footer.php'; ?>
