<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('customfields.manage');
$modules=['employee'=>'Employee','attendance'=>'Attendance','salary'=>'Salary','deduction'=>'Deduction','leave'=>'Leave'];
$types=['text','number','amount','dropdown','date','time','checkbox','yesno','textarea'];

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='save') {
        $id=(int)param('id',0,'POST');
        $module=param('module','employee','POST'); $label=trim((string)param('label','','POST'));
        $ftype=in_array(param('field_type','text','POST'),$types,true)?param('field_type','text','POST'):'text';
        $options=trim((string)param('options','','POST'));
        $req=param('is_required',0,'POST')?1:0; $active=param('is_active',0,'POST')?1:0;
        $order=(int)param('sort_order',0,'POST');
        if ($label!=='' && isset($modules[$module])) {
            $key=slugify($label);
            if ($id) q("UPDATE custom_fields SET module=?,label=?,field_type=?,options=?,is_required=?,is_active=?,sort_order=? WHERE id=?",[$module,$label,$ftype,$options,$req,$active,$order,$id]);
            else     q("INSERT INTO custom_fields (module,label,field_key,field_type,options,is_required,is_active,sort_order) VALUES (?,?,?,?,?,?,?,?)",[$module,$label,$key.'_'.substr(md5($label.microtime()),0,4),$ftype,$options,$req,$active,$order]);
            audit_log('custom_field_saved','custom_field',$id?:insert_id(),$label);
            flash_success('Custom field saved.');
        }
    } elseif ($act==='delete') { q("DELETE FROM custom_fields WHERE id=?",[(int)param('id',0,'POST')]); flash_success('Deleted.'); }
    redirect('admin/custom_fields.php');
}
$rows=fetch_all("SELECT * FROM custom_fields ORDER BY module, sort_order, id");
$pageTitle='Custom Fields'; $activeNav='custom_fields';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Custom Fields Manager</h2>
  <div class="breadcrumb">Add extra HR fields to any module without touching code.</div></div>
  <button class="btn" data-modal="cfModal" onclick="cfForm()">➕ Add Field</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Module</th><th>Label</th><th>Type</th><th>Required</th><th>Order</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><span class="pill pill-info"><?= e(ucfirst($r['module'])) ?></span></td><td><b><?= e($r['label']) ?></b></td>
    <td><?= e($r['field_type']) ?></td><td><?= $r['is_required']?'Yes':'No' ?></td><td><?= $r['sort_order'] ?></td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Inactive' ?></span></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="cfModal" onclick='cfForm(<?= json_encode($r) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete field and its values?"><?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="7" class="empty">No custom fields yet.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="cfModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="cfTitle">Add Custom Field</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="cf_id">
    <div class="form-row">
      <div class="form-group"><label>Module</label><select name="module" id="cf_module">
        <?php foreach($modules as $k=>$v): ?><option value="<?= $k ?>"><?= $v ?></option><?php endforeach; ?></select></div>
      <div class="form-group"><label>Field Type</label><select name="field_type" id="cf_type">
        <?php foreach($types as $t): ?><option value="<?= $t ?>"><?= ucfirst($t) ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="form-group"><label>Label <span class="req">*</span></label><input type="text" name="label" id="cf_label" required></div>
    <div class="form-group"><label>Options (for dropdown, comma-separated)</label><input type="text" name="options" id="cf_options" placeholder="e.g. Small, Medium, Large"></div>
    <div class="form-row">
      <div class="form-group"><label>Display Order</label><input type="number" name="sort_order" id="cf_order" value="0"></div>
      <div class="form-group"><label>&nbsp;</label>
        <label class="switch"><input type="checkbox" name="is_required" id="cf_req"> Required</label></div>
    </div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="cf_act" checked> Active</label></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function cfForm(d){d=d||{};cfTitle.textContent=d.id?'Edit Custom Field':'Add Custom Field';
  cf_id.value=d.id||'';cf_module.value=d.module||'employee';cf_type.value=d.field_type||'text';
  cf_label.value=d.label||'';cf_options.value=d.options||'';cf_order.value=d.sort_order||0;
  cf_req.checked=d.id?d.is_required==1:false;cf_act.checked=d.id?d.is_active==1:true;}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
