<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('config.leave_types');   // Super Admin configuration
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='save') {
        $id=(int)param('id',0,'POST'); $name=trim((string)param('name','','POST'));
        $paid=param('is_paid',0,'POST')?1:0; $quota=(float)param('annual_quota',0,'POST');
        $color=trim((string)param('color','#3b82f6','POST')); $active=param('is_active',0,'POST')?1:0;
        if ($name!=='') {
            if ($id) q("UPDATE leave_types SET name=?,is_paid=?,annual_quota=?,color=?,is_active=? WHERE id=?",[$name,$paid,$quota,$color,$active,$id]);
            else     q("INSERT INTO leave_types (name,slug,is_paid,annual_quota,color,is_active) VALUES (?,?,?,?,?,?)",[$name,slugify($name),$paid,$quota,$color,$active]);
            flash_success('Leave type saved.');
        }
    } elseif ($act==='delete') { q("DELETE FROM leave_types WHERE id=?",[(int)param('id',0,'POST')]); flash_success('Deleted.'); }
    redirect('admin/leave_types.php');
}
$rows=fetch_all("SELECT * FROM leave_types ORDER BY name");
$pageTitle='Leave Types'; $activeNav='leave_types';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Leave Types</h2></div>
  <button class="btn" data-modal="ltModal" onclick="ltForm()">➕ Add Leave Type</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Name</th><th>Paid</th><th>Annual Quota</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><span class="badge" style="background:<?= e($r['color']) ?>"><?= e($r['name']) ?></span></td>
    <td><?= $r['is_paid']?'Yes':'No' ?></td><td><?= e($r['annual_quota']) ?> days</td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Inactive' ?></span></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="ltModal" onclick='ltForm(<?= json_encode($r) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete?"><?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>"><button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; ?></tbody>
</table></div></div>
<div class="modal-overlay" id="ltModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="ltTitle">Add Leave Type</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="lt_id">
    <div class="form-group"><label>Name <span class="req">*</span></label><input type="text" name="name" id="lt_name" required></div>
    <div class="form-row">
      <div class="form-group"><label>Annual Quota (days)</label><input type="number" step="0.5" name="annual_quota" id="lt_quota" value="0"></div>
      <div class="form-group"><label>Color</label><input type="color" name="color" id="lt_color" value="#3b82f6" style="height:42px"></div>
    </div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_paid" id="lt_paid" checked> Paid leave</label></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="lt_active" checked> Active</label></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function ltForm(d){d=d||{};document.getElementById('ltTitle').textContent=d.id?'Edit Leave Type':'Add Leave Type';
  lt_id.value=d.id||'';lt_name.value=d.name||'';lt_quota.value=d.annual_quota||0;lt_color.value=d.color||'#3b82f6';
  lt_paid.checked=d.id?d.is_paid==1:true;lt_active.checked=d.id?d.is_active==1:true;}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
