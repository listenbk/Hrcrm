<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('employees.view');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (!is_admin()) { http_response_code(403); exit; }
    $act = param('do', '', 'POST');
    if ($act === 'save') {
        $did = (int)param('id', 0, 'POST');
        $name = trim((string)param('name', '', 'POST'));
        $code = trim((string)param('code', '', 'POST'));
        $active = param('is_active', 0, 'POST') ? 1 : 0;
        if ($name !== '') {
            if ($did) {
                q("UPDATE departments SET name=?,code=?,is_active=? WHERE id=?", [$name,$code,$active,$did]);
                audit_log('department_edited','department',$did,$name);
            } else {
                q("INSERT INTO departments (name,code,is_active) VALUES (?,?,?)", [$name,$code,$active]);
                audit_log('department_created','department',insert_id(),$name);
            }
            flash_success('Department saved.');
        }
    } elseif ($act === 'delete') {
        $did = (int)param('id', 0, 'POST');
        q("DELETE FROM departments WHERE id=?", [$did]);
        audit_log('department_deleted','department',$did);
        flash_success('Department deleted.');
    }
    redirect('admin/departments.php');
}

$rows = fetch_all("SELECT d.*, (SELECT COUNT(*) FROM employees e WHERE e.department_id=d.id) emp_count FROM departments d ORDER BY d.name");
$pageTitle='Departments'; $activeNav='departments';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Departments</h2></div>
  <button class="btn" data-modal="deptModal" onclick="deptForm()">➕ Add Department</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Name</th><th>Code</th><th>Employees</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach ($rows as $r): ?>
    <tr><td><b><?= e($r['name']) ?></b></td><td><?= e($r['code'] ?: '—') ?></td><td><?= $r['emp_count'] ?></td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Inactive' ?></span></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="deptModal"
        onclick='deptForm(<?= json_encode($r) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete this department?">
        <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
        <button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="5" class="empty">No departments yet.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="deptModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="deptTitle">Add Department</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="dept_id">
    <div class="form-group"><label>Name <span class="req">*</span></label><input type="text" name="name" id="dept_name" required></div>
    <div class="form-group"><label>Code</label><input type="text" name="code" id="dept_code"></div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="dept_active" checked> Active</label></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>
function deptForm(d){d=d||{};
  document.getElementById('deptTitle').textContent=d.id?'Edit Department':'Add Department';
  document.getElementById('dept_id').value=d.id||'';
  document.getElementById('dept_name').value=d.name||'';
  document.getElementById('dept_code').value=d.code||'';
  document.getElementById('dept_active').checked=d.id?d.is_active==1:true;
}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
