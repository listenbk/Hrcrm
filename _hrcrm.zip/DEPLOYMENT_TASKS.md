# RG Realty HRCRM — Task Manager & Daily Reporting

This update adds a **Task Manager + End-of-Day Reporting** module natively inside
the existing HRCRM. It reuses your current employees, users, roles, authentication,
database connection and UI. **No existing module or data is changed** — the
migration only *adds* two tables and one permission.

---

## 1. Files to upload (into your live `hrcrm/` folder)

**New files**
- `install/migrate_tasks.sql`      — database migration (import once, see step 2)
- `includes/task_lib.php`          — task helpers
- `admin/tasks.php`                — Task Board (assign / list / filter) for Admin, HR, Team Leader
- `admin/task_reports.php`         — End-of-Day reports viewer
- `employee/tasks.php`             — "My Tasks" for employees (update status + remark)
- `employee/report.php`            — "Daily Report" for employees (submit EOD + history)

**Changed files (overwrite the existing ones)**
- `includes/bootstrap.php`         — loads `task_lib.php`
- `templates/sidebar.php`          — adds the Tasks navigation links

> Hostinger's File Manager "Extract" will **not** overwrite existing files.
> Before extracting, delete the two files being replaced on the server first:
> `includes/bootstrap.php` and `templates/sidebar.php`. The rest are new.

---

## 2. Database changes to import

In **hPanel → phpMyAdmin → your `hrcrm` database → SQL tab**, paste the contents
of `install/migrate_tasks.sql` and click **Go**.

It creates:
- `tasks` — assigned tasks (title, description, priority, status, assigned_to =
  `employees.id`, assigned_by = `users.id`, assign/due dates, remarks).
- `daily_reports` — one End-of-Day report per employee per day.
- permission `tasks.manage`, granted to **Super Admin, HR/Admin and Team Leader**.

The migration is **idempotent** (safe to run once; re-running does nothing harmful).
It only ADDS objects — attendance, leave, salary, incentives, loan/EMI, assets,
notice board and employee data are untouched.

---

## 3. Configuration to preserve from the live server

Nothing new to configure. This module uses your existing:
- `config/config.php` database credentials (do **not** overwrite this file),
- authentication, roles and permissions,
- employee records and IDs.

There are no localhost-only settings in these files and no new API keys or paths.

---

## 4. Backup steps before replacing files (do this first)

1. **Database:** phpMyAdmin → your `hrcrm` DB → **Export** → *Quick / SQL* → save the file.
   (Or use the CRM's built-in **Database Backups** page if you deployed that module.)
2. **Files:** in File Manager, download (or copy) your current `hrcrm/includes/bootstrap.php`
   and `hrcrm/templates/sidebar.php` so you can roll back if needed.

---

## 5. Post-upload verification

1. **Log in** as Super Admin (or HR) — the sidebar now shows a **Tasks** group
   (Task Board, Daily Reports).
2. **Assign a task:** Task Board → **Assign Task** → pick an employee, set title,
   priority and due date → Save. It should appear in the list and the employee gets
   a notification.
3. **Employee side:** log in as that employee — **My Tasks** shows the task; use
   **Update** to change status to *In Progress* / *Completed* and add a remark.
4. **Daily Report:** as the employee, open **Daily Report**, submit a summary; it
   appears under **Daily Reports** for Admin/HR, and in the employee's own history.
5. **Team Leader:** confirm a TL account sees the **Tasks** group and can assign.
6. **Regression check:** open Attendance, Leave, Payroll, Assets and Notice Board —
   all continue to work exactly as before.

---

## Who can do what
| Role | Capability |
|------|------------|
| Super Admin / HR / Team Leader | Assign tasks to any active employee, view/filter all tasks, view all EOD reports |
| Employee (incl. HR/TL self-view) | See only their own tasks, update status + remark, submit EOD reports, view own history |

If you'd rather restrict **Team Leaders** to only their own reportees (employees
whose *Reporting Manager* is that TL), tell me and I'll scope it.
