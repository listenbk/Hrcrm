<?php
/** AJAX endpoint for employee check-in / check-out (server timestamps). */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');

require_login();
csrf_verify();

$emp = current_employee();
if (!$emp) {
    // HR / Team Leaders get a self-attendance profile on first use.
    $emp = ensure_staff_employee(current_user());
}
if (!$emp) {
    echo json_encode(['ok' => false, 'message' => 'No employee profile is linked to your account.']);
    exit;
}

$action = (string)param('action', '', 'POST');
$lat = param('latitude', null, 'POST');
$lng = param('longitude', null, 'POST');
$acc = param('accuracy', null, 'POST');
try {
    $empId = (int)$emp['id'];
    // Geofence gate runs BEFORE the existing attendance rules, server-side.
    $geoAction =$action === 'check_in' ? 'check_in' : ($action === 'check_out' ? 'check_out' : 'ot');
    $needsGeo = in_array($action, ['check_in','check_out','ot_check_in','ot_check_out'], true);
    if ($needsGeo) {
        [$gOk, $gMsg, $gStatus, $gDist, $gLoc, $gAcc] = geofence_validate($empId, $geoAction, $lat, $lng, $acc);
        if (!$gOk) {
            audit_log('geofence_rejected', 'attendance', $empId,
                "{$action} rejected for employee #{$empId}: {$gStatus}" . ($gDist !== null ? " ({$gDist}m)" : ''));
            echo json_encode(['ok' => false, 'message' => $gMsg, 'geofence' => $gStatus]);
            exit;
        }
    }

    if ($action === 'check_in') {
        [$ok, $msg] = do_check_in($empId);
        if ($ok && geofence_applies_to('check_in')) {
            geofence_store($empId, 'check_in', $lat, $lng, $acc, $gStatus, $gDist, $gLoc);
        }
    } elseif ($action === 'check_out') {
        [$ok, $msg] = do_check_out($empId);
        if ($ok && geofence_applies_to('check_out')) {
            geofence_store($empId, 'check_out', $lat, $lng, $acc, $gStatus, $gDist, $gLoc);
        }
    } elseif ($action === 'ot_check_in') {
        [$ok, $msg] = ot_session_start($empId);
    } elseif ($action === 'ot_check_out') {
        [$ok, $msg] = ot_session_stop($empId);
    } else {
        echo json_encode(['ok' => false, 'message' => 'Unknown action.']);
        exit;
    }
    echo json_encode(['ok' => $ok, 'message' => $msg]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'message' => APP_ENV === 'development' ? $e->getMessage() : 'Something went wrong.']);
}
