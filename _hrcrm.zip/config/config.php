<?php
/**
 * RG Realty CRM — central application & database configuration
 * =============================================================================
 *  HOSTINGER / PRODUCTION.  This is the ONLY file that holds DB credentials.
 *
 *  >>> EDIT THE FOUR DB_* VALUES BELOW WITH YOUR HOSTINGER DATABASE DETAILS <<<
 *
 *  hPanel → Databases → MySQL Databases:
 *    Database name → DB_NAME (e.g. u123456789_rgcrm)
 *    Database user → DB_USER (e.g. u123456789_rguser)
 *    Password      → DB_PASS
 *    Host          → DB_HOST (Hostinger is almost always 'localhost')
 *
 *  BASE_URL (NO trailing slash):
 *    Domain root  https://yourdomain.com        →  ''
 *    Subfolder    https://yourdomain.com/crm     →  '/crm'
 *
 *  You may instead supply any of these via server environment variables of the
 *  same name (getenv) — the literal values here are the fallback.
 */

// ---- Database (EDIT THESE) -----------------------------------------
define('DB_HOST', getenv('DB_HOST') ?: 'localhost');
define('DB_NAME', getenv('DB_NAME') ?: 'u957986597_hrcrm');
define('DB_USER', getenv('DB_USER') ?: 'u957986597_hrcrm');
define('DB_PASS', getenv('DB_PASS') ?: 'Hrcrm@#1234');
define('DB_CHARSET', 'utf8mb4');

// ---- Application ----------------------------------------------------
define('APP_NAME', 'RG Realty CRM');
define('APP_ENV', getenv('APP_ENV') ?: 'development');   // 'development' shows errors
define('APP_TIMEZONE', 'Asia/Kolkata');
define('BASE_URL', getenv('BASE_URL') !== false ? getenv('BASE_URL') : '');

// Absolute filesystem root (hosting-safe — never hard-coded).
define('APP_ROOT', dirname(__DIR__));
define('UPLOAD_DIR', APP_ROOT . '/uploads');
define('UPLOAD_URL', BASE_URL . '/uploads');
define('SESSION_NAME', 'RGCRMSESID');

// ---- Error handling -------------------------------------------------
date_default_timezone_set(APP_TIMEZONE);
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    // Production: hide errors from visitors, log them privately.
    error_reporting(E_ALL);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    // Uncomment to keep a private error log (folder is web-protected):
    // ini_set('error_log', APP_ROOT . '/storage/php-error.log');
}
