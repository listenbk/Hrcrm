# Fix: "Unknown column 'shift_id'" when adding an employee

## Cause (from the error, the source and the migration files)
- `admin/employee_edit.php` (line 111 on the live server) inserts the
  employee with `shift_id` (and `week_off_days`, `team_leader_id`, geofence
  columns…).
- The restored database has the `shifts` **table** (the form loads, and it
  reads that table) but **not** the `employees.shift_id` **column**. Both come
  from `migrate_improvements.sql`, so the backup was taken from a database
  where that migration only partly ran. `week_off_days` is added
  `AFTER shift_id`, so it is very likely missing too.
- Side effect: the old code created the **login account first** and then the
  employee, with no transaction. Each failed attempt (with email + password)
  left a login with no employee profile.

## What this package contains
| File | Purpose |
|---|---|
| `install/schema_check.sql` | **Read-only.** Lists missing tables/columns, orphan logins, demo accounts. |
| `install/migrate_repair_schema.sql` | **Add-only, guarded, re-runnable.** Adds only what is missing (checks `information_schema` first). No DROP/DELETE/UPDATE of rows. Works on MySQL and MariaDB. Includes everything from `migrate_geofence.sql` and `_v2`. |
| `admin/employee_edit.php` | Saves login + employee in **one transaction**; friendly error with a reference code (details only in the server error log); links an orphan login with the same email instead of leaving the new employee without one. Also keeps the geofence fixes. |
| Geofence v3 files | `includes/geofence_lib.php`, `api/attendance.php`, `assets/js/app.js`, `templates/header.php`, `templates/footer.php`, `admin/geofence.php` — the live server currently has an older `employee_edit.php`, so the geofence files may be old too. |

**Do not** re-run the old `migrate_*.sql` files to fix this: re-running
`migrate_reporting_manager.sql` sets every employee's reporting manager to
NULL; `migrate_auth.sql` and `migrate_team_leader.sql` reset HR / Team-Leader
permissions; `migrate_team_leader.sql` creates a demo login.

## Step 1 — Staging first
1. hPanel → Domains → **Subdomains** → create `staging` under `hrcrm.rgrealty.in`
   (or `staging-hrcrm.rgrealty.in`).
2. hPanel → Databases → create a **new** database + user for staging.
3. phpMyAdmin (live DB) → **Export** → save. phpMyAdmin (**staging DB**) →
   **Import** that file. (Import only ever into the *staging* database.)
4. Copy the `hrcrm/` files into the staging folder; edit **staging's**
   `config/config.php` with the staging DB name/user/password.
5. On staging: run `schema_check.sql` → `migrate_repair_schema.sql` →
   `schema_check.sql` (queries 1–2 empty). Upload this package. Test (Step 4).

## Step 2 — Production database (after staging passes)
1. phpMyAdmin → live DB → **Export** (Custom: all tables, structure + data) →
   save to your PC; open it and confirm it contains `INSERT INTO \`employees\``.
2. SQL tab → paste `install/schema_check.sql` → Go. Save the output.
3. SQL tab → paste `install/migrate_repair_schema.sql` → Go.
4. Run `schema_check.sql` again → queries 1 and 2 must return **no rows**.

## Step 3 — Production files
1. File Manager: download the live copies of the files listed above (rollback).
2. Upload `hrcrm_fix_add_employee_v4.zip` into `hrcrm/`, extract, overwrite.
   It does **not** contain `config/config.php` or any data.
3. Recommended one-line change in the **live** `config/config.php` (do not
   replace the file, credentials stay as they are):
   `define('APP_ENV', getenv('APP_ENV') ?: 'production');`
   — hides technical error pages (server paths, SQL) from users.

## Step 4 — Tests
| # | Test | Expected |
|---|---|---|
| 1 | Add Employee with email + password | "Employee saved successfully."; employee appears; login works |
| 2 | New employee logs in | Employee dashboard |
| 3 | Add Employee without login password | Saved, no login created |
| 4 | Add Employee whose email has an orphan login (schema_check query 3) | Saved; "existing login … linked"; that login now opens the profile |
| 5 | Add Employee with an email used by HR/TL/admin | Saved; "No login was created: this email already belongs to another account." |
| 6 | Edit existing employee (shift, week-off, team leader, site) | Saved, values kept |
| 7 | Existing employees / HR / Super Admin log in | Unchanged |
| 8 | Admin → Users → add a user | Works as before |
| 9 | Check-in / check-out (geofence OFF) | Unchanged |
| 10 | Week-Off Management, Shifts dropdown, Overtime, Payroll | Unchanged |

If something fails, the page shows "database problem (ref XXXXXX)". The
details are in the server error log (hPanel → Advanced → Error logs, or
`hrcrm/error_log`), searchable by that reference.

## Rollback
- Files: re-upload the live copies saved in Step 3.1.
- Database: the repair only **adds** nullable/defaulted columns and empty
  tables; old code ignores them, so no database rollback is needed. Full
  restore = import the export from Step 2.1.
