# RG Realty HRCRM — Team Leader Routing Update

## What changed

1. **Overtime 8:00 PM gate** — Overtime Check-In is now blocked until the
   configured time (default **8:00 PM**, editable in Admin → Overtime Rules →
   "Overtime Check-In Allowed From"), regardless of when normal attendance
   ended. Enforced server-side in `ot_session_start()`.

2. **OT approval routed to the assigned Team Leader** — when an employee
   submits an overtime reason, it's sent directly to their **assigned Team
   Leader** (new field, see #3) for approval, in addition to the existing
   HR/Super Admin visibility. Team Leaders can now open **Overtime** in their
   sidebar and **Approve/Reject** — but only for employees assigned to them;
   attempting to act on another team's record is blocked server-side. Super
   Admin remains unrestricted. HR keeps its existing "Review & forward"
   role — approval only comes from the assigned Team Leader or Super Admin,
   so nothing is counted until one of them acts.

3. **Mandatory "Assigned Team Leader" field** — Admin → Employees → Add/Edit
   now has a **required** "Assigned Team Leader" dropdown (separate from the
   existing optional "Reporting Manager" field, which is unchanged). This
   drives OT and reporting routing. Existing employees keep whatever they
   had (NULL) until next edited — nothing is forced in bulk.

4. **Reporting/approval requests routed to the assigned Team Leader** — Leave
   requests, End-of-Day reports, and Asset return requests are now also sent
   directly to the employee's assigned Team Leader (on top of the existing
   HR/broadcast notifications, which are unchanged).

5. **Downloadable Employee Report** — Admin → Employees → open an employee →
   **Download Report** button. One printable page with personal details,
   6-month attendance, leave balances, overtime, assigned assets, and
   advances/EMI. "Download" is via the browser's Print → Save as PDF, same
   pattern as salary slips (no new server dependency).

## Files to upload (into your live `hrcrm/` folder)

**New**
- `install/migrate_tl_routing.sql`
- `includes/employee_report_render.php`
- `admin/employee_report.php`

**Changed (overwrite existing)**
- `includes/functions.php`
- `includes/overtime_lib.php`
- `admin/overtime.php`
- `admin/overtime_settings.php`
- `admin/employee_edit.php`
- `admin/employee_view.php`
- `employee/overtime.php`
- `employee/dashboard.php`
- `employee/leave_apply.php`
- `employee/report.php`
- `employee/assets.php`
- `templates/sidebar.php`

Hostinger's extractor won't overwrite existing files — delete the "Changed"
list above on the server first, then extract this ZIP into `hrcrm/`.

## Database change

Import `install/migrate_tl_routing.sql` in phpMyAdmin. It only:
- adds `employees.team_leader_id` (nullable),
- adds the `ot_checkin_after` setting (default `20:00`),
- grants Team Leaders the existing `overtime.view`/`overtime.approve`
  permissions (scoped to their own team in application code).

No existing table, column, row, or permission is altered. Safe to re-run.

## ⚠️ Before this is fully live: assign Team Leaders

Routing only works for an employee once they have an **Assigned Team
Leader**. Go to **Admin → Employees**, open each employee, click **Edit**,
and set their Assigned Team Leader (required from now on for any save).
Until that's done for an employee, their OT/leave/report requests still
reach HR/Super Admin as before — nothing breaks, it just isn't routed to a
specific Team Leader yet.

## Post-upload verification
1. **Edit an employee** without choosing a Team Leader → confirm it's
   rejected with "Assigned Team Leader is required."
2. **Assign a Team Leader** to an employee, save, confirm it sticks.
3. As that **Team Leader**, log in → confirm **Overtime** appears in the
   sidebar and shows only that employee's OT records, not everyone's.
4. As the **employee**, try **Overtime Check-In** before 8 PM → confirm it's
   blocked with a clear message; after 8 PM (or after changing the setting)
   it should work.
5. As Admin/HR, open an employee → **Download Report** → confirm it opens
   and **Print/Save as PDF** works.
6. Confirm Attendance, Leave, Payroll, Assets, Notices, Tasks, Shifts, and
   Week-Off Management all continue to work exactly as before.
