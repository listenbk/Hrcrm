<?php
/**
 * Geofence validation — the SERVER decides. Browser coordinates are only
 * inputs; they are never trusted on their own.
 *
 * Scope: attendance actions only (check-in, check-out, overtime check-in/out).
 * Login and general browsing are never location-restricted.
 */

/** Great-circle distance in metres between two lat/lng points (Haversine). */
function haversine_meters(float $lat1, float $lng1, float $lat2, float $lng2): float
{
    $R = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    return $R * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

/**
 * Master switch. An optional emergency constant in config/config.php
 *   define('GEOFENCE_FORCE_OFF', true);
 * turns geofencing off instantly without touching the database.
 */
function geofence_enabled(): bool
{
    if (defined('GEOFENCE_FORCE_OFF') && GEOFENCE_FORCE_OFF) return false;
    return setting('geofence_enabled', '0') === '1';
}

/** Is geofencing enforced for this action? action: check_in | check_out | ot */
function geofence_applies_to(string $action): bool
{
    return geofence_enabled() && setting('geofence_' . $action, '1') === '1';
}

/** Map an attendance API action to its geofence action key (null = not geofenced). */
function geofence_action_key(string $apiAction): ?string
{
    return ['check_in' => 'check_in', 'check_out' => 'check_out',
            'ot_check_in' => 'ot', 'ot_check_out' => 'ot'][$apiAction] ?? null;
}

/**
 * Must this employee prove their location for this action? No coordinates
 * needed — used by the page header (to decide whether the browser asks for
 * GPS at all) and by geofence_validate().
 * Returns [required, status, location_id]; status is set when not required.
 */
function geofence_requirement(int $employeeId, string $action): array
{
    if (!geofence_applies_to($action)) {
        return [false, 'Not Required', null];
    }
    $emp = fetch_one("SELECT geofence_exempt, geofence_location_id FROM employees WHERE id=?", [$employeeId]);
    if (!empty($emp['geofence_exempt'])) {
        return [false, 'Exempt', null];
    }
    // Per-site switch: a site may enforce only some actions (check-in / check-out / OT).
    $siteCol = ['check_in' => 'enforce_check_in', 'check_out' => 'enforce_check_out', 'ot' => 'enforce_ot'][$action] ?? 'enforce_check_in';
    if (!empty($emp['geofence_location_id'])) {
        $site = fetch_one("SELECT id, {$siteCol} AS enf FROM geofence_locations WHERE id=? AND status=1", [$emp['geofence_location_id']]);
        if ($site && empty($site['enf'])) {
            return [false, 'Not Required', (int)$site['id']];
        }
    }
    return [true, '', null];
}

function geofence_required_for(int $employeeId, string $action): bool
{
    return geofence_requirement($employeeId, $action)[0];
}

/**
 * Validate a location for an employee and action.
 * $geoError is the browser's reason when no position was obtained:
 *   denied | timeout | unavailable | unsupported | insecure
 * $positionTs / $clientTs: position.timestamp and Date.now() from the browser (ms).
 * Returns [ok, message, status, distance_m, location_id, accuracy]
 *   status: Inside | Outside | Denied | Unavailable | Stale | Poor Accuracy | No Site | Not Required | Exempt
 */
function geofence_validate(int $employeeId, string $action, $lat, $lng, $accuracy, string $geoError = '',
                           $positionTs = null, $clientTs = null): array
{
    [$required, $skipStatus, $skipLoc] = geofence_requirement($employeeId, $action);
    if (!$required) {
        return [true, '', $skipStatus, null, $skipLoc, null];
    }

    // Employee must have an assigned, active site. Checked first: it is an HR
    // set-up issue, so the employee should not be told to fix their GPS.
    $locId = fetch_col("SELECT geofence_location_id FROM employees WHERE id=?", [$employeeId]);
    $loc = $locId ? fetch_one("SELECT * FROM geofence_locations WHERE id=? AND status=1", [$locId]) : null;
    if (!$loc) {
        return [false, 'No office location is assigned to you for attendance. Please contact HR.', 'No Site', null, null, null];
    }
    $siteId = (int)$loc['id'];

    // The browser could not provide a position. Never fall back to IP location.
    switch ($geoError) {
        case 'denied':
            return [false, 'Please enable location permission to mark attendance.', 'Denied', null, $siteId, null];
        case 'timeout':
            return [false, 'Could not get your location in time. Please make sure GPS/location is on and try again.', 'Unavailable', null, $siteId, null];
        case 'insecure':
            return [false, 'Location is only available over a secure (https://) connection.', 'Unavailable', null, $siteId, null];
        case 'unsupported':
            return [false, 'Your browser does not support location. Please use an up-to-date browser.', 'Unavailable', null, $siteId, null];
        case 'unavailable':
            return [false, 'Your location could not be determined. Please turn on GPS/location and try again.', 'Unavailable', null, $siteId, null];
    }

    // Missing or malformed coordinates.
    if (!is_numeric($lat) || !is_numeric($lng)) {
        return [false, 'Please enable location permission to mark attendance.', 'Unavailable', null, $siteId, null];
    }
    $lat = (float)$lat; $lng = (float)$lng;
    if (!is_finite($lat) || !is_finite($lng) || $lat < -90 || $lat > 90 || $lng < -180 || $lng > 180
        || ($lat == 0.0 && $lng == 0.0)) {
        return [false, 'Invalid location reading. Please try again.', 'Unavailable', null, $siteId, null];
    }

    // Freshness: the fix must have been taken just before submitting. Both values are
    // milliseconds on the DEVICE clock (position.timestamp vs Date.now()), so a wrong
    // phone clock does not matter — only the age of the reading is checked.
    if (!is_numeric($positionTs) || !is_numeric($clientTs) || (float)$positionTs <= 0) {
        return [false, 'Location reading could not be verified. Please refresh the page and try again.', 'Stale', null, $siteId, null];
    }
    $ageSec = ((float)$clientTs - (float)$positionTs) / 1000;
    $maxAge = max(30, (int)setting('geofence_max_position_age', '120'));
    if ($ageSec > $maxAge || $ageSec < -60) {
        return [false, 'Your location reading is outdated. Please try again to get a fresh GPS position.', 'Stale', null, $siteId, null];
    }

    // GPS accuracy gate (metres). Missing, zero or negative accuracy is treated as unusable.
    $maxAcc = (float)setting('geofence_max_accuracy', '100');
    $acc = is_numeric($accuracy) ? (float)$accuracy : null;
    if ($acc === null || !is_finite($acc) || $acc <= 0 || $acc > $maxAcc) {
        $shown = ($acc === null || !is_finite($acc) || $acc <= 0) ? 'unknown' : '±' . round($acc) . ' m';
        return [false, "GPS accuracy is too low ({$shown}; ±" . round($maxAcc) . " m or better needed). Please move to an open area and try again.",
                'Poor Accuracy', null, $siteId, ($acc !== null && is_finite($acc)) ? $acc : null];
    }

    $dist = (int)round(haversine_meters($lat, $lng, (float)$loc['latitude'], (float)$loc['longitude']));
    $radius = (int)$loc['radius'];

    if ($dist > $radius) {
        return [false,
            "You are outside your assigned office location — {$dist} m away from {$loc['location_name']} (allowed: {$radius} m).",
            'Outside', $dist, $siteId, $acc];
    }
    return [true, '', 'Inside', $dist, $siteId, $acc];
}

/**
 * Possible-spoofing hints. Informational only (shown to HR) — they never block,
 * because browser GPS cannot be made tamper-proof.
 */
function geofence_spoof_flags(int $employeeId, $lat, $lng, ?int $locId): ?string
{
    if (!is_numeric($lat) || !is_numeric($lng)) return null;
    $lat = round((float)$lat, 7); $lng = round((float)$lng, 7);
    $flags = [];
    if ($locId) {
        $site = fetch_one("SELECT latitude, longitude FROM geofence_locations WHERE id=?", [$locId]);
        // Real GPS virtually never lands on the exact configured site point.
        if ($site && round((float)$site['latitude'], 6) == round($lat, 6) && round((float)$site['longitude'], 6) == round($lng, 6)) {
            $flags[] = 'exact_site_point';
        }
    }
    try {
        // Real GPS readings virtually never repeat to 7 decimals on different days.
        $repeat = (int)fetch_col(
            "SELECT COUNT(*) FROM geofence_attempts
             WHERE employee_id=? AND latitude=? AND longitude=? AND DATE(created_at) <> CURDATE()",
            [$employeeId, $lat, $lng]);
        if ($repeat > 0) $flags[] = 'repeated_exact_coords';
    } catch (Throwable $e) { /* v2 migration not run yet */ }
    return $flags ? implode(',', $flags) : null;
}

/**
 * Log one geofence-checked attendance attempt (accepted or rejected) for HR.
 * Never throws: a logging problem must not break attendance.
 */
function geofence_record_attempt(?int $employeeId, string $apiAction, bool $accepted, string $status, string $reason,
                                 $lat, $lng, $acc, ?int $dist, ?int $locId, ?string $flags = null): void
{
    try {
        $ok = is_numeric($lat) && is_numeric($lng);
        $u = function_exists('current_user') ? current_user() : null;
        q("INSERT INTO geofence_attempts
             (employee_id, user_id, action, result, status, reason, latitude, longitude, accuracy,
              distance_m, location_id, flags, ip_address, user_agent)
           VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
          [$employeeId, $u['id'] ?? null, substr($apiAction, 0, 20), $accepted ? 'accepted' : 'rejected',
           substr($status, 0, 20), $reason !== '' ? substr($reason, 0, 250) : null,
           $ok ? round((float)$lat, 7) : null, $ok ? round((float)$lng, 7) : null,
           (is_numeric($acc) && is_finite((float)$acc)) ? min(999999, (float)$acc) : null,
           $dist, $locId, $flags,
           substr((string)($_SERVER['REMOTE_ADDR'] ?? ''), 0, 45), device_info()]);
    } catch (Throwable $e) {
        // geofence_attempts table missing (v2 migration not run) — ignore.
    }
}

/** Persist the location evidence on today's attendance row (check_in or check_out). */
function geofence_store(int $employeeId, string $phase, $lat, $lng, $acc, string $status, ?int $dist, ?int $locId): void
{
    $date = date('Y-m-d');
    $p = $phase === 'check_out' ? 'checkout' : 'checkin';
    $ok = is_numeric($lat) && is_numeric($lng);
    q("UPDATE attendance SET {$p}_latitude=?, {$p}_longitude=?, {$p}_accuracy=?, {$p}_distance_m=?,
           {$p}_geofence_status=?, geofence_location_id=COALESCE(?, geofence_location_id)
       WHERE employee_id=? AND att_date=?",
      [$ok ? (float)$lat : null, $ok ? (float)$lng : null, is_numeric($acc) ? (float)$acc : null,
       $dist, $status, $locId, $employeeId, $date]);
}

/**
 * Persist location evidence on today's manual overtime session ('in' | 'out').
 * Never throws: a missing column (v2 migration not run) must not break overtime.
 */
function geofence_store_ot(int $employeeId, string $phase, $lat, $lng, $acc, string $status, ?int $dist): void
{
    $p = $phase === 'out' ? 'ot_out' : 'ot_in';
    $ok = is_numeric($lat) && is_numeric($lng);
    try {
        q("UPDATE overtime SET {$p}_latitude=?, {$p}_longitude=?, {$p}_accuracy=?, {$p}_distance_m=?, {$p}_geofence_status=?
           WHERE employee_id=? AND ot_date=? AND session_type='manual'
           ORDER BY id DESC LIMIT 1",
          [$ok ? (float)$lat : null, $ok ? (float)$lng : null, is_numeric($acc) ? (float)$acc : null,
           $dist, $status, $employeeId, date('Y-m-d')]);
    } catch (Throwable $e) {
        // ignore
    }
}

/** Escape a value for CSV so spreadsheet apps never run it as a formula. */
function geofence_csv_cell($v)
{
    $s = (string)($v ?? '');
    return ($s !== '' && strpbrk($s[0], "=+-@\t\r") !== false) ? "'" . $s : $s;
}
