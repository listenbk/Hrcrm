-- =====================================================================
--  RG Realty CRM - SCHEMA REPAIR (ADD-ONLY, GUARDED, RE-RUNNABLE)
--
--  Adds ONLY the tables/columns that the current code needs and that are
--  missing (e.g. after restoring an older backup). For every column it first
--  uses ADD COLUMN IF NOT EXISTS; if the column exists, nothing happens.
--
--  NEVER: DROP / TRUNCATE / DELETE / UPDATE of existing rows, no permission
--  resets, no demo users. MariaDB version (Hostinger). One plain statement per column.
--
--  BEFORE RUNNING: phpMyAdmin - Export a full backup and keep it on your PC.
--  Run install/schema_check.sql before and after; after = empty results.
--
--  Do NOT re-run the old migrate_*.sql files instead: migrate_auth,
--  migrate_team_leader and migrate_reporting_manager reset permissions /
--  reporting managers when run again.
-- =====================================================================
SET NAMES utf8mb4;

-- ---------- Tables (created only if absent) ---------------------------
CREATE TABLE IF NOT EXISTS `shifts` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(80)  NOT NULL,
  `start_time`  TIME         NOT NULL DEFAULT '10:30:00',
  `end_time`    TIME         NOT NULL DEFAULT '19:00:00',
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shift_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed the default shift ONLY when the table is empty (never re-adds a deleted one).
INSERT INTO `shifts` (`name`,`start_time`,`end_time`,`is_active`)
SELECT 'General (10:30-19:00)','10:30:00','19:00:00',1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `shifts`);

CREATE TABLE IF NOT EXISTS `geofence_locations` (
  `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `location_name`     VARCHAR(120) NOT NULL,
  `latitude`          DECIMAL(10,7) NOT NULL,
  `longitude`         DECIMAL(10,7) NOT NULL,
  `radius`            INT UNSIGNED NOT NULL DEFAULT 100,
  `status`            TINYINT(1)   NOT NULL DEFAULT 1,
  `enforce_check_in`  TINYINT(1)   NOT NULL DEFAULT 1,
  `enforce_check_out` TINYINT(1)   NOT NULL DEFAULT 1,
  `enforce_ot`        TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_geo_name` (`location_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `geofence_attempts` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` INT UNSIGNED  NULL,
  `user_id`     INT UNSIGNED  NULL,
  `action`      VARCHAR(20)   NOT NULL,
  `result`      VARCHAR(12)   NOT NULL,
  `status`      VARCHAR(20)   NOT NULL,
  `reason`      VARCHAR(255)  NULL,
  `latitude`    DECIMAL(10,7) NULL,
  `longitude`   DECIMAL(10,7) NULL,
  `accuracy`    DECIMAL(8,2)  NULL,
  `distance_m`  INT UNSIGNED  NULL,
  `location_id` INT UNSIGNED  NULL,
  `flags`       VARCHAR(120)  NULL,
  `ip_address`  VARCHAR(45)   NULL,
  `user_agent`  VARCHAR(255)  NULL,
  `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ga_emp_time` (`employee_id`, `created_at`),
  KEY `idx_ga_result_time` (`result`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Columns (each added only if missing; table must exist) ---

-- employees
ALTER TABLE `employees` ADD COLUMN IF NOT EXISTS `shift_id` INT UNSIGNED NULL;
ALTER TABLE `employees` ADD COLUMN IF NOT EXISTS `week_off_days` VARCHAR(20) NULL;
ALTER TABLE `employees` ADD COLUMN IF NOT EXISTS `team_leader_id` INT UNSIGNED NULL;
ALTER TABLE `employees` ADD COLUMN IF NOT EXISTS `is_staff` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `employees` ADD COLUMN IF NOT EXISTS `geofence_location_id` INT UNSIGNED NULL;
ALTER TABLE `employees` ADD COLUMN IF NOT EXISTS `geofence_exempt` TINYINT(1) NOT NULL DEFAULT 0;

-- attendance
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `is_auto_checkout` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkin_latitude` DECIMAL(10,7) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkin_longitude` DECIMAL(10,7) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkin_accuracy` DECIMAL(8,2) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkin_distance_m` INT UNSIGNED NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkin_geofence_status` VARCHAR(20) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkout_latitude` DECIMAL(10,7) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkout_longitude` DECIMAL(10,7) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkout_accuracy` DECIMAL(8,2) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkout_distance_m` INT UNSIGNED NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `checkout_geofence_status` VARCHAR(20) NULL;
ALTER TABLE `attendance` ADD COLUMN IF NOT EXISTS `geofence_location_id` INT UNSIGNED NULL;

-- users
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `username` VARCHAR(60) NULL;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `auth_version` INT UNSIGNED NOT NULL DEFAULT 1;
ALTER TABLE `users` ADD COLUMN IF NOT EXISTS `last_activity` DATETIME NULL;

-- leave_requests
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `hr_decision` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending';
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `hr_by` INT UNSIGNED NULL;
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `hr_at` DATETIME NULL;
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `hr_remark` VARCHAR(255) NULL;
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `tl_decision` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending';
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `tl_by` INT UNSIGNED NULL;
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `tl_at` DATETIME NULL;
ALTER TABLE `leave_requests` ADD COLUMN IF NOT EXISTS `tl_remark` VARCHAR(255) NULL;

-- geofence_locations
ALTER TABLE `geofence_locations` ADD COLUMN IF NOT EXISTS `enforce_check_in` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `geofence_locations` ADD COLUMN IF NOT EXISTS `enforce_check_out` TINYINT(1) NOT NULL DEFAULT 1;
ALTER TABLE `geofence_locations` ADD COLUMN IF NOT EXISTS `enforce_ot` TINYINT(1) NOT NULL DEFAULT 1;

-- overtime
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_check_in` DATETIME NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `session_type` ENUM('auto_detected','manual') NOT NULL DEFAULT 'auto_detected';
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_in_latitude` DECIMAL(10,7) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_in_longitude` DECIMAL(10,7) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_in_accuracy` DECIMAL(8,2) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_in_distance_m` INT UNSIGNED NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_in_geofence_status` VARCHAR(20) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_out_latitude` DECIMAL(10,7) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_out_longitude` DECIMAL(10,7) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_out_accuracy` DECIMAL(8,2) NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_out_distance_m` INT UNSIGNED NULL;
ALTER TABLE `overtime` ADD COLUMN IF NOT EXISTS `ot_out_geofence_status` VARCHAR(20) NULL;

-- notices
ALTER TABLE `notices` ADD COLUMN IF NOT EXISTS `is_archived` TINYINT(1) NOT NULL DEFAULT 0;
ALTER TABLE `notices` ADD COLUMN IF NOT EXISTS `deleted_at` DATETIME NULL;
ALTER TABLE `notices` ADD COLUMN IF NOT EXISTS `deleted_by` INT UNSIGNED NULL;
ALTER TABLE `notices` ADD COLUMN IF NOT EXISTS `delete_reason` VARCHAR(255) NULL;

-- ---------- Settings defaults (existing values are never changed) -----
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
  ('geofence_enabled','0'), ('geofence_check_in','1'), ('geofence_check_out','1'),
  ('geofence_ot','1'), ('geofence_max_accuracy','100'),
  ('auto_checkout_enabled','1'), ('auto_checkout_grace_minutes','30'),
  ('ot_manual_sessions','1'), ('ot_checkin_after','20:00'),
  ('min_checkout_minutes','30'), ('auto_absent_enabled','1'),
  ('session_timeout_minutes','30'), ('remember_me_days','30')
ON DUPLICATE KEY UPDATE `setting_key` = `setting_key`;

-- ---------- Permission catalogue (adds missing rows; grants unchanged) -
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
  ('Manage Shifts','shifts.manage','Employees'),
  ('Manage Week-Offs','weekoff.manage','Attendance'),
  ('Manage Geofence','geofence.manage','Attendance')
ON DUPLICATE KEY UPDATE `slug` = `slug`;
-- Super Admin always has every permission. To give HR these menus, run
-- (optional, reviewed separately):
--   INSERT IGNORE INTO role_permissions (role_id, permission_id)
--     SELECT 2, id FROM permissions WHERE slug IN ('shifts.manage','weekoff.manage','geofence.manage');

-- Done. Now run install/schema_check.sql - queries 1 and 2 should be empty.
