# RG Realty HRCRM — Attendance Automation Update

Adds: **Auto-Absent after 7:00 PM** + **30-minute minimum checkout wait**.
This is a **safe in-place update** — it does **not** touch or re-import your
existing attendance data. Just overwrite a few files, run one small SQL, and add
one cron job.

Your live app folder is:
`/home/u957986597/domains/rgrealty.in/public_html/hrcrm/`

---

## STEP 1 — Upload the updated files (overwrite)

In hPanel → **File Manager**, upload each file below into the **same path**
inside your `hrcrm/` folder (overwrite the existing ones). Easiest: upload this
ZIP into `hrcrm/`, **Extract**, and let it overwrite.

Files in this pack:
```
includes/attendance_lib.php     ← 30-min checkout lock + auto-absent engine
includes/functions.php          ← (also carries the earlier Employee-ID fix)
assets/js/app.js                ← checkout countdown/enable
employee/dashboard.php          ← checkout button lock (employee)
hr/dashboard.php                ← checkout button lock (HR)
tl/dashboard.php                ← checkout button lock (Team Leader)
admin/settings.php              ← new Attendance settings fields
admin/early_leave.php           ← (earlier fix: hide HR/TL staff)
admin/late_employees.php        ← (earlier fix: hide HR/TL staff)
cron/auto_absent.php            ← NEW daily automation script
```
> None of these change the database schema or your records. They only replace
> program files.

---

## STEP 2 — Run the settings SQL (one time)

phpMyAdmin → select your database → **SQL** tab → paste and run:

```sql
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('min_checkout_minutes','30'),
 ('auto_absent_enabled','1'),
 ('cron_key','')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;
```

(Also included as `install/migrate_attendance_automation.sql`.) This only adds 3
setting rows — it does not modify attendance data.

You can later change these from **Settings → Attendance Rules** in the CRM
(Minimum Checkout Wait, and the Auto-Absent toggle).

---

## STEP 3 — Add the daily cron job (this is what makes it run automatically)

hPanel → **Advanced → Cron Jobs** → **Create a new cron job**.

- **Command to run:**
  ```
  php /home/u957986597/domains/rgrealty.in/public_html/hrcrm/cron/auto_absent.php
  ```
  (If Hostinger asks for the PHP binary explicitly, use
  `/usr/bin/php` instead of `php`.)

- **Schedule:** choose **“Once per hour”** (recommended).

**Why hourly?** The script is safe and idempotent: it only marks Absent **after
7:00 PM (Asia/Kolkata)** for the current day, skips weekly-offs, holidays and
approved leave, and never creates duplicates. Running hourly guarantees it fires
during the evening window regardless of the server's timezone. (You may instead
run it once daily after 7:15 PM IST if you prefer.)

That's it — from now on, any employee who doesn't check in on a working day is
automatically marked **Absent**, and those absents flow into totals, reports,
salary and dashboards exactly like manual ones.

---

## How it behaves

**Auto-Absent**
- Runs server-side via cron (not only when someone opens the dashboard).
- Marks Active employees who never checked in on a working day as **Absent**.
- **Skips**: approved leave, weekly offs, configured holidays, and anyone who
  already has a status or a check-in that day.
- **No duplicates** — re-running is harmless.
- HR/Team-Leader self-attendance profiles are not auto-absented.

**30-minute checkout**
- After check-in, the **Check Out** button is disabled and shows
  “Checkout will be available 30 minutes after check-in”, with a live countdown
  that enables it automatically.
- Enforced on the **server** too, so it can't be bypassed by editing the page.
- Change the 30 to any value in **Settings → Attendance Rules**.

---

## Verify it works
1. Open **Settings → Attendance Rules** — you should see “Min. Checkout Wait”
   and the “Auto-mark Absent…” toggle.
2. Check in as a test employee → the **Check Out** button is greyed out with the
   countdown; it enables after the wait.
3. After your cron has run past 7 PM on a working day, open **Monthly
   Attendance** — employees who didn't check in show **Absent**.
4. (Optional) run the cron manually once from hPanel → Cron Jobs → **Run**, or
   check `storage/cron.log` for a line like
   `... auto_absent {"date":"2026-09-22","employees":13,"marked":4}`.
