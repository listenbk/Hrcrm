<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
if (!is_team_leader() && !is_super_admin()) { http_response_code(403); require __DIR__ . '/../templates/403.php'; exit; }

$today = date('Y-m-d');
$att = attendance_dashboard($today);
$pendingLeaves = (int)fetch_col("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'");

// Team Leader's own self-attendance profile
$me = ensure_staff_employee(current_user());
$myAtt = $me ? fetch_one("SELECT a.*, s.name AS status_name, s.color FROM attendance a
    LEFT JOIN attendance_statuses s ON s.id=a.status_id WHERE a.employee_id=? AND a.att_date=?", [$me['id'], $today]) : null;

// Leaves still awaiting a decision (either approver can act)
$pending = fetch_all(
    "SELECT lr.*, e.full_name, e.emp_code, lt.name AS type_name, lt.color
     FROM leave_requests lr
     JOIN employees e ON e.id=lr.employee_id
     JOIN leave_types lt ON lt.id=lr.leave_type_id
     WHERE lr.status='Pending'
     ORDER BY lr.created_at DESC LIMIT 15");

$pageTitle = 'Team Leader Dashboard'; $activeNav = 'dashboard';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>Team Leader Dashboard</h2>
    <div class="breadcrumb"><?= fmt_date($today,'l, d F Y') ?> · <span id="liveClock"></span></div></div>
  <a class="btn" href="<?= url('admin/leaves.php') ?>">📝 Review Leave Requests</a>
</div>

<?php require __DIR__ . '/../templates/notices_widget.php'; ?>

<div id="attMsg" class="alert" style="display:none"></div>
<div class="card mb-2"><div class="card-head"><h3>My Attendance — Today</h3>
  <?php if($myAtt && $myAtt['status_name']): ?><span class="badge" style="background:<?= e($myAtt['color']) ?>"><?= e($myAtt['status_name']) ?></span><?php endif; ?></div>
  <div class="card-body">
    <div class="grid cols-3" style="text-align:center;gap:12px">
      <div><div class="text-muted">Check In</div><div style="font-size:20px;font-weight:800"><?= $myAtt&&$myAtt['check_in']?fmt_date($myAtt['check_in'],'h:i A'):'—' ?>
        <?php if($myAtt && $myAtt['late_minutes']>0): ?><div><span class="pill pill-warning">Late <?= $myAtt['late_minutes'] ?>m</span></div><?php endif; ?></div></div>
      <div><div class="text-muted">Working</div><div class="hours-big" style="font-size:22px"><?= $myAtt?fmt_hm((int)$myAtt['working_minutes']):'0h 0m' ?></div></div>
      <div><div class="text-muted">Check Out</div><div style="font-size:20px;font-weight:800"><?= $myAtt&&$myAtt['check_out']?fmt_date($myAtt['check_out'],'h:i A'):'—' ?></div></div>
    </div>
    <div class="text-center mt-2">
      <?php if(!$myAtt || !$myAtt['check_in']): ?>
        <button class="btn btn-lg" style="width:auto" onclick="attendanceAction('check_in',this)">🟢 Check In</button>
      <?php elseif(!$myAtt['check_out']):
        $minCk=(int)setting('min_checkout_minutes',30);
        $remain=(strtotime($myAtt['check_in'])+$minCk*60)-time(); ?>
        <button class="btn btn-lg btn-danger" style="width:auto" id="checkoutBtn" data-unlock="<?= max(0,$remain) ?>" <?= $remain>0?'disabled':'' ?> onclick="attendanceAction('check_out',this)">🔴 Check Out</button>
        <?php if($remain>0): ?><div class="mt-1"><span class="pill pill-warning" id="checkoutMsg">⏳ Checkout will be available <?= $minCk ?> minutes after check-in</span></div><?php endif; ?>
      <?php else: ?>
        <span class="pill pill-success" style="font-size:14px;padding:8px 16px">✔️ Attendance complete for today</span>
      <?php endif; ?>
      <a class="btn btn-outline" href="<?= url('employee/attendance.php') ?>">🕐 My History</a>
      <a class="btn btn-outline" href="<?= url('employee/leave_apply.php') ?>">📝 Apply Leave</a>
    </div>
  </div>
</div>

<div class="grid cols-4">
  <div class="card"><div class="stat"><div class="icon bg-amber">📝</div><div><div class="label">Pending Leave Requests</div><div class="value"><?= $pendingLeaves ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">🟢</div><div><div class="label">Present Today</div><div class="value"><?= $att['present'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏰</div><div><div class="label">Late Today</div><div class="value"><?= $att['late'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🌴</div><div><div class="label">On Leave</div><div class="value"><?= $att['leave'] ?></div></div></div></div>
</div>

<div class="card mt-3">
  <div class="card-head"><h3>Leave Requests Awaiting Approval</h3>
    <a class="btn btn-sm btn-outline" href="<?= url('admin/leaves.php') ?>">Open Leave Requests</a></div>
  <div class="table-wrap"><table class="data">
    <thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th><th>Team Leader</th><th>HR</th><th></th></tr></thead>
    <tbody>
    <?php foreach ($pending as $r): ?>
      <tr>
        <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
        <td><span class="badge" style="background:<?= e($r['color']) ?>"><?= e($r['type_name']) ?></span></td>
        <td><?= fmt_date($r['start_date']) ?> → <?= fmt_date($r['end_date']) ?></td>
        <td><?= e($r['total_days']) ?></td>
        <td><span class="pill <?= $r['tl_decision']==='Approved'?'pill-success':($r['tl_decision']==='Rejected'?'pill-danger':'pill-muted') ?>"><?= e($r['tl_decision']) ?></span></td>
        <td><span class="pill <?= $r['hr_decision']==='Approved'?'pill-success':($r['hr_decision']==='Rejected'?'pill-danger':'pill-muted') ?>"><?= e($r['hr_decision']) ?></span></td>
        <td class="text-right"><a class="btn btn-sm" href="<?= url('admin/leaves.php') ?>">Review</a></td>
      </tr>
    <?php endforeach; if(!$pending): ?><tr><td colspan="7" class="empty">No pending leave requests 🎉</td></tr><?php endif; ?>
    </tbody>
  </table></div>
</div>

<div class="flex gap mt-3 wrap">
  <a class="btn btn-outline" href="<?= url('admin/attendance_today.php') ?>">🕐 Today's Attendance</a>
  <a class="btn btn-outline" href="<?= url('admin/attendance_monthly.php') ?>">🗓️ Monthly Attendance</a>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
