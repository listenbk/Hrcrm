-- =====================================================================
--  RG Realty Employee Management CRM
--  Complete MySQL schema  --  rg_realty_crm.sql
--  Import directly via phpMyAdmin (Import tab) or:
--     mysql -u root -p rg_realty_crm < rg_realty_crm.sql
--
--  Engine: InnoDB  |  Charset: utf8mb4  |  Timezone: Asia/Kolkata
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;
SET NAMES utf8mb4;
SET time_zone = '+05:30';

-- If you prefer the SQL to create the database, uncomment these two lines
-- and remove the CREATE/USE done by the installer/README.
-- CREATE DATABASE IF NOT EXISTS `rg_realty_crm` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE `rg_realty_crm`;

-- ---------------------------------------------------------------------
-- Roles & Permissions (RBAC)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `role_permissions`;
DROP TABLE IF EXISTS `permissions`;
DROP TABLE IF EXISTS `roles`;

CREATE TABLE `roles` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(60)  NOT NULL,
  `slug`        VARCHAR(60)  NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `is_system`   TINYINT(1)   NOT NULL DEFAULT 0,   -- system roles cannot be deleted
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_roles_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `permissions` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(100) NOT NULL,           -- human label
  `slug`        VARCHAR(100) NOT NULL,           -- machine key e.g. employees.create
  `module`      VARCHAR(60)  NOT NULL,           -- grouping e.g. Employees
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_permissions_slug` (`slug`),
  KEY `idx_permissions_module` (`module`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `role_permissions` (
  `role_id`       INT UNSIGNED NOT NULL,
  `permission_id` INT UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`,`permission_id`),
  KEY `idx_rp_permission` (`permission_id`),
  CONSTRAINT `fk_rp_role` FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_rp_perm` FOREIGN KEY (`permission_id`) REFERENCES `permissions`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Users (login accounts)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `role_id`        INT UNSIGNED NOT NULL,
  `username`       VARCHAR(60)  DEFAULT NULL,      -- optional login handle
  `name`           VARCHAR(120) NOT NULL,
  `email`          VARCHAR(150) NOT NULL,
  `password_hash`  VARCHAR(255) NOT NULL,
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `must_change_pw` TINYINT(1)   NOT NULL DEFAULT 0,
  `auth_version`   INT UNSIGNED NOT NULL DEFAULT 1, -- bump to invalidate sessions
  `last_login_at`  DATETIME     DEFAULT NULL,
  `last_login_ip`  VARCHAR(45)  DEFAULT NULL,
  `last_activity`  DATETIME     DEFAULT NULL,       -- for idle session timeout
  `failed_attempts` INT UNSIGNED NOT NULL DEFAULT 0,
  `locked_until`   DATETIME     DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_users_email` (`email`),
  UNIQUE KEY `uq_users_username` (`username`),
  KEY `idx_users_role` (`role_id`),
  CONSTRAINT `fk_users_role` FOREIGN KEY (`role_id`) REFERENCES `roles`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Remember-me tokens (selector/validator pattern)
DROP TABLE IF EXISTS `auth_tokens`;
CREATE TABLE `auth_tokens` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED NOT NULL,
  `selector`       CHAR(24)     NOT NULL,
  `validator_hash` CHAR(64)     NOT NULL,
  `expires_at`     DATETIME     NOT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_auth_selector` (`selector`),
  KEY `idx_auth_user` (`user_id`),
  CONSTRAINT `fk_auth_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Password reset tokens
DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE `password_resets` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED NOT NULL,
  `selector`    CHAR(24)     NOT NULL,
  `token_hash`  CHAR(64)     NOT NULL,
  `expires_at`  DATETIME     NOT NULL,
  `used_at`     DATETIME     NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reset_selector` (`selector`),
  KEY `idx_reset_user` (`user_id`),
  CONSTRAINT `fk_reset_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Login attempt log (rate limiting / audit)
DROP TABLE IF EXISTS `login_attempts`;
CREATE TABLE `login_attempts` (
  `id`         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `email`      VARCHAR(150) DEFAULT NULL,
  `ip_address` VARCHAR(45)  DEFAULT NULL,
  `success`    TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_la_email_time` (`email`,`created_at`),
  KEY `idx_la_ip_time` (`ip_address`,`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Org structure
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `departments`;
CREATE TABLE `departments` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(120) NOT NULL,
  `code`       VARCHAR(30)  DEFAULT NULL,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_dept_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `designations`;
CREATE TABLE `designations` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(120) NOT NULL,
  `department_id` INT UNSIGNED DEFAULT NULL,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_desig_dept` (`department_id`),
  CONSTRAINT `fk_desig_dept` FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Employees
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `employees`;
CREATE TABLE `employees` (
  `id`               INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`          INT UNSIGNED DEFAULT NULL,     -- linked login account
  `emp_code`         VARCHAR(40)  NOT NULL,         -- Employee ID e.g. RG0001
  `full_name`        VARCHAR(150) NOT NULL,
  `photo`            VARCHAR(255) DEFAULT NULL,
  `mobile`           VARCHAR(20)  DEFAULT NULL,
  `email`            VARCHAR(150) DEFAULT NULL,
  `address`          TEXT         DEFAULT NULL,
  `dob`              DATE         DEFAULT NULL,
  `joining_date`     DATE         DEFAULT NULL,
  `department_id`    INT UNSIGNED DEFAULT NULL,
  `designation_id`   INT UNSIGNED DEFAULT NULL,
  `reporting_manager_id` INT UNSIGNED DEFAULT NULL, -- users.id (HR / Team Leader)
  `employment_type`  VARCHAR(50)  DEFAULT 'Full Time',
  `office_location`  VARCHAR(150) DEFAULT NULL,
  `basic_salary`     DECIMAL(12,2) NOT NULL DEFAULT 0,
  `salary_structure` VARCHAR(80)  DEFAULT NULL,
  `bank_name`        VARCHAR(120) DEFAULT NULL,
  `bank_account`     VARCHAR(50)  DEFAULT NULL,
  `bank_ifsc`        VARCHAR(20)  DEFAULT NULL,
  `upi_id`           VARCHAR(120) DEFAULT NULL,
  `pan`              VARCHAR(20)  DEFAULT NULL,
  `aadhaar`          VARCHAR(20)  DEFAULT NULL,
  `emergency_name`   VARCHAR(120) DEFAULT NULL,
  `emergency_phone`  VARCHAR(20)  DEFAULT NULL,
  `emergency_relation` VARCHAR(60) DEFAULT NULL,
  `status`           ENUM('Active','Inactive','Resigned','Terminated') NOT NULL DEFAULT 'Active',
  `is_staff`         TINYINT(1)   NOT NULL DEFAULT 0,   -- 1 = HR/Team-Leader self-attendance profile
  `notes`            TEXT         DEFAULT NULL,
  `created_at`       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`       TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_emp_code` (`emp_code`),
  KEY `idx_emp_user` (`user_id`),
  KEY `idx_emp_dept` (`department_id`),
  KEY `idx_emp_desig` (`designation_id`),
  KEY `idx_emp_status` (`status`),
  KEY `idx_emp_is_staff` (`is_staff`),
  KEY `idx_emp_manager` (`reporting_manager_id`),
  CONSTRAINT `fk_emp_user`  FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_dept`  FOREIGN KEY (`department_id`) REFERENCES `departments`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_desig` FOREIGN KEY (`designation_id`) REFERENCES `designations`(`id`) ON DELETE SET NULL,
  CONSTRAINT `fk_emp_mgr`   FOREIGN KEY (`reporting_manager_id`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `employee_documents`;
CREATE TABLE `employee_documents` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` INT UNSIGNED NOT NULL,
  `title`       VARCHAR(150) NOT NULL,
  `file_path`   VARCHAR(255) NOT NULL,
  `uploaded_by` INT UNSIGNED DEFAULT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_docs_emp` (`employee_id`),
  CONSTRAINT `fk_docs_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Attendance
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `attendance_statuses`;
CREATE TABLE `attendance_statuses` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`       VARCHAR(60)  NOT NULL,
  `slug`       VARCHAR(60)  NOT NULL,
  `color`      VARCHAR(20)  NOT NULL DEFAULT '#6b7280',
  `short_code` VARCHAR(5)   NOT NULL DEFAULT 'P',
  `is_paid`    TINYINT(1)   NOT NULL DEFAULT 1,   -- counts as paid for payroll
  `is_leave`   TINYINT(1)   NOT NULL DEFAULT 0,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order` INT          NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_attstatus_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `attendance`;
CREATE TABLE `attendance` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    INT UNSIGNED NOT NULL,
  `att_date`       DATE         NOT NULL,
  `check_in`       DATETIME     DEFAULT NULL,   -- server generated
  `check_out`      DATETIME     DEFAULT NULL,   -- server generated
  `status_id`      INT UNSIGNED DEFAULT NULL,   -- attendance_statuses.id
  `working_minutes` INT         NOT NULL DEFAULT 0,
  `late_minutes`   INT          NOT NULL DEFAULT 0,
  `early_minutes`  INT          NOT NULL DEFAULT 0,
  `check_in_ip`    VARCHAR(45)  DEFAULT NULL,
  `check_out_ip`   VARCHAR(45)  DEFAULT NULL,
  `check_in_device`  VARCHAR(255) DEFAULT NULL,
  `check_out_device` VARCHAR(255) DEFAULT NULL,
  `late_reason`    VARCHAR(255) DEFAULT NULL,
  `early_reason`   VARCHAR(255) DEFAULT NULL,
  `early_status`   ENUM('Pending','Approved','Rejected') DEFAULT NULL,
  `employee_remark` VARCHAR(255) DEFAULT NULL,
  `admin_remark`   VARCHAR(255) DEFAULT NULL,
  `is_locked`      TINYINT(1)   NOT NULL DEFAULT 0,
  `is_manual`      TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_att_emp_date` (`employee_id`,`att_date`),
  KEY `idx_att_date` (`att_date`),
  KEY `idx_att_status` (`status_id`),
  CONSTRAINT `fk_att_emp`    FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_att_status` FOREIGN KEY (`status_id`) REFERENCES `attendance_statuses`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Attendance change audit (before/after)
DROP TABLE IF EXISTS `attendance_audit`;
CREATE TABLE `attendance_audit` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `attendance_id` BIGINT UNSIGNED DEFAULT NULL,
  `employee_id`  INT UNSIGNED NOT NULL,
  `att_date`     DATE         NOT NULL,
  `old_value`    JSON         DEFAULT NULL,
  `new_value`    JSON         DEFAULT NULL,
  `reason`       VARCHAR(255) DEFAULT NULL,
  `changed_by`   INT UNSIGNED DEFAULT NULL,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_attaudit_emp` (`employee_id`,`att_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Leave management
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `leave_types`;
CREATE TABLE `leave_types` (
  `id`             INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`           VARCHAR(80)  NOT NULL,
  `slug`           VARCHAR(80)  NOT NULL,
  `is_paid`        TINYINT(1)   NOT NULL DEFAULT 1,
  `annual_quota`   DECIMAL(5,1) NOT NULL DEFAULT 0,   -- days/year default
  `color`          VARCHAR(20)  NOT NULL DEFAULT '#3b82f6',
  `is_active`      TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_leavetype_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `leave_requests`;
CREATE TABLE `leave_requests` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    INT UNSIGNED NOT NULL,
  `leave_type_id`  INT UNSIGNED NOT NULL,
  `start_date`     DATE         NOT NULL,
  `end_date`       DATE         NOT NULL,
  `is_half_day`    TINYINT(1)   NOT NULL DEFAULT 0,
  `total_days`     DECIMAL(5,1) NOT NULL DEFAULT 1,
  `reason`         TEXT         DEFAULT NULL,
  `emergency_reason` TEXT       DEFAULT NULL,
  `contact_during_leave` VARCHAR(120) DEFAULT NULL,
  `document`       VARCHAR(255) DEFAULT NULL,
  `status`         ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  -- Parallel approval: either Team Leader OR HR approving allows the leave;
  -- both must reject to deny it.
  `hr_decision`    ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `hr_by`          INT UNSIGNED DEFAULT NULL,
  `hr_at`          DATETIME     DEFAULT NULL,
  `hr_remark`      VARCHAR(255) DEFAULT NULL,
  `tl_decision`    ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `tl_by`          INT UNSIGNED DEFAULT NULL,
  `tl_at`          DATETIME     DEFAULT NULL,
  `tl_remark`      VARCHAR(255) DEFAULT NULL,
  `admin_remark`   VARCHAR(255) DEFAULT NULL,
  `approved_by`    INT UNSIGNED DEFAULT NULL,
  `approved_at`    DATETIME     DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_lr_emp` (`employee_id`),
  KEY `idx_lr_type` (`leave_type_id`),
  KEY `idx_lr_status` (`status`),
  CONSTRAINT `fk_lr_emp`  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_lr_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types`(`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

DROP TABLE IF EXISTS `leave_balances`;
CREATE TABLE `leave_balances` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`   INT UNSIGNED NOT NULL,
  `leave_type_id` INT UNSIGNED NOT NULL,
  `year`          SMALLINT     NOT NULL,
  `entitlement`   DECIMAL(5,1) NOT NULL DEFAULT 0,
  `used`          DECIMAL(5,1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_balance` (`employee_id`,`leave_type_id`,`year`),
  CONSTRAINT `fk_bal_emp`  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_bal_type` FOREIGN KEY (`leave_type_id`) REFERENCES `leave_types`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Holidays
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `holidays`;
CREATE TABLE `holidays` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(120) NOT NULL,
  `holiday_date` DATE        NOT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `scope`       VARCHAR(120) DEFAULT 'All',   -- department/location or All
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_holiday_date` (`holiday_date`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Salary components (customizable earnings/deductions)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `salary_components`;
CREATE TABLE `salary_components` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`         VARCHAR(120) NOT NULL,
  `slug`         VARCHAR(120) NOT NULL,
  `type`         ENUM('earning','deduction') NOT NULL,
  `calc_type`    ENUM('fixed','percentage') NOT NULL DEFAULT 'fixed',
  `default_amount` DECIMAL(12,2) NOT NULL DEFAULT 0,  -- amount or % of basic
  `is_recurring` TINYINT(1)   NOT NULL DEFAULT 1,
  `is_active`    TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order`   INT          NOT NULL DEFAULT 0,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_component_slug` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Per-employee overrides of default component amounts (salary structure)
DROP TABLE IF EXISTS `employee_salary_components`;
CREATE TABLE `employee_salary_components` (
  `id`           INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`  INT UNSIGNED NOT NULL,
  `component_id` INT UNSIGNED NOT NULL,
  `amount`       DECIMAL(12,2) NOT NULL DEFAULT 0,
  `calc_type`    ENUM('fixed','percentage') NOT NULL DEFAULT 'fixed',
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_esc` (`employee_id`,`component_id`),
  CONSTRAINT `fk_esc_emp`  FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_esc_comp` FOREIGN KEY (`component_id`) REFERENCES `salary_components`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Payroll (one row per employee per month) + line items
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `payroll_items`;
DROP TABLE IF EXISTS `salary_payments`;
DROP TABLE IF EXISTS `payroll`;
CREATE TABLE `payroll` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    INT UNSIGNED NOT NULL,
  `pay_month`      CHAR(7)      NOT NULL,          -- YYYY-MM
  `basic_salary`   DECIMAL(12,2) NOT NULL DEFAULT 0,
  `gross_earnings` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `total_deductions` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `net_salary`     DECIMAL(12,2) NOT NULL DEFAULT 0,
  `paid_amount`    DECIMAL(12,2) NOT NULL DEFAULT 0,
  `pending_amount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  -- attendance summary snapshot
  `present_days`   DECIMAL(5,1) NOT NULL DEFAULT 0,
  `absent_days`    DECIMAL(5,1) NOT NULL DEFAULT 0,
  `leave_days`     DECIMAL(5,1) NOT NULL DEFAULT 0,
  `late_count`     INT          NOT NULL DEFAULT 0,
  `payable_days`   DECIMAL(5,1) NOT NULL DEFAULT 0,
  `working_days`   DECIMAL(5,1) NOT NULL DEFAULT 0,
  `status`         ENUM('Draft','Pending','Partially Paid','Paid','On Hold','Unpaid') NOT NULL DEFAULT 'Draft',
  `is_finalized`   TINYINT(1)   NOT NULL DEFAULT 0,
  `payment_date`   DATE         DEFAULT NULL,
  `payment_mode`   VARCHAR(60)  DEFAULT NULL,
  `reference_no`   VARCHAR(120) DEFAULT NULL,
  `admin_remark`   VARCHAR(255) DEFAULT NULL,
  `created_by`     INT UNSIGNED DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_payroll_emp_month` (`employee_id`,`pay_month`),
  KEY `idx_payroll_month` (`pay_month`),
  KEY `idx_payroll_status` (`status`),
  CONSTRAINT `fk_payroll_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payroll_items` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_id`   BIGINT UNSIGNED NOT NULL,
  `component_id` INT UNSIGNED DEFAULT NULL,   -- null for system generated (late/leave/emi)
  `label`        VARCHAR(120) NOT NULL,
  `type`         ENUM('earning','deduction') NOT NULL,
  `amount`       DECIMAL(12,2) NOT NULL DEFAULT 0,
  `source`       VARCHAR(40)  NOT NULL DEFAULT 'component', -- component|late|leave|absent|emi|advance|manual
  PRIMARY KEY (`id`),
  KEY `idx_pi_payroll` (`payroll_id`),
  CONSTRAINT `fk_pi_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `salary_payments` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `payroll_id`  BIGINT UNSIGNED NOT NULL,
  `amount`      DECIMAL(12,2) NOT NULL,
  `payment_date` DATE        NOT NULL,
  `payment_mode` VARCHAR(60) DEFAULT NULL,
  `reference_no` VARCHAR(120) DEFAULT NULL,
  `remark`      VARCHAR(255) DEFAULT NULL,
  `created_by`  INT UNSIGNED DEFAULT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_sp_payroll` (`payroll_id`),
  CONSTRAINT `fk_sp_payroll` FOREIGN KEY (`payroll_id`) REFERENCES `payroll`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Advances / Loans / EMI
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `emi_schedules`;
DROP TABLE IF EXISTS `employee_advances`;
CREATE TABLE `employee_advances` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    INT UNSIGNED NOT NULL,
  `advance_type`   VARCHAR(60)  NOT NULL DEFAULT 'Salary Advance',
  `total_amount`   DECIMAL(12,2) NOT NULL,
  `emi_amount`     DECIMAL(12,2) NOT NULL,
  `installments`   INT          NOT NULL,
  `first_emi_month` CHAR(7)     NOT NULL,          -- YYYY-MM
  `date_issued`    DATE         NOT NULL,
  `recovered_amount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `balance_amount` DECIMAL(12,2) NOT NULL DEFAULT 0,
  `status`         ENUM('Active','Completed','Paused','Cancelled') NOT NULL DEFAULT 'Active',
  `remark`         VARCHAR(255) DEFAULT NULL,
  `created_by`     INT UNSIGNED DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_adv_emp` (`employee_id`),
  KEY `idx_adv_status` (`status`),
  CONSTRAINT `fk_adv_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `emi_schedules` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `advance_id`  BIGINT UNSIGNED NOT NULL,
  `installment_no` INT       NOT NULL,
  `due_month`   CHAR(7)      NOT NULL,             -- YYYY-MM
  `amount`      DECIMAL(12,2) NOT NULL,
  `status`      ENUM('Pending','Paid','Skipped') NOT NULL DEFAULT 'Pending',
  `payroll_id`  BIGINT UNSIGNED DEFAULT NULL,      -- linked when deducted
  `paid_at`     DATETIME     DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_emi_advance` (`advance_id`),
  KEY `idx_emi_month` (`due_month`),
  CONSTRAINT `fk_emi_advance` FOREIGN KEY (`advance_id`) REFERENCES `employee_advances`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Custom fields (dynamic per module) + values
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `custom_field_values`;
DROP TABLE IF EXISTS `custom_fields`;
CREATE TABLE `custom_fields` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `module`      VARCHAR(60)  NOT NULL,   -- employee|attendance|salary|deduction ...
  `label`       VARCHAR(120) NOT NULL,
  `field_key`   VARCHAR(120) NOT NULL,
  `field_type`  ENUM('text','number','amount','dropdown','date','time','checkbox','yesno','textarea') NOT NULL DEFAULT 'text',
  `options`     TEXT         DEFAULT NULL,   -- comma or JSON for dropdown
  `is_required` TINYINT(1)   NOT NULL DEFAULT 0,
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order`  INT          NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cf_module_key` (`module`,`field_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `custom_field_values` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `field_id`    INT UNSIGNED NOT NULL,
  `record_id`   BIGINT UNSIGNED NOT NULL,   -- id of the row in the module table
  `value`       TEXT         DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_cfv` (`field_id`,`record_id`),
  CONSTRAINT `fk_cfv_field` FOREIGN KEY (`field_id`) REFERENCES `custom_fields`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Notifications
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `notifications`;
CREATE TABLE `notifications` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED NOT NULL,      -- recipient
  `type`        VARCHAR(60)  NOT NULL,
  `title`       VARCHAR(150) NOT NULL,
  `body`        VARCHAR(500) DEFAULT NULL,
  `link`        VARCHAR(255) DEFAULT NULL,
  `is_read`     TINYINT(1)   NOT NULL DEFAULT 0,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notif_user` (`user_id`,`is_read`),
  CONSTRAINT `fk_notif_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Audit logs (admin actions)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `audit_logs`;
CREATE TABLE `audit_logs` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED DEFAULT NULL,
  `action`      VARCHAR(120) NOT NULL,
  `entity`      VARCHAR(60)  DEFAULT NULL,
  `entity_id`   BIGINT UNSIGNED DEFAULT NULL,
  `description` VARCHAR(255) DEFAULT NULL,
  `old_value`   JSON         DEFAULT NULL,
  `new_value`   JSON         DEFAULT NULL,
  `ip_address`  VARCHAR(45)  DEFAULT NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_audit_user` (`user_id`),
  KEY `idx_audit_entity` (`entity`,`entity_id`),
  KEY `idx_audit_time` (`created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- Settings (key/value)
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `settings`;
CREATE TABLE `settings` (
  `setting_key`   VARCHAR(80)  NOT NULL,
  `setting_value` TEXT         DEFAULT NULL,
  `updated_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`setting_key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- =====================================================================
--  SEED DATA
-- =====================================================================

-- Roles ---------------------------------------------------------------
INSERT INTO `roles` (`id`,`name`,`slug`,`description`,`is_system`) VALUES
 (1,'Super Admin','super_admin','Full unrestricted access',1),
 (2,'Admin / HR','hr_admin','HR and payroll management',1),
 (3,'Employee','employee','Self-service employee portal',1),
 (4,'Team Leader','team_leader','Approves team leave requests and views attendance',1);

-- Permissions ---------------------------------------------------------
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
 ('View Dashboard','dashboard.view','Dashboard'),
 ('View Employees','employees.view','Employees'),
 ('Create Employees','employees.create','Employees'),
 ('Edit Employees','employees.edit','Employees'),
 ('Delete Employees','employees.delete','Employees'),
 ('View Attendance','attendance.view','Attendance'),
 ('Manage Attendance','attendance.manage','Attendance'),
 ('Manual Attendance','attendance.manual','Attendance'),
 ('View Leaves','leaves.view','Leave'),
 ('Approve Leaves','leaves.approve','Leave'),
 ('View Payroll','payroll.view','Payroll'),
 ('Manage Payroll','payroll.manage','Payroll'),
 ('View Advances','advances.view','Advance'),
 ('Manage Advances','advances.manage','Advance'),
 ('View Reports','reports.view','Reports'),
 ('Manage Custom Fields','customfields.manage','Administration'),
 ('Manage Holidays','holidays.manage','Administration'),
 ('View Audit Logs','audit.view','Administration'),
 ('Manage Users','users.manage','Administration'),
 ('Manage Roles','roles.manage','Administration'),
 ('Manage Settings','settings.manage','Settings'),
 ('Manage Employee Login Credentials','employees.credentials','Employees'),
 ('Configure Salary Components','config.salary_components','Settings'),
 ('Configure Leave Types','config.leave_types','Settings'),
 ('Permanently Delete Records','records.delete','Administration');

-- Super Admin gets all permissions
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 1, id FROM `permissions`;

-- Admin/HR gets operational permissions only (no global config, no user/role
-- management, no permanent delete). Super Admin retains full control.
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 2, id FROM `permissions` WHERE slug IN (
   'dashboard.view',
   'employees.view','employees.create','employees.edit','employees.credentials',
   'attendance.view','attendance.manage','attendance.manual',
   'leaves.view','leaves.approve',
   'payroll.view','payroll.manage',
   'advances.view','advances.manage',
   'reports.view'
 );

-- Employee: dashboard, own attendance/leaves handled in code (no admin perms)
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 3, id FROM `permissions` WHERE slug IN ('dashboard.view');

-- Team Leader: view attendance, view + approve leave requests
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 4, id FROM `permissions` WHERE slug IN (
   'dashboard.view','attendance.view','leaves.view','leaves.approve'
 );

-- Default users -------------------------------------------------------
-- Password for BOTH accounts below is:  Admin@123
-- Hash generated with password_hash('Admin@123', PASSWORD_DEFAULT)
INSERT INTO `users` (`id`,`role_id`,`name`,`email`,`password_hash`,`is_active`) VALUES
 (1,1,'Super Admin','superadmin@rgrealty.com','$2y$10$PKTz3N4I/qwN8dfv7wBpku9Yqj2Bh3/1nvDBe0Bu4HjbdWQsz5fhO',1),
 (2,2,'HR Manager','hr@rgrealty.com','$2y$10$PKTz3N4I/qwN8dfv7wBpku9Yqj2Bh3/1nvDBe0Bu4HjbdWQsz5fhO',1);
-- The hash above is a real bcrypt hash of  Admin@123 . You can log in
-- immediately after import. Use install/generate_admin.php to reset it,
-- and CHANGE all passwords before going live.

-- Departments & designations -----------------------------------------
INSERT INTO `departments` (`id`,`name`,`code`) VALUES
 (1,'Sales',''),(2,'Marketing',''),(3,'Administration',''),(4,'Operations','');
INSERT INTO `designations` (`id`,`name`,`department_id`) VALUES
 (1,'Sales Executive',1),(2,'Sales Manager',1),(3,'Telecaller',2),
 (4,'HR Manager',3),(5,'Accountant',3),(6,'Site Supervisor',4);

-- Attendance statuses -------------------------------------------------
INSERT INTO `attendance_statuses` (`name`,`slug`,`color`,`short_code`,`is_paid`,`is_leave`,`sort_order`) VALUES
 ('Present','present','#16a34a','P',1,0,1),
 ('Absent','absent','#dc2626','A',0,0,2),
 ('Late','late','#f59e0b','L',1,0,3),
 ('Half Day','half_day','#f97316','HD',1,0,4),
 ('Paid Leave','paid_leave','#3b82f6','PL',1,1,5),
 ('Unpaid Leave','unpaid_leave','#6b7280','UL',0,1,6),
 ('Casual Leave','casual_leave','#8b5cf6','CL',1,1,7),
 ('Sick Leave','sick_leave','#ec4899','SL',1,1,8),
 ('Urgent Leave','urgent_leave','#ef4444','UR',1,1,9),
 ('Early Leave','early_leave','#eab308','EL',1,0,10),
 ('Weekly Off','weekly_off','#94a3b8','WO',1,0,11),
 ('Holiday','holiday','#0ea5e9','H',1,0,12),
 ('Work From Home','wfh','#14b8a6','WFH',1,0,13),
 ('Outdoor Duty','outdoor_duty','#0891b2','OD',1,0,14),
 ('Client Meeting','client_meeting','#6366f1','CM',1,0,15),
 ('Comp Off','comp_off','#22c55e','CO',1,0,16);

-- Leave types ---------------------------------------------------------
INSERT INTO `leave_types` (`name`,`slug`,`is_paid`,`annual_quota`,`color`) VALUES
 ('Casual Leave','casual',1,12,'#8b5cf6'),
 ('Sick Leave','sick',1,8,'#ec4899'),
 ('Paid Leave','paid',1,12,'#3b82f6'),
 ('Unpaid Leave','unpaid',0,0,'#6b7280'),
 ('Emergency Leave','emergency',1,4,'#ef4444'),
 ('Personal Leave','personal',1,4,'#f59e0b'),
 ('Half-Day Leave','half_day',1,0,'#f97316');

-- Salary components ---------------------------------------------------
INSERT INTO `salary_components` (`name`,`slug`,`type`,`calc_type`,`default_amount`,`is_recurring`,`sort_order`) VALUES
 ('Basic','basic','earning','fixed',0,1,1),
 ('House Rent Allowance','hra','earning','percentage',20,1,2),
 ('Travel Allowance','travel','earning','fixed',0,1,3),
 ('Mobile Allowance','mobile','earning','fixed',0,1,4),
 ('Incentive','incentive','earning','fixed',0,0,5),
 ('Commission','commission','earning','fixed',0,0,6),
 ('Bonus','bonus','earning','fixed',0,0,7),
 ('Performance Bonus','performance_bonus','earning','fixed',0,0,8),
 ('Professional Tax','professional_tax','deduction','fixed',200,1,20),
 ('Other Deduction','other_deduction','deduction','fixed',0,0,21);

-- Settings ------------------------------------------------------------
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('company_name','RG Realty'),
 ('company_logo',''),
 ('company_address','RG Realty, India'),
 ('company_phone',''),
 ('company_email','info@rgrealty.com'),
 ('currency_symbol','₹'),
 ('timezone','Asia/Kolkata'),
 ('office_login_time','10:30'),
 ('office_logout_time','19:00'),
 ('grace_minutes','10'),
 ('half_day_after_minutes','120'),
 ('full_day_minutes','480'),
 ('weekly_offs','0'),                 -- comma list of weekday numbers, 0=Sunday
 ('late_deduction_per_day','0'),
 ('salary_month_start_day','1'),
 ('emp_code_prefix','RG'),
 ('emp_code_next','1'),
 ('login_max_attempts','5'),
 ('login_lockout_minutes','15'),
 ('session_timeout_minutes','30'),
 ('remember_me_days','30');

-- Sample employees (linked to users for testing) ----------------------
-- Employee login accounts (password: Admin@123 -- same placeholder hash)
INSERT INTO `users` (`id`,`role_id`,`name`,`email`,`password_hash`,`is_active`) VALUES
 (3,3,'Amit Sharma','amit@rgrealty.com','$2y$10$PKTz3N4I/qwN8dfv7wBpku9Yqj2Bh3/1nvDBe0Bu4HjbdWQsz5fhO',1),
 (4,3,'Priya Verma','priya@rgrealty.com','$2y$10$PKTz3N4I/qwN8dfv7wBpku9Yqj2Bh3/1nvDBe0Bu4HjbdWQsz5fhO',1),
 (5,3,'Rahul Singh','rahul@rgrealty.com','$2y$10$PKTz3N4I/qwN8dfv7wBpku9Yqj2Bh3/1nvDBe0Bu4HjbdWQsz5fhO',1);

-- Team Leader login (password: Admin@123 -- same placeholder hash; change it)
INSERT INTO `users` (`id`,`role_id`,`username`,`name`,`email`,`password_hash`,`is_active`) VALUES
 (6,4,'teamlead','Karan Mehta (Team Leader)','tl@rgrealty.com','$2y$10$PKTz3N4I/qwN8dfv7wBpku9Yqj2Bh3/1nvDBe0Bu4HjbdWQsz5fhO',1);

INSERT INTO `employees`
 (`id`,`user_id`,`emp_code`,`full_name`,`mobile`,`email`,`joining_date`,`department_id`,`designation_id`,`employment_type`,`office_location`,`basic_salary`,`status`) VALUES
 (1,3,'RG0001','Amit Sharma','9876500001','amit@rgrealty.com','2024-04-01',1,1,'Full Time','Head Office',35000,'Active'),
 (2,4,'RG0002','Priya Verma','9876500002','priya@rgrealty.com','2024-06-15',2,3,'Full Time','Head Office',28000,'Active'),
 (3,5,'RG0003','Rahul Singh','9876500003','rahul@rgrealty.com','2023-11-01',1,2,'Full Time','Head Office',50000,'Active');

UPDATE `settings` SET `setting_value`='4' WHERE `setting_key`='emp_code_next';

-- Sample advance / EMI for RG0001 (₹30,000 over 6 months @ ₹5,000) -----
INSERT INTO `employee_advances`
 (`id`,`employee_id`,`advance_type`,`total_amount`,`emi_amount`,`installments`,`first_emi_month`,`date_issued`,`recovered_amount`,`balance_amount`,`status`) VALUES
 (1,1,'Salary Advance',30000,5000,6,'2026-10',CURDATE(),0,30000,'Active');
INSERT INTO `emi_schedules` (`advance_id`,`installment_no`,`due_month`,`amount`) VALUES
 (1,1,'2026-10',5000),(1,2,'2026-11',5000),(1,3,'2026-12',5000),
 (1,4,'2027-01',5000),(1,5,'2027-02',5000),(1,6,'2027-03',5000);

-- ---------------------------------------------------------------------
-- Overtime & Extra Pay Management
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `overtime`;
DROP TABLE IF EXISTS `overtime_rates`;
CREATE TABLE `overtime_rates` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `day_type`   VARCHAR(40)  NOT NULL,
  `label`      VARCHAR(80)  NOT NULL,
  `multiplier` DECIMAL(4,2) NOT NULL DEFAULT 1.00,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order` INT          NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ot_daytype` (`day_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `overtime_rates` (`day_type`,`label`,`multiplier`,`sort_order`) VALUES
 ('normal','Regular Working Day',1.00,1),('weekly_off','Weekly Off',1.50,2),
 ('sunday','Sunday',1.50,3),('public_holiday','Public Holiday',2.00,4),
 ('festival','Festival Holiday',2.00,5),('emergency','Emergency Work',1.50,6),
 ('night','Night Work',1.50,7),('client_visit','Client / Site Visit',1.00,8),
 ('special_project','Special Project',1.25,9);

CREATE TABLE `overtime` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    INT UNSIGNED NOT NULL,
  `attendance_id`  BIGINT UNSIGNED DEFAULT NULL,
  `ot_date`        DATE         NOT NULL,
  `standard_out`   DATETIME     DEFAULT NULL,
  `actual_out`     DATETIME     DEFAULT NULL,
  `actual_minutes` INT          NOT NULL DEFAULT 0,
  `actual_hours`   DECIMAL(6,2) NOT NULL DEFAULT 0,
  `approved_hours` DECIMAL(6,2) NOT NULL DEFAULT 0,
  `day_type`       VARCHAR(40)  NOT NULL DEFAULT 'normal',
  `multiplier`     DECIMAL(4,2) NOT NULL DEFAULT 1.00,
  `hourly_rate`    DECIMAL(10,2) NOT NULL DEFAULT 0,
  `amount`         DECIMAL(12,2) NOT NULL DEFAULT 0,
  `employee_reason` TEXT        DEFAULT NULL,
  `work_performed` TEXT         DEFAULT NULL,
  `project_name`   VARCHAR(150) DEFAULT NULL,
  `hr_remark`      VARCHAR(255) DEFAULT NULL,
  `hr_by`          INT UNSIGNED DEFAULT NULL,
  `hr_at`          DATETIME     DEFAULT NULL,
  `manager_remark` VARCHAR(255) DEFAULT NULL,
  `approved_by`    INT UNSIGNED DEFAULT NULL,
  `approved_at`    DATETIME     DEFAULT NULL,
  `include_in_payroll` TINYINT(1) NOT NULL DEFAULT 1,
  `status`         ENUM('Detected','Pending Approval','HR Reviewed','Approved','Partially Approved','Rejected','Paid') NOT NULL DEFAULT 'Detected',
  `payroll_id`     BIGINT UNSIGNED DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ot_emp_date` (`employee_id`,`ot_date`),
  KEY `idx_ot_status` (`status`),
  KEY `idx_ot_date` (`ot_date`),
  CONSTRAINT `fk_ot_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('ot_enabled','1'),('ot_min_minutes','30'),('ot_rate_mode','salary'),
 ('ot_fixed_hourly','150'),('ot_monthly_standard_hours','200'),
 ('ot_rounding','nearest30'),('ot_max_daily_hours','5'),('ot_max_monthly_hours','60');

INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
 ('View Overtime','overtime.view','Overtime'),
 ('Approve Overtime','overtime.approve','Overtime'),
 ('Configure Overtime','overtime.config','Settings');
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 1, id FROM `permissions` WHERE slug IN ('overtime.view','overtime.approve','overtime.config');
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 2, id FROM `permissions` WHERE slug = 'overtime.view';

-- ---------------------------------------------------------------------
-- Notice Board / Announcements
-- ---------------------------------------------------------------------
DROP TABLE IF EXISTS `notice_reads`;
DROP TABLE IF EXISTS `notice_targets`;
DROP TABLE IF EXISTS `notices`;
CREATE TABLE `notices` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`         VARCHAR(200) NOT NULL,
  `message`       TEXT         NOT NULL,
  `priority`      ENUM('Normal','Important','Urgent') NOT NULL DEFAULT 'Normal',
  `audience_type` ENUM('all','employees','hr','department','branch','selected') NOT NULL DEFAULT 'all',
  `audience_value` VARCHAR(150) DEFAULT NULL,
  `attachment`    VARCHAR(255) DEFAULT NULL,
  `is_pinned`     TINYINT(1)   NOT NULL DEFAULT 0,
  `is_archived`   TINYINT(1)   NOT NULL DEFAULT 0,
  `publish_date`  DATE         NOT NULL,
  `expiry_date`   DATE         DEFAULT NULL,
  `created_by`    INT UNSIGNED DEFAULT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `deleted_at`    DATETIME     DEFAULT NULL,        -- soft-delete (Trash)
  `deleted_by`    INT UNSIGNED DEFAULT NULL,
  `delete_reason` VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_notice_pub` (`publish_date`),
  KEY `idx_notice_exp` (`expiry_date`),
  KEY `idx_notice_pin` (`is_pinned`),
  KEY `idx_notice_deleted` (`deleted_at`),
  CONSTRAINT `fk_notice_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `notice_targets` (
  `id`        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `notice_id` BIGINT UNSIGNED NOT NULL,
  `user_id`   INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notice_target` (`notice_id`,`user_id`),
  KEY `idx_nt_user` (`user_id`),
  CONSTRAINT `fk_nt_notice` FOREIGN KEY (`notice_id`) REFERENCES `notices`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nt_user`   FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `notice_reads` (
  `id`        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `notice_id` BIGINT UNSIGNED NOT NULL,
  `user_id`   INT UNSIGNED NOT NULL,
  `read_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notice_read` (`notice_id`,`user_id`),
  KEY `idx_nr_user` (`user_id`),
  CONSTRAINT `fk_nr_notice` FOREIGN KEY (`notice_id`) REFERENCES `notices`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nr_user`   FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
 ('Manage Notice Board','notices.manage','Notice Board');
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 1, id FROM `permissions` WHERE slug='notices.manage';
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
 SELECT 2, id FROM `permissions` WHERE slug='notices.manage';

SET FOREIGN_KEY_CHECKS = 1;
-- =====================================================================
--  End of rg_realty_crm.sql
-- =====================================================================
