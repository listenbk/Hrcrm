<?php
require_once __DIR__ . '/includes/bootstrap.php';
if (is_logged_in()) {
    redirect(home_for_current());
}
redirect('auth/login.php');
