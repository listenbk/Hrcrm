# RG Realty — Employee Management CRM

A complete, secure, responsive HR + Attendance + Payroll CRM built with
**PHP (PDO) + MySQL/MariaDB** — no framework, runs on standard XAMPP and
Hostinger shared hosting.

It manages employees, attendance (server-timestamped check-in/out), leave,
salary/payroll, salary advances & EMI, deductions, salary slips, and gives
administrators dashboard-level control over almost every HR rule (attendance
timings, leave types, salary components, custom fields, roles & permissions)
**without editing code**.

---

## 1. Requirements

| Component | Minimum |
|-----------|---------|
| PHP       | **8.0+** (uses `str_starts_with`, arrow functions, typed helpers) |
| MySQL / MariaDB | 5.7+ / 10.2+ (uses `JSON` columns, `utf8mb4`) |
| Apache    | with `mod_headers` (optional but recommended) |
| PHP ext.  | `pdo_mysql`, `mbstring`, `fileinfo` |

XAMPP 8.x and Hostinger's default PHP 8.x both satisfy this.

---

## 2. Install on XAMPP (local)

1. **Copy the project** so it lives at:
   ```
   C:\xampp\htdocs\rg_crm
   ```
   (It already is if you are reading this there.)

2. **Start** Apache + MySQL from the XAMPP Control Panel.

3. **Create the database & import the schema**
   - Open <http://localhost/phpmyadmin>
   - Create a database named **`rg_realty_crm`** (collation `utf8mb4_unicode_ci`).
   - Select it → **Import** tab → choose **`rg_realty_crm.sql`** → **Go**.

4. **Set the admin passwords** (the SQL ships with a placeholder hash):
   - Open <http://localhost/rg_crm/install/generate_admin.php>
   - Click **Generate & Apply** (default password `Admin@123`).
   - **Then delete the `install/` folder.**

5. **Log in** at <http://localhost/rg_crm/>

> If your app is not at `/rg_crm`, set `BASE_URL` in `config/config.php`
> (e.g. `''` when the app is a domain root).

---

## 3. Deploy on Hostinger

1. **Create a MySQL database** in hPanel → *Databases → MySQL Databases*.
   Note the **database name, user, password, host**.

2. **Upload** all project files (via File Manager or FTP) into
   `public_html/` (or a subfolder such as `public_html/crm`).

3. **Import** `rg_realty_crm.sql` through hPanel → *phpMyAdmin → Import*.

4. **Edit `config/config.php`** — set your Hostinger DB credentials and the
   correct `BASE_URL`:
   ```php
   define('DB_HOST', 'localhost');            // Hostinger usually 'localhost'
   define('DB_NAME', 'uXXXXXX_rgcrm');
   define('DB_USER', 'uXXXXXX_rguser');
   define('DB_PASS', 'your-strong-password');
   define('APP_ENV', 'production');
   define('BASE_URL', '');                     // '' if app is the domain root
   ```

5. Visit `https://yourdomain.com/install/generate_admin.php`, set a strong
   password, then **delete `install/`**.

6. In `.htaccess`, **uncomment the "Force HTTPS" block** once SSL is active.

### Database configuration via environment variables (optional)
`config/config.php` reads `getenv()` first, so on hosts that support env vars
you can avoid editing the file:
```
DB_HOST, DB_NAME, DB_USER, DB_PASS, BASE_URL, APP_ENV
```

---

## 4. Default accounts (after running the installer)

| Role        | Email                        | Password   |
|-------------|------------------------------|------------|
| Super Admin | `superadmin@rgrealty.com`    | `Admin@123` |
| Admin / HR  | `hr@rgrealty.com`            | `Admin@123` |
| Employee    | `amit@rgrealty.com`          | `Admin@123` |
| Employee    | `priya@rgrealty.com`         | `Admin@123` |
| Employee    | `rahul@rgrealty.com`         | `Admin@123` |

**Change every password after first login** (Users page, or employee Profile).

Sample data included for testing: 3 employees (RG0001–RG0003), departments,
designations, attendance statuses, leave types, salary components, and one
sample advance (₹30,000 @ ₹5,000 × 6 EMIs) for RG0001.

---

## 5. First-run checklist for the administrator

1. **Settings → Company & Rules** — set company name, logo, office timings
   (default 10:30 AM–7:00 PM), grace period, weekly offs, currency, security.
2. **Departments / Designations** — adjust to your structure.
3. **Attendance statuses / Leave types / Salary components** — customize.
4. **Employees → Add Employee** — create staff (optionally with a login).
5. Employees **Check In / Check Out** from their dashboard (server records
   the real time, late/early are auto-flagged).
6. **Payroll → Generate Payroll** for a month → review → record payments →
   **Salary Slips** → View / Print / Save as PDF.

---

## 5a. Multi-role login & security hierarchy

One professional login page (`auth/login.php`) accepts **Employee ID, username,
or email** + password, with **Remember me** and **Forgot password**. The role is
detected from the database (never chosen on the page) and the user is redirected:

| Role slug     | Who         | Lands on               |
|---------------|-------------|------------------------|
| `super_admin` | Manager     | `/admin/dashboard.php` |
| `hr_admin`    | Admin / HR  | `/hr/dashboard.php`    |
| `team_leader` | Team Leader | `/tl/dashboard.php`    |
| `employee`    | Employee    | `/employee/dashboard.php` |

### Leave approval — parallel (Team Leader **or** HR)

Each leave request is sent to **both a Team Leader and HR** (Managers act on the
HR channel). Each holds an independent decision slot (`tl_decision` / `hr_decision`
on `leave_requests`):

- **Either** approver approving ⇒ the leave is **Approved** immediately (allowed),
  even if the other had already rejected it.
- A single rejection leaves the request **Pending**, awaiting the other approver.
- Only when **both** reject is the leave finally **Rejected**.

The Team Leader (`team_leader`) can view attendance and approve/reject leave, but
has no employee-management, payroll or configuration access. Apply
`install/migrate_team_leader.sql` once to add this role to an existing database.

Permissions live in `roles` / `permissions` / `role_permissions` (never
hard-coded). **HR** has operational permissions only; **Super Admin** additionally
holds all global configuration, user/role management and permanent-delete rights.
Menus and page guards adapt automatically to the signed-in user's permissions.

Login security implemented in `includes/auth.php`:
`password_hash`/`password_verify`, PDO prepared statements, CSRF, hardened
sessions with ID regeneration, **idle session timeout**, **account lockout**
after N failed attempts (`failed_attempts` + `locked_until`), IP rate limiting,
**remember-me** tokens (`auth_tokens`, selector/validator), **password reset**
(`password_resets`, 1-hour tokens), and **`auth_version`** which invalidates a
user's other sessions whenever their password is changed or reset.

Password-reset delivery uses PHP `mail()` (works on Hostinger). On localhost
without SMTP, the reset link is written to `storage/reset_links.log` (a
web-inaccessible folder) and, when `APP_ENV=development`, shown on screen.

### Deleting accounts & employees (password-confirmed)

Destructive actions re-authenticate the acting Super Admin with their **own**
password (`password_verify`, never the target's) plus an optional reason, and
are written to the audit log:

- **Delete a user account** — Administration → **Users** → *Delete*. Blocked for
  your own account and for the last active Super Admin; HR/Team-Leader users
  cannot reach this page at all (it is `users.manage`, Super-Admin-only).
- **Delete an employee** — the employee's profile → **Delete**. Removes the
  employee and, via foreign-key cascade, all attendance, leave, payroll & slips,
  advances/EMI, overtime and documents, plus the linked login account. Requires
  the `employees.delete` permission (Super Admin only).

The **Employee ID** (`emp_code`) is editable from the Edit Employee form
(uniqueness enforced). Employee status Active / Inactive / Resigned / Terminated
covers marking staff as resigned, terminated or archived.

A Super Admin can also **generate a reset link on demand** for any account from
**Administration → Password Resets** (`admin/password_resets.php`) and hand it
over directly — the link is shown once with a copy button and any pending link
is listed with a revoke option. (Reset tokens are stored only as a one-way hash,
so a previously issued link can never be re-displayed — only re-generated.)

> **Upgrading an existing database** (installed before this auth update):
> import `install/migrate_auth.sql` once via phpMyAdmin — it adds the new
> columns/tables, renames the HR role slug to `hr_admin`, and applies the
> HR-vs-Super-Admin permission split. Fresh imports of `rg_realty_crm.sql`
> already include everything.

---

## 5b. Overtime & Extra Pay

Overtime is detected automatically from the **server-generated** check-out time
(never user-entered) whenever an employee works past the configured office
closing time by at least the minimum eligible minutes.

- **Workflow**: Detected → employee submits reason (Pending Approval) →
  HR reviews/recommends (HR Reviewed) → **Manager approves** (Approved /
  Partially Approved) → included in payroll → **Paid** on payroll finalize.
- **Rate**: fixed hourly, or salary-based (`monthly salary ÷ standard hours`),
  times a **day-type multiplier** (regular 1.0× / weekly-off & Sunday 1.5× /
  holiday 2.0× …, all editable). Amount = approved hours × rate × multiplier.
- **Configurable** (Super Admin → *Overtime Rules*): enable/disable, minimum
  minutes, rounding (exact / nearest 15 / nearest 30 / up / down), rate method,
  fixed rate, standard monthly hours, daily/monthly caps, and every multiplier.
- Manager can approve **fewer hours** than recorded; both actual and approved
  hours are stored. Approved OT appears on payroll as **Overtime Pay** and on the
  salary slip with an hours / rate / multiplier / earnings breakdown.
- Pages: `admin/overtime.php` (HR review + Manager approval),
  `admin/overtime_settings.php` (config), `employee/overtime.php` (own records +
  submit reason). Engine in `includes/overtime_lib.php`.

Apply `install/migrate_overtime.sql` once to add this to an existing database.

---

## 5c. HR / Team-Leader self-attendance

HR and Team-Leader users are also staff, so they get their **own** attendance —
they behave like an employee for their own record while still managing employee
operations. On first login a lightweight employee profile (`is_staff = 1`,
code `STFxxxx`) is created and linked to their user, reusing the whole
attendance / overtime / leave engine. These profiles are hidden from the regular
employee roster, payroll runs and attendance dashboards.

- **Check-in / Check-out** from the HR (and TL) dashboard — server-timestamped,
  same late / early / overtime rules as employees.
- **My Workspace** sidebar section: My Attendance history, Apply for Leave,
  Leave History, My Overtime.
- The **Manager** sees it all under **Attendance → HR Attendance**
  (`admin/hr_attendance.php`) with today's status and a monthly summary.

**Accountability guards — staff cannot self-approve or self-edit:**

| Action on own record | Result |
|---|---|
| Approve/reject own leave | blocked ("cannot approve your own leave") |
| Approve any HR/TL leave (as HR) | blocked — Manager only |
| Review/approve own overtime | blocked |
| Decide own early-leave | blocked |
| Edit own attendance in the manual editor | blocked — Manager only |

Only the **Manager (Super Admin)** can correct staff attendance, and that
correction requires the Manager's **own password** plus a reason, written to the
audit log. Apply `install/migrate_hr_attendance.sql` once for existing databases.

---

## 5d. Notice Board / Announcements

HR and the Manager broadcast announcements to targeted audiences; everyone sees
what applies to them.

- **Targeting**: All Users · All Employees · All HR/Admins · a Department · a
  Branch/office · Selected users.
- **Fields**: title, message, priority (Normal / Important / **Urgent**),
  publish date, expiry date, optional attachment, pin-to-top.
- **On each dashboard** (employee, HR, TL, Manager): a Notice Board widget with
  the latest notices; **Urgent** notices show as a prominent red banner; a 📢
  unread badge sits in the top bar.
- **Read tracking**: each notice records who has read it; the manager view
  (`admin/notice_reads.php`) lists read vs. not-read per person, and the list
  shows a live `read / audience` count.
- **Lifecycle**: pinned notices float to the top; **expired notices move to the
  Archive tab automatically**, and notices can be **manually Archived/Unarchived**.
- **Delete = soft-delete to Trash** (reason + the acting user's password
  required); deleted notices vanish from every dashboard immediately. A
  **Super Admin can Restore** from Trash or **permanently delete** (password
  again). HR may delete only notices they created — **never a Super Admin's**.
  Every trash / restore / permanent-delete action is audit-logged with the
  notice title, creator, actor, reason and time.
- Publishing also raises an **in-app notification** to every targeted user
  (the `notify()` layer is the single hook for future Email / WhatsApp / SMS).
- Pages: `noticeboard.php` (everyone), `admin/notices.php` (create/send),
  `admin/notice_reads.php` (read tracking). Logic in `includes/notice_lib.php`.
  Permission `notices.manage` (HR + Super Admin). All actions are audit-logged.

Apply `install/migrate_notices.sql` once to add this to an existing database.

---

## 6. Key features & where they live

| Area | File(s) |
|------|---------|
| Multi-role auth, lockout, remember-me, reset | `includes/auth.php`, `auth/*.php` |
| Overtime engine (detect → approve → pay) | `includes/overtime_lib.php`, `admin/overtime.php` |
| Notice Board (targeting + read tracking) | `includes/notice_lib.php`, `noticeboard.php`, `admin/notices.php` |
| Attendance engine (server time)  | `includes/attendance_lib.php`, `api/attendance.php` |
| Payroll calculation engine       | `includes/payroll_lib.php` |
| Custom fields (dynamic)          | `includes/customfields_lib.php`, `admin/custom_fields.php` |
| Salary slip (print → PDF)        | `includes/slip_render.php` |
| Admin dashboard & modules        | `admin/*.php` |
| Employee self-service            | `employee/*.php` |
| Audit logging                    | `includes/audit.php`, `admin/audit_logs.php` |

---

## 7. Security implementation

- Passwords: `password_hash()` / `password_verify()` (bcrypt), auto-rehash.
- **PDO prepared statements everywhere** (no string-built SQL) → SQL-injection safe.
- **CSRF tokens** on every POST form and AJAX call (`includes/csrf.php`).
- Hardened sessions: HttpOnly, SameSite=Lax, Secure on HTTPS, `use_strict_mode`,
  periodic + post-login `session_regenerate_id()`.
- **Login rate limiting / lockout** (configurable) via `login_attempts` table.
- Output escaping via `e()` (XSS), security headers + CSP in `bootstrap.php`.
- Role-based authorization guards (`require_perm`, `require_admin`) on every page.
- Uploads folder blocks script execution (`uploads/.htaccess`);
  `config/` and `includes/` deny direct web access.
- Full **audit log** of sensitive admin actions + a dedicated attendance-change
  audit (old vs new value, who, when, reason).

> After going live: delete `install/`, set `APP_ENV = production`, enable HTTPS.

---

## 8. Salary slip PDF

Slips render as a print-optimized HTML page with a **Print / Save as PDF**
button (works on every host, no library needed). To generate a fully
server-side PDF instead, drop [Dompdf](https://github.com/dompdf/dompdf) into
`vendor/` and render `includes/slip_render.php`'s HTML through it — the markup
is already print-ready.

---

## 9. Folder structure

```
rg_crm/
├─ config/            config.php (DB + app), protected
├─ includes/          db, auth, csrf, functions, settings, audit,
│                     attendance_lib, payroll_lib, customfields_lib,
│                     slip_render, bootstrap  (protected)
├─ templates/         header, sidebar, footer, 403
├─ assets/css|js/     style.css, app.js
├─ auth/              login.php, logout.php
├─ api/               attendance.php (AJAX check-in/out)
├─ admin/             dashboard + all HR/payroll/admin modules
├─ employee/          employee self-service portal
├─ uploads/           photos, logo, leaves (script exec disabled)
├─ install/           generate_admin.php  (DELETE after setup)
├─ index.php          router
├─ notifications.php  shared notifications
├─ .htaccess          security config
└─ rg_realty_crm.sql  importable database
```

---

## 10. Notes on extensibility (no-code customization)

Admins can add, without touching PHP:
- Attendance statuses, leave types, salary components (earnings & deductions),
  EMI/advance types, holidays, departments, designations.
- **Custom fields** for Employee / Attendance / Salary / Deduction / Leave.
- **Roles & granular permissions** (Super Admin only).
- Attendance rules (timings, grace, weekly offs, half-day thresholds),
  payroll and security settings.

Notification architecture (`notify()` / `notify_admins()`) is centralized so
Email / WhatsApp / SMS channels can be added later in one place.
