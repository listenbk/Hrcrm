<?php
/** Latest-notices dashboard widget. Include after $u = current_user() is set. */
$nw_user   = current_user();
$nw_all    = visible_notices_for($nw_user, false);
$nw_read   = [];
foreach (fetch_all("SELECT notice_id FROM notice_reads WHERE user_id=?", [$nw_user['id']]) as $r) $nw_read[(int)$r['notice_id']] = true;
$nw_urgent = array_values(array_filter($nw_all, fn($n) => $n['priority'] === 'Urgent' && !isset($nw_read[(int)$n['id']])));
$nw_latest = array_slice($nw_all, 0, 4);
if ($nw_all):
?>
<?php foreach ($nw_urgent as $un): ?>
  <div class="alert alert-error" style="align-items:flex-start">
    <span style="font-size:18px">🔴</span>
    <div><b>URGENT · <?= e($un['title']) ?></b>
      <div style="font-weight:400;font-size:13px"><?= e(mb_strimwidth($un['message'],0,140,'…')) ?>
        <a href="<?= url('noticeboard.php') ?>" style="white-space:nowrap">Read more →</a></div></div>
  </div>
<?php endforeach; ?>
<div class="card mb-2"><div class="card-head"><h3>📢 Notice Board</h3>
  <a class="btn btn-sm btn-outline" href="<?= url('noticeboard.php') ?>">View all</a></div>
  <div class="card-body" style="padding:0">
    <?php foreach ($nw_latest as $n): $unread = !isset($nw_read[(int)$n['id']]); ?>
      <a href="<?= url('noticeboard.php') ?>" class="list-row" style="<?= $unread?'background:#f0fdfa':'' ?>">
        <div style="width:100%"><div class="flex between" style="gap:8px">
          <span><?= $n['is_pinned']?'📌 ':'' ?><b><?= e($n['title']) ?></b>
            <span class="pill <?= notice_priority_pill($n['priority']) ?>" style="font-size:10px"><?= e($n['priority']) ?></span>
            <?php if($unread): ?><span class="pill pill-info" style="font-size:10px">New</span><?php endif; ?></span>
          <span class="text-muted" style="font-size:11px;white-space:nowrap"><?= fmt_date($n['publish_date'],'d M') ?></span>
        </div></div>
      </a>
    <?php endforeach; ?>
  </div>
</div>
<?php endif; ?>
