<?php
/** Role-aware navigation sidebar. $activeNav marks the current item. */
$isAdmin = is_admin();
$company = setting('company_name', 'RG Realty');
function nav_item(string $key, string $active, string $href, string $ico, string $label): string
{
    $cls = $key === $active ? 'nav-item active' : 'nav-item';
    return '<a class="'.$cls.'" href="'.url($href).'"><span class="ico">'.$ico.'</span> '.e($label).'</a>';
}
?>
<aside class="sidebar">
  <div class="sidebar-brand">
    <span class="logo">RG</span>
    <span><?= e($company) ?></span>
  </div>

<?php if ($isAdmin): $dashHref = is_super_admin() ? 'admin/dashboard.php' : 'hr/dashboard.php'; ?>
  <div class="nav-group">
    <?= nav_item('dashboard',$activeNav,$dashHref,'📊','Dashboard') ?>
    <?= nav_item('noticeboard',$activeNav,'noticeboard.php','📢','Notice Board') ?>
  <?php if (has_perm('notices.manage')): ?>
    <?= nav_item('notices_manage',$activeNav,'admin/notices.php','📝','Manage Notices') ?>
  <?php endif; ?>
  </div>

  <div class="nav-group">
    <div class="nav-group-title">Employees</div>
    <?= nav_item('employees',$activeNav,'admin/employees.php','👥','All Employees') ?>
    <?= nav_item('employee_add',$activeNav,'admin/employee_edit.php','➕','Add Employee') ?>
    <?= nav_item('departments',$activeNav,'admin/departments.php','🏢','Departments') ?>
    <?= nav_item('designations',$activeNav,'admin/designations.php','🏷️','Designations') ?>
  <?php if (has_perm('shifts.manage')): ?>
    <?= nav_item('shifts',$activeNav,'admin/shifts.php','🕘','Shifts') ?>
  <?php endif; ?>
  </div>

  <div class="nav-group">
    <div class="nav-group-title">Attendance</div>
    <?= nav_item('att_today',$activeNav,'admin/attendance_today.php','🕐',"Today's Attendance") ?>
    <?= nav_item('att_monthly',$activeNav,'admin/attendance_monthly.php','🗓️','Monthly Attendance') ?>
    <?= nav_item('att_manual',$activeNav,'admin/attendance_manual.php','✏️','Manual Attendance') ?>
    <?= nav_item('att_late',$activeNav,'admin/late_employees.php','⏰','Late Employees') ?>
    <?= nav_item('att_early',$activeNav,'admin/early_leave.php','🚪','Early Leave') ?>
  <?php if (has_perm('weekoff.manage')): ?>
    <?= nav_item('week_offs',$activeNav,'admin/week_offs.php','🗓️','Week-Off Management') ?>
  <?php endif; ?>
  <?php if (has_perm('geofence.manage')): ?>
    <?= nav_item('geofence',$activeNav,'admin/geofence.php','📍','Geofence & Sites') ?>
  <?php endif; ?>
  <?php if (is_super_admin()): ?>
    <?= nav_item('hr_att',$activeNav,'admin/hr_attendance.php','🧑‍💼','HR Attendance') ?>
  <?php endif; ?>
  </div>

  <?php if (is_hr()): ?>
  <div class="nav-group">
    <div class="nav-group-title">My Workspace</div>
    <?= nav_item('my_att',$activeNav,'employee/attendance.php','🕐','My Attendance') ?>
    <?= nav_item('my_tasks',$activeNav,'employee/tasks.php','✅','My Tasks') ?>
    <?= nav_item('my_report',$activeNav,'employee/report.php','📄','Daily Report') ?>
    <?= nav_item('leave_apply',$activeNav,'employee/leave_apply.php','📝','Apply for Leave') ?>
    <?= nav_item('leave_history',$activeNav,'employee/leave_history.php','📋','My Leave History') ?>
    <?= nav_item('my_ot',$activeNav,'employee/overtime.php','⏱️','My Overtime') ?>
    <?= nav_item('my_assets',$activeNav,'employee/assets.php','🖥️','My Assets') ?>
  </div>
  <?php endif; ?>

  <div class="nav-group">
    <div class="nav-group-title">Leave</div>
    <?= nav_item('leave_req',$activeNav,'admin/leaves.php','📝','Leave Requests') ?>
  <?php if (has_perm('config.leave_types')): ?>
    <?= nav_item('leave_types',$activeNav,'admin/leave_types.php','📋','Leave Types') ?>
  <?php endif; ?>
    <?= nav_item('leave_bal',$activeNav,'admin/leave_balance.php','⚖️','Leave Balance') ?>
  </div>

  <div class="nav-group">
    <div class="nav-group-title">Payroll</div>
    <?= nav_item('payroll',$activeNav,'admin/payroll.php','💰','Salary Management') ?>
    <?= nav_item('payroll_gen',$activeNav,'admin/payroll_generate.php','⚙️','Generate Payroll') ?>
  <?php if (has_perm('config.salary_components')): ?>
    <?= nav_item('components',$activeNav,'admin/salary_components.php','🧩','Salary Components') ?>
  <?php endif; ?>
    <?= nav_item('slips',$activeNav,'admin/salary_slips.php','🧾','Salary Slips') ?>
  <?php if (has_perm('overtime.view')): ?>
    <?= nav_item('overtime',$activeNav,'admin/overtime.php','⏱️','Overtime') ?>
  <?php endif; ?>
  </div>

  <div class="nav-group">
    <div class="nav-group-title">Advance & EMI</div>
    <?= nav_item('advances',$activeNav,'admin/advances.php','🏦','Employee Advances') ?>
    <?= nav_item('emi',$activeNav,'admin/emi_schedule.php','📆','EMI Schedule') ?>
  </div>

  <?php if (has_perm('assets.manage')): ?>
  <div class="nav-group">
    <div class="nav-group-title">Assets</div>
    <?= nav_item('assets',$activeNav,'admin/assets.php','🖥️','Asset Management') ?>
  </div>
  <?php endif; ?>

  <?php if (has_perm('tasks.manage')): ?>
  <div class="nav-group">
    <div class="nav-group-title">Tasks</div>
    <?= nav_item('tasks',$activeNav,'admin/tasks.php','✅','Task Board') ?>
    <?= nav_item('task_reports',$activeNav,'admin/task_reports.php','📄','Daily Reports') ?>
  </div>
  <?php endif; ?>

  <div class="nav-group">
    <div class="nav-group-title">Reports</div>
    <?= nav_item('reports',$activeNav,'admin/reports.php','📈','Reports') ?>
  </div>

  <?php if (has_perm('customfields.manage') || has_perm('holidays.manage') || has_perm('users.manage') || has_perm('roles.manage') || has_perm('audit.view') || has_perm('backups.manage')): ?>
  <div class="nav-group">
    <div class="nav-group-title">Administration</div>
  <?php if (has_perm('customfields.manage')): ?><?= nav_item('custom_fields',$activeNav,'admin/custom_fields.php','🧱','Custom Fields') ?><?php endif; ?>
  <?php if (has_perm('holidays.manage')): ?><?= nav_item('holidays',$activeNav,'admin/holidays.php','🎉','Holidays') ?><?php endif; ?>
  <?php if (has_perm('users.manage')): ?><?= nav_item('users',$activeNav,'admin/users.php','🔑','Users') ?><?php endif; ?>
  <?php if (has_perm('users.manage')): ?><?= nav_item('pwresets',$activeNav,'admin/password_resets.php','🔗','Password Resets') ?><?php endif; ?>
  <?php if (has_perm('roles.manage')): ?><?= nav_item('roles',$activeNav,'admin/roles.php','🛡️','Roles & Permissions') ?><?php endif; ?>
  <?php if (has_perm('audit.view')): ?><?= nav_item('audit',$activeNav,'admin/audit_logs.php','📜','Audit Logs') ?><?php endif; ?>
  <?php if (has_perm('backups.manage')): ?><?= nav_item('backups',$activeNav,'admin/backups.php','💾','Database Backups') ?><?php endif; ?>
  </div>
  <?php endif; ?>

  <?php if (has_perm('settings.manage')): ?>
  <div class="nav-group">
    <div class="nav-group-title">Settings</div>
    <?= nav_item('settings',$activeNav,'admin/settings.php','⚙️','Company & Rules') ?>
  <?php if (has_perm('overtime.config')): ?>
    <?= nav_item('ot_settings',$activeNav,'admin/overtime_settings.php','⏱️','Overtime Rules') ?>
  <?php endif; ?>
  </div>
  <?php endif; ?>

<?php elseif (is_team_leader()): /* ---------- Team Leader menu ---------- */ ?>
  <div class="nav-group">
    <?= nav_item('dashboard',$activeNav,'tl/dashboard.php','📊','Dashboard') ?>
    <?= nav_item('noticeboard',$activeNav,'noticeboard.php','📢','Notice Board') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Attendance</div>
    <?= nav_item('att_today',$activeNav,'admin/attendance_today.php','🕐',"Today's Attendance") ?>
    <?= nav_item('att_monthly',$activeNav,'admin/attendance_monthly.php','🗓️','Monthly Attendance') ?>
  <?php if (has_perm('weekoff.manage')): ?>
    <?= nav_item('week_offs',$activeNav,'admin/week_offs.php','🗓️','Week-Off Management') ?>
  <?php endif; ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Leave</div>
    <?= nav_item('leave_req',$activeNav,'admin/leaves.php','📝','Leave Requests') ?>
  </div>
  <?php if (has_perm('overtime.view')): ?>
  <div class="nav-group">
    <div class="nav-group-title">Overtime</div>
    <?= nav_item('overtime',$activeNav,'admin/overtime.php','⏱️','My Team\'s Overtime') ?>
  </div>
  <?php endif; ?>
  <?php if (has_perm('tasks.manage')): ?>
  <div class="nav-group">
    <div class="nav-group-title">Tasks</div>
    <?= nav_item('tasks',$activeNav,'admin/tasks.php','✅','Task Board') ?>
    <?= nav_item('task_reports',$activeNav,'admin/task_reports.php','📄','Daily Reports') ?>
  </div>
  <?php endif; ?>
  <div class="nav-group">
    <div class="nav-group-title">My Workspace</div>
    <?= nav_item('my_att',$activeNav,'employee/attendance.php','🕐','My Attendance') ?>
    <?= nav_item('my_tasks',$activeNav,'employee/tasks.php','✅','My Tasks') ?>
    <?= nav_item('my_report',$activeNav,'employee/report.php','📄','Daily Report') ?>
    <?= nav_item('leave_apply',$activeNav,'employee/leave_apply.php','📝','Apply for Leave') ?>
    <?= nav_item('leave_history',$activeNav,'employee/leave_history.php','📋','My Leave History') ?>
    <?= nav_item('my_ot',$activeNav,'employee/overtime.php','⏱️','My Overtime') ?>
    <?= nav_item('my_assets',$activeNav,'employee/assets.php','🖥️','My Assets') ?>
  </div>

<?php else: /* ---------- Employee menu ---------- */ ?>
  <div class="nav-group">
    <?= nav_item('dashboard',$activeNav,'employee/dashboard.php','📊','Dashboard') ?>
    <?= nav_item('noticeboard',$activeNav,'noticeboard.php','📢','Notice Board') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Attendance</div>
    <?= nav_item('my_att',$activeNav,'employee/attendance.php','🕐','My Attendance') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Tasks</div>
    <?= nav_item('my_tasks',$activeNav,'employee/tasks.php','✅','My Tasks') ?>
    <?= nav_item('my_report',$activeNav,'employee/report.php','📄','Daily Report') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Leave</div>
    <?= nav_item('leave_apply',$activeNav,'employee/leave_apply.php','📝','Apply for Leave') ?>
    <?= nav_item('leave_history',$activeNav,'employee/leave_history.php','📋','Leave History') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Salary</div>
    <?= nav_item('my_slips',$activeNav,'employee/salary_slips.php','🧾','Salary Slips') ?>
    <?= nav_item('my_ot',$activeNav,'employee/overtime.php','⏱️','My Overtime') ?>
    <?= nav_item('my_emi',$activeNav,'employee/advances.php','🏦','Advances & EMI') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Assets</div>
    <?= nav_item('my_assets',$activeNav,'employee/assets.php','🖥️','My Assets') ?>
  </div>
  <div class="nav-group">
    <div class="nav-group-title">Account</div>
    <?= nav_item('profile',$activeNav,'employee/profile.php','👤','My Profile') ?>
  </div>
<?php endif; ?>
</aside>
