  </div><!-- .content -->
</div><!-- .main -->
</div><!-- .app -->
<script src="<?= url('assets/js/app.js') ?>"></script>
<?php if (!empty($extraScript)) echo $extraScript; ?>
</body>
</html>
