<?php $pageTitle = 'Access Denied'; require __DIR__ . '/header.php'; ?>
<div class="empty">
  <div style="font-size:52px">🚫</div>
  <h2>403 — Access Denied</h2>
  <p class="text-muted">You do not have permission to view this page.</p>
  <a class="btn" href="<?= url(home_for_current()) ?>">Back to Dashboard</a>
</div>
<?php require __DIR__ . '/footer.php'; ?>
