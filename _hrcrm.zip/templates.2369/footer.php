  </div><!-- .content -->
</div><!-- .main -->
</div><!-- .app -->
<script src="<?= url('assets/js/app.js') ?>?v=geo3"></script>
<?php if (!empty($extraScript)) echo $extraScript; ?>
</body>
</html>
