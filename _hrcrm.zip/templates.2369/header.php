<?php
/**
 * Layout header. Pages set $pageTitle and $activeNav, then:
 *   require __DIR__ . '/../templates/header.php';
 */
if (!defined('APP_ROOT')) { require_once __DIR__ . '/../includes/bootstrap.php'; }
$u = current_user();
$pageTitle = $pageTitle ?? APP_NAME;
$activeNav = $activeNav ?? '';
$unread = 0; $noticeUnread = 0;
if ($u) {
    $unread = (int)fetch_col("SELECT COUNT(*) FROM notifications WHERE user_id=? AND is_read=0", [$u['id']]);
    $noticeUnread = notice_unread_count($u);
}
$company = setting('company_name', 'RG Realty');
// Which attendance actions need a GPS reading for THIS user (server re-checks on submit).
$geoActions = [];
if ($u && geofence_enabled()) {
    $geoEmp = current_employee();
    foreach (['check_in' => 'check_in', 'check_out' => 'check_out', 'ot_check_in' => 'ot', 'ot_check_out' => 'ot'] as $apiAct => $gAct) {
        $geoActions[$apiAct] = $geoEmp ? geofence_required_for((int)$geoEmp['id'], $gAct) : geofence_applies_to($gAct);
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="csrf-token" content="<?= e(csrf_token()) ?>">
<title><?= e($pageTitle) ?> · <?= e($company) ?> CRM</title>
<link rel="preconnect" href="https://fonts.googleapis.com">
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
<script>const BASE = <?= json_encode(BASE_URL) ?>; window.GEO_ON = <?= geofence_enabled() ? 'true' : 'false' ?>; window.GEO_ACTIONS = <?= json_encode((object)$geoActions) ?>;</script>
</head>
<body>
<div class="app">
<?php require __DIR__ . '/sidebar.php'; ?>
<div class="backdrop"></div>
<div class="main">
  <div class="topbar">
    <div class="flex items-center gap">
      <button class="hamburger" aria-label="Menu">☰</button>
      <h1><?= e($pageTitle) ?></h1>
    </div>
    <?php if ($u && function_exists('has_perm') && has_perm('employees.view')): ?>
    <form class="topbar-search no-print" method="get" action="<?= url('admin/employees.php') ?>" role="search"
          style="margin-left:8px">
      <input type="search" name="q" placeholder="🔍 Search employees…" aria-label="Search employees"
             value="<?= e((string)($activeNav==='employees' ? ($_GET['q'] ?? '') : '')) ?>"
             style="height:34px;padding:6px 12px;border:1px solid var(--border);border-radius:8px;background:var(--surface,#fff);min-width:180px;font-size:13px">
    </form>
    <?php endif; ?>
    <div class="topbar-right">
      <a href="<?= url('noticeboard.php') ?>" class="bell" title="Notice Board">📢<?php if ($noticeUnread): ?><span class="dot"><?= $noticeUnread ?></span><?php endif; ?></a>
      <a href="<?= url('notifications.php') ?>" class="bell" title="Notifications">🔔<?php if ($unread): ?><span class="dot"><?= $unread ?></span><?php endif; ?></a>
      <div class="user-chip">
        <div class="avatar"><?= e(strtoupper(substr($u['name'] ?? 'U', 0, 1))) ?></div>
        <div class="no-print">
          <div style="font-weight:700;font-size:13px;line-height:1.1"><?= e($u['name'] ?? '') ?></div>
          <div style="font-size:11px;color:var(--muted)"><?= e($u['role_name'] ?? '') ?></div>
        </div>
        <a href="<?= url('auth/logout.php') ?>" class="btn btn-outline btn-sm no-print" style="margin-left:8px">Logout</a>
      </div>
    </div>
  </div>
  <div class="content">
    <?php foreach (get_flashes() as $f): ?>
      <div class="alert alert-<?= $f['type'] === 'error' ? 'error' : ($f['type'] === 'info' ? 'info' : 'success') ?>">
        <?= e($f['message']) ?>
      </div>
    <?php endforeach; ?>
