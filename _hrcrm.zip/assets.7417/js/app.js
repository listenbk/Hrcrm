/* RG Realty CRM — front-end helpers */
(function () {
  // Sidebar toggle (mobile)
  var burger = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var backdrop = document.querySelector('.backdrop');
  function closeSb(){ sidebar && sidebar.classList.remove('open'); backdrop && backdrop.classList.remove('show'); }
  if (burger) burger.addEventListener('click', function () {
    sidebar.classList.toggle('open'); backdrop.classList.toggle('show');
  });
  if (backdrop) backdrop.addEventListener('click', closeSb);

  // Generic modal open/close
  document.addEventListener('click', function (e) {
    var openBtn = e.target.closest('[data-modal]');
    if (openBtn) {
      var m = document.getElementById(openBtn.getAttribute('data-modal'));
      if (m) m.classList.add('open');
    }
    if (e.target.matches('.modal-close') || e.target.matches('.modal-overlay')) {
      var ov = e.target.closest('.modal-overlay') || e.target;
      if (ov.classList.contains('modal-overlay')) ov.classList.remove('open');
    }
    if (e.target.closest('[data-close-modal]')) {
      var ov2 = e.target.closest('.modal-overlay'); if (ov2) ov2.classList.remove('open');
    }

    // Show/hide password toggle
    var pwdBtn = e.target.closest('.pwd-toggle');
    if (pwdBtn) {
      var input = pwdBtn.previousElementSibling;
      if (input && input.tagName === 'INPUT') {
        var showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        pwdBtn.textContent = showing ? 'Show' : 'Hide';
        pwdBtn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
      }
    }
  });

  // Confirm dialogs
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute('data-confirm') && !confirm(f.getAttribute('data-confirm'))) {
      e.preventDefault();
    }
  });

  // CSRF token for fetch
  window.CSRF = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

  // Live clock
  var clock = document.getElementById('liveClock');
  if (clock) {
    setInterval(function () {
      clock.textContent = new Date().toLocaleTimeString('en-IN', { hour12: true });
    }, 1000);
  }

  // Minimum-checkout countdown: enable the Check Out button once the wait passes.
  var coBtn = document.getElementById('checkoutBtn');
  if (coBtn && coBtn.getAttribute('data-unlock')) {
    var remaining = parseInt(coBtn.getAttribute('data-unlock'), 10) || 0;
    var coMsg = document.getElementById('checkoutMsg');
    if (remaining > 0) {
      coBtn.disabled = true;
      var t = setInterval(function () {
        remaining--;
        if (remaining <= 0) {
          clearInterval(t);
          coBtn.disabled = false;
          if (coMsg) { coMsg.textContent = '✅ Checkout is now available'; coMsg.className = 'pill pill-success'; }
        } else if (coMsg) {
          var m = Math.floor(remaining / 60), s = remaining % 60;
          coMsg.textContent = '⏳ Checkout available in ' + m + 'm ' + (s < 10 ? '0' : '') + s + 's';
        }
      }, 1000);
    }
  }
})();

/* Attendance check-in / check-out via fetch (server timestamps) */
/* Browser location, read once per click (never continuous).
   Always resolves: {lat,lng,acc,ts} on success, or {error:'denied|timeout|unavailable|unsupported|insecure'}.
   The SERVER decides what a missing position means (exempt staff are never blocked here). */
function getAttendancePosition() {
  return new Promise(function (resolve) {
    if (window.isSecureContext === false) return resolve({ error: 'insecure' });
    if (!navigator.geolocation) return resolve({ error: 'unsupported' });
    navigator.geolocation.getCurrentPosition(
      function (p) {
        // p.timestamp = when the device took this fix (ms). With maximumAge:0 it is a fresh reading,
        // even if permission was granted earlier and no popup is shown.
        resolve({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy, ts: p.timestamp });
      },
      function (err) {
        var code = err ? err.code : 0;
        resolve({ error: code === 1 ? 'denied' : (code === 3 ? 'timeout' : 'unavailable') });
      },
      { enableHighAccuracy: true, timeout: 20000, maximumAge: 0 }
    );
  });
}

function attendanceMessage(type, text) {
  var box = document.getElementById('attMsg');
  if (!box) return false;
  box.className = 'alert alert-' + type;
  box.textContent = text;
  box.style.display = 'flex';
  return true;
}

var attendanceBusy = false;
function attendanceAction(action, btn) {
  if (attendanceBusy) return;           // ignore repeated clicks while a request is running
  attendanceBusy = true;
  btn.disabled = true;
  var orig = btn.innerHTML;
  btn.innerHTML = 'Please wait…';

  var geo = window.GEO_ACTIONS;
  var needsGeo = /^(check_in|check_out|ot_check_in|ot_check_out)$/.test(action) &&
    (geo && typeof geo === 'object' ? !!geo[action] : !!window.GEO_ON);
  if (needsGeo) {
    btn.innerHTML = 'Checking location…';
    attendanceMessage('info', 'Checking your current location...');
  }
  var geoPromise = needsGeo ? getAttendancePosition() : Promise.resolve(null);

  geoPromise.then(function (pos) {
    var body = 'action=' + encodeURIComponent(action) + '&csrf_token=' + encodeURIComponent(window.CSRF);
    if (pos && pos.error) {
      body += '&geo_error=' + encodeURIComponent(pos.error);
    } else if (pos) {
      body += '&latitude=' + encodeURIComponent(pos.lat) +
              '&longitude=' + encodeURIComponent(pos.lng) +
              '&accuracy=' + encodeURIComponent(pos.acc) +
              // Both on the device clock, so the server can compute the reading's age without clock-skew issues.
              '&position_ts=' + encodeURIComponent(Math.round(pos.ts || 0)) +
              '&client_ts=' + encodeURIComponent(Date.now());
    }
    if (needsGeo) btn.innerHTML = 'Please wait…';
    return fetch(BASE + '/api/attendance.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': window.CSRF },
      body: body
    });
  })
    .then(function (r) { return r.json(); })
    .then(function (res) {
      if (!attendanceMessage(res.ok ? 'success' : 'error', res.message) && !res.ok) alert(res.message);
      if (res.ok) { setTimeout(function () { location.reload(); }, 1200); }
      else { attendanceBusy = false; btn.disabled = false; btn.innerHTML = orig; }
    })
    .catch(function () {
      attendanceBusy = false; btn.disabled = false; btn.innerHTML = orig;
      if (!attendanceMessage('error', 'Network error, please retry.')) alert('Network error, please retry.');
    });
}