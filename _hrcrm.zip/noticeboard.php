<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$u = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    if ($act === 'read') {
        mark_notice_read((int)param('id', 0, 'POST'), (int)$u['id']);
    } elseif ($act === 'read_all') {
        foreach (visible_notices_for($u, false) as $n) mark_notice_read((int)$n['id'], (int)$u['id']);
    }
    redirect('noticeboard.php' . (param('tab','','POST') === 'archive' ? '?tab=archive' : ''));
}

$tab = param('tab', 'active') === 'archive' ? 'archive' : 'active';
$notices = visible_notices_for($u, $tab === 'archive');
$readMap = [];
foreach (fetch_all("SELECT notice_id FROM notice_reads WHERE user_id=?", [$u['id']]) as $r) $readMap[(int)$r['notice_id']] = true;

$pageTitle = 'Notice Board'; $activeNav = 'noticeboard';
require __DIR__ . '/templates/header.php';
?>
<div class="page-head">
  <div><h2>📢 Notice Board</h2><div class="breadcrumb">Company announcements &amp; notices</div></div>
  <div class="flex gap">
    <a class="btn btn-outline <?= $tab==='active'?'':'' ?>" href="<?= url('noticeboard.php') ?>" style="<?= $tab==='active'?'background:var(--brand);color:#fff':'' ?>">Active</a>
    <a class="btn btn-outline" href="<?= url('noticeboard.php?tab=archive') ?>" style="<?= $tab==='archive'?'background:var(--brand);color:#fff':'' ?>">Archive</a>
    <?php if ($tab==='active'): ?>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="read_all"><button class="btn">✓ Mark all read</button></form>
    <?php endif; ?>
  </div>
</div>

<?php if (!$notices): ?>
  <div class="card"><div class="empty"><?= $tab==='archive'?'No archived notices.':'No notices right now. 📭' ?></div></div>
<?php else: foreach ($notices as $n):
  $isRead = isset($readMap[(int)$n['id']]);
  $urgent = $n['priority'] === 'Urgent';
  $border = $urgent ? 'var(--danger)' : ($n['priority']==='Important' ? 'var(--warning)' : 'var(--border)');
  $creator = fetch_col("SELECT name FROM users WHERE id=?", [$n['created_by']]);
?>
  <div class="card mb-2" style="border-left:4px solid <?= $border ?>;<?= (!$isRead && $tab==='active')?'background:#f0fdfa':'' ?>">
    <div class="card-body">
      <div class="flex between wrap" style="gap:8px">
        <div style="flex:1;min-width:240px">
          <div class="flex gap wrap" style="align-items:center">
            <?php if($n['is_pinned']): ?><span title="Pinned">📌</span><?php endif; ?>
            <h3 style="margin:0"><?= e($n['title']) ?></h3>
            <span class="pill <?= notice_priority_pill($n['priority']) ?>"><?= e($n['priority']) ?></span>
            <?php if(!$isRead && $tab==='active'): ?><span class="pill pill-info">New</span><?php endif; ?>
          </div>
          <div class="text-muted" style="font-size:12px;margin-top:4px">
            By <?= e($creator ?: 'Admin') ?> · <?= fmt_date($n['publish_date'],'d M Y') ?>
            <?php if($n['expiry_date']): ?> · expires <?= fmt_date($n['expiry_date'],'d M Y') ?><?php endif; ?>
          </div>
        </div>
      </div>
      <div style="margin-top:10px;white-space:pre-wrap;line-height:1.6"><?= nl2br(e($n['message'])) ?></div>
      <?php if($n['attachment']): ?>
        <div class="mt-2"><a class="btn btn-sm btn-outline" href="<?= url('uploads/'.$n['attachment']) ?>" target="_blank">📎 Attachment</a></div>
      <?php endif; ?>
      <?php if(!$isRead && $tab==='active'): ?>
      <div class="mt-2">
        <form method="post" style="display:inline"><?= csrf_field() ?>
          <input type="hidden" name="do" value="read"><input type="hidden" name="id" value="<?= $n['id'] ?>">
          <button class="btn btn-sm">✓ Mark as Read</button></form>
      </div>
      <?php elseif($tab==='active'): ?>
        <div class="mt-2"><span class="pill pill-success">✓ Read</span></div>
      <?php endif; ?>
    </div>
  </div>
<?php endforeach; endif; ?>
<?php require __DIR__ . '/templates/footer.php'; ?>
