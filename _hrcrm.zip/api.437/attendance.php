<?php
/** AJAX endpoint for employee check-in / check-out (server timestamps). */
require_once __DIR__ . '/../includes/bootstrap.php';
header('Content-Type: application/json');

require_login();
csrf_verify();

$emp = current_employee();
if (!$emp) {
    // HR / Team Leaders get a self-attendance profile on first use.
    $emp = ensure_staff_employee(current_user());
}
if (!$emp) {
    echo json_encode(['ok' => false, 'message' => 'No employee profile is linked to your account.']);
    exit;
}

$action = (string)param('action', '', 'POST');
$lat = param('latitude', null, 'POST');
$lng = param('longitude', null, 'POST');
$acc = param('accuracy', null, 'POST');
// Why the browser could not give a position (denied | timeout | unavailable | unsupported | insecure).
$geoError = preg_replace('/[^a-z]/', '', strtolower((string)param('geo_error', '', 'POST')));
// Device-clock milliseconds: when the GPS fix was taken, and when the request was sent.
$posTs    = param('position_ts', null, 'POST');
$clientTs = param('client_ts', null, 'POST');
try {
    $empId = (int)$emp['id'];
    // Geofence gate runs BEFORE the existing attendance rules, server-side.
    $geoAction = geofence_action_key($action);
    $gOk = true; $gMsg = ''; $gStatus = 'Not Required'; $gDist = null; $gLoc = null; $gAcc = null; $gFlags = null;
    $geoOn = $geoAction !== null && geofence_applies_to($geoAction);
    if ($geoAction !== null) {
        [$gOk, $gMsg, $gStatus, $gDist, $gLoc, $gAcc] = geofence_validate($empId, $geoAction, $lat, $lng, $acc, $geoError, $posTs, $clientTs);
        if ($geoOn && $gStatus === 'Inside') {
            $gFlags = geofence_spoof_flags($empId, $lat, $lng, $gLoc);
        }
        if (!$gOk) {
            geofence_record_attempt($empId, $action, false, $gStatus, $gMsg, $lat, $lng, $acc, $gDist, $gLoc);
            audit_log('geofence_rejected', 'attendance', $empId,
                "{$action} rejected for {$emp['full_name']} ({$emp['emp_code']}): {$gStatus}" . ($gDist !== null ? " ({$gDist}m)" : ''));
            echo json_encode(['ok' => false, 'message' => $gMsg, 'geofence' => $gStatus, 'distance' => $gDist]);
            exit;
        }
    }

    if ($action === 'check_in') {
        [$ok, $msg] = do_check_in($empId);
        if ($ok && $geoOn) {
            geofence_store($empId, 'check_in', $lat, $lng, $acc, $gStatus, $gDist, $gLoc);
        }
    } elseif ($action === 'check_out') {
        [$ok, $msg] = do_check_out($empId);
        if ($ok && $geoOn) {
            geofence_store($empId, 'check_out', $lat, $lng, $acc, $gStatus, $gDist, $gLoc);
        }
    } elseif ($action === 'ot_check_in') {
        [$ok, $msg] = ot_session_start($empId);
        if ($ok && $geoOn) {
            geofence_store_ot($empId, 'in', $lat, $lng, $acc, $gStatus, $gDist);
        }
    } elseif ($action === 'ot_check_out') {
        [$ok, $msg] = ot_session_stop($empId);
        if ($ok && $geoOn) {
            geofence_store_ot($empId, 'out', $lat, $lng, $acc, $gStatus, $gDist);
        }
    } else {
        echo json_encode(['ok' => false, 'message' => 'Unknown action.']);
        exit;
    }

    if ($geoOn) {
        // Location passed; record whether the attendance rule itself accepted the action.
        geofence_record_attempt($empId, $action, true, $gStatus, $ok ? '' : 'Location OK; not marked: ' . $msg,
            $lat, $lng, $acc, $gDist, $gLoc, $gFlags);
        if ($ok && $gStatus === 'Inside') {
            $msg = "Location verified ({$gDist} m from office). " . $msg;
        }
    }
    echo json_encode(['ok' => $ok, 'message' => $msg, 'geofence' => $gStatus, 'distance' => $gDist]);
} catch (Throwable $e) {
    echo json_encode(['ok' => false, 'message' => APP_ENV === 'development' ? $e->getMessage() : 'Something went wrong.']);
}
