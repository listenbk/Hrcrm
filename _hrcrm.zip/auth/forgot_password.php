<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (is_logged_in()) redirect(home_for_current());

$done = false; $devLink = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $email = (string)param('email', '', 'POST');
    if (valid_email($email)) {
        $combined = create_password_reset($email);
        if ($combined) {
            $link = reset_link_url($combined);
            // Try email delivery (works on hosts with mail configured, e.g. Hostinger)
            $company = setting('company_name', 'RG Realty');
            @mail($email, "$company CRM — Password reset",
                  "Reset your password (valid 1 hour):\n\n$link\n\nIf you didn't request this, ignore this email.",
                  "From: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'rgrealty.com'));
            // Always log for admin retrieval (protected folder)
            @file_put_contents(APP_ROOT . '/storage/reset_links.log',
                date('c') . "  $email  $link\n", FILE_APPEND);
            // On local/dev, show the link directly (no SMTP on XAMPP)
            if (APP_ENV === 'development') $devLink = $link;
        }
    }
    $done = true; // generic response regardless (no account enumeration)
    audit_log('password_reset_requested', 'user', null, 'Reset requested for ' . substr($email, 0, 120));
}
$company = setting('company_name', 'RG Realty');
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Forgot Password · <?= e($company) ?> CRM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"></head>
<body>
<div class="auth-wrap"><form class="auth-card" method="post">
  <div class="auth-logo"><?= e($company) ?></div>
  <div class="auth-sub">Reset your password</div>
  <?php if ($done): ?>
    <div class="alert alert-success">If an account exists for that email, a password-reset link has been generated (valid 1 hour).</div>
    <?php if ($devLink): ?>
      <div class="alert alert-info" style="word-break:break-all">
        <b>Dev mode link</b> (no email server on localhost):<br>
        <a href="<?= e($devLink) ?>"><?= e($devLink) ?></a>
      </div>
    <?php endif; ?>
    <a class="btn btn-lg" href="<?= url('auth/login.php') ?>">Back to Login</a>
  <?php else: ?>
    <?= csrf_field() ?>
    <div class="form-group"><label for="email">Registered Email</label>
      <input type="email" id="email" name="email" required autofocus></div>
    <button class="btn btn-lg" type="submit">Send Reset Link</button>
    <p class="help mt-2 text-center"><a href="<?= url('auth/login.php') ?>">← Back to Login</a></p>
  <?php endif; ?>
</form></div>
</body></html>
