<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (is_logged_in()) redirect(home_for_current());

$token = (string)param('token', '');
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $token = (string)param('token', '', 'POST');
    $new   = (string)param('password', '', 'POST');
    $conf  = (string)param('confirm', '', 'POST');
    $reset = find_valid_reset($token);
    if (!$reset) {
        $error = 'This reset link is invalid or has expired. Please request a new one.';
    } elseif (strlen($new) < 8) {
        $error = 'Password must be at least 8 characters.';
    } elseif ($new !== $conf) {
        $error = 'Passwords do not match.';
    } else {
        complete_password_reset($reset, $new);
        audit_log('password_reset_completed', 'user', (int)$reset['user_id'], 'Password reset via token');
        flash_success('Your password has been reset. Please sign in.');
        redirect('auth/login.php');
    }
}

$validToken = $token !== '' && find_valid_reset($token) !== null;
$company = setting('company_name', 'RG Realty');
?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Reset Password · <?= e($company) ?> CRM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"></head>
<body>
<div class="auth-wrap"><form class="auth-card" method="post">
  <div class="auth-logo"><?= e($company) ?></div>
  <div class="auth-sub">Set a new password</div>
  <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
  <?php if (!$validToken && !$error): ?>
    <div class="alert alert-error">This reset link is invalid or has expired.</div>
    <a class="btn btn-lg" href="<?= url('auth/forgot_password.php') ?>">Request a new link</a>
  <?php else: ?>
    <?= csrf_field() ?>
    <input type="hidden" name="token" value="<?= e($token) ?>">
    <div class="form-group"><label for="password">New Password</label>
      <div class="pwd-wrap"><input type="password" id="password" name="password" required minlength="8">
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div>
      <div class="help">At least 8 characters.</div></div>
    <div class="form-group"><label for="confirm">Confirm Password</label>
      <div class="pwd-wrap"><input type="password" id="confirm" name="confirm" required>
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
    <button class="btn btn-lg" type="submit">Reset Password</button>
  <?php endif; ?>
</form></div>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body></html>
