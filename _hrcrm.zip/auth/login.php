<?php
require_once __DIR__ . '/../includes/bootstrap.php';

if (is_logged_in()) {
    redirect(home_for_current());
}

$error = '';
$notice = '';
if (param('timeout') === '1') $notice = 'Your session timed out due to inactivity. Please sign in again.';
if (param('expired') === '1') $notice = 'Your session ended because your credentials changed. Please sign in again.';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $identifier = (string)param('identifier', '', 'POST');
    $pass       = (string)param('password', '', 'POST');
    $remember   = (bool)param('remember', false, 'POST');
    if ($identifier === '' || $pass === '') {
        $error = 'Please enter your login and password.';
    } else {
        [$ok, $msg] = attempt_login($identifier, $pass, $remember);
        if ($ok) {
            audit_log('login', 'user', current_user()['id'] ?? null, 'User logged in');
            redirect(home_for_current());
        }
        $error = $msg;
    }
}
$company = setting('company_name', 'RG Realty');
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Login · <?= e($company) ?> CRM</title>
<link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>">
</head>
<body>
<div class="auth-wrap">
  <form class="auth-card" method="post" autocomplete="off">
    <div class="auth-logo"><?= e($company) ?></div>
    <div class="auth-sub">Employee Management CRM</div>

    <?php foreach (get_flashes() as $fl): ?>
      <div class="alert alert-<?= $fl['type']==='error'?'error':($fl['type']==='info'?'info':'success') ?>"><?= e($fl['message']) ?></div>
    <?php endforeach; ?>
    <?php if ($error): ?><div class="alert alert-error"><?= e($error) ?></div><?php endif; ?>
    <?php if ($notice): ?><div class="alert alert-info"><?= e($notice) ?></div><?php endif; ?>

    <?= csrf_field() ?>
    <div class="form-group">
      <label for="identifier">Employee ID / Username / Email</label>
      <input type="text" id="identifier" name="identifier" required autofocus
             value="<?= e(param('identifier', '', 'POST')) ?>" placeholder="e.g. RG0001 or you@rgrealty.com">
    </div>
    <div class="form-group">
      <label for="password">Password</label>
      <div class="pwd-wrap"><input type="password" id="password" name="password" required>
      <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div>
    </div>
    <div class="flex between items-center mb-2">
      <label class="switch"><input type="checkbox" name="remember" value="1"> Remember me</label>
      <a href="<?= url('auth/forgot_password.php') ?>" style="font-size:13px">Forgot password?</a>
    </div>
    <button class="btn btn-lg" type="submit">Login</button>
    <p class="help mt-2 text-center">The system detects your role automatically after sign-in.</p>
  </form>
</div>
<script src="<?= url('assets/js/app.js') ?>"></script>
</body>
</html>
