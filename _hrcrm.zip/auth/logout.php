<?php
require_once __DIR__ . '/../includes/bootstrap.php';
if (is_logged_in()) {
    audit_log('logout', 'user', current_user()['id'] ?? null, 'User logged out');
}
logout();
redirect('auth/login.php');
