<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();   // HR or Super Admin

$today = date('Y-m-d'); $thisMonth = date('Y-m');

// HR's own self-attendance profile (created on first visit)
$me = ensure_staff_employee(current_user());
$myAtt = $me ? fetch_one("SELECT a.*, s.name AS status_name, s.color FROM attendance a
    LEFT JOIN attendance_statuses s ON s.id=a.status_id
    WHERE a.employee_id=? AND a.att_date=?", [$me['id'], $today]) : null;
$myOT = $me ? fetch_one("SELECT * FROM overtime WHERE employee_id=? AND ot_date=?", [$me['id'], $today]) : null;

$totalEmp  = (int)fetch_col("SELECT COUNT(*) FROM employees WHERE is_staff=0");
$activeEmp = (int)fetch_col("SELECT COUNT(*) FROM employees WHERE status='Active' AND is_staff=0");
$att = attendance_dashboard($today);
$pendingLeaves = (int)fetch_col("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'");
$pendingEarly  = (int)fetch_col("SELECT COUNT(*) FROM attendance WHERE att_date=? AND early_minutes>0 AND (early_status='Pending' OR early_status IS NULL)", [$today]);
$payrollPending= (float)fetch_col("SELECT COALESCE(SUM(pending_amount),0) FROM payroll WHERE pay_month=?", [$thisMonth]);
$pendingOT = (int)fetch_col("SELECT COUNT(*) FROM overtime WHERE status IN ('Detected','Pending Approval','HR Reviewed')");
$assetSum = function_exists('asset_summary') ? asset_summary() : ['total'=>0,'Available'=>0,'Allocated'=>0];
$pendingAssetReturns = (int)fetch_col("SELECT COUNT(*) FROM asset_return_requests WHERE status='Pending'");

$live = fetch_all(
    "SELECT e.emp_code, e.full_name, a.check_in, a.check_out, a.working_minutes, a.late_minutes, a.early_minutes,
            s.name AS status_name, s.color
     FROM employees e
     LEFT JOIN attendance a ON a.employee_id=e.id AND a.att_date=?
     LEFT JOIN attendance_statuses s ON s.id=a.status_id
     WHERE e.status='Active' AND e.is_staff=0 ORDER BY e.full_name LIMIT 12", [$today]);

$pageTitle = 'HR Dashboard'; $activeNav = 'dashboard';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>HR Dashboard</h2>
    <div class="breadcrumb"><?= fmt_date($today,'l, d F Y') ?> · <span id="liveClock"></span></div></div>
  <div class="flex gap">
    <a class="btn btn-outline" href="<?= url('admin/employee_edit.php') ?>">➕ Add Employee</a>
    <a class="btn" href="<?= url('admin/leaves.php') ?>">📝 Leave Requests</a>
  </div>
</div>

<?php require __DIR__ . '/../templates/notices_widget.php'; ?>

<!-- HR's own attendance (self-attendance, same rules as employees) -->
<div id="attMsg" class="alert" style="display:none"></div>
<div class="card mb-2"><div class="card-head"><h3>My Attendance — Today</h3>
  <?php if($myAtt && $myAtt['status_name']): ?><span class="badge" style="background:<?= e($myAtt['color']) ?>"><?= e($myAtt['status_name']) ?></span><?php endif; ?></div>
  <div class="card-body">
    <div class="grid cols-4" style="text-align:center;gap:12px">
      <div><div class="text-muted">Check In</div><div style="font-size:20px;font-weight:800"><?= $myAtt&&$myAtt['check_in']?fmt_date($myAtt['check_in'],'h:i A'):'—' ?>
        <?php if($myAtt && $myAtt['late_minutes']>0): ?><div><span class="pill pill-warning">Late <?= $myAtt['late_minutes'] ?>m</span></div><?php endif; ?></div></div>
      <div><div class="text-muted">Working</div><div class="hours-big" style="font-size:22px"><?= $myAtt?fmt_hm((int)$myAtt['working_minutes']):'0h 0m' ?></div></div>
      <div><div class="text-muted">Check Out</div><div style="font-size:20px;font-weight:800"><?= $myAtt&&$myAtt['check_out']?fmt_date($myAtt['check_out'],'h:i A'):'—' ?>
        <?php if($myAtt && $myAtt['early_minutes']>0): ?><div><span class="pill pill-info">Early <?= $myAtt['early_minutes'] ?>m</span></div><?php endif; ?></div></div>
      <div><div class="text-muted">Overtime</div><div style="font-size:20px;font-weight:800"><?= $myOT?rtrim(rtrim(number_format($myOT['actual_hours'],2),'0'),'.').'h':'—' ?></div></div>
    </div>
    <div class="text-center mt-2">
      <?php if(!$myAtt || !$myAtt['check_in']): ?>
        <button class="btn btn-lg" style="width:auto" onclick="attendanceAction('check_in',this)">🟢 Check In</button>
      <?php elseif(!$myAtt['check_out']):
        $minCk=(int)setting('min_checkout_minutes',30);
        $remain=(strtotime($myAtt['check_in'])+$minCk*60)-time(); ?>
        <button class="btn btn-lg btn-danger" style="width:auto" id="checkoutBtn" data-unlock="<?= max(0,$remain) ?>" <?= $remain>0?'disabled':'' ?> onclick="attendanceAction('check_out',this)">🔴 Check Out</button>
        <?php if($remain>0): ?><div class="mt-1"><span class="pill pill-warning" id="checkoutMsg">⏳ Checkout will be available <?= $minCk ?> minutes after check-in</span></div><?php endif; ?>
      <?php else: ?>
        <span class="pill pill-success" style="font-size:14px;padding:8px 16px">✔️ Attendance complete for today</span>
      <?php endif; ?>
      <a class="btn btn-outline" href="<?= url('employee/attendance.php') ?>">🕐 My History</a>
      <a class="btn btn-outline" href="<?= url('employee/leave_apply.php') ?>">📝 Apply Leave</a>
    </div>
  </div>
</div>

<div class="grid cols-4">
  <div class="card"><div class="stat"><div class="icon bg-brand">👥</div><div><div class="label">Total Employees</div><div class="value"><?= $totalEmp ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div><div><div class="label">Active</div><div class="value"><?= $activeEmp ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">📝</div><div><div class="label">Pending Leaves</div><div class="value"><?= $pendingLeaves ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-pink">🚪</div><div><div class="label">Early Leave (today)</div><div class="value"><?= $pendingEarly ?></div></div></div></div>
</div>

<h3 class="mt-3" style="margin-bottom:12px">Today's Attendance</h3>
<div class="grid cols-4">
  <div class="card"><div class="stat"><div class="icon bg-green">🟢</div><div><div class="label">Present</div><div class="value"><?= $att['present'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏰</div><div><div class="label">Late</div><div class="value"><?= $att['late'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">🔴</div><div><div class="label">Not Checked In</div><div class="value"><?= $att['not_checked_in'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🌴</div><div><div class="label">On Leave</div><div class="value"><?= $att['leave'] ?></div></div></div></div>
</div>

<div class="card mt-3">
  <div class="card-head"><h3><span class="dot-live"></span>Live Employee Attendance</h3>
    <a class="btn btn-sm btn-outline" href="<?= url('admin/attendance_today.php') ?>">Full view</a></div>
  <div class="table-wrap"><table class="data">
    <thead><tr><th>Employee</th><th>Check In</th><th>Status</th><th>Working Hours</th><th>Check Out</th></tr></thead>
    <tbody>
    <?php foreach ($live as $r): ?>
      <tr>
        <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
        <td><?= $r['check_in']?fmt_date($r['check_in'],'h:i A'):'—' ?>
            <?php if($r['late_minutes']>0): ?><span class="pill pill-warning">+<?= $r['late_minutes'] ?>m</span><?php endif; ?></td>
        <td><?= $r['status_name']?'<span class="badge" style="background:'.e($r['color']).'">'.e($r['status_name']).'</span>':'<span class="pill pill-muted">—</span>' ?></td>
        <td><?= $r['working_minutes']?fmt_hm((int)$r['working_minutes']):($r['check_in']&&!$r['check_out']?'<span class="text-muted">Working…</span>':'—') ?></td>
        <td><?= $r['check_out']?fmt_date($r['check_out'],'h:i A'):'—' ?></td>
      </tr>
    <?php endforeach; ?>
    </tbody>
  </table></div>
</div>

<div class="flex gap mt-3 wrap">
  <a class="btn btn-outline" href="<?= url('admin/attendance_manual.php') ?>">✏️ Manual Attendance</a>
  <a class="btn btn-outline" href="<?= url('admin/overtime.php') ?>">⏱️ Overtime Review<?php if($pendingOT): ?> (<?= $pendingOT ?>)<?php endif; ?></a>
  <a class="btn btn-outline" href="<?= url('admin/assets.php') ?>">🖥️ Assets<?php if($pendingAssetReturns): ?> · <?= $pendingAssetReturns ?> return req<?php endif; ?></a>
  <a class="btn btn-outline" href="<?= url('admin/payroll_generate.php') ?>">💰 Generate Payroll</a>
  <a class="btn btn-outline" href="<?= url('admin/reports.php') ?>">📈 Reports</a>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
