# RG Realty HRCRM — Asset Management Update

Adds a full **Asset Management** module (HR/Manager controlled) with permanent
allocation history and an employee "My Assets" view.

**Safe in-place update** — it only **adds** new files + 3 new database tables.
No existing file, module, or record is changed. Your app folder is:
`/home/u957986597/domains/rgrealty.in/public_html/hrcrm/`

---

## STEP 1 — Upload the code files (into `hrcrm/`)

Upload this ZIP into `public_html/hrcrm/` and **Extract → Overwrite All**.
It places these files (2 are overwritten, the rest are new — no conflicts on the
new ones):

```
includes/asset_lib.php        (new)   asset logic
includes/bootstrap.php        (overwrite) loads asset_lib
admin/assets.php              (new)   HR asset dashboard + allocate/return
admin/asset_view.php          (new)   asset detail + full history
employee/assets.php           (new)   employee "My Assets" + return request
templates/sidebar.php         (overwrite) adds Assets menu links
hr/dashboard.php              (overwrite) adds an Assets quick link
install/migrate_assets.sql    (new)   the database migration (for Step 2)
```

> **If you get "409 Conflict"** on the 3 overwrite files
> (`includes/bootstrap.php`, `templates/sidebar.php`, `hr/dashboard.php`),
> delete just those 3 files first, then Extract again. The other files are new
> and won't conflict.

---

## STEP 2 — Add the database tables (phpMyAdmin)

phpMyAdmin → select your database → **Import** tab → choose
**`install/migrate_assets.sql`** (from this pack) → **Go**.

*(Or paste its contents into the **SQL** tab and run.)* It creates 3 tables
(`assets`, `asset_allocations`, `asset_return_requests`) and one permission
(`assets.manage`) for HR + Super Admin. It does **not** touch existing tables.

---

## STEP 3 — Done — verify

1. Log in as **HR** or **Manager** → the sidebar now shows **Assets → Asset
   Management**. Open it: you'll see the summary cards and an **Add Asset** button.
2. **Add an asset** → **Allocate** it to an employee (by Employee ID) → its
   status becomes **Allocated**.
3. Log in as that **employee** → sidebar shows **Assets → My Assets** with the
   asset assigned to them, and a **Request Return** button.
4. Back as HR → the return request appears at the top of Asset Management →
   **Receive & Return** puts it back to inventory. Open the asset's **View** page
   to see the full permanent **Allocation History**.

---

## What it does (matches your spec)
- **HR-only** create/allocate/receive/update — enforced server-side; employees
  can only view their own assets and submit a return request (never transfer to
  another employee).
- **Asset details**: type, brand, model, serial/IMEI, purchase date, condition,
  status, assigned employee, allocation/return dates, remarks.
- **Statuses**: Available, Allocated, Returned, Under Repair, Damaged, Lost, Retired.
- **Guards**: can't allocate a non-Available asset (already allocated / damaged /
  lost / retired / under repair); an allocated asset must be **returned to HR**
  before reuse.
- **Permanent history**: every allocation & return is kept forever (never deleted
  on return or reassignment), including who allocated/received it and conditions.
- **Audit log** entries for create, allocate, return, edit and status changes.
- Confirmation prompts before allocate/return.
