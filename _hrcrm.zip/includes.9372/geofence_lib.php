<?php
/**
 * Geofence validation — the SERVER decides. Browser coordinates are only
 * inputs; they are never trusted on their own.
 */

/** Great-circle distance in metres between two lat/lng points (Haversine). */
function haversine_meters(float $lat1, float $lng1, float $lat2, float $lng2): float
{
    $R = 6371000;
    $dLat = deg2rad($lat2 - $lat1);
    $dLng = deg2rad($lng2 - $lng1);
    $a = sin($dLat / 2) ** 2 + cos(deg2rad($lat1)) * cos(deg2rad($lat2)) * sin($dLng / 2) ** 2;
    return $R * 2 * atan2(sqrt($a), sqrt(1 - $a));
}

function geofence_enabled(): bool { return setting('geofence_enabled', '0') === '1'; }

/** Is geofencing enforced for this action? action: check_in | check_out | ot */
function geofence_applies_to(string $action): bool
{
    return geofence_enabled() && setting('geofence_' . $action, '1') === '1';
}

/**
 * Validate a location for an employee and action.
 * Returns [ok, message, status, distance_m, location_id, accuracy]
 *   status: Inside | Outside | Unavailable | Poor Accuracy | No Site | Not Required | Exempt
 */
function geofence_validate(int $employeeId, string $action, $lat, $lng, $accuracy): array
{
    if (!geofence_applies_to($action)) {
        return [true, '', 'Not Required', null, null, null];
    }
    $emp = fetch_one("SELECT geofence_exempt, geofence_location_id FROM employees WHERE id=?", [$employeeId]);
    if (!empty($emp['geofence_exempt'])) {
        return [true, '', 'Exempt', null, null, null];
    }

    // Per-site switch: a site may enforce only some actions (check-in / check-out / OT).
    $siteCol = ['check_in' => 'enforce_check_in', 'check_out' => 'enforce_check_out', 'ot' => 'enforce_ot'][$action] ?? 'enforce_check_in';
    if (!empty($emp['geofence_location_id'])) {
        $site = fetch_one("SELECT id, {$siteCol} AS enf FROM geofence_locations WHERE id=? AND status=1", [$emp['geofence_location_id']]);
        if ($site && empty($site['enf'])) {
            return [true, '', 'Not Required', null, (int)$site['id'], null];
        }
    }

    // No usable coordinates from the browser.
    if ($lat === null || $lng === null || $lat === '' || $lng === '' || !is_numeric($lat) || !is_numeric($lng)) {
        return [false, 'Your location could not be read. Please allow location access and try again.', 'Unavailable', null, null, null];
    }
    $lat = (float)$lat; $lng = (float)$lng;
    if ($lat < -90 || $lat > 90 || $lng < -180 || $lng > 180) {
        return [false, 'Invalid location reading. Please try again.', 'Unavailable', null, null, null];
    }

    // GPS accuracy gate (metres). Missing accuracy is treated as poor.
    $maxAcc = (float)setting('geofence_max_accuracy', '100');
    $acc = is_numeric($accuracy) ? (float)$accuracy : null;
    if ($acc === null || $acc > $maxAcc) {
        $shown = $acc === null ? 'unknown' : '±' . round($acc) . 'm';
        return [false, "Your GPS signal is too weak ({$shown}). Move to an open area or enable precise location and try again.", 'Poor Accuracy', null, null, $acc];
    }

    // Employee must have an assigned, active site.
    $loc = !empty($emp['geofence_location_id'])
        ? fetch_one("SELECT * FROM geofence_locations WHERE id=? AND status=1", [$emp['geofence_location_id']])
        : null;
    if (!$loc) {
        return [false, 'No attendance site is assigned to you. Please contact HR.', 'No Site', null, null, $acc];
    }

    $distance = haversine_meters($lat, $lng, (float)$loc['latitude'], (float)$loc['longitude']);
    $dist = (int)round($distance);
    $radius = (int)$loc['radius'];

    if ($distance > $radius) {
        return [false,
            "You are outside the permitted attendance area ({$dist}m away from {$loc['location_name']}). Please come within {$radius}m of the site.",
            'Outside', $dist, (int)$loc['id'], $acc];
    }
    return [true, '', 'Inside', $dist, (int)$loc['id'], $acc];
}

/** Persist the location evidence on today's attendance row (check_in or check_out). */
function geofence_store(int $employeeId, string $phase, $lat, $lng, $acc, string $status, ?int $dist, ?int $locId): void
{
    $date = date('Y-m-d');
    $p = $phase === 'check_out' ? 'checkout' : 'checkin';
    $ok = is_numeric($lat) && is_numeric($lng);
    q("UPDATE attendance SET {$p}_latitude=?, {$p}_longitude=?, {$p}_accuracy=?, {$p}_distance_m=?,
           {$p}_geofence_status=?, geofence_location_id=COALESCE(?, geofence_location_id)
       WHERE employee_id=? AND att_date=?",
      [$ok ? (float)$lat : null, $ok ? (float)$lng : null, is_numeric($acc) ? (float)$acc : null,
       $dist, $status, $locId, $employeeId, $date]);
}
