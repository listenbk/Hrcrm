<?php
/**
 * Custom fields — dynamic per-module fields rendered on forms and stored
 * in custom_field_values, so admins add HR fields without code changes.
 */

function custom_fields(string $module, bool $activeOnly = true): array
{
    $sql = "SELECT * FROM custom_fields WHERE module = ?";
    if ($activeOnly) $sql .= " AND is_active = 1";
    $sql .= " ORDER BY sort_order, id";
    return fetch_all($sql, [$module]);
}

/** Values for a record keyed by field_id. */
function custom_field_values(string $module, int $recordId): array
{
    $rows = fetch_all(
        "SELECT v.field_id, v.value FROM custom_field_values v
         JOIN custom_fields f ON f.id = v.field_id
         WHERE f.module = ? AND v.record_id = ?", [$module, $recordId]);
    $out = [];
    foreach ($rows as $r) $out[(int)$r['field_id']] = $r['value'];
    return $out;
}

/** Save posted custom field values for a record. */
function save_custom_fields(string $module, int $recordId, array $post): void
{
    foreach (custom_fields($module) as $f) {
        $key = 'cf_' . $f['id'];
        $val = $post[$key] ?? '';
        if (is_array($val)) $val = implode(',', $val);
        if ($f['field_type'] === 'checkbox' || $f['field_type'] === 'yesno') {
            $val = isset($post[$key]) ? '1' : '0';
        }
        q("INSERT INTO custom_field_values (field_id, record_id, value) VALUES (?,?,?)
           ON DUPLICATE KEY UPDATE value = VALUES(value)", [$f['id'], $recordId, $val]);
    }
}

/** Render form inputs for a module's custom fields. */
function render_custom_fields(string $module, array $values = []): string
{
    $fields = custom_fields($module);
    if (!$fields) return '';
    $html = '';
    foreach ($fields as $f) {
        $id = 'cf_' . $f['id'];
        $val = $values[(int)$f['id']] ?? '';
        $req = $f['is_required'] ? 'required' : '';
        $label = e($f['label']) . ($f['is_required'] ? ' <span class="req">*</span>' : '');
        $html .= '<div class="form-group"><label for="'.$id.'">'.$label.'</label>';
        switch ($f['field_type']) {
            case 'textarea':
                $html .= '<textarea id="'.$id.'" name="'.$id.'" '.$req.'>'.e($val).'</textarea>';
                break;
            case 'number': case 'amount':
                $step = $f['field_type']==='amount' ? '0.01' : '1';
                $html .= '<input type="number" step="'.$step.'" id="'.$id.'" name="'.$id.'" value="'.e($val).'" '.$req.'>';
                break;
            case 'date':
                $html .= '<input type="date" id="'.$id.'" name="'.$id.'" value="'.e($val).'" '.$req.'>';
                break;
            case 'time':
                $html .= '<input type="time" id="'.$id.'" name="'.$id.'" value="'.e($val).'" '.$req.'>';
                break;
            case 'checkbox': case 'yesno':
                $checked = $val === '1' ? 'checked' : '';
                $html .= '<label class="switch"><input type="checkbox" id="'.$id.'" name="'.$id.'" value="1" '.$checked.'> '.
                         ($f['field_type']==='yesno'?'Yes':'Enabled').'</label>';
                break;
            case 'dropdown':
                $opts = array_filter(array_map('trim', preg_split('/[,\n]/', (string)$f['options'])));
                $html .= '<select id="'.$id.'" name="'.$id.'" '.$req.'><option value="">— Select —</option>';
                foreach ($opts as $o) {
                    $sel = ((string)$val === $o) ? 'selected' : '';
                    $html .= '<option value="'.e($o).'" '.$sel.'>'.e($o).'</option>';
                }
                $html .= '</select>';
                break;
            default:
                $html .= '<input type="text" id="'.$id.'" name="'.$id.'" value="'.e($val).'" '.$req.'>';
        }
        $html .= '</div>';
    }
    return $html;
}
