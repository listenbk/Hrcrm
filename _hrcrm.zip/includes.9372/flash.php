<?php
/** Flash messages stored in session, shown once. */
function flash(string $type, string $message): void
{
    if (session_status() !== PHP_SESSION_ACTIVE) start_secure_session();
    $_SESSION['_flash'][] = ['type' => $type, 'message' => $message];
}
function flash_success(string $m): void { flash('success', $m); }
function flash_error(string $m): void   { flash('error', $m); }

function get_flashes(): array
{
    $f = $_SESSION['_flash'] ?? [];
    unset($_SESSION['_flash']);
    return $f;
}
