<?php
/**
 * Audit logging for administrator actions.
 */
function audit_log(string $action, string $entity = '', $entityId = null, string $description = '', $old = null, $new = null): void
{
    $u = current_user();
    q("INSERT INTO audit_logs (user_id, action, entity, entity_id, description, old_value, new_value, ip_address)
       VALUES (?,?,?,?,?,?,?,?)",
      [
        $u['id'] ?? null,
        $action,
        $entity ?: null,
        $entityId !== null ? (int)$entityId : null,
        $description ?: null,
        $old !== null ? json_encode($old, JSON_UNESCAPED_UNICODE) : null,
        $new !== null ? json_encode($new, JSON_UNESCAPED_UNICODE) : null,
        client_ip(),
      ]);
}
