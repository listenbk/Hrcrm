<?php
/**
 * Task Manager helpers — priorities, statuses, pills and small utilities.
 * Tasks are assigned to employees (employees.id) by Admin / HR / Team Leader.
 */

function task_priorities(): array { return ['Low','Medium','High','Urgent']; }
function task_statuses(): array   { return ['Pending','In Progress','Completed']; }

function task_status_pill(string $s): string
{
    $m = ['Pending'=>'pill-warning','In Progress'=>'pill-info','Completed'=>'pill-success'];
    return '<span class="pill '.($m[$s] ?? 'pill-muted').'">'.e($s).'</span>';
}

function task_priority_pill(string $p): string
{
    $m = ['Low'=>'pill-muted','Medium'=>'pill-info','High'=>'pill-warning','Urgent'=>'pill-danger'];
    return '<span class="pill '.($m[$p] ?? 'pill-muted').'">'.e($p).'</span>';
}

/** Is the task overdue (has a due date in the past and not completed)? */
function task_is_overdue(array $t): bool
{
    return $t['status'] !== 'Completed' && !empty($t['due_date']) && $t['due_date'] < date('Y-m-d');
}

/** Open-task summary counters for an employee (dashboard badge / cards). */
function task_counts_for_employee(int $employeeId): array
{
    $rows = fetch_all("SELECT status, COUNT(*) c FROM tasks WHERE assigned_to=? GROUP BY status", [$employeeId]);
    $c = ['Pending'=>0,'In Progress'=>0,'Completed'=>0,'open'=>0,'total'=>0];
    foreach ($rows as $r) { $c[$r['status']] = (int)$r['c']; $c['total'] += (int)$r['c']; }
    $c['open'] = $c['Pending'] + $c['In Progress'];
    return $c;
}
