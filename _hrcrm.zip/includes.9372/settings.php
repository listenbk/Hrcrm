<?php
/**
 * Settings loader with in-request cache.
 */
function settings_all(bool $reload = false): array
{
    static $cache = null;
    if ($cache === null || $reload) {
        $cache = [];
        foreach (fetch_all("SELECT setting_key, setting_value FROM settings") as $row) {
            $cache[$row['setting_key']] = $row['setting_value'];
        }
    }
    return $cache;
}

function setting(string $key, $default = null)
{
    $all = settings_all();
    return array_key_exists($key, $all) ? $all[$key] : $default;
}

function set_setting(string $key, $value): void
{
    q("INSERT INTO settings (setting_key,setting_value) VALUES (?,?)
       ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)", [$key, (string)$value]);
    settings_all(true); // refresh cache
}
