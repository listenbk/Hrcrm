<?php
/**
 * PDO database connection (singleton).
 * All queries in the app use prepared statements via this handle.
 */
require_once __DIR__ . '/../config/config.php';

function db(): PDO
{
    static $pdo = null;
    if ($pdo instanceof PDO) {
        return $pdo;
    }
    $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=' . DB_CHARSET;
    $options = [
        PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
        PDO::ATTR_EMULATE_PREPARES   => false,
    ];
    try {
        $pdo = new PDO($dsn, DB_USER, DB_PASS, $options);
        $pdo->exec("SET time_zone = '+05:30'");
    } catch (PDOException $e) {
        if (APP_ENV === 'development') {
            die('Database connection failed: ' . htmlspecialchars($e->getMessage()));
        }
        http_response_code(500);
        die('Service temporarily unavailable. Please try again later.');
    }
    return $pdo;
}

/** Convenience helpers ------------------------------------------------ */
function q(string $sql, array $params = []): PDOStatement
{
    $stmt = db()->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}
function fetch_one(string $sql, array $params = []): ?array
{
    $row = q($sql, $params)->fetch();
    return $row === false ? null : $row;
}
function fetch_all(string $sql, array $params = []): array
{
    return q($sql, $params)->fetchAll();
}
function fetch_col(string $sql, array $params = [])
{
    return q($sql, $params)->fetchColumn();
}
function insert_id(): string
{
    return db()->lastInsertId();
}
