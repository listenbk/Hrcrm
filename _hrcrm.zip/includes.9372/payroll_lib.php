<?php
/**
 * Payroll calculation engine.
 * Builds a payroll draft for one employee for one month (YYYY-MM),
 * pulling salary components, attendance-based deductions and EMI.
 */

/** Number of days in a payroll month. */
function month_days(string $ym): int
{
    return (int)date('t', strtotime($ym . '-01'));
}

/** Attendance summary for payroll (present, absent, leave, late, working days). */
function payroll_attendance_summary(int $employeeId, string $ym): array
{
    $start = $ym . '-01';
    $end   = date('Y-m-t', strtotime($start));
    $rows = fetch_all(
        "SELECT a.*, s.name AS status_name, s.is_leave, s.is_paid
         FROM attendance a LEFT JOIN attendance_statuses s ON s.id=a.status_id
         WHERE a.employee_id=? AND a.att_date BETWEEN ? AND ?",
        [$employeeId, $start, $end]);

    $present = 0; $absent = 0; $leavePaid = 0; $leaveUnpaid = 0; $late = 0; $half = 0;
    foreach ($rows as $r) {
        if (!empty($r['is_leave'])) {
            $r['is_paid'] ? $leavePaid++ : $leaveUnpaid++;
        } elseif (($r['status_name'] ?? '') === 'Absent') {
            $absent++;
        } elseif (($r['status_name'] ?? '') === 'Half Day') {
            $half++; $present += 0.5;
        } elseif ($r['check_in']) {
            $present++;
        }
        if ($r['late_minutes'] > 0) $late++;
    }
    $totalDays = month_days($ym);
    // working days = total minus this employee's weekly offs (custom or company default) & holidays
    $workingDays = 0;
    for ($d = 1; $d <= $totalDays; $d++) {
        $date = sprintf('%s-%02d', $ym, $d);
        if (is_weekly_off($date, $employeeId)) continue;
        $workingDays++;
    }
    $payableDays = $present + $leavePaid + ($half * 0); // half already counted as 0.5
    return compact('present','absent','leavePaid','leaveUnpaid','late','half','totalDays','workingDays','payableDays');
}

/** Per-employee component amount (override else default), resolving % of basic. */
function resolve_component_amount(array $comp, float $basic, ?array $override): float
{
    $calc = $override['calc_type'] ?? $comp['calc_type'];
    $val  = $override ? (float)$override['amount'] : (float)$comp['default_amount'];
    if ($calc === 'percentage') {
        return round($basic * $val / 100, 2);
    }
    return round($val, 2);
}

/**
 * Build (calculate) a payroll for one employee/month. Does NOT save.
 * Returns a structured array with items and totals.
 */
function calculate_payroll(int $employeeId, string $ym): array
{
    $emp = fetch_one("SELECT * FROM employees WHERE id=?", [$employeeId]);
    if (!$emp) return [];

    $basic = (float)$emp['basic_salary'];
    $summary = payroll_attendance_summary($employeeId, $ym);

    $earnings = [];
    $deductions = [];

    // Basic salary as first earning
    $earnings[] = ['label'=>'Basic Salary','amount'=>$basic,'component_id'=>null,'source'=>'component'];

    // Employee overrides
    $overrides = [];
    foreach (fetch_all("SELECT * FROM employee_salary_components WHERE employee_id=?", [$employeeId]) as $o) {
        $overrides[$o['component_id']] = $o;
    }

    // Active recurring components (skip 'basic' — already added)
    $comps = fetch_all("SELECT * FROM salary_components WHERE is_active=1 AND is_recurring=1 ORDER BY sort_order");
    foreach ($comps as $comp) {
        if ($comp['slug'] === 'basic') continue;
        $amt = resolve_component_amount($comp, $basic, $overrides[$comp['id']] ?? null);
        if ($amt == 0 && !isset($overrides[$comp['id']])) continue;
        $entry = ['label'=>$comp['name'],'amount'=>$amt,'component_id'=>(int)$comp['id'],'source'=>'component'];
        $comp['type'] === 'earning' ? $earnings[] = $entry : $deductions[] = $entry;
    }

    // Overtime pay (Manager-approved, not yet paid) — appears as an earning
    $otIds = []; $otHours = 0.0;
    if (function_exists('ot_payable_for_month')) {
        $otRows = ot_payable_for_month($employeeId, $ym);
        $otTotal = 0.0;
        foreach ($otRows as $ot) {
            $otTotal += (float)$ot['amount'];
            $otHours += (float)$ot['approved_hours'];
            $otIds[] = (int)$ot['id'];
        }
        if ($otTotal > 0) {
            $hLabel = rtrim(rtrim(number_format($otHours, 2), '0'), '.');
            $earnings[] = ['label'=>"Overtime Pay ({$hLabel}h)",'amount'=>round($otTotal,2),'component_id'=>null,'source'=>'overtime'];
        }
    }

    // Per-day rate for attendance deductions
    $perDay = $summary['workingDays'] > 0 ? $basic / $summary['workingDays'] : 0;

    // Absent / unpaid-leave deduction
    $unpaidDays = $summary['absent'] + $summary['leaveUnpaid'];
    if ($unpaidDays > 0 && $perDay > 0) {
        $deductions[] = ['label'=>"Absent/Unpaid Leave ({$unpaidDays}d)",'amount'=>round($perDay*$unpaidDays,2),'component_id'=>null,'source'=>'absent'];
    }

    // Late deduction (optional, configurable per-day charge)
    $lateCharge = (float)setting('late_deduction_per_day', 0);
    if ($lateCharge > 0 && $summary['late'] > 0) {
        $deductions[] = ['label'=>"Late Penalty ({$summary['late']}x)",'amount'=>round($lateCharge*$summary['late'],2),'component_id'=>null,'source'=>'late'];
    }

    // EMI deductions due this month
    $emis = fetch_all(
        "SELECT es.*, ea.advance_type FROM emi_schedules es
         JOIN employee_advances ea ON ea.id = es.advance_id
         WHERE ea.employee_id = ? AND es.due_month = ? AND es.status='Pending' AND ea.status='Active'",
        [$employeeId, $ym]);
    foreach ($emis as $emi) {
        $deductions[] = ['label'=>$emi['advance_type'].' EMI','amount'=>(float)$emi['amount'],'component_id'=>null,'source'=>'emi','emi_id'=>(int)$emi['id']];
    }

    $gross = array_sum(array_column($earnings, 'amount'));
    $totalDed = array_sum(array_column($deductions, 'amount'));
    $net = round($gross - $totalDed, 2);

    return [
        'employee' => $emp,
        'pay_month' => $ym,
        'earnings' => $earnings,
        'deductions' => $deductions,
        'gross' => round($gross, 2),
        'total_deductions' => round($totalDed, 2),
        'net' => $net,
        'summary' => $summary,
        'basic' => $basic,
        'overtime_ids' => $otIds,
        'overtime_hours' => $otHours,
    ];
}

/**
 * Persist a calculated payroll (insert or update the draft).
 * Marks linked EMI schedules Paid and updates advance balances.
 * Returns payroll id.
 */
function save_payroll(array $calc, int $createdBy): int
{
    $emp = $calc['employee'];
    $ym  = $calc['pay_month'];
    $s   = $calc['summary'];

    $existing = fetch_one("SELECT * FROM payroll WHERE employee_id=? AND pay_month=?", [$emp['id'], $ym]);
    if ($existing && $existing['is_finalized']) {
        return (int)$existing['id']; // don't overwrite finalized
    }

    db()->beginTransaction();
    try {
        if ($existing) {
            $payrollId = (int)$existing['id'];
            q("UPDATE payroll SET basic_salary=?, gross_earnings=?, total_deductions=?, net_salary=?, pending_amount=?,
                 present_days=?, absent_days=?, leave_days=?, late_count=?, payable_days=?, working_days=?, updated_at=NOW()
               WHERE id=?",
              [$calc['basic'],$calc['gross'],$calc['total_deductions'],$calc['net'],
               max(0,$calc['net']-(float)$existing['paid_amount']),
               $s['present'],$s['absent'],$s['leavePaid']+$s['leaveUnpaid'],$s['late'],$s['payableDays'],$s['workingDays'],
               $payrollId]);
            q("DELETE FROM payroll_items WHERE payroll_id=?", [$payrollId]);
        } else {
            q("INSERT INTO payroll (employee_id,pay_month,basic_salary,gross_earnings,total_deductions,net_salary,pending_amount,
                 present_days,absent_days,leave_days,late_count,payable_days,working_days,status,created_by)
               VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?, 'Pending', ?)",
              [$emp['id'],$ym,$calc['basic'],$calc['gross'],$calc['total_deductions'],$calc['net'],$calc['net'],
               $s['present'],$s['absent'],$s['leavePaid']+$s['leaveUnpaid'],$s['late'],$s['payableDays'],$s['workingDays'],$createdBy]);
            $payrollId = (int)insert_id();
        }

        foreach ($calc['earnings'] as $it) {
            q("INSERT INTO payroll_items (payroll_id,component_id,label,type,amount,source) VALUES (?,?,?,?,?,?)",
              [$payrollId,$it['component_id'],$it['label'],'earning',$it['amount'],$it['source']]);
        }
        foreach ($calc['deductions'] as $it) {
            q("INSERT INTO payroll_items (payroll_id,component_id,label,type,amount,source) VALUES (?,?,?,?,?,?)",
              [$payrollId,$it['component_id'],$it['label'],'deduction',$it['amount'],$it['source']]);
            // link & mark EMI schedule
            if (($it['source'] ?? '') === 'emi' && !empty($it['emi_id'])) {
                q("UPDATE emi_schedules SET status='Paid', payroll_id=?, paid_at=NOW() WHERE id=?", [$payrollId, $it['emi_id']]);
                $emi = fetch_one("SELECT * FROM emi_schedules WHERE id=?", [$it['emi_id']]);
                if ($emi) {
                    q("UPDATE employee_advances SET recovered_amount=recovered_amount+?, balance_amount=GREATEST(0,balance_amount-?) WHERE id=?",
                      [$it['amount'],$it['amount'],$emi['advance_id']]);
                    // complete advance if balance hits zero
                    q("UPDATE employee_advances SET status='Completed' WHERE id=? AND balance_amount<=0", [$emi['advance_id']]);
                }
            }
        }
        db()->commit();
    } catch (Throwable $ex) {
        db()->rollBack();
        throw $ex;
    }

    if (!empty($emp['user_id'])) {
        notify((int)$emp['user_id'], 'salary', 'Salary generated',
            "Your salary slip for {$ym} is ready.", url('employee/salary_slips.php'));
    }
    return $payrollId;
}
