<?php
/**
 * Single entry point loaded by every page.
 * Starts the session, loads helpers, sets security headers.
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/csrf.php';
require_once __DIR__ . '/flash.php';
require_once __DIR__ . '/audit.php';
require_once __DIR__ . '/attendance_lib.php';
require_once __DIR__ . '/overtime_lib.php';
require_once __DIR__ . '/payroll_lib.php';
require_once __DIR__ . '/customfields_lib.php';
require_once __DIR__ . '/notice_lib.php';
require_once __DIR__ . '/asset_lib.php';
require_once __DIR__ . '/task_lib.php';
require_once __DIR__ . '/geofence_lib.php';

start_secure_session();

// Basic security headers (defense in depth)
header('X-Content-Type-Options: nosniff');
header('X-Frame-Options: SAMEORIGIN');
header('Referrer-Policy: strict-origin-when-cross-origin');
header("Content-Security-Policy: default-src 'self'; img-src 'self' data:; "
     . "script-src 'self' https://cdn.jsdelivr.net 'unsafe-inline'; "
     . "style-src 'self' https://cdn.jsdelivr.net https://fonts.googleapis.com 'unsafe-inline'; "
     . "font-src 'self' https://fonts.gstatic.com data:;");
