<?php
/**
 * Overtime engine — detection from verified attendance, configurable
 * rounding / rates / multipliers, approval-aware amount calculation,
 * and payroll integration.  All timings/rates come from settings.
 */

function ot_enabled(): bool { return setting('ot_enabled', '1') === '1'; }

/** Manual OT sessions on? When true, OT is only counted via a separate OT Check-In. */
function ot_manual_enabled(): bool { return setting('ot_manual_sessions', '1') === '1'; }

/** The employee's currently OPEN manual OT session for a date (or today). */
function ot_open_session(int $employeeId, ?string $date = null): ?array
{
    $date = $date ?: date('Y-m-d');
    return fetch_one(
        "SELECT * FROM overtime
         WHERE employee_id=? AND ot_date=? AND session_type='manual'
           AND ot_check_in IS NOT NULL AND actual_out IS NULL
         ORDER BY id DESC LIMIT 1",
        [$employeeId, $date]);
}

/**
 * OVERTIME CHECK-IN — start a separate, employee-initiated OT session.
 * Requires: OT enabled, the normal attendance session for today already ended
 * (checked out), and no OT session already recorded today. Returns [ok, msg].
 */
function ot_session_start(int $employeeId): array
{
    if (!ot_enabled() || !ot_manual_enabled()) {
        return [false, 'Overtime sessions are not enabled.'];
    }
    $now  = new DateTime();
    $date = $now->format('Y-m-d');

    // Overtime check-in is only allowed from the configured cut-off onward
    // (default 8:00 PM), regardless of when normal attendance ended.
    $cutoffStr = (string)setting('ot_checkin_after', '20:00');
    $cutoff = DateTime::createFromFormat('Y-m-d H:i', "$date $cutoffStr") ?: new DateTime("$date 20:00");
    if ($now < $cutoff) {
        return [false, 'Overtime check-in is only available from ' . $cutoff->format('h:i A') . ' onward.'];
    }

    // Normal session must have ended first.
    $att = fetch_one("SELECT * FROM attendance WHERE employee_id=? AND att_date=?", [$employeeId, $date]);
    if (!$att || empty($att['check_in'])) {
        return [false, 'Check in for the day before starting overtime.'];
    }
    if (empty($att['check_out'])) {
        return [false, 'Finish your normal attendance (check out) before starting an overtime session.'];
    }

    // One OT session per day.
    $existing = fetch_one("SELECT * FROM overtime WHERE employee_id=? AND ot_date=?", [$employeeId, $date]);
    if ($existing) {
        if (!empty($existing['ot_check_in']) && empty($existing['actual_out'])) {
            return [false, 'You already have an overtime session running. Please check out of it first.'];
        }
        return [false, 'An overtime record already exists for today.'];
    }

    [, $officeOut] = office_times($date, $employeeId);
    $emp     = fetch_one("SELECT basic_salary FROM employees WHERE id=?", [$employeeId]);
    $dayType = ot_resolve_day_type($date, $employeeId);
    $rate    = ot_hourly_rate((float)($emp['basic_salary'] ?? 0));
    $mult    = ot_multiplier($dayType);

    q("INSERT INTO overtime
         (employee_id, ot_date, standard_out, ot_check_in, session_type, day_type, multiplier, hourly_rate, status)
       VALUES (?,?,?,?, 'manual', ?,?,?, 'Detected')",
      [$employeeId, $date, $officeOut->format('Y-m-d H:i:s'), $now->format('Y-m-d H:i:s'),
       $dayType, $mult, $rate]);

    return [true, 'Overtime session started at ' . $now->format('h:i A') . '. Remember to check out when you finish.'];
}

/**
 * OVERTIME CHECK-OUT — end the open OT session. Overtime duration is the OT
 * session length (OT check-out − OT check-in), calculated separately from
 * regular hours. Leaves the record as 'Detected' so the employee then submits
 * a reason and it flows through the existing approval / payroll pipeline.
 * Returns [ok, msg].
 */
function ot_session_stop(int $employeeId): array
{
    $now = new DateTime();
    $ot  = ot_open_session($employeeId, $now->format('Y-m-d'));
    if (!$ot) return [false, 'No overtime session is currently running.'];

    $start = new DateTime($ot['ot_check_in']);
    $rawMin = max(0, (int)round(($now->getTimestamp() - $start->getTimestamp()) / 60));
    $hours  = ot_round_hours($rawMin);
    $maxDaily = (float)setting('ot_max_daily_hours', 0);
    if ($maxDaily > 0 && $hours > $maxDaily) $hours = $maxDaily;

    q("UPDATE overtime
         SET actual_out=?, actual_minutes=?, actual_hours=?
       WHERE id=? AND actual_out IS NULL",
      [$now->format('Y-m-d H:i:s'), $rawMin, $hours, $ot['id']]);

    $hStr = rtrim(rtrim(number_format($hours, 2), '0'), '.');
    return [true, "Overtime session ended — {$hStr}h recorded. Submit a reason to send it for approval."];
}

/** Convert raw OT minutes to decimal hours using the configured rounding rule. */
function ot_round_hours(int $minutes): float
{
    if ($minutes <= 0) return 0.0;
    switch (setting('ot_rounding', 'nearest30')) {
        case 'exact':     return round($minutes / 60, 2);
        case 'nearest15': return round(round($minutes / 15) * 15 / 60, 2);
        case 'down':      return (float)floor($minutes / 60);
        case 'up':        return (float)ceil($minutes / 60);
        case 'nearest30':
        default:          return round(round($minutes / 30) * 30 / 60, 2);
    }
}

/** Resolve the day type slug for a date (drives the OT multiplier). Weekly-off is employee-aware. */
function ot_resolve_day_type(string $date, ?int $employeeId = null): string
{
    if (is_holiday($date)) return 'public_holiday';
    if ((int)date('w', strtotime($date)) === 0) return 'sunday';
    if (is_weekly_off($date, $employeeId)) return 'weekly_off';
    return 'normal';
}

/** Multiplier for a day type (from overtime_rates), default 1.0. */
function ot_multiplier(string $dayType): float
{
    $m = fetch_col("SELECT multiplier FROM overtime_rates WHERE day_type=? AND is_active=1", [$dayType]);
    return $m !== false ? (float)$m : 1.0;
}

function ot_day_type_label(string $dayType): string
{
    $l = fetch_col("SELECT label FROM overtime_rates WHERE day_type=?", [$dayType]);
    return $l !== false ? (string)$l : ucfirst(str_replace('_', ' ', $dayType));
}

/** Hourly OT rate: fixed, or derived from monthly salary. */
function ot_hourly_rate(float $basic): float
{
    if (setting('ot_rate_mode', 'salary') === 'fixed') {
        return (float)setting('ot_fixed_hourly', 150);
    }
    $std = (float)setting('ot_monthly_standard_hours', 200);
    return $std > 0 ? round($basic / $std, 2) : 0.0;
}

/**
 * Detect overtime for a completed attendance day. Called from do_check_out
 * using the SERVER-generated checkout time only. Creates/updates a 'Detected'
 * record; never overwrites a record already in the approval workflow.
 * Returns the overtime row or null.
 */
function detect_overtime(int $employeeId, ?int $attendanceId, DateTime $actualOut, string $date): ?array
{
    if (!ot_enabled()) return null;
    [, $officeOut] = office_times($date, $employeeId);
    if ($actualOut <= $officeOut) return null;

    $rawMin = (int)round(($actualOut->getTimestamp() - $officeOut->getTimestamp()) / 60);
    if ($rawMin < (int)setting('ot_min_minutes', 30)) return null;

    $hours = ot_round_hours($rawMin);
    $maxDaily = (float)setting('ot_max_daily_hours', 0);
    if ($maxDaily > 0 && $hours > $maxDaily) $hours = $maxDaily;
    if ($hours <= 0) return null;

    $existing = fetch_one("SELECT * FROM overtime WHERE employee_id=? AND ot_date=?", [$employeeId, $date]);
    if ($existing && $existing['status'] !== 'Detected') {
        return $existing;   // already submitted/approved — don't clobber
    }

    $emp = fetch_one("SELECT basic_salary, user_id, full_name FROM employees WHERE id=?", [$employeeId]);
    $dayType = ot_resolve_day_type($date, $employeeId);
    $rate = ot_hourly_rate((float)($emp['basic_salary'] ?? 0));
    $mult = ot_multiplier($dayType);

    if ($existing) {
        q("UPDATE overtime SET attendance_id=?, standard_out=?, actual_out=?, actual_minutes=?, actual_hours=?,
             day_type=?, multiplier=?, hourly_rate=?, status='Detected' WHERE id=?",
          [$attendanceId, $officeOut->format('Y-m-d H:i:s'), $actualOut->format('Y-m-d H:i:s'),
           $rawMin, $hours, $dayType, $mult, $rate, $existing['id']]);
        $id = (int)$existing['id'];
    } else {
        q("INSERT INTO overtime (employee_id, attendance_id, ot_date, standard_out, actual_out, actual_minutes,
             actual_hours, day_type, multiplier, hourly_rate, status)
           VALUES (?,?,?,?,?,?,?,?,?,?, 'Detected')",
          [$employeeId, $attendanceId, $date, $officeOut->format('Y-m-d H:i:s'), $actualOut->format('Y-m-d H:i:s'),
           $rawMin, $hours, $dayType, $mult, $rate]);
        $id = (int)insert_id();
    }

    if (!empty($emp['user_id'])) {
        notify((int)$emp['user_id'], 'overtime_detected', 'Overtime detected',
            "You worked {$hours}h beyond office hours on " . fmt_date($date) . ". Submit a reason for approval.",
            url('employee/overtime.php'));
    }
    return fetch_one("SELECT * FROM overtime WHERE id=?", [$id]);
}

/** Expected (provisional) earnings for a not-yet-approved record. */
function ot_expected_amount(array $ot): float
{
    return round((float)$ot['actual_hours'] * (float)$ot['hourly_rate'] * (float)$ot['multiplier'], 2);
}

/** Recompute the approved amount from approved_hours × rate × multiplier. */
function ot_recalc_amount(float $approvedHours, float $rate, float $mult): float
{
    return round($approvedHours * $rate * $mult, 2);
}

/** Monthly OT summary for an employee. */
function ot_month_summary(int $employeeId, string $ym): array
{
    $start = $ym . '-01'; $end = date('Y-m-t', strtotime($start));
    $rows = fetch_all("SELECT * FROM overtime WHERE employee_id=? AND ot_date BETWEEN ? AND ?",
        [$employeeId, $start, $end]);
    $s = ['actual_hours'=>0,'approved_hours'=>0,'pending'=>0,'approved'=>0,'rejected'=>0,'paid'=>0,
          'expected_amount'=>0,'approved_amount'=>0,'paid_amount'=>0];
    foreach ($rows as $r) {
        $s['actual_hours'] += (float)$r['actual_hours'];
        $s['approved_hours'] += (float)$r['approved_hours'];
        if (in_array($r['status'], ['Detected','Pending Approval','HR Reviewed'], true)) { $s['pending']++; $s['expected_amount'] += ot_expected_amount($r); }
        if (in_array($r['status'], ['Approved','Partially Approved'], true)) { $s['approved']++; $s['approved_amount'] += (float)$r['amount']; }
        if ($r['status'] === 'Rejected') $s['rejected']++;
        if ($r['status'] === 'Paid') { $s['paid']++; $s['paid_amount'] += (float)$r['amount']; }
    }
    return $s;
}

/** Approved-and-unpaid OT rows for a month (for payroll pickup). */
function ot_payable_for_month(int $employeeId, string $ym): array
{
    $start = $ym . '-01'; $end = date('Y-m-t', strtotime($start));
    return fetch_all(
        "SELECT * FROM overtime
         WHERE employee_id=? AND ot_date BETWEEN ? AND ?
           AND status IN ('Approved','Partially Approved')
           AND include_in_payroll=1 AND payroll_id IS NULL",
        [$employeeId, $start, $end]);
}
