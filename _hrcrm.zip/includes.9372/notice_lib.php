<?php
/**
 * Notice Board logic — audience resolution, visibility windows,
 * read tracking and unread counts.
 */

/** Is a notice currently active (published, not expired, not archived/trashed)? */
function notice_is_active(array $n): bool
{
    if (!empty($n['deleted_at'])) return false;                    // in Trash
    if (!empty($n['is_archived'])) return false;                   // manually archived
    $today = date('Y-m-d');
    if ($n['publish_date'] > $today) return false;                 // scheduled
    if (!empty($n['expiry_date']) && $n['expiry_date'] < $today) return false; // expired
    return true;
}

/** Can the given user delete/archive this notice?
 *  Super Admin: any notice. HR: only notices they created (never a Super
 *  Admin's). Everyone else: no. */
function can_manage_notice(array $n, array $user): bool
{
    if ($user['role_slug'] === 'super_admin') return true;
    if (!has_perm('notices.manage')) return false;
    return (int)$n['created_by'] === (int)$user['id'];
}

/** Does a given user fall within a notice's target audience? */
function user_sees_notice(array $n, array $user, ?array $emp): bool
{
    if ($user['role_slug'] === 'super_admin') return true;          // manager oversees all
    if ((int)$n['created_by'] === (int)$user['id']) return true;    // the author
    switch ($n['audience_type']) {
        case 'all':       return true;
        case 'employees': return $user['role_slug'] === 'employee';
        case 'hr':        return $user['role_slug'] === 'hr_admin';
        case 'department':return $emp && (string)($emp['department_id'] ?? '') === (string)$n['audience_value'];
        case 'branch':    return $emp && strcasecmp((string)($emp['office_location'] ?? ''), (string)$n['audience_value']) === 0;
        case 'selected':
            return (int)fetch_col("SELECT COUNT(*) FROM notice_targets WHERE notice_id=? AND user_id=?",
                [$n['id'], $user['id']]) > 0;
    }
    return false;
}

/** Notices visible to a user, pinned + priority ordered. $archived => expired ones. */
function visible_notices_for(array $user, bool $archived = false): array
{
    $emp = fetch_one("SELECT department_id, office_location FROM employees WHERE user_id=?", [$user['id']]);
    $today = date('Y-m-d');
    $rows = fetch_all(
        "SELECT * FROM notices
         WHERE deleted_at IS NULL
         ORDER BY is_pinned DESC, FIELD(priority,'Urgent','Important','Normal'), publish_date DESC, id DESC");
    $out = [];
    foreach ($rows as $n) {
        if (!empty($n['deleted_at'])) continue;                     // never show trashed notices
        $published = $n['publish_date'] <= $today;
        $expired   = !empty($n['expiry_date']) && $n['expiry_date'] < $today;
        $isArchived = !empty($n['is_archived']) || $expired;
        if ($archived) {
            if (!$published || !$isArchived) continue;              // Archive tab = archived/expired only
        } else {
            if (!$published || $isArchived) continue;               // Active board only
        }
        if (user_sees_notice($n, $user, $emp)) $out[] = $n;
    }
    return $out;
}

/** Count of active notices visible to the user that they have not read. */
function notice_unread_count(array $user): int
{
    $vis = visible_notices_for($user, false);
    if (!$vis) return 0;
    $read = [];
    foreach (fetch_all("SELECT notice_id FROM notice_reads WHERE user_id=?", [$user['id']]) as $r) {
        $read[(int)$r['notice_id']] = true;
    }
    $c = 0;
    foreach ($vis as $n) if (!isset($read[(int)$n['id']])) $c++;
    return $c;
}

/** Has this user read a notice? */
function notice_is_read(int $noticeId, int $userId): bool
{
    return (int)fetch_col("SELECT COUNT(*) FROM notice_reads WHERE notice_id=? AND user_id=?", [$noticeId, $userId]) > 0;
}

/** Record a read receipt. */
function mark_notice_read(int $noticeId, int $userId): void
{
    q("INSERT IGNORE INTO notice_reads (notice_id,user_id) VALUES (?,?)", [$noticeId, $userId]);
}

/** Resolve the set of user ids that a notice targets (for read tracking). */
function notice_audience_user_ids(array $n): array
{
    switch ($n['audience_type']) {
        case 'all':
            $rows = fetch_all("SELECT id FROM users WHERE is_active=1"); break;
        case 'employees':
            $rows = fetch_all("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE r.slug='employee' AND u.is_active=1"); break;
        case 'hr':
            $rows = fetch_all("SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id WHERE r.slug='hr_admin' AND u.is_active=1"); break;
        case 'department':
            $rows = fetch_all("SELECT DISTINCT e.user_id AS id FROM employees e WHERE e.department_id=? AND e.user_id IS NOT NULL", [$n['audience_value']]); break;
        case 'branch':
            $rows = fetch_all("SELECT DISTINCT e.user_id AS id FROM employees e WHERE e.office_location=? AND e.user_id IS NOT NULL", [$n['audience_value']]); break;
        case 'selected':
            $rows = fetch_all("SELECT user_id AS id FROM notice_targets WHERE notice_id=?", [$n['id']]); break;
        default:
            $rows = [];
    }
    return array_values(array_unique(array_map(fn($r) => (int)$r['id'], $rows)));
}

/** Read statistics for a notice: [audience_count, read_count]. */
function notice_read_stats(array $n): array
{
    $audience = notice_audience_user_ids($n);
    if (!$audience) return [0, 0];
    $in = implode(',', array_fill(0, count($audience), '?'));
    $read = (int)fetch_col("SELECT COUNT(DISTINCT user_id) FROM notice_reads WHERE notice_id=? AND user_id IN ($in)",
        array_merge([$n['id']], $audience));
    return [count($audience), $read];
}

/** Human label for an audience. */
function notice_audience_label(array $n): string
{
    switch ($n['audience_type']) {
        case 'all':       return 'All Users';
        case 'employees': return 'All Employees';
        case 'hr':        return 'All HR / Admins';
        case 'department':
            $d = fetch_col("SELECT name FROM departments WHERE id=?", [$n['audience_value']]);
            return 'Department: ' . ($d ?: '—');
        case 'branch':    return 'Branch: ' . $n['audience_value'];
        case 'selected':  return 'Selected users (' . (int)fetch_col("SELECT COUNT(*) FROM notice_targets WHERE notice_id=?", [$n['id']]) . ')';
    }
    return '—';
}

/** Priority pill CSS class. */
function notice_priority_pill(string $p): string
{
    return ['Urgent' => 'pill-danger', 'Important' => 'pill-warning', 'Normal' => 'pill-muted'][$p] ?? 'pill-muted';
}
