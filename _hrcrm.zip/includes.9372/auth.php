<?php
/**
 * Authentication, secure sessions, RBAC, rate limiting, account lockout,
 * remember-me, session timeout and password reset.
 *
 * Every protected page starts with require_login() and, where relevant,
 * require_perm('some.permission') / require_super_admin().
 */
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/settings.php';
require_once __DIR__ . '/functions.php';

const REMEMBER_COOKIE = 'rg_remember';

/* ===================================================================
 *  Sessions
 * =================================================================== */

/** Start a hardened session. */
function start_secure_session(): void
{
    if (session_status() === PHP_SESSION_ACTIVE) {
        return;
    }
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off')
          || (($_SERVER['HTTP_X_FORWARDED_PROTO'] ?? '') === 'https');
    session_name(SESSION_NAME);
    session_set_cookie_params([
        'lifetime' => 0,
        'path'     => '/',
        'domain'   => '',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    ini_set('session.use_strict_mode', '1');
    session_start();

    // Rotate id periodically to limit fixation window
    if (empty($_SESSION['_created'])) {
        $_SESSION['_created'] = time();
    } elseif (time() - $_SESSION['_created'] > 1800) {
        session_regenerate_id(true);
        $_SESSION['_created'] = time();
    }
}

/** Currently logged-in user row, or null. Cache keyed to the session user id. */
function current_user(): ?array
{
    static $cachedFor = null;
    static $user = null;
    $sid = $_SESSION['user_id'] ?? null;
    if ($cachedFor === $sid) {
        return $user;
    }
    $cachedFor = $sid;
    if (empty($sid)) {
        return $user = null;
    }
    $user = fetch_one(
        "SELECT u.*, r.slug AS role_slug, r.name AS role_name
         FROM users u JOIN roles r ON r.id = u.role_id
         WHERE u.id = ? AND u.is_active = 1",
        [$sid]
    );
    return $user;
}

/** Employee row linked to the current user (for the employee portal). */
function current_employee(): ?array
{
    $u = current_user();
    if (!$u) return null;
    return fetch_one("SELECT * FROM employees WHERE user_id = ?", [$u['id']]);
}

function is_logged_in(): bool { return current_user() !== null; }

/**
 * Guard: require an authenticated session.
 * Also runs remember-me auto-login and enforces timeout + auth_version.
 */
function require_login(): void
{
    start_secure_session();

    if (!is_logged_in()) {
        try_remember_login();
    }
    if (is_logged_in()) {
        enforce_session_policies();
    }
    if (!is_logged_in()) {
        redirect('auth/login.php');
    }
}

/** Idle timeout + auth_version (password-change) session invalidation. */
function enforce_session_policies(): void
{
    $u = current_user();
    if (!$u) return;

    // auth_version mismatch => credentials changed elsewhere, force re-login
    if (isset($_SESSION['auth_version']) && (int)$_SESSION['auth_version'] !== (int)$u['auth_version']) {
        logout();
        redirect('auth/login.php?expired=1');
    }

    // idle session timeout
    $timeout = (int)setting('session_timeout_minutes', 30) * 60;
    $last = $_SESSION['_last_activity'] ?? time();
    if ($timeout > 0 && (time() - $last) > $timeout) {
        logout();
        redirect('auth/login.php?timeout=1');
    }
    $_SESSION['_last_activity'] = time();
    q("UPDATE users SET last_activity = NOW() WHERE id = ?", [$u['id']]);
}

/* ===================================================================
 *  Roles & permissions
 * =================================================================== */

function is_role(string ...$slugs): bool
{
    $u = current_user();
    return $u && in_array($u['role_slug'], $slugs, true);
}

/** Any staff/back-office role (HR or Super Admin). */
function is_admin(): bool       { return is_role('super_admin', 'hr_admin'); }
function is_super_admin(): bool  { return is_role('super_admin'); }
function is_hr(): bool           { return is_role('hr_admin'); }
function is_team_leader(): bool  { return is_role('team_leader'); }
function is_employee(): bool     { return is_role('employee'); }

/** Does the current user's role hold a permission slug? Super Admin => all. */
function has_perm(string $slug): bool
{
    $u = current_user();
    if (!$u) return false;
    if ($u['role_slug'] === 'super_admin') return true;
    static $cache = null;
    static $cachedRole = null;
    if ($cache === null || $cachedRole !== $u['role_id']) {
        $cache = [];
        $cachedRole = $u['role_id'];
        foreach (fetch_all(
            "SELECT p.slug FROM role_permissions rp
             JOIN permissions p ON p.id = rp.permission_id
             WHERE rp.role_id = ?", [$u['role_id']]) as $r) {
            $cache[$r['slug']] = true;
        }
    }
    return isset($cache[$slug]);
}

/** Guard a page by permission slug. */
function require_perm(string $slug): void
{
    require_login();
    if (!has_perm($slug)) {
        http_response_code(403);
        require __DIR__ . '/../templates/403.php';
        exit;
    }
}

/** Guard: any back-office user (HR or Super Admin). */
function require_admin(): void
{
    require_login();
    if (!is_admin()) {
        http_response_code(403);
        require __DIR__ . '/../templates/403.php';
        exit;
    }
}

/** Guard: Super Admin / Manager only (global config, users, roles, deletes). */
function require_super_admin(): void
{
    require_login();
    if (!is_super_admin()) {
        http_response_code(403);
        require __DIR__ . '/../templates/403.php';
        exit;
    }
}

/* ===================================================================
 *  Login, lockout & rate limiting
 * =================================================================== */

/** Resolve a login identifier (email OR username OR employee code) to a user. */
function find_login_user(string $identifier): ?array
{
    $id = trim($identifier);
    if ($id === '') return null;

    if (strpos($id, '@') !== false) {
        $u = fetch_one("SELECT * FROM users WHERE email = ?", [strtolower($id)]);
        if ($u) return $u;
    }
    $u = fetch_one("SELECT * FROM users WHERE username = ?", [$id]);
    if ($u) return $u;

    $u = fetch_one(
        "SELECT u.* FROM users u JOIN employees e ON e.user_id = u.id
         WHERE e.emp_code = ?", [$id]);
    if ($u) return $u;

    return fetch_one("SELECT * FROM users WHERE email = ?", [strtolower($id)]) ?: null;
}

function login_recent_failures(string $identifier, string $ip): int
{
    $window = (int)setting('login_lockout_minutes', 15);
    $row = fetch_one(
        "SELECT COUNT(*) c FROM login_attempts
         WHERE success = 0 AND (email = ? OR ip_address = ?)
           AND created_at > (NOW() - INTERVAL ? MINUTE)",
        [$identifier, $ip, $window]
    );
    return (int)($row['c'] ?? 0);
}

function record_login_attempt(string $identifier, string $ip, bool $success): void
{
    q("INSERT INTO login_attempts (email, ip_address, success) VALUES (?,?,?)",
      [substr($identifier, 0, 150), $ip, $success ? 1 : 0]);
}

/**
 * Attempt a login.
 * @return array [bool ok, string message]
 */
function attempt_login(string $identifier, string $password, bool $remember = false): array
{
    $ip = client_ip();
    $identifier = trim($identifier);
    $maxAttempts = (int)setting('login_max_attempts', 5);
    $lockMin     = (int)setting('login_lockout_minutes', 15);

    // Global IP/identifier rate limit (defence in depth)
    if (login_recent_failures($identifier, $ip) >= max($maxAttempts * 2, 10)) {
        record_login_attempt($identifier, $ip, false);
        return [false, 'Too many attempts from your network. Please wait a few minutes.'];
    }

    $user = find_login_user($identifier);

    // Locked account?
    if ($user && !empty($user['locked_until']) && strtotime($user['locked_until']) > time()) {
        record_login_attempt($identifier, $ip, false);
        $mins = max(1, (int)ceil((strtotime($user['locked_until']) - time()) / 60));
        return [false, "Account temporarily locked. Try again in {$mins} minute(s)."];
    }

    $valid = $user && $user['is_active'] && password_verify($password, $user['password_hash']);

    if (!$valid) {
        record_login_attempt($identifier, $ip, false);
        if ($user) {
            $fa = (int)$user['failed_attempts'] + 1;
            if ($fa >= $maxAttempts) {
                q("UPDATE users SET failed_attempts = ?, locked_until = (NOW() + INTERVAL ? MINUTE) WHERE id = ?",
                  [$fa, $lockMin, $user['id']]);
                return [false, "Too many failed attempts. Account locked for {$lockMin} minutes."];
            }
            q("UPDATE users SET failed_attempts = ? WHERE id = ?", [$fa, $user['id']]);
            $left = $maxAttempts - $fa;
            return [false, "Invalid login. {$left} attempt(s) left before lockout."];
        }
        return [false, 'Invalid login credentials.'];
    }

    // ---- success ----
    record_login_attempt($identifier, $ip, true);
    session_regenerate_id(true);
    $_SESSION['user_id']        = (int)$user['id'];
    $_SESSION['auth_version']   = (int)$user['auth_version'];
    $_SESSION['_created']       = time();
    $_SESSION['_last_activity'] = time();

    if (password_needs_rehash($user['password_hash'], PASSWORD_DEFAULT)) {
        q("UPDATE users SET password_hash = ? WHERE id = ?",
          [password_hash($password, PASSWORD_DEFAULT), $user['id']]);
    }
    q("UPDATE users SET last_login_at = NOW(), last_login_ip = ?, last_activity = NOW(),
         failed_attempts = 0, locked_until = NULL WHERE id = ?",
      [$ip, $user['id']]);

    if ($remember) {
        issue_remember_token((int)$user['id']);
    }
    return [true, 'ok'];
}

function logout(): void
{
    start_secure_session();
    clear_remember_token();
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], $p['secure'], $p['httponly']);
    }
    session_destroy();
}

/** Verify a plaintext password against the currently logged-in user (re-auth
 *  gate for destructive actions like deletes). */
function verify_current_password(string $password): bool
{
    $u = current_user();
    if (!$u || $password === '') return false;
    return password_verify($password, $u['password_hash']);
}

/** Bump auth_version so any other active sessions for this user are invalidated. */
function bump_auth_version(int $userId): void
{
    q("UPDATE users SET auth_version = auth_version + 1 WHERE id = ?", [$userId]);
    if (($_SESSION['user_id'] ?? null) == $userId) {
        $_SESSION['auth_version'] = (int)fetch_col("SELECT auth_version FROM users WHERE id=?", [$userId]);
    }
}

/* ===================================================================
 *  Remember-me (selector / validator cookie)
 * =================================================================== */

function issue_remember_token(int $userId): void
{
    $days = (int)setting('remember_me_days', 30);
    $selector  = bin2hex(random_bytes(12));   // 24 chars
    $validator = bin2hex(random_bytes(32));
    $hash = hash('sha256', $validator);
    $exp  = date('Y-m-d H:i:s', time() + $days * 86400);
    q("INSERT INTO auth_tokens (user_id, selector, validator_hash, expires_at) VALUES (?,?,?,?)",
      [$userId, $selector, $hash, $exp]);
    $https = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off');
    setcookie(REMEMBER_COOKIE, $selector . ':' . $validator, [
        'expires'  => time() + $days * 86400,
        'path'     => '/',
        'secure'   => $https,
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
}

function try_remember_login(): void
{
    if (empty($_COOKIE[REMEMBER_COOKIE])) return;
    [$selector, $validator] = array_pad(explode(':', $_COOKIE[REMEMBER_COOKIE], 2), 2, '');
    if ($selector === '' || $validator === '') { clear_remember_token(); return; }

    $row = fetch_one("SELECT * FROM auth_tokens WHERE selector = ?", [$selector]);
    if (!$row || strtotime($row['expires_at']) < time()) { clear_remember_token(); return; }
    if (!hash_equals($row['validator_hash'], hash('sha256', $validator))) { clear_remember_token(); return; }

    $user = fetch_one("SELECT * FROM users WHERE id = ? AND is_active = 1", [$row['user_id']]);
    if (!$user) { clear_remember_token(); return; }

    // Valid — establish session and rotate the token
    session_regenerate_id(true);
    $_SESSION['user_id']        = (int)$user['id'];
    $_SESSION['auth_version']   = (int)$user['auth_version'];
    $_SESSION['_created']       = time();
    $_SESSION['_last_activity'] = time();
    q("DELETE FROM auth_tokens WHERE id = ?", [$row['id']]);
    issue_remember_token((int)$user['id']);
    q("UPDATE users SET last_login_at = NOW(), last_activity = NOW() WHERE id = ?", [$user['id']]);
}

function clear_remember_token(): void
{
    if (!empty($_COOKIE[REMEMBER_COOKIE])) {
        $selector = explode(':', $_COOKIE[REMEMBER_COOKIE], 2)[0];
        if ($selector) q("DELETE FROM auth_tokens WHERE selector = ?", [$selector]);
    }
    setcookie(REMEMBER_COOKIE, '', time() - 42000, '/');
    unset($_COOKIE[REMEMBER_COOKIE]);
}

/* ===================================================================
 *  Password reset
 * =================================================================== */

/** Create a reset token for an email; returns "selector:token" or null. */
function create_password_reset(string $email): ?string
{
    $u = fetch_one("SELECT * FROM users WHERE email = ? AND is_active = 1", [strtolower(trim($email))]);
    if (!$u) return null;
    $selector = bin2hex(random_bytes(12));
    $token    = bin2hex(random_bytes(32));
    $exp = date('Y-m-d H:i:s', time() + 3600);   // 1 hour
    q("DELETE FROM password_resets WHERE user_id = ?", [$u['id']]);
    q("INSERT INTO password_resets (user_id, selector, token_hash, expires_at) VALUES (?,?,?,?)",
      [$u['id'], $selector, hash('sha256', $token), $exp]);
    return $selector . ':' . $token;
}

/** Admin-initiated reset: create a token for a user id. Returns "selector:token" or null. */
function create_password_reset_for_user(int $userId): ?string
{
    $u = fetch_one("SELECT id FROM users WHERE id = ? AND is_active = 1", [$userId]);
    if (!$u) return null;
    $selector = bin2hex(random_bytes(12));
    $token    = bin2hex(random_bytes(32));
    $exp = date('Y-m-d H:i:s', time() + 3600);   // 1 hour
    q("DELETE FROM password_resets WHERE user_id = ?", [$userId]);
    q("INSERT INTO password_resets (user_id, selector, token_hash, expires_at) VALUES (?,?,?,?)",
      [$userId, $selector, hash('sha256', $token), $exp]);
    return $selector . ':' . $token;
}

/** Build the absolute reset-link URL for a "selector:token" string. */
function reset_link_url(string $combined): string
{
    $scheme = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host   = $_SERVER['HTTP_HOST'] ?? 'localhost';
    return $scheme . '://' . $host . url('auth/reset_password.php') . '?token=' . urlencode($combined);
}

/** Return the reset row if the combined token is valid & unused, else null. */
function find_valid_reset(string $combined): ?array
{
    [$sel, $tok] = array_pad(explode(':', $combined, 2), 2, '');
    if ($sel === '' || $tok === '') return null;
    $r = fetch_one(
        "SELECT * FROM password_resets WHERE selector = ? AND used_at IS NULL AND expires_at > NOW()",
        [$sel]);
    if (!$r) return null;
    if (!hash_equals($r['token_hash'], hash('sha256', $tok))) return null;
    return $r;
}

/** Apply a new password for a validated reset row. */
function complete_password_reset(array $reset, string $newPassword): void
{
    q("UPDATE users SET password_hash = ?, failed_attempts = 0, locked_until = NULL WHERE id = ?",
      [password_hash($newPassword, PASSWORD_DEFAULT), $reset['user_id']]);
    q("UPDATE password_resets SET used_at = NOW() WHERE id = ?", [$reset['id']]);
    q("DELETE FROM auth_tokens WHERE user_id = ?", [$reset['user_id']]);   // revoke remember-me
    bump_auth_version((int)$reset['user_id']);                              // invalidate sessions
}

/* ===================================================================
 *  Post-login destination by role
 * =================================================================== */
function home_for_current(): string
{
    if (is_super_admin())  return 'admin/dashboard.php';
    if (is_hr())           return 'hr/dashboard.php';
    if (is_team_leader())  return 'tl/dashboard.php';
    return 'employee/dashboard.php';
}
