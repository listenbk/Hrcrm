<?php
/**
 * Renders a professional RG Realty salary slip as a standalone HTML page.
 * Used by admin/salary_slip.php and employee/salary_slip.php.
 * "Download PDF" is provided via the browser Print → Save as PDF button,
 * so no external PDF library is required on the host. (Drop in Dompdf later
 * if a fully server-side PDF is desired — see README.)
 */
function render_salary_slip(int $payrollId): void
{
    $p = fetch_one(
      "SELECT p.*, e.full_name,e.emp_code,e.designation_id,e.department_id,e.bank_account,e.bank_name,
              d.name AS dept_name, ds.name AS desig_name
       FROM payroll p JOIN employees e ON e.id=p.employee_id
       LEFT JOIN departments d ON d.id=e.department_id
       LEFT JOIN designations ds ON ds.id=e.designation_id
       WHERE p.id=?", [$payrollId]);
    if (!$p) { http_response_code(404); echo 'Slip not found.'; return; }

    $items = fetch_all("SELECT * FROM payroll_items WHERE payroll_id=? ORDER BY type DESC,id",[$payrollId]);
    $earn = array_values(array_filter($items, fn($i)=>$i['type']==='earning'));
    $ded  = array_values(array_filter($items, fn($i)=>$i['type']==='deduction'));
    // Overtime detail for this payroll's month (paid against this payroll, or approved)
    $otStart = $p['pay_month'].'-01'; $otEnd = date('Y-m-t', strtotime($otStart));
    $otRows = fetch_all(
        "SELECT * FROM overtime WHERE employee_id=? AND ot_date BETWEEN ? AND ?
           AND (payroll_id=? OR (status IN ('Approved','Partially Approved') AND payroll_id IS NULL))",
        [$p['employee_id'], $otStart, $otEnd, $payrollId]);
    $otHours = array_sum(array_map(fn($r)=>(float)$r['approved_hours'], $otRows));
    $otAmount = array_sum(array_map(fn($r)=>(float)$r['amount'], $otRows));
    $otRate = $otRows ? (float)$otRows[0]['hourly_rate'] : 0;
    $otMult = $otRows ? (float)$otRows[0]['multiplier'] : 0;
    $company = setting('company_name','RG Realty');
    $logo = setting('company_logo','');
    $addr = setting('company_address','');
    $status = $p['status'];
    ?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Salary Slip · <?= e($p['full_name']) ?> · <?= e($p['pay_month']) ?></title>
<style>
body{font-family:'Segoe UI',Arial,sans-serif;background:#eef2f6;margin:0;color:#0f172a;font-size:13px}
.wrap{max-width:800px;margin:24px auto;background:#fff;border:1px solid #e2e8f0}
.head{display:flex;justify-content:space-between;align-items:center;padding:24px 28px;border-bottom:3px solid #0f766e}
.brand{display:flex;align-items:center;gap:14px}
.logo{width:54px;height:54px;border-radius:10px;background:#0f766e;color:#fff;display:grid;place-items:center;font-weight:800;font-size:22px}
.brand h1{margin:0;font-size:22px;color:#0f766e}
.brand .addr{color:#64748b;font-size:12px}
.title{text-align:right}.title h2{margin:0;font-size:16px}.title .mon{color:#64748b}
.meta{display:grid;grid-template-columns:1fr 1fr;gap:0;padding:18px 28px;background:#f8fafc}
.meta div{padding:5px 0;font-size:12.5px}.meta b{display:inline-block;min-width:130px;color:#64748b;font-weight:600}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:0}
table{width:100%;border-collapse:collapse}
th,td{padding:9px 28px;text-align:left;border-bottom:1px solid #eef2f6;font-size:12.5px}
th{background:#0f766e;color:#fff;font-size:12px}
td.amt{text-align:right;font-variant-numeric:tabular-nums}
.tot{font-weight:800;background:#f1f5f9}
.net{padding:18px 28px;background:#0f766e;color:#fff;display:flex;justify-content:space-between;align-items:center}
.net .big{font-size:24px;font-weight:800}
.summary{padding:14px 28px;color:#475569;font-size:12px;border-bottom:1px solid #eef2f6}
.foot{display:flex;justify-content:space-between;padding:38px 28px 24px}
.sign{text-align:center;color:#64748b;font-size:12px}.sign .line{border-top:1px solid #94a3b8;width:170px;margin-bottom:6px}
.badge{padding:3px 10px;border-radius:20px;font-size:11px;font-weight:700;color:#fff;background:<?= $status==='Paid'?'#16a34a':($status==='On Hold'?'#dc2626':'#f59e0b') ?>}
.toolbar{max-width:800px;margin:12px auto;text-align:right}
.btn{display:inline-block;padding:9px 16px;background:#0f766e;color:#fff;border:0;border-radius:8px;cursor:pointer;font-weight:600;text-decoration:none}
.btn.o{background:#fff;color:#0f766e;border:1px solid #cbd5e1}
@media print{.toolbar{display:none}body{background:#fff}.wrap{border:0;margin:0}}
</style></head><body>
<div class="toolbar">
  <a class="btn o" href="javascript:history.back()">← Back</a>
  <button class="btn" onclick="window.print()">🖨️ Print / Save as PDF</button>
</div>
<div class="wrap">
  <div class="head">
    <div class="brand">
      <?php if($logo): ?><img src="<?= url('uploads/'.$logo) ?>" style="width:54px;height:54px;object-fit:contain"><?php else: ?><div class="logo">RG</div><?php endif; ?>
      <div><h1><?= e($company) ?></h1><div class="addr"><?= e($addr) ?></div></div>
    </div>
    <div class="title"><h2>SALARY SLIP</h2><div class="mon"><?= fmt_date($p['pay_month'].'-01','F Y') ?></div>
      <div style="margin-top:6px"><span class="badge"><?= e($status) ?></span></div></div>
  </div>

  <div class="meta">
    <div><b>Employee</b> <?= e($p['full_name']) ?></div>
    <div><b>Employee ID</b> <?= e($p['emp_code']) ?></div>
    <div><b>Designation</b> <?= e($p['desig_name'] ?: '—') ?></div>
    <div><b>Department</b> <?= e($p['dept_name'] ?: '—') ?></div>
    <div><b>Bank A/C</b> <?= e($p['bank_account'] ?: '—') ?></div>
    <div><b>Pay Date</b> <?= $p['payment_date']?fmt_date($p['payment_date']):'—' ?></div>
  </div>

  <div class="summary">
    <b>Attendance:</b> Present <?= $p['present_days'] ?> · Absent <?= $p['absent_days'] ?> · Leave <?= $p['leave_days'] ?> · Late <?= $p['late_count'] ?> · Working Days <?= $p['working_days'] ?>
  </div>
  <?php if ($otHours > 0): ?>
  <div class="summary">
    <b>Overtime:</b> <?= rtrim(rtrim(number_format($otHours,2),'0'),'.') ?> Hours ·
    Rate <?= money($otRate) ?>/hr · Multiplier <?= rtrim(rtrim(number_format($otMult,2),'0'),'.') ?>× ·
    Earnings <?= money($otAmount) ?>
  </div>
  <?php endif; ?>

  <div class="cols">
    <table><thead><tr><th>Earnings</th><th class="amt" style="text-align:right;color:#fff">Amount</th></tr></thead><tbody>
      <?php foreach($earn as $it): ?><tr><td><?= e($it['label']) ?></td><td class="amt"><?= money($it['amount'],false) ?></td></tr><?php endforeach; ?>
      <tr class="tot"><td>Gross Earnings</td><td class="amt"><?= money($p['gross_earnings'],false) ?></td></tr>
    </tbody></table>
    <table><thead><tr><th>Deductions</th><th class="amt" style="text-align:right;color:#fff">Amount</th></tr></thead><tbody>
      <?php foreach($ded as $it): ?><tr><td><?= e($it['label']) ?></td><td class="amt"><?= money($it['amount'],false) ?></td></tr><?php endforeach;
      if(!$ded): ?><tr><td colspan="2">No deductions</td></tr><?php endif; ?>
      <tr class="tot"><td>Total Deductions</td><td class="amt"><?= money($p['total_deductions'],false) ?></td></tr>
    </tbody></table>
  </div>

  <div class="net"><div>NET PAYABLE SALARY</div><div class="big"><?= money($p['net_salary']) ?></div></div>

  <div class="foot">
    <div class="sign"><div class="line"></div>Employee Signature</div>
    <div class="sign"><div class="line"></div>Authorized Signatory<br><?= e($company) ?></div>
  </div>
  <div style="text-align:center;color:#94a3b8;font-size:11px;padding:0 0 18px">This is a computer-generated salary slip.</div>
</div>
</body></html>
<?php
}
