<?php
/**
 * Renders a complete, printable Employee Report — personal details,
 * attendance, leave, overtime, assets and advances — as a standalone HTML
 * page. "Download PDF" is via the browser Print → Save as PDF button, same
 * pattern as salary slips, so no external PDF library is required.
 */
if (!function_exists('erl_pill')) {
    function erl_pill(string $s): string {
        $m=['Approved'=>'#16a34a','Pending'=>'#f59e0b','Rejected'=>'#dc2626','Completed'=>'#16a34a','Active'=>'#3b82f6'];
        $c = $m[$s] ?? '#64748b';
        return '<span style="padding:2px 9px;border-radius:12px;font-size:11px;font-weight:700;color:#fff;background:'.$c.'">'.e($s).'</span>';
    }
}

function render_employee_report(int $employeeId): void
{
    $e = fetch_one(
      "SELECT emp.*, d.name AS dept_name, ds.name AS desig_name, sh.name AS shift_name,
              rm.name AS reporting_manager_name, tl.name AS team_leader_name
       FROM employees emp
       LEFT JOIN departments d ON d.id=emp.department_id
       LEFT JOIN designations ds ON ds.id=emp.designation_id
       LEFT JOIN shifts sh ON sh.id=emp.shift_id
       LEFT JOIN users rm ON rm.id=emp.reporting_manager_id
       LEFT JOIN users tl ON tl.id=emp.team_leader_id
       WHERE emp.id=?", [$employeeId]);
    if (!$e) { http_response_code(404); echo 'Employee not found.'; return; }

    $today = date('Y-m-d');
    $yearStart = date('Y-01-01');

    // Attendance — last 6 complete months, monthly totals.
    $attMonths = [];
    for ($i = 5; $i >= 0; $i--) {
        $ym = date('Y-m', strtotime("first day of -$i month"));
        $s = payroll_attendance_summary($employeeId, $ym);
        $attMonths[] = ['ym' => $ym, 'label' => fmt_date($ym.'-01','M Y')] + $s;
    }

    // Leave — this year's balance by type, plus recent requests.
    $leaveBal = fetch_all(
      "SELECT lt.name, lt.annual_quota, COALESCE(lb.used,0) AS used
       FROM leave_types lt
       LEFT JOIN leave_balances lb ON lb.leave_type_id=lt.id AND lb.employee_id=? AND lb.year=?
       WHERE lt.is_active=1 ORDER BY lt.name", [$employeeId, date('Y')]);
    $recentLeaves = fetch_all(
      "SELECT lr.*, lt.name AS type_name FROM leave_requests lr JOIN leave_types lt ON lt.id=lr.leave_type_id
       WHERE lr.employee_id=? ORDER BY lr.start_date DESC LIMIT 10", [$employeeId]);

    // Overtime — this year total + recent records.
    $otTotal = fetch_one(
      "SELECT COALESCE(SUM(actual_hours),0) actual_hours, COALESCE(SUM(amount),0) amount
       FROM overtime WHERE employee_id=? AND ot_date BETWEEN ? AND ?", [$employeeId, $yearStart, $today]);
    $recentOt = fetch_all(
      "SELECT * FROM overtime WHERE employee_id=? ORDER BY ot_date DESC LIMIT 10", [$employeeId]);

    // Assets currently assigned.
    $assets = fetch_all(
      "SELECT asset_code, asset_type, brand, model, allocation_date FROM assets
       WHERE assigned_employee_id=? AND status='Allocated' ORDER BY allocation_date DESC", [$employeeId]);

    // Advances / EMI outstanding.
    $advances = fetch_all(
      "SELECT advance_type, total_amount, emi_amount, recovered_amount, balance_amount, status
       FROM employee_advances WHERE employee_id=? ORDER BY created_at DESC", [$employeeId]);

    $company = setting('company_name','RG Realty');
    $logo = setting('company_logo','');
    $addr = setting('company_address','');
    ?>
<!DOCTYPE html><html lang="en"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Employee Report · <?= e($e['full_name']) ?></title>
<style>
body{font-family:'Segoe UI',Arial,sans-serif;background:#eef2f6;margin:0;color:#0f172a;font-size:13px}
.wrap{max-width:900px;margin:24px auto;background:#fff;border:1px solid #e2e8f0}
.head{display:flex;justify-content:space-between;align-items:center;padding:24px 28px;border-bottom:3px solid #0f766e}
.brand{display:flex;align-items:center;gap:14px}
.logo{width:54px;height:54px;border-radius:10px;background:#0f766e;color:#fff;display:grid;place-items:center;font-weight:800;font-size:22px}
.brand h1{margin:0;font-size:22px;color:#0f766e}
.brand .addr{color:#64748b;font-size:12px}
.title{text-align:right}.title h2{margin:0;font-size:16px}.title .mon{color:#64748b}
.sec{padding:18px 28px;border-bottom:1px solid #eef2f6}
.sec h3{margin:0 0 12px;font-size:14px;color:#0f766e;text-transform:uppercase;letter-spacing:.03em}
.meta{display:grid;grid-template-columns:1fr 1fr;gap:0}
.meta div{padding:5px 0;font-size:12.5px}.meta b{display:inline-block;min-width:150px;color:#64748b;font-weight:600}
table{width:100%;border-collapse:collapse;margin-top:4px}
th,td{padding:8px 10px;text-align:left;border-bottom:1px solid #eef2f6;font-size:12px}
th{background:#f8fafc;color:#64748b;font-weight:700;text-transform:uppercase;font-size:10.5px}
td.num,th.num{text-align:right}
.empty-row{color:#94a3b8;padding:10px 0;font-size:12px}
.toolbar{max-width:900px;margin:12px auto;text-align:right}
.btn{display:inline-block;padding:9px 16px;background:#0f766e;color:#fff;border:0;border-radius:8px;cursor:pointer;font-weight:600;text-decoration:none}
.btn.o{background:#fff;color:#0f766e;border:1px solid #cbd5e1}
@media print{.toolbar{display:none}body{background:#fff}.wrap{border:0;margin:0}.sec{break-inside:avoid}}
</style></head><body>
<div class="toolbar">
  <a class="btn o" href="javascript:history.back()">← Back</a>
  <button class="btn" onclick="window.print()">🖨️ Print / Save as PDF</button>
</div>
<div class="wrap">
  <div class="head">
    <div class="brand">
      <?php if($logo): ?><img src="<?= url('uploads/'.$logo) ?>" style="width:54px;height:54px;object-fit:contain"><?php else: ?><div class="logo">RG</div><?php endif; ?>
      <div><h1><?= e($company) ?></h1><div class="addr"><?= e($addr) ?></div></div>
    </div>
    <div class="title"><h2>EMPLOYEE REPORT</h2><div class="mon">Generated <?= fmt_date($today) ?></div></div>
  </div>

  <div class="sec">
    <h3>Personal &amp; Employment Details</h3>
    <div class="meta">
      <div><b>Full Name</b> <?= e($e['full_name']) ?></div>
      <div><b>Employee ID</b> <?= e($e['emp_code']) ?></div>
      <div><b>Department</b> <?= e($e['dept_name'] ?: '—') ?></div>
      <div><b>Designation</b> <?= e($e['desig_name'] ?: '—') ?></div>
      <div><b>Mobile</b> <?= e($e['mobile'] ?: '—') ?></div>
      <div><b>Email</b> <?= e($e['email'] ?: '—') ?></div>
      <div><b>Date of Birth</b> <?= $e['dob']?fmt_date($e['dob']):'—' ?></div>
      <div><b>Joining Date</b> <?= $e['joining_date']?fmt_date($e['joining_date']):'—' ?></div>
      <div><b>Employment Type</b> <?= e($e['employment_type'] ?: '—') ?></div>
      <div><b>Status</b> <?= e($e['status']) ?></div>
      <div><b>Shift</b> <?= e($e['shift_name'] ?: 'Company default') ?></div>
      <div><b>Office / Location</b> <?= e($e['office_location'] ?: '—') ?></div>
      <div><b>Reporting Manager</b> <?= e($e['reporting_manager_name'] ?: '—') ?></div>
      <div><b>Assigned Team Leader</b> <?= e($e['team_leader_name'] ?: '—') ?></div>
      <div><b>Bank A/C</b> <?= e($e['bank_account'] ?: '—') ?></div>
      <div><b>Basic Salary</b> <?= money($e['basic_salary']) ?></div>
      <div><b>Emergency Contact</b> <?= e($e['emergency_name'] ?: '—') ?><?= $e['emergency_phone']?' ('.e($e['emergency_phone']).')':'' ?></div>
      <div><b>Address</b> <?= e($e['address'] ?: '—') ?></div>
    </div>
  </div>

  <div class="sec">
    <h3>Attendance — Last 6 Months</h3>
    <table><thead><tr><th>Month</th><th class="num">Present</th><th class="num">Absent</th><th class="num">Leave</th><th class="num">Late</th><th class="num">Working Days</th></tr></thead>
    <tbody><?php foreach($attMonths as $m): ?>
      <tr><td><?= e($m['label']) ?></td><td class="num"><?= $m['present'] ?></td><td class="num"><?= $m['absent'] ?></td>
        <td class="num"><?= $m['leavePaid']+$m['leaveUnpaid'] ?></td><td class="num"><?= $m['late'] ?></td><td class="num"><?= $m['workingDays'] ?></td></tr>
    <?php endforeach; ?></tbody></table>
  </div>

  <div class="sec">
    <h3>Check-In / Check-Out Location Log (latest 10)</h3>
    <?php $geoLog = fetch_all(
        "SELECT a.att_date, a.check_in, a.check_out, a.checkin_geofence_status, a.checkin_distance_m,
                a.checkin_accuracy, a.checkout_geofence_status, a.checkout_distance_m, a.checkout_accuracy, g.location_name
         FROM attendance a LEFT JOIN geofence_locations g ON g.id=a.geofence_location_id
         WHERE a.employee_id=? AND (a.checkin_geofence_status IS NOT NULL OR a.checkout_geofence_status IS NOT NULL)
         ORDER BY a.att_date DESC LIMIT 10", [$employeeId]); ?>
    <?php if ($geoLog): ?>
    <table><thead><tr><th>Date</th><th>Site</th><th>Check-In</th><th class="num">Dist.</th><th>Check-Out</th><th class="num">Dist.</th></tr></thead>
    <tbody><?php foreach($geoLog as $g): ?>
      <tr><td><?= fmt_date($g['att_date']) ?></td><td><?= e($g['location_name'] ?: '—') ?></td>
        <td><?= e($g['checkin_geofence_status'] ?: '—') ?><?= $g['checkin_accuracy']!==null?' (±'.round($g['checkin_accuracy']).'m)':'' ?></td>
        <td class="num"><?= $g['checkin_distance_m']!==null?(int)$g['checkin_distance_m'].' m':'—' ?></td>
        <td><?= e($g['checkout_geofence_status'] ?: '—') ?><?= $g['checkout_accuracy']!==null?' (±'.round($g['checkout_accuracy']).'m)':'' ?></td>
        <td class="num"><?= $g['checkout_distance_m']!==null?(int)$g['checkout_distance_m'].' m':'—' ?></td></tr>
    <?php endforeach; ?></tbody></table>
    <?php else: ?><div class="empty-row">No location-verified attendance recorded.</div><?php endif; ?>
  </div>

  <div class="sec">
    <h3>Leave — <?= date('Y') ?> Balance</h3>
    <table><thead><tr><th>Leave Type</th><th class="num">Entitlement</th><th class="num">Used</th><th class="num">Remaining</th></tr></thead>
    <tbody><?php foreach($leaveBal as $lb): $rem=(float)$lb['annual_quota']-(float)$lb['used']; ?>
      <tr><td><?= e($lb['name']) ?></td><td class="num"><?= rtrim(rtrim(number_format($lb['annual_quota'],1),'0'),'.') ?></td>
        <td class="num"><?= rtrim(rtrim(number_format($lb['used'],1),'0'),'.') ?></td><td class="num"><?= rtrim(rtrim(number_format($rem,1),'0'),'.') ?></td></tr>
    <?php endforeach; if(!$leaveBal): ?><tr><td colspan="4" class="empty-row">No leave types configured.</td></tr><?php endif; ?></tbody></table>
    <?php if($recentLeaves): ?>
    <table style="margin-top:14px"><thead><tr><th>Recent Requests</th><th>Dates</th><th class="num">Days</th><th>Status</th></tr></thead>
    <tbody><?php foreach($recentLeaves as $lr): ?>
      <tr><td><?= e($lr['type_name']) ?></td><td><?= fmt_date($lr['start_date']) ?> → <?= fmt_date($lr['end_date']) ?></td>
        <td class="num"><?= e($lr['total_days']) ?></td><td><?= erl_pill($lr['status']) ?></td></tr>
    <?php endforeach; ?></tbody></table>
    <?php endif; ?>
  </div>

  <div class="sec">
    <h3>Overtime — <?= date('Y') ?></h3>
    <p style="margin:0 0 10px"><b><?= rtrim(rtrim(number_format($otTotal['actual_hours'],2),'0'),'.') ?> hours</b> recorded this year ·
      <b><?= money($otTotal['amount']) ?></b> approved earnings.</p>
    <?php if($recentOt): ?>
    <table><thead><tr><th>Date</th><th>Day Type</th><th class="num">Actual</th><th class="num">Approved</th><th class="num">Amount</th><th>Status</th></tr></thead>
    <tbody><?php foreach($recentOt as $o): ?>
      <tr><td><?= fmt_date($o['ot_date']) ?></td><td><?= e(ot_day_type_label($o['day_type'])) ?></td>
        <td class="num"><?= rtrim(rtrim(number_format($o['actual_hours'],2),'0'),'.') ?>h</td>
        <td class="num"><?= $o['approved_hours']>0?rtrim(rtrim(number_format($o['approved_hours'],2),'0'),'.').'h':'—' ?></td>
        <td class="num"><?= $o['amount']>0?money($o['amount']):'—' ?></td><td><?= erl_pill($o['status']) ?></td></tr>
    <?php endforeach; ?></tbody></table>
    <?php else: ?><div class="empty-row">No overtime records.</div><?php endif; ?>
  </div>

  <div class="sec">
    <h3>Assigned Assets</h3>
    <?php if($assets): ?>
    <table><thead><tr><th>Asset ID</th><th>Type</th><th>Brand / Model</th><th>Allocated</th></tr></thead>
    <tbody><?php foreach($assets as $a): ?>
      <tr><td><?= e($a['asset_code']) ?></td><td><?= e($a['asset_type']) ?></td>
        <td><?= e(trim($a['brand'].' '.$a['model'])) ?: '—' ?></td><td><?= $a['allocation_date']?fmt_date($a['allocation_date']):'—' ?></td></tr>
    <?php endforeach; ?></tbody></table>
    <?php else: ?><div class="empty-row">No assets currently assigned.</div><?php endif; ?>
  </div>

  <div class="sec" style="border-bottom:0">
    <h3>Advances / EMI</h3>
    <?php if($advances): ?>
    <table><thead><tr><th>Type</th><th class="num">Total</th><th class="num">EMI</th><th class="num">Recovered</th><th class="num">Balance</th><th>Status</th></tr></thead>
    <tbody><?php foreach($advances as $ad): ?>
      <tr><td><?= e($ad['advance_type']) ?></td><td class="num"><?= money($ad['total_amount'],false) ?></td>
        <td class="num"><?= money($ad['emi_amount'],false) ?></td><td class="num"><?= money($ad['recovered_amount'],false) ?></td>
        <td class="num"><?= money($ad['balance_amount'],false) ?></td><td><?= erl_pill($ad['status']) ?></td></tr>
    <?php endforeach; ?></tbody></table>
    <?php else: ?><div class="empty-row">No advances on record.</div><?php endif; ?>
  </div>

  <div style="text-align:center;color:#94a3b8;font-size:11px;padding:0 0 18px">This is a computer-generated employee report.</div>
</div>
</body></html>
<?php
}
