<?php
/**
 * Shared helpers: escaping, formatting, validation, uploads, notifications.
 */

/** HTML-escape output (XSS protection). */
function e($value): string
{
    return htmlspecialchars((string)($value ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

/** Build a URL relative to the app base. */
function url(string $path = ''): string
{
    return BASE_URL . '/' . ltrim($path, '/');
}

/** Redirect helper. */
function redirect(string $path): void
{
    header('Location: ' . (str_starts_with($path, 'http') ? $path : url($path)));
    exit;
}

/** Indian-format currency:  ₹1,25,000.00 */
function money($amount, bool $withSymbol = true): string
{
    $symbol = $withSymbol ? setting('currency_symbol', '₹') : '';
    $amount = (float)$amount;
    $neg = $amount < 0 ? '-' : '';
    $amount = abs($amount);
    $num = number_format($amount, 2, '.', '');
    [$int, $dec] = explode('.', $num);
    // Indian grouping: last 3 digits, then groups of 2
    $lastThree = substr($int, -3);
    $rest = substr($int, 0, -3);
    if ($rest !== '') {
        $rest = preg_replace('/\B(?=(\d{2})+(?!\d))/', ',', $rest);
        $formatted = $rest . ',' . $lastThree;
    } else {
        $formatted = $lastThree;
    }
    return $neg . $symbol . $formatted . '.' . $dec;
}

/** Format a date safely. */
function fmt_date(?string $date, string $format = 'd M Y'): string
{
    if (empty($date) || $date === '0000-00-00' || str_starts_with($date, '0000')) {
        return '—';
    }
    $ts = strtotime($date);
    return $ts ? date($format, $ts) : '—';
}

/** Minutes → "Xh Ym" */
function fmt_hm(int $minutes): string
{
    if ($minutes <= 0) return '0h 0m';
    return intdiv($minutes, 60) . 'h ' . ($minutes % 60) . 'm';
}

/** Read a POST/GET value with default. */
function param(string $key, $default = null, string $method = 'REQUEST')
{
    $src = $method === 'POST' ? $_POST : ($method === 'GET' ? $_GET : $_REQUEST);
    return array_key_exists($key, $src) ? $src[$key] : $default;
}

/** Client IP address. */
function client_ip(): string
{
    foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'REMOTE_ADDR'] as $k) {
        if (!empty($_SERVER[$k])) {
            $ip = explode(',', $_SERVER[$k])[0];
            return substr(trim($ip), 0, 45);
        }
    }
    return '0.0.0.0';
}

/** User agent / device info. */
function device_info(): string
{
    return substr($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown', 0, 255);
}

/** Validate an email. */
function valid_email(string $email): bool
{
    return (bool)filter_var($email, FILTER_VALIDATE_EMAIL);
}

/** Slugify a label into a machine key. */
function slugify(string $text): string
{
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9]+/', '_', $text);
    return trim($text, '_');
}

/**
 * Handle a secure file upload. Returns stored relative path or null.
 * @param array  $file   entry from $_FILES
 * @param string $sub    subfolder inside /uploads
 * @param array  $allow  allowed extensions
 */
function handle_upload(array $file, string $sub, array $allow = ['jpg','jpeg','png','gif','pdf','doc','docx'], int $maxBytes = 5242880): ?string
{
    if (!isset($file['tmp_name']) || $file['error'] !== UPLOAD_ERR_OK) {
        return null;
    }
    if ($file['size'] > $maxBytes) {
        return null;
    }
    $ext = strtolower(pathinfo($file['name'], PATHINFO_EXTENSION));
    if (!in_array($ext, $allow, true)) {
        return null;
    }
    $dir = UPLOAD_DIR . '/' . trim($sub, '/');
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
    }
    $name = bin2hex(random_bytes(8)) . '_' . time() . '.' . $ext;
    $dest = $dir . '/' . $name;
    if (!move_uploaded_file($file['tmp_name'], $dest)) {
        return null;
    }
    return trim($sub, '/') . '/' . $name;
}

/** Create an in-app notification. */
function notify(int $userId, string $type, string $title, string $body = '', string $link = ''): void
{
    if ($userId <= 0) return;
    q("INSERT INTO notifications (user_id,type,title,body,link) VALUES (?,?,?,?,?)",
      [$userId, $type, $title, $body, $link]);
}

/** Notify all users whose role slug is in the given list. */
function notify_roles(array $roleSlugs, string $type, string $title, string $body = '', string $link = ''): void
{
    if (!$roleSlugs) return;
    $in = implode(',', array_fill(0, count($roleSlugs), '?'));
    $rows = fetch_all(
        "SELECT u.id FROM users u JOIN roles r ON r.id=u.role_id
         WHERE r.slug IN ($in) AND u.is_active=1", $roleSlugs);
    foreach ($rows as $a) {
        notify((int)$a['id'], $type, $title, $body, $link);
    }
}

/** Notify all admins / super admins. */
function notify_admins(string $type, string $title, string $body = '', string $link = ''): void
{
    notify_roles(['super_admin', 'hr_admin'], $type, $title, $body, $link);
}

/** Notify everyone who can approve leave: Team Leaders, HR and Managers. */
function notify_leave_approvers(string $type, string $title, string $body = '', string $link = ''): void
{
    notify_roles(['super_admin', 'hr_admin', 'team_leader'], $type, $title, $body, $link);
}

/** The employee's assigned Team Leader (users.id), or null if none set / not a valid active TL. */
function emp_team_leader_user_id(int $employeeId): ?int
{
    $uid = fetch_col(
        "SELECT u.id FROM employees e
         JOIN users u ON u.id = e.team_leader_id
         JOIN roles r ON r.id = u.role_id
         WHERE e.id = ? AND r.slug = 'team_leader' AND u.is_active = 1",
        [$employeeId]);
    return $uid !== false ? (int)$uid : null;
}

/**
 * Route an employee's reporting/approval request directly to their assigned
 * Team Leader (in addition to any broader role broadcast already sent).
 * No-op if the employee has no assigned Team Leader. Consistent single point
 * used by leave, overtime, daily reports and asset-return requests.
 */
function notify_employee_tl(int $employeeId, string $type, string $title, string $body = '', string $link = ''): void
{
    $tlUserId = emp_team_leader_user_id($employeeId);
    if ($tlUserId) notify($tlUserId, $type, $title, $body, $link);
}

/** Paginate helper: returns [limit, offset, page]. */
function paginate(int $perPage = 20): array
{
    $page = max(1, (int)param('page', 1));
    return [$perPage, ($page - 1) * $perPage, $page];
}

/**
 * Ensure an HR / Team-Leader user has a self-attendance employee profile.
 * These are flagged is_staff=1 so they can check in/out like employees while
 * staying out of the main employee roster and payroll runs. Returns the row.
 */
function ensure_staff_employee(array $user): ?array
{
    if (!in_array($user['role_slug'] ?? '', ['hr_admin', 'team_leader'], true)) {
        return null;
    }
    $emp = fetch_one("SELECT * FROM employees WHERE user_id = ?", [$user['id']]);
    if ($emp) return $emp;
    $code = 'STF' . str_pad((string)$user['id'], 4, '0', STR_PAD_LEFT);
    q("INSERT INTO employees (user_id, emp_code, full_name, email, joining_date, employment_type, is_staff, status)
       VALUES (?,?,?,?,?, 'Staff', 1, 'Active')",
      [$user['id'], $code, $user['name'], $user['email'] ?? null, date('Y-m-d')]);
    return fetch_one("SELECT * FROM employees WHERE id = ?", [insert_id()]);
}

/**
 * Generate the next employee code, e.g. RG0004.
 * Self-healing: uses the greater of the stored counter and one past the highest
 * existing code for this prefix, so the counter can never drift into a
 * duplicate (which would violate uq_emp_code). Staff codes (STF…) are ignored.
 */
function next_emp_code(): string
{
    $prefix = setting('emp_code_prefix', 'RG');
    $counter = (int)setting('emp_code_next', '1');
    // Highest numeric suffix already used for this prefix.
    $maxUsed = (int)fetch_col(
        "SELECT COALESCE(MAX(CAST(SUBSTRING(emp_code, ?) AS UNSIGNED)), 0)
         FROM employees WHERE emp_code LIKE ?",
        [strlen($prefix) + 1, $prefix . '%']
    );
    $next = max($counter, $maxUsed + 1);
    return $prefix . str_pad((string)$next, 4, '0', STR_PAD_LEFT);
}
