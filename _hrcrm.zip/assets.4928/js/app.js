/* RG Realty CRM — front-end helpers */
(function () {
  // Sidebar toggle (mobile)
  var burger = document.querySelector('.hamburger');
  var sidebar = document.querySelector('.sidebar');
  var backdrop = document.querySelector('.backdrop');
  function closeSb(){ sidebar && sidebar.classList.remove('open'); backdrop && backdrop.classList.remove('show'); }
  if (burger) burger.addEventListener('click', function () {
    sidebar.classList.toggle('open'); backdrop.classList.toggle('show');
  });
  if (backdrop) backdrop.addEventListener('click', closeSb);

  // Generic modal open/close
  document.addEventListener('click', function (e) {
    var openBtn = e.target.closest('[data-modal]');
    if (openBtn) {
      var m = document.getElementById(openBtn.getAttribute('data-modal'));
      if (m) m.classList.add('open');
    }
    if (e.target.matches('.modal-close') || e.target.matches('.modal-overlay')) {
      var ov = e.target.closest('.modal-overlay') || e.target;
      if (ov.classList.contains('modal-overlay')) ov.classList.remove('open');
    }
    if (e.target.closest('[data-close-modal]')) {
      var ov2 = e.target.closest('.modal-overlay'); if (ov2) ov2.classList.remove('open');
    }

    // Show/hide password toggle
    var pwdBtn = e.target.closest('.pwd-toggle');
    if (pwdBtn) {
      var input = pwdBtn.previousElementSibling;
      if (input && input.tagName === 'INPUT') {
        var showing = input.type === 'text';
        input.type = showing ? 'password' : 'text';
        pwdBtn.textContent = showing ? 'Show' : 'Hide';
        pwdBtn.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
      }
    }
  });

  // Confirm dialogs
  document.addEventListener('submit', function (e) {
    var f = e.target;
    if (f.hasAttribute('data-confirm') && !confirm(f.getAttribute('data-confirm'))) {
      e.preventDefault();
    }
  });

  // CSRF token for fetch
  window.CSRF = (document.querySelector('meta[name="csrf-token"]') || {}).content || '';

  // Live clock
  var clock = document.getElementById('liveClock');
  if (clock) {
    setInterval(function () {
      clock.textContent = new Date().toLocaleTimeString('en-IN', { hour12: true });
    }, 1000);
  }

  // Minimum-checkout countdown: enable the Check Out button once the wait passes.
  var coBtn = document.getElementById('checkoutBtn');
  if (coBtn && coBtn.getAttribute('data-unlock')) {
    var remaining = parseInt(coBtn.getAttribute('data-unlock'), 10) || 0;
    var coMsg = document.getElementById('checkoutMsg');
    if (remaining > 0) {
      coBtn.disabled = true;
      var t = setInterval(function () {
        remaining--;
        if (remaining <= 0) {
          clearInterval(t);
          coBtn.disabled = false;
          if (coMsg) { coMsg.textContent = '✅ Checkout is now available'; coMsg.className = 'pill pill-success'; }
        } else if (coMsg) {
          var m = Math.floor(remaining / 60), s = remaining % 60;
          coMsg.textContent = '⏳ Checkout available in ' + m + 'm ' + (s < 10 ? '0' : '') + s + 's';
        }
      }, 1000);
    }
  }
})();

/* Attendance check-in / check-out via fetch (server timestamps) */
/* Browser location, read once per click (never continuous). Resolves {lat,lng,acc}. */
function getAttendancePosition() {
  return new Promise(function (resolve, reject) {
    if (!navigator.geolocation) {
      return reject('Your browser does not support location. Please use a modern browser.');
    }
    navigator.geolocation.getCurrentPosition(
      function (p) {
        resolve({ lat: p.coords.latitude, lng: p.coords.longitude, acc: p.coords.accuracy });
      },
      function (err) {
        reject(err && err.code === 1
          ? 'Location permission is required to mark attendance. Please allow location access and try again.'
          : 'Could not read your location. Check that GPS/location is on and try again.');
      },
      { enableHighAccuracy: true, timeout: 15000, maximumAge: 0 }
    );
  });
}

function attendanceAction(action, btn) {
  btn.disabled = true;
  var orig = btn.innerHTML;
  btn.innerHTML = 'Please wait…';

  var needsGeo = window.GEO_ON && /^(check_in|check_out|ot_check_in|ot_check_out)$/.test(action);
  var geoPromise = needsGeo ? getAttendancePosition() : Promise.resolve(null);

  geoPromise.then(function (pos) {
    var body = 'action=' + encodeURIComponent(action) + '&csrf_token=' + encodeURIComponent(window.CSRF);
    if (pos) {
      body += '&latitude=' + encodeURIComponent(pos.lat) +
              '&longitude=' + encodeURIComponent(pos.lng) +
              '&accuracy=' + encodeURIComponent(pos.acc);
    }
    return fetch(BASE + '/api/attendance.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded', 'X-Requested-With': 'XMLHttpRequest', 'X-CSRF-Token': window.CSRF },
      body: body
    });
  })
    .then(function (r) { return r.json(); })
    .then(function (res) {
      var box = document.getElementById('attMsg');
      if (box) {
        box.className = 'alert ' + (res.ok ? 'alert-success' : 'alert-error');
        box.textContent = res.message;
        box.style.display = 'flex';
      }
      if (res.ok) { setTimeout(function () { location.reload(); }, 900); }
      else { btn.disabled = false; btn.innerHTML = orig; }
    })
    .catch(function (err) {
      btn.disabled = false; btn.innerHTML = orig;
      alert(typeof err === 'string' ? err : 'Network error, please retry.');
    });
}
