# RG Realty HRCRM — Geofenced Attendance (v3)

**Login and every page work from anywhere.** Only attendance actions —
Check-In, Check-Out and Overtime Check-In/Out — are location-checked, and only
while the master switch is ON. Feature ships **OFF**.

## How it works
1. Employee clicks Check-In / Check-Out. The page shows *"Checking your current
   location..."* and the browser reads GPS **once** (only if this employee
   actually needs it — exempt staff are never prompted).
2. Coordinates + accuracy + the fix's timestamp (or the reason there is no fix:
   denied / timeout / unavailable) are POSTed to `api/attendance.php`.
   `maximumAge: 0` forces a fresh reading even when permission was granted
   earlier and the browser shows no popup.
3. PHP decides (`includes/geofence_lib.php`): assigned site → GPS available →
   valid coordinates → reading ≤ 2 min old → accuracy ≤ limit → Haversine
   distance ≤ radius. No IP-location fallback, ever.

## Is a Google Cloud API key needed? — No
- GPS comes from the browser's built-in `navigator.geolocation` (phone GPS /
  Wi-Fi). Distance is computed in PHP with Haversine. Neither uses Google.
- Google's *Geolocation API* estimates position from IP / Wi-Fi lists — that is
  exactly the IP-style fallback this system must **not** use. Do not enable it.
- The attempts card has a plain "📍 Map" link (`google.com/maps?q=lat,lng`):
  free, no key, no script on our pages.
- Only if you later want an **embedded** map (e.g. pick a site by clicking a
  map) you would need: Google Cloud Console → enable **Maps JavaScript API** →
  create an API key → *Application restrictions: Websites* =
  `https://hrcrm.rgrealty.in/*` → *API restrictions*: Maps JavaScript API only →
  set a daily quota/budget alert. Store the key as a setting (e.g.
  `google_maps_key` in the `settings` table, never in JS files committed to
  the repo), and add `https://maps.googleapis.com https://maps.gstatic.com` to
  the Content-Security-Policy in `includes/bootstrap.php` (script-src, img-src,
  connect-src). Not required for attendance.
4. Accepted → the **unchanged** attendance rules run (`do_check_in`,
   `do_check_out`, `ot_session_start/stop`): 10:30–19:00 timing, 30-min
   checkout wait, duplicate prevention, OT after 8 PM, etc.
5. Every checked attempt (accepted and rejected) is logged in
   `geofence_attempts`; rejections also go to Audit Logs.

Auto check-out and auto-absent cron jobs do not use GPS and are unaffected.

## v2 changes
| File | Change |
|---|---|
| `install/migrate_geofence_v2.sql` | **New.** `geofence_attempts` table; OT location columns on `overtime`. Add-only. |
| `includes/geofence_lib.php` | Per-employee pre-check, browser-error reasons, "no site" checked before GPS, stricter coordinate/accuracy validation, attempt log, OT location, spoofing hints, CSV escaping, optional `GEOFENCE_FORCE_OFF`. |
| `api/attendance.php` | Logs accepted + rejected attempts, stores OT location, "Location verified (N m from office)" message. |
| `assets/js/app.js` | Status messages, sends GPS failure reason to the server instead of stopping in the browser, ignores repeat clicks. |
| `templates/header.php` | `window.GEO_ACTIONS` — which actions need GPS for the logged-in user. |
| `templates/footer.php` | `app.js?v=geo3` so browsers load the new script. |
| v3 | Fresh-fix check (`position_ts` / `client_ts`, status **Stale**, optional setting `geofence_max_position_age`, default 120 s); "📍 Map" link on attempts. No DB change. |
| `admin/geofence.php` | Attempts card (rejected / all, accepted-today count, spoof flags), Export Attempts CSV, HR/Team Leader site assignment, exempt list includes staff. |
| `admin/employee_edit.php` | Keeps an assigned site even if it was deactivated; validates the site id. |

Not touched: attendance / overtime / payroll libraries, cron jobs, login, roles,
permissions, all existing data.

## Deployment (Hostinger)
1. **Compare with live first.** In Hostinger File Manager download the live
   copies of the 8 changed files listed above. If any live file differs from
   the copy in `hrcrm_geofence_v2_ROLLBACK.zip` (someone edited it on the
   server), stop and merge before uploading.
2. **Back up**: phpMyAdmin → Export the database; File Manager → compress `hrcrm/`.
3. **Database**: phpMyAdmin → Import `install/migrate_geofence_v2.sql`.
   (Run v1 `migrate_geofence.sql` first only if it was never imported.)
4. **Files**: upload `hrcrm_geofence_attendance_v2.zip` into `hrcrm/` and
   extract, overwriting. (Delete-then-extract per file if File Manager refuses
   to overwrite.)
5. Open `https://hrcrm.rgrealty.in/admin/geofence.php` — the page should load,
   show **Accepted today: 0**, and the **HR / Team Leader attendance sites** card.
6. **Set up while still OFF**:
   - Every active employee → Employee → Edit → Attendance Site (or Exempt).
   - HR / TL → *Create their profiles* (if shown), then assign a site or Exempt.
7. **Pilot**: turn the master switch ON. One person checks in at the site, one
   from home. Confirm accept / reject and the rows in the attempts card.
8. Review attempts for a few days; tune radius (100–150 m) and Max GPS error
   (50–100 m).

## Rollback
- **Instant (no file changes):** Geofence & Sites → untick master switch → Save.
  Attendance works exactly as before, no GPS prompt.
- **Emergency (admin page unreachable):** add to `config/config.php`
  `define('GEOFENCE_FORCE_OFF', true);` — all geofencing off immediately.
- **Code rollback:** extract `hrcrm_geofence_v2_ROLLBACK.zip` into `hrcrm/`
  (restores the 7 original files). The v2 tables/columns can stay — old code
  ignores them. To remove them (optional, deletes the attempt log):
  ```sql
  DROP TABLE IF EXISTS geofence_attempts;
  ALTER TABLE overtime
    DROP COLUMN IF EXISTS ot_in_latitude,  DROP COLUMN IF EXISTS ot_in_longitude,
    DROP COLUMN IF EXISTS ot_in_accuracy,  DROP COLUMN IF EXISTS ot_in_distance_m,
    DROP COLUMN IF EXISTS ot_in_geofence_status,
    DROP COLUMN IF EXISTS ot_out_latitude, DROP COLUMN IF EXISTS ot_out_longitude,
    DROP COLUMN IF EXISTS ot_out_accuracy, DROP COLUMN IF EXISTS ot_out_distance_m,
    DROP COLUMN IF EXISTS ot_out_geofence_status;
  ```

## Testing checklist
| # | Scenario | Expected |
|---|---|---|
| 1 | Employee logs in from home | Allowed, no location prompt |
| 2 | Views salary slip / applies leave / reads notices from home | Allowed |
| 3 | Master switch OFF → check-in / check-out | Works as before, no location prompt |
| 4 | ON, check-in inside radius, good GPS | "Location verified (N m from office). Checked in…"; attendance row has lat/lng/accuracy/distance; attempt *accepted / Inside* |
| 5 | ON, check-in outside radius | Blocked: "You are outside your assigned office location — N m away…"; attempt *rejected / Outside*; Audit Log entry |
| 6 | ON, check-out outside radius | Blocked, same as above |
| 7 | Location permission denied | Blocked: "Please enable location permission to mark attendance." (*Denied*) |
| 8 | Desktop / weak GPS above Max GPS error | Blocked: "GPS accuracy is too low…" (*Poor Accuracy*) |
| 9 | Employee with no site assigned | Blocked: "No office location is assigned… contact HR." |
| 10 | Exempt employee | No prompt; check-in allowed from anywhere (*Exempt*) |
| 11 | Second check-in same day | "You have already checked in today." (existing rule) |
| 12 | Check-out within 30 min | "Checkout will be available 30 minutes after check-in." (existing rule) |
| 13 | Double-click Check-In | One request only |
| 14 | Late check-in after 10:40 | Late status + minutes as before |
| 15 | Auto check-out cron (19:30) and auto-absent | Run as before (check `storage/cron.log`) |
| 16 | OT check-in before 8 PM at site | Existing "only available from 08:00 PM" message |
| 17 | OT check-in/out after 8 PM at site, OT geofence ON | Allowed; `overtime.ot_in_*/ot_out_*` filled |
| 18 | OT with "Enforce on Overtime" OFF | No prompt; OT works from anywhere |
| 19 | HR self check-in (HR dashboard) with site assigned | Inside → allowed; outside → blocked |
| 20 | Team Leader self check-in (TL dashboard) | Same as HR |
| 21 | Super Admin pages, Geofence & Sites, Manual Attendance | Unchanged; manual edits need no GPS |
| 22 | Site set Inactive, then edit an employee assigned to it | Site still selected (marked "inactive"), not cleared |
| 23 | Export Location Log / Export Attempts | CSV downloads; names starting with `=`/`+` are escaped |
| 24 | Payroll generation for the month | Same totals as before deployment |
| 25 | Permission granted earlier (no popup) → Check-In | Fresh fix still taken; accepted if inside |
| 26 | Page left open from before deployment (old script) → Check-In | "Please refresh the page and try again." (*Stale*) — refresh fixes it |
| 27 | Accepted attempt in admin card → "📍 Map" | Opens Google Maps at that point |

## Known limits (tell staff honestly)
- Browser GPS can be spoofed by a determined user (mock-location apps,
  devtools). The system **flags** suspicious readings (`exact_site_point`,
  `repeated_exact_coords`) for HR review but is **not** tamper-proof.
- Desktop PCs usually report poor accuracy; use a phone for attendance.
- Location is read only when an attendance button is pressed — never
  continuously, never at login. Logs are visible only to users with the
  *Manage Geofence* permission (Super Admin, HR).
- Geolocation requires HTTPS (the live site already uses it).
