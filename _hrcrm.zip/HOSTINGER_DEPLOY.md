# RG Realty CRM — Hostinger Deployment Guide

Production-ready package. Nothing is tied to XAMPP; all paths use `__DIR__`, and
the only file you edit is `config/config.php` (the single, central place that
holds DB credentials). The full CRM is included: employees, attendance,
HR/Team-Leader self-attendance, leave (TL + HR parallel approval), payroll,
EMI/advances, overtime, notice board (with Trash/Restore), roles & permissions,
and audit logs.

---

## STEP 1 — Upload the files
**hPanel File Manager (easiest):**
1. hPanel → **Files → File Manager** → open **`public_html`**.
2. **Upload** `rg_realty_crm_hostinger.zip` → right-click → **Extract**.
   You now have `public_html/rg_crm/…`.
3. Choose where the app lives:
   - **Whole domain** `https://yourdomain.com` → move everything *inside*
     `rg_crm/` up into `public_html/`, delete the empty `rg_crm` folder. Keep
     `BASE_URL = ''`.
   - **Subfolder** `https://yourdomain.com/crm` → rename `rg_crm` → `crm`, and
     set `BASE_URL = '/crm'` in Step 3.

**FTP (FileZilla):** upload the extracted contents to `public_html/` (root) or
`public_html/crm/` (subfolder).

---

## STEP 2 — Create the database & import the SQL
1. hPanel → **Databases → MySQL Databases** → create a database + user (strong
   password); ensure the user has **All Privileges** on it. You'll get names like
   `u123456789_rgcrm` / `u123456789_rguser`.
2. Click **Enter phpMyAdmin** → select the database → **Import** tab →
   **Choose File** → `rg_realty_crm.sql` → **Go**.
3. You should see "Import successfully finished" and **35 tables** created and
   seeded (roles, permissions, attendance statuses, leave types, salary
   components, overtime rates, settings, sample accounts, …).

---

## STEP 3 — Enter DB details in the central config
Edit **`config/config.php`** (File Manager → right-click → Edit):
```php
define('DB_HOST', 'localhost');
define('DB_NAME', 'u123456789_rgcrm');
define('DB_USER', 'u123456789_rguser');
define('DB_PASS', 'your-strong-db-password');
define('BASE_URL', '');          // '' at domain root, '/crm' in a subfolder
```
Save. `APP_ENV` is already `production` (errors hidden + logged), timezone is
`Asia/Kolkata`. No other file needs editing — this is the only place with
credentials.

---

## STEP 4 — First login & lock down
1. Open your site — the RG Realty login page should appear.
2. (Optional) open `…/install/generate_admin.php` → **Generate & Apply** to reset
   the admin password, then **delete the entire `install/` folder** (security).
3. Log in and **change every default password** (Administration → Users, or each
   user via My Profile):

| Role        | Login                        | Password    |
|-------------|------------------------------|-------------|
| Super Admin | `superadmin@rgrealty.com`    | `Admin@123` |
| Admin / HR  | `hr@rgrealty.com`            | `Admin@123` |
| Team Leader | `tl@rgrealty.com`            | `Admin@123` |
| Employee    | `amit@rgrealty.com` (RG0001) | `Admin@123` |

---

## STEP 5 — HTTPS (after SSL is active)
hPanel → **Security → SSL** → wait until **Active**. Then edit **`.htaccess`**
and uncomment the "Force HTTPS" block:
```apache
<IfModule mod_rewrite.c>
  RewriteEngine On
  RewriteCond %{HTTPS} off
  RewriteRule ^ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]
</IfModule>
```
Do this only **after** SSL shows Active (avoids a redirect loop). Secure session
cookies switch on automatically over HTTPS.

---

## STEP 6 — Folder permissions
The app writes to these; Hostinger defaults (dirs `755`, files `644`) are usually
correct. If uploads fail, set via File Manager → right-click → **Permissions**:

| Folder      | Permission | Purpose                                         |
|-------------|-----------|--------------------------------------------------|
| `uploads/`  | **755**   | employee photos, company logo, documents, leave & notice attachments |
| `storage/`  | **755**   | password-reset link log (kept private)           |

Both already contain an `.htaccess` blocking script execution and directory
listing. `config/` and `includes/` also have `.htaccess` denying direct web
access, so no source or credentials are reachable from a browser.

---

## STEP 7 — PHP version
hPanel → **Advanced → PHP Configuration** → **PHP 8.0+** with `pdo_mysql`,
`mbstring`, `fileinfo` enabled (defaults). MySQL/MariaDB 5.7+/10.2+.

---

## Folder permission requirements (summary)
```
config/     644 files, 755 dir   (protected by .htaccess "deny all")
includes/   644 files, 755 dir   (protected by .htaccess "deny all")
uploads/    644 files, 755 dir   (WRITABLE; script execution disabled)
storage/    644 files, 755 dir   (WRITABLE; private, deny all)
everything else  644 files, 755 dirs
```

---

## Final deployment checklist
- [ ] Files uploaded to the correct folder (root or `/crm`)
- [ ] Database created; `rg_realty_crm.sql` imported (35 tables)
- [ ] `config/config.php` — DB values + `BASE_URL` set and saved
- [ ] Site loads; logged in successfully
- [ ] **Deleted the `install/` folder**
- [ ] Changed all default passwords
- [ ] Company name, logo, office timings set in **Settings**
- [ ] SSL Active and HTTPS redirect enabled in `.htaccess`
- [ ] `uploads/` and `storage/` writable
- [ ] Test: check-in/out, apply leave, generate payroll, view salary slip,
      post a notice — all work on the live domain

You're live. 🎉
