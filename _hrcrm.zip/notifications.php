<?php
require_once __DIR__ . '/includes/bootstrap.php';
require_login();
$u=current_user();
if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    q("UPDATE notifications SET is_read=1 WHERE user_id=?",[$u['id']]);
    redirect('notifications.php');
}
// mark listed as read on view
$rows=fetch_all("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 100",[$u['id']]);
q("UPDATE notifications SET is_read=1 WHERE user_id=? AND is_read=0",[$u['id']]);
$pageTitle='Notifications'; $activeNav='';
require __DIR__ . '/templates/header.php';
?>
<div class="page-head"><div><h2>Notifications</h2></div>
  <form method="post"><?= csrf_field() ?><button class="btn btn-outline">Mark all read</button></form></div>
<div class="card"><div class="card-body" style="padding:0">
  <?php if(!$rows): ?><div class="empty">No notifications.</div><?php else: foreach($rows as $n): ?>
    <a href="<?= e($n['link'] ?: '#') ?>" style="display:block" class="list-row" >
      <div style="width:100%"><div class="flex between"><b><?= e($n['title']) ?></b>
        <span class="text-muted" style="font-size:11px"><?= fmt_date($n['created_at'],'d M h:i A') ?></span></div>
        <div class="text-muted" style="font-size:12.5px"><?= e($n['body']) ?></div></div>
    </a>
  <?php endforeach; endif; ?>
</div></div>
<?php require __DIR__ . '/templates/footer.php'; ?>
