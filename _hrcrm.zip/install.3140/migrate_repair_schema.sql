-- =====================================================================
--  RG Realty CRM â€” SCHEMA REPAIR (ADD-ONLY, GUARDED, RE-RUNNABLE)
--
--  Adds ONLY the tables/columns that the current code needs and that are
--  missing (e.g. after restoring an older backup). For every column it first
--  checks information_schema; if the column exists, nothing happens.
--
--  NEVER: DROP / TRUNCATE / DELETE / UPDATE of existing rows, no permission
--  resets, no demo users. Works on MySQL 5.7/8.x and MariaDB 10.x.
--
--  BEFORE RUNNING: phpMyAdmin â†’ Export a full backup and keep it on your PC.
--  Run install/schema_check.sql before and after; after = empty results.
--
--  Do NOT re-run the old migrate_*.sql files instead: migrate_auth,
--  migrate_team_leader and migrate_reporting_manager reset permissions /
--  reporting managers when run again.
-- =====================================================================
SET NAMES utf8mb4;

-- ---------- Tables (created only if absent) ---------------------------
CREATE TABLE IF NOT EXISTS `shifts` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(80)  NOT NULL,
  `start_time`  TIME         NOT NULL DEFAULT '10:30:00',
  `end_time`    TIME         NOT NULL DEFAULT '19:00:00',
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shift_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Seed the default shift ONLY when the table is empty (never re-adds a deleted one).
INSERT INTO `shifts` (`name`,`start_time`,`end_time`,`is_active`)
SELECT 'General (10:30-19:00)','10:30:00','19:00:00',1 FROM DUAL
WHERE NOT EXISTS (SELECT 1 FROM `shifts`);

CREATE TABLE IF NOT EXISTS `geofence_locations` (
  `id`                INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `location_name`     VARCHAR(120) NOT NULL,
  `latitude`          DECIMAL(10,7) NOT NULL,
  `longitude`         DECIMAL(10,7) NOT NULL,
  `radius`            INT UNSIGNED NOT NULL DEFAULT 100,
  `status`            TINYINT(1)   NOT NULL DEFAULT 1,
  `enforce_check_in`  TINYINT(1)   NOT NULL DEFAULT 1,
  `enforce_check_out` TINYINT(1)   NOT NULL DEFAULT 1,
  `enforce_ot`        TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`        TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_geo_name` (`location_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS `geofence_attempts` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id` INT UNSIGNED  NULL,
  `user_id`     INT UNSIGNED  NULL,
  `action`      VARCHAR(20)   NOT NULL,
  `result`      VARCHAR(12)   NOT NULL,
  `status`      VARCHAR(20)   NOT NULL,
  `reason`      VARCHAR(255)  NULL,
  `latitude`    DECIMAL(10,7) NULL,
  `longitude`   DECIMAL(10,7) NULL,
  `accuracy`    DECIMAL(8,2)  NULL,
  `distance_m`  INT UNSIGNED  NULL,
  `location_id` INT UNSIGNED  NULL,
  `flags`       VARCHAR(120)  NULL,
  `ip_address`  VARCHAR(45)   NULL,
  `user_agent`  VARCHAR(255)  NULL,
  `created_at`  TIMESTAMP     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_ga_emp_time` (`employee_id`, `created_at`),
  KEY `idx_ga_result_time` (`result`, `created_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- Columns (each added only if missing; table must exist) ---SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'employees') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'employees' AND column_name = 'shift_id') = 0,
  'ALTER TABLE `employees` ADD COLUMN `shift_id` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'employees') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'employees' AND column_name = 'week_off_days') = 0,
  'ALTER TABLE `employees` ADD COLUMN `week_off_days` VARCHAR(20) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'employees') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'employees' AND column_name = 'team_leader_id') = 0,
  'ALTER TABLE `employees` ADD COLUMN `team_leader_id` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'employees') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'employees' AND column_name = 'is_staff') = 0,
  'ALTER TABLE `employees` ADD COLUMN `is_staff` TINYINT(1) NOT NULL DEFAULT 0', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'employees') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'employees' AND column_name = 'geofence_location_id') = 0,
  'ALTER TABLE `employees` ADD COLUMN `geofence_location_id` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'employees') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'employees' AND column_name = 'geofence_exempt') = 0,
  'ALTER TABLE `employees` ADD COLUMN `geofence_exempt` TINYINT(1) NOT NULL DEFAULT 0', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'is_auto_checkout') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `is_auto_checkout` TINYINT(1) NOT NULL DEFAULT 0', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkin_latitude') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkin_latitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkin_longitude') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkin_longitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkin_accuracy') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkin_accuracy` DECIMAL(8,2) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkin_distance_m') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkin_distance_m` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkin_geofence_status') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkin_geofence_status` VARCHAR(20) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkout_latitude') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkout_latitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkout_longitude') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkout_longitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkout_accuracy') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkout_accuracy` DECIMAL(8,2) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkout_distance_m') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkout_distance_m` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'checkout_geofence_status') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `checkout_geofence_status` VARCHAR(20) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'attendance') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'attendance' AND column_name = 'geofence_location_id') = 0,
  'ALTER TABLE `attendance` ADD COLUMN `geofence_location_id` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_check_in') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_check_in` DATETIME NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'session_type') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `session_type` ENUM(''auto_detected'',''manual'') NOT NULL DEFAULT ''auto_detected''', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_in_latitude') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_in_latitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_in_longitude') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_in_longitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_in_accuracy') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_in_accuracy` DECIMAL(8,2) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_in_distance_m') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_in_distance_m` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_in_geofence_status') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_in_geofence_status` VARCHAR(20) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_out_latitude') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_out_latitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_out_longitude') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_out_longitude` DECIMAL(10,7) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_out_accuracy') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_out_accuracy` DECIMAL(8,2) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_out_distance_m') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_out_distance_m` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'overtime') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'overtime' AND column_name = 'ot_out_geofence_status') = 0,
  'ALTER TABLE `overtime` ADD COLUMN `ot_out_geofence_status` VARCHAR(20) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'users') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'username') = 0,
  'ALTER TABLE `users` ADD COLUMN `username` VARCHAR(60) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'users') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'auth_version') = 0,
  'ALTER TABLE `users` ADD COLUMN `auth_version` INT UNSIGNED NOT NULL DEFAULT 1', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'users') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'users' AND column_name = 'last_activity') = 0,
  'ALTER TABLE `users` ADD COLUMN `last_activity` DATETIME NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'hr_decision') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `hr_decision` ENUM(''Pending'',''Approved'',''Rejected'') NOT NULL DEFAULT ''Pending''', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'hr_by') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `hr_by` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'hr_at') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `hr_at` DATETIME NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'hr_remark') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `hr_remark` VARCHAR(255) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'tl_decision') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `tl_decision` ENUM(''Pending'',''Approved'',''Rejected'') NOT NULL DEFAULT ''Pending''', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'tl_by') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `tl_by` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'tl_at') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `tl_at` DATETIME NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'leave_requests') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'leave_requests' AND column_name = 'tl_remark') = 0,
  'ALTER TABLE `leave_requests` ADD COLUMN `tl_remark` VARCHAR(255) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'notices') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'notices' AND column_name = 'is_archived') = 0,
  'ALTER TABLE `notices` ADD COLUMN `is_archived` TINYINT(1) NOT NULL DEFAULT 0', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'notices') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'notices' AND column_name = 'deleted_at') = 0,
  'ALTER TABLE `notices` ADD COLUMN `deleted_at` DATETIME NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'notices') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'notices' AND column_name = 'deleted_by') = 0,
  'ALTER TABLE `notices` ADD COLUMN `deleted_by` INT UNSIGNED NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'notices') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'notices' AND column_name = 'delete_reason') = 0,
  'ALTER TABLE `notices` ADD COLUMN `delete_reason` VARCHAR(255) NULL', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'geofence_locations') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'geofence_locations' AND column_name = 'enforce_check_in') = 0,
  'ALTER TABLE `geofence_locations` ADD COLUMN `enforce_check_in` TINYINT(1) NOT NULL DEFAULT 1', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'geofence_locations') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'geofence_locations' AND column_name = 'enforce_check_out') = 0,
  'ALTER TABLE `geofence_locations` ADD COLUMN `enforce_check_out` TINYINT(1) NOT NULL DEFAULT 1', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
SET @s = IF(
  (SELECT COUNT(*) FROM information_schema.tables  WHERE table_schema = DATABASE() AND table_name = 'geofence_locations') = 1
  AND (SELECT COUNT(*) FROM information_schema.columns WHERE table_schema = DATABASE() AND table_name = 'geofence_locations' AND column_name = 'enforce_ot') = 0,
  'ALTER TABLE `geofence_locations` ADD COLUMN `enforce_ot` TINYINT(1) NOT NULL DEFAULT 1', 'DO 0');
PREPARE stmt FROM @s; EXECUTE stmt; DEALLOCATE PREPARE stmt;
-- ---------- Settings defaults (existing values are never changed) -----
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
  ('geofence_enabled','0'), ('geofence_check_in','1'), ('geofence_check_out','1'),
  ('geofence_ot','1'), ('geofence_max_accuracy','100'),
  ('auto_checkout_enabled','1'), ('auto_checkout_grace_minutes','30'),
  ('ot_manual_sessions','1'), ('ot_checkin_after','20:00'),
  ('min_checkout_minutes','30'), ('auto_absent_enabled','1'),
  ('session_timeout_minutes','30'), ('remember_me_days','30')
ON DUPLICATE KEY UPDATE `setting_key` = `setting_key`;

-- ---------- Permission catalogue (adds missing rows; grants unchanged) -
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
  ('Manage Shifts','shifts.manage','Employees'),
  ('Manage Week-Offs','weekoff.manage','Attendance'),
  ('Manage Geofence','geofence.manage','Attendance')
ON DUPLICATE KEY UPDATE `slug` = `slug`;
-- Super Admin always has every permission. To give HR these menus, run
-- (optional, reviewed separately):
--   INSERT IGNORE INTO role_permissions (role_id, permission_id)
--     SELECT 2, id FROM permissions WHERE slug IN ('shifts.manage','weekoff.manage','geofence.manage');

-- Done. Now run install/schema_check.sql â€” queries 1 and 2 should be empty.