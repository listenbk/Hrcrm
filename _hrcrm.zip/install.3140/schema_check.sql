-- =====================================================================
--  RG Realty CRM — SCHEMA CHECK (READ-ONLY)
--  Lists every table / column the current PHP code needs that is MISSING
--  from this database. Changes NOTHING. Run it any time (before/after a
--  deploy, after restoring a backup).
--
--  phpMyAdmin → select the HRCRM database → SQL tab → paste → Go.
--  Empty result for both queries = schema matches the code.
-- =====================================================================

SELECT DATABASE() AS database_in_use, VERSION() AS server_version;

-- 1) Missing tables
SELECT e.t AS missing_table
FROM (
  SELECT 'shifts' t UNION ALL SELECT 'geofence_locations' UNION ALL SELECT 'geofence_attempts'
  UNION ALL SELECT 'auth_tokens' UNION ALL SELECT 'password_resets'
  UNION ALL SELECT 'overtime' UNION ALL SELECT 'overtime_rates'
  UNION ALL SELECT 'notices' UNION ALL SELECT 'notice_targets' UNION ALL SELECT 'notice_reads'
  UNION ALL SELECT 'tasks' UNION ALL SELECT 'daily_reports'
  UNION ALL SELECT 'assets' UNION ALL SELECT 'asset_allocations' UNION ALL SELECT 'asset_return_requests'
) e
LEFT JOIN information_schema.tables it
  ON it.table_schema = DATABASE() AND BINARY it.table_name = BINARY e.t
WHERE it.table_name IS NULL;

-- 2) Missing columns (only checked where the table itself exists)
SELECT e.t AS table_name, e.c AS missing_column, e.src AS added_by
FROM (
  SELECT 'employees' t, 'shift_id' c, 'migrate_improvements' src
  UNION ALL SELECT 'employees','week_off_days','migrate_flexible_weekoff'
  UNION ALL SELECT 'employees','team_leader_id','migrate_tl_routing'
  UNION ALL SELECT 'employees','is_staff','migrate_hr_attendance'
  UNION ALL SELECT 'employees','geofence_location_id','migrate_geofence'
  UNION ALL SELECT 'employees','geofence_exempt','migrate_geofence'
  UNION ALL SELECT 'attendance','is_auto_checkout','migrate_auto_checkout_ot'
  UNION ALL SELECT 'attendance','checkin_latitude','migrate_geofence'
  UNION ALL SELECT 'attendance','checkin_longitude','migrate_geofence'
  UNION ALL SELECT 'attendance','checkin_accuracy','migrate_geofence'
  UNION ALL SELECT 'attendance','checkin_distance_m','migrate_geofence'
  UNION ALL SELECT 'attendance','checkin_geofence_status','migrate_geofence'
  UNION ALL SELECT 'attendance','checkout_latitude','migrate_geofence'
  UNION ALL SELECT 'attendance','checkout_longitude','migrate_geofence'
  UNION ALL SELECT 'attendance','checkout_accuracy','migrate_geofence'
  UNION ALL SELECT 'attendance','checkout_distance_m','migrate_geofence'
  UNION ALL SELECT 'attendance','checkout_geofence_status','migrate_geofence'
  UNION ALL SELECT 'attendance','geofence_location_id','migrate_geofence'
  UNION ALL SELECT 'overtime','ot_check_in','migrate_auto_checkout_ot'
  UNION ALL SELECT 'overtime','session_type','migrate_auto_checkout_ot'
  UNION ALL SELECT 'overtime','ot_in_latitude','migrate_geofence_v2'
  UNION ALL SELECT 'overtime','ot_out_latitude','migrate_geofence_v2'
  UNION ALL SELECT 'users','username','migrate_auth'
  UNION ALL SELECT 'users','auth_version','migrate_auth'
  UNION ALL SELECT 'users','last_activity','migrate_auth'
  UNION ALL SELECT 'leave_requests','hr_decision','migrate_team_leader'
  UNION ALL SELECT 'leave_requests','tl_decision','migrate_team_leader'
  UNION ALL SELECT 'notices','is_archived','migrate_notice_trash'
  UNION ALL SELECT 'notices','deleted_at','migrate_notice_trash'
  UNION ALL SELECT 'geofence_locations','enforce_check_in','migrate_geofence'
  UNION ALL SELECT 'geofence_locations','enforce_check_out','migrate_geofence'
  UNION ALL SELECT 'geofence_locations','enforce_ot','migrate_geofence'
) e
JOIN information_schema.tables it
  ON it.table_schema = DATABASE() AND BINARY it.table_name = BINARY e.t
LEFT JOIN information_schema.columns ic
  ON ic.table_schema = DATABASE() AND BINARY ic.table_name = BINARY e.t AND BINARY ic.column_name = BINARY e.c
WHERE ic.column_name IS NULL
ORDER BY e.t, e.c;

-- 3) Login accounts with no employee profile (e.g. left behind by a failed
--    "Add Employee"). Informational — nothing is deleted.
SELECT u.id, u.name, u.email, u.created_at, u.last_login_at
FROM users u
JOIN roles r ON r.id = u.role_id AND r.slug = 'employee'
LEFT JOIN employees e ON e.user_id = u.id
WHERE e.id IS NULL
ORDER BY u.created_at DESC;

-- 4) Demo accounts created by the install / old migration scripts. Their
--    passwords are public in the project files. Any ACTIVE row here should be
--    deactivated or given a new password from Admin → Users.
SELECT id, email, name, is_active, last_login_at
FROM users
WHERE email IN ('superadmin@rgrealty.com','hr@rgrealty.com','tl@rgrealty.com',
                'amit@rgrealty.com','priya@rgrealty.com','rahul@rgrealty.com');
