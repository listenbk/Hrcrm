-- =====================================================================
--  RG Realty CRM — Team Leader role + parallel leave approval
--  Adds a Team Leader login role and dual (TL + HR) leave approval,
--  where EITHER approver allows the leave; both must reject to deny.
--  Safe to run once on an existing rg_realty_crm database.
-- =====================================================================
SET NAMES utf8mb4;

-- 1) Team Leader role -------------------------------------------------
INSERT INTO `roles` (`id`,`name`,`slug`,`description`,`is_system`) VALUES
 (4,'Team Leader','team_leader','Approves team leave requests and views attendance',1)
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`), `slug`=VALUES(`slug`);

-- Team Leader permissions: dashboard, view attendance, view + approve leave
DELETE FROM `role_permissions` WHERE `role_id`=4;
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 4, id FROM `permissions` WHERE `slug` IN (
    'dashboard.view','attendance.view','leaves.view','leaves.approve'
  );

-- 2) Parallel approval columns on leave_requests ----------------------
ALTER TABLE `leave_requests`
  ADD COLUMN `hr_decision` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending' AFTER `status`,
  ADD COLUMN `hr_by`     INT UNSIGNED DEFAULT NULL AFTER `hr_decision`,
  ADD COLUMN `hr_at`     DATETIME     DEFAULT NULL AFTER `hr_by`,
  ADD COLUMN `hr_remark` VARCHAR(255) DEFAULT NULL AFTER `hr_at`,
  ADD COLUMN `tl_decision` ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending' AFTER `hr_remark`,
  ADD COLUMN `tl_by`     INT UNSIGNED DEFAULT NULL AFTER `tl_decision`,
  ADD COLUMN `tl_at`     DATETIME     DEFAULT NULL AFTER `tl_by`,
  ADD COLUMN `tl_remark` VARCHAR(255) DEFAULT NULL AFTER `tl_at`;

-- 3) A Team Leader login account (password: Leader@123) --------------
--    Real bcrypt hash of Leader@123. Change it after first login.
INSERT INTO `users` (`role_id`,`username`,`name`,`email`,`password_hash`,`is_active`)
SELECT 4,'teamlead','Karan Mehta (Team Leader)','tl@rgrealty.com',
       '$2y$10$vZa2qzLkoiYgbWj2dNBfJuWCy9XLfAKR/PMbvG5MIgWqnpqwk.CiK', 1
WHERE NOT EXISTS (SELECT 1 FROM `users` WHERE `email`='tl@rgrealty.com');
