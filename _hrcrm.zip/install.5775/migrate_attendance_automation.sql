-- =====================================================================
--  RG Realty CRM — Attendance automation settings
--  (auto-absent + minimum checkout wait time). Safe to run once.
-- =====================================================================
SET NAMES utf8mb4;

INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('min_checkout_minutes','30'),   -- checkout disabled for N minutes after check-in
 ('auto_absent_enabled','1'),     -- 1 = auto-mark absent after office close
 ('cron_key','')                  -- optional secret for URL-triggered cron (blank = CLI only)
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;
