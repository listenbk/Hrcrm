-- =====================================================================
--  RG Realty CRM — Auto Check-Out (7:30 PM) + Separate Overtime Sessions
--  ADD-ONLY migration. Existing attendance, salary, leave and employee
--  data are never modified. Safe to run once (idempotent).
--
--  Rules implemented:
--   * Normal working hours end at office_logout_time (default 19:00 / 7:00 PM).
--   * A 30-minute grace period is allowed. At 7:30 PM any employee still
--     checked in is auto checked-out with check_out time = 7:30 PM and the
--     row is flagged is_auto_checkout=1 ("Auto Check-Out").
--   * Overtime is NOT counted automatically. An employee must perform a
--     separate Overtime Check-In (after the normal session has ended) and a
--     matching Overtime Check-Out. Overtime duration is the OT session length.
-- =====================================================================
SET NAMES utf8mb4;

-- Attendance: flag rows that were auto checked-out by the server.
ALTER TABLE `attendance`
  ADD COLUMN IF NOT EXISTS `is_auto_checkout` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_manual`;

-- Overtime: support an employee-initiated OT session (check-in / check-out)
-- and distinguish it from the legacy auto-detected records.
ALTER TABLE `overtime`
  ADD COLUMN IF NOT EXISTS `ot_check_in` DATETIME NULL AFTER `standard_out`;
ALTER TABLE `overtime`
  ADD COLUMN IF NOT EXISTS `session_type` ENUM('auto_detected','manual')
      NOT NULL DEFAULT 'auto_detected' AFTER `ot_check_in`;

-- Settings (added only if missing — existing values are preserved).
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
  ('auto_checkout_enabled','1'),         -- master switch for the 7:30 PM auto check-out
  ('auto_checkout_grace_minutes','30'),  -- grace after office_logout_time before auto check-out
  ('ot_manual_sessions','1')             -- 1 = overtime requires a manual OT Check-In (no auto-count)
ON DUPLICATE KEY UPDATE `setting_key`=`setting_key`;
