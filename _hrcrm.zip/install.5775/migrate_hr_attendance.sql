-- =====================================================================
--  RG Realty CRM — HR / staff self-attendance
--  Flags employee profiles that belong to staff (HR / Team Leader) users
--  so they can check in/out like employees while staying out of the main
--  employee roster and payroll runs. Safe to run once.
-- =====================================================================
SET NAMES utf8mb4;

ALTER TABLE `employees`
  ADD COLUMN `is_staff` TINYINT(1) NOT NULL DEFAULT 0 AFTER `status`;

CREATE INDEX `idx_emp_is_staff` ON `employees` (`is_staff`);
