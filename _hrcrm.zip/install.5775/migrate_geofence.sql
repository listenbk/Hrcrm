-- =====================================================================
--  RG Realty CRM — Geofenced Attendance (multi-location)
--  ADD-ONLY migration. Feature ships DISABLED (settings.geofence_enabled=0)
--  so no existing check-in/out behaviour changes until HR switches it on.
--  Safe to run once (idempotent).
-- =====================================================================
SET NAMES utf8mb4;

-- Office / site locations managed by Admin (never hard-coded).
CREATE TABLE IF NOT EXISTS `geofence_locations` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `location_name` VARCHAR(120) NOT NULL,
  `latitude`      DECIMAL(10,7) NOT NULL,
  `longitude`     DECIMAL(10,7) NOT NULL,
  `radius`        INT UNSIGNED NOT NULL DEFAULT 100,      -- metres
  `status`        TINYINT(1)   NOT NULL DEFAULT 1,        -- 1 = active
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_geo_name` (`location_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Per-site enforcement switches (Check-In / Check-Out / Overtime).
ALTER TABLE `geofence_locations`
  ADD COLUMN IF NOT EXISTS `enforce_check_in`  TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `enforce_check_out` TINYINT(1) NOT NULL DEFAULT 1,
  ADD COLUMN IF NOT EXISTS `enforce_ot`        TINYINT(1) NOT NULL DEFAULT 1;

-- Each employee is assigned ONE site (NULL = no site assigned).
-- Exempt employees (e.g. roaming field staff) are never geofence-checked.
ALTER TABLE `employees`
  ADD COLUMN IF NOT EXISTS `geofence_location_id` INT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS `geofence_exempt` TINYINT(1) NOT NULL DEFAULT 0;

-- Location evidence on every attendance row.
ALTER TABLE `attendance`
  ADD COLUMN IF NOT EXISTS `checkin_latitude`  DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS `checkin_longitude` DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS `checkin_accuracy`  DECIMAL(8,2)  NULL,
  ADD COLUMN IF NOT EXISTS `checkin_distance_m` INT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS `checkin_geofence_status` VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS `checkout_latitude`  DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS `checkout_longitude` DECIMAL(10,7) NULL,
  ADD COLUMN IF NOT EXISTS `checkout_accuracy`  DECIMAL(8,2)  NULL,
  ADD COLUMN IF NOT EXISTS `checkout_distance_m` INT UNSIGNED NULL,
  ADD COLUMN IF NOT EXISTS `checkout_geofence_status` VARCHAR(20) NULL,
  ADD COLUMN IF NOT EXISTS `geofence_location_id` INT UNSIGNED NULL;

-- Settings (existing values are never overwritten).
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
  ('geofence_enabled','0'),          -- master switch: OFF by default
  ('geofence_check_in','1'),         -- enforce on check-in
  ('geofence_check_out','1'),        -- enforce on check-out
  ('geofence_ot','1'),               -- enforce on overtime check-in/out
  ('geofence_max_accuracy','100')    -- reject GPS readings worse than this (metres)
ON DUPLICATE KEY UPDATE `setting_key`=`setting_key`;

-- Permission to manage locations and read geofence reports.
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES ('Manage Geofence','geofence.manage','Attendance')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions` WHERE slug='geofence.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug='geofence.manage';
