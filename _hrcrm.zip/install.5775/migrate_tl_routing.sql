-- =====================================================================
--  RG Realty CRM — Team Leader Routing (OT gate, TL approval, mandatory
--  TL assignment, employee report)
--  ADD-ONLY migration. No existing data is modified. Safe to run once
--  (idempotent).
-- =====================================================================
SET NAMES utf8mb4;

-- Dedicated "assigned Team Leader" field, distinct from the existing
-- reporting_manager_id (which may be HR or TL and drives the existing
-- leave-approval channel). This new field is what OT, reporting and
-- approval routing now use. NULL for existing employees until next edit —
-- the web form makes it required going forward, nothing is forced in bulk.
ALTER TABLE `employees`
  ADD COLUMN IF NOT EXISTS `team_leader_id` INT UNSIGNED NULL AFTER `reporting_manager_id`;

-- Overtime check-in time gate (default 8:00 PM). Configurable in
-- Admin → Overtime Rules.
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
  ('ot_checkin_after','20:00')
ON DUPLICATE KEY UPDATE `setting_key`=`setting_key`;

-- Team Leaders can now view & approve overtime for their assigned team
-- (scoped in application code to only employees whose team_leader_id is
-- that Team Leader's own user id). Super Admin keeps unrestricted approval.
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 4, id FROM `permissions` WHERE slug='overtime.view';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 4, id FROM `permissions` WHERE slug='overtime.approve';
