<?php
/**
 * Asset Management logic — codes, allocation, return, history and summary.
 * All state changes are server-side; UI only calls these.
 */

/** Default asset types (dropdown). Free-text stored, so "Other" is allowed. */
function asset_types(): array
{
    return ['Mobile','Laptop','Desktop Computer','Monitor','SIM Card','Accessories','Other'];
}

/** Asset condition options. */
function asset_conditions(): array
{
    return ['New','Good','Fair','Poor','Damaged'];
}

/** Self-healing next asset code, e.g. AST0004 (never collides with an existing one). */
function next_asset_code(): string
{
    $prefix = 'AST';
    $maxUsed = (int)fetch_col(
        "SELECT COALESCE(MAX(CAST(SUBSTRING(asset_code, ?) AS UNSIGNED)),0)
         FROM assets WHERE asset_code LIKE ?",
        [strlen($prefix) + 1, $prefix . '%']);
    return $prefix . str_pad((string)($maxUsed + 1), 4, '0', STR_PAD_LEFT);
}

/** Status → pill CSS class. */
function asset_status_pill(string $s): string
{
    return [
        'Available'    => 'pill-success',
        'Allocated'    => 'pill-info',
        'Returned'     => 'pill-muted',
        'Under Repair' => 'pill-warning',
        'Damaged'      => 'pill-danger',
        'Lost'         => 'pill-danger',
        'Retired'      => 'pill-muted',
    ][$s] ?? 'pill-muted';
}

/** Can this asset be allocated right now? */
function asset_is_allocatable(array $asset): bool
{
    return $asset['status'] === 'Available';
}

/** Summary counts for the dashboard cards. */
function asset_summary(): array
{
    $rows = fetch_all("SELECT status, COUNT(*) c FROM assets GROUP BY status");
    $s = ['total'=>0,'Available'=>0,'Allocated'=>0,'Returned'=>0,'Under Repair'=>0,'Damaged'=>0,'Lost'=>0,'Retired'=>0];
    foreach ($rows as $r) { $s[$r['status']] = (int)$r['c']; $s['total'] += (int)$r['c']; }
    $s['damaged_lost'] = $s['Damaged'] + $s['Lost'];
    return $s;
}

/**
 * Allocate an available asset to an employee. Returns [ok, message].
 * Prevents allocating a non-Available asset (already allocated / damaged /
 * lost / retired / under repair).
 */
function allocate_asset(int $assetId, int $employeeId, string $allocDate, string $condition, string $remark, int $hrUserId): array
{
    $asset = fetch_one("SELECT * FROM assets WHERE id=?", [$assetId]);
    if (!$asset) return [false, 'Asset not found.'];
    if (!asset_is_allocatable($asset)) {
        return [false, "This asset is '{$asset['status']}' and cannot be allocated. Only Available assets can be allocated."];
    }
    $emp = fetch_one("SELECT id, emp_code, full_name, user_id FROM employees WHERE id=? AND status NOT IN ('Resigned','Terminated')", [$employeeId]);
    if (!$emp) return [false, 'Select a valid employee (resigned/terminated employees cannot be assigned assets).'];

    db()->beginTransaction();
    try {
        q("UPDATE assets SET status='Allocated', assigned_employee_id=?, allocation_date=?, `condition`=?, return_date=NULL WHERE id=?",
          [$employeeId, $allocDate, $condition, $assetId]);
        q("INSERT INTO asset_allocations
             (asset_id, employee_id, emp_code, employee_name, allocated_by, allocation_date, allocation_condition, allocation_remark, status)
           VALUES (?,?,?,?,?,?,?,?, 'Active')",
          [$assetId, $employeeId, $emp['emp_code'], $emp['full_name'], $hrUserId, $allocDate, $condition, $remark]);
        db()->commit();
    } catch (Throwable $e) {
        db()->rollBack();
        return [false, 'Could not allocate: ' . (APP_ENV==='development' ? $e->getMessage() : 'database error')];
    }

    if (!empty($emp['user_id'])) {
        notify((int)$emp['user_id'], 'asset_allocated', 'Asset assigned to you',
            "{$asset['asset_type']} ({$asset['asset_code']}) was allocated to you.", url('employee/assets.php'));
    }
    audit_log('asset_allocated','asset',$assetId,
        "Allocated {$asset['asset_code']} ({$asset['asset_type']}) to {$emp['full_name']} ({$emp['emp_code']})");
    return [true, "Asset allocated to {$emp['full_name']}."];
}

/**
 * Return an allocated asset back to inventory. Returns [ok, message].
 * @param string $newStatus Available|Under Repair|Damaged|Lost|Retired
 */
function return_asset(int $assetId, string $newStatus, string $returnCondition, string $returnRemark, int $hrUserId, string $returnDate): array
{
    $asset = fetch_one("SELECT * FROM assets WHERE id=?", [$assetId]);
    if (!$asset) return [false, 'Asset not found.'];
    if ($asset['status'] !== 'Allocated') {
        return [false, 'Only an allocated asset can be returned.'];
    }
    $valid = ['Available','Under Repair','Damaged','Lost','Retired'];
    if (!in_array($newStatus, $valid, true)) $newStatus = 'Available';

    $alloc = fetch_one("SELECT * FROM asset_allocations WHERE asset_id=? AND status='Active' ORDER BY id DESC LIMIT 1", [$assetId]);

    db()->beginTransaction();
    try {
        if ($alloc) {
            q("UPDATE asset_allocations
                 SET return_date=?, return_condition=?, return_remark=?, received_by=?, status='Returned'
               WHERE id=?",
              [$returnDate, $returnCondition, $returnRemark, $hrUserId, $alloc['id']]);
        }
        q("UPDATE assets SET status=?, assigned_employee_id=NULL, allocation_date=NULL, return_date=?, `condition`=? WHERE id=?",
          [$newStatus, $returnDate, $returnCondition, $assetId]);
        // Close any pending return request for this asset
        q("UPDATE asset_return_requests SET status='Completed', handled_by=?, handled_at=NOW() WHERE asset_id=? AND status='Pending'",
          [$hrUserId, $assetId]);
        db()->commit();
    } catch (Throwable $e) {
        db()->rollBack();
        return [false, 'Could not process return: ' . (APP_ENV==='development' ? $e->getMessage() : 'database error')];
    }

    if ($alloc && !empty($alloc['employee_id'])) {
        $u = fetch_col("SELECT user_id FROM employees WHERE id=?", [$alloc['employee_id']]);
        if ($u) notify((int)$u, 'asset_returned', 'Asset return recorded',
            "{$asset['asset_code']} was returned to company inventory.", url('employee/assets.php'));
    }
    audit_log('asset_returned','asset',$assetId,
        "Returned {$asset['asset_code']} → status {$newStatus} (condition {$returnCondition})");
    return [true, "Asset returned. Status set to {$newStatus}."];
}
