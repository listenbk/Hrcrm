<?php
/**
 * Database backup — pure PHP (no exec / mysqldump needed, works on shared
 * hosting). Produces a gzipped SQL dump under storage/backups and prunes old
 * files by retention count. Read-only against the live DB; never alters data.
 */

/** Absolute path to the backups folder (created on demand). */
function backup_dir(): string
{
    $d = APP_ROOT . '/storage/backups';
    if (!is_dir($d)) @mkdir($d, 0770, true);
    return $d;
}

/** Keep only the newest N backups (setting backup_keep, default 14). */
function db_backup_prune(): void
{
    $keep = max(1, (int)setting('backup_keep', 14));
    $files = glob(backup_dir() . '/backup_*.sql.gz') ?: [];
    usort($files, fn($a,$b) => filemtime($b) <=> filemtime($a));  // newest first
    foreach (array_slice($files, $keep) as $old) { @unlink($old); }
}

/**
 * Create a gzipped SQL backup of the whole database.
 * @return array [ok, message, filename|null]
 */
function db_backup_run(): array
{
    $dir  = backup_dir();
    if (!is_writable($dir)) return [false, 'Backups folder is not writable: ' . $dir, null];

    $file = 'backup_' . date('Y-m-d_His') . '.sql.gz';
    $path = $dir . '/' . $file;
    $gz = @gzopen($path, 'wb9');
    if (!$gz) return [false, 'Could not open backup file for writing.', null];

    try {
        $pdo = db();
        gzwrite($gz, "-- RG Realty CRM database backup\n-- Generated: " . date('c') . "\n");
        gzwrite($gz, "SET FOREIGN_KEY_CHECKS=0;\nSET NAMES utf8mb4;\n\n");

        $tables = $pdo->query("SHOW TABLES")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($tables as $t) {
            $create = $pdo->query("SHOW CREATE TABLE `$t`")->fetch(PDO::FETCH_ASSOC);
            $ddl = $create['Create Table'] ?? ($create['Create View'] ?? '');
            gzwrite($gz, "DROP TABLE IF EXISTS `$t`;\n$ddl;\n\n");

            $stmt = $pdo->query("SELECT * FROM `$t`");
            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
                $cols = implode(',', array_map(fn($c) => "`$c`", array_keys($row)));
                $vals = implode(',', array_map(
                    fn($v) => $v === null ? 'NULL' : $pdo->quote((string)$v),
                    array_values($row)));
                gzwrite($gz, "INSERT INTO `$t` ($cols) VALUES ($vals);\n");
            }
            gzwrite($gz, "\n");
        }
        gzwrite($gz, "SET FOREIGN_KEY_CHECKS=1;\n");
    } catch (Throwable $e) {
        gzclose($gz);
        @unlink($path);
        error_log('[backup] failed: ' . $e->getMessage());
        return [false, 'Backup failed: ' . $e->getMessage(), null];
    }
    gzclose($gz);
    db_backup_prune();
    return [true, 'Backup created: ' . $file . ' (' . db_human_size(filesize($path)) . ')', $file];
}

/** List existing backups, newest first. */
function db_backup_list(): array
{
    $files = glob(backup_dir() . '/backup_*.sql.gz') ?: [];
    usort($files, fn($a,$b) => filemtime($b) <=> filemtime($a));
    return array_map(fn($f) => [
        'name' => basename($f),
        'size' => filesize($f),
        'time' => filemtime($f),
    ], $files);
}

/** Delete one backup by basename (path-traversal safe). */
function db_backup_delete(string $name): bool
{
    $name = basename($name);
    if (!preg_match('/^backup_[\d_]+\.sql\.gz$/', $name)) return false;
    $path = backup_dir() . '/' . $name;
    return is_file($path) ? @unlink($path) : false;
}

/** Absolute path for a backup basename, or null if invalid/missing. */
function db_backup_path(string $name): ?string
{
    $name = basename($name);
    if (!preg_match('/^backup_[\d_]+\.sql\.gz$/', $name)) return null;
    $path = backup_dir() . '/' . $name;
    return is_file($path) ? $path : null;
}

function db_human_size(int $bytes): string
{
    $u = ['B','KB','MB','GB']; $i = 0;
    while ($bytes >= 1024 && $i < count($u)-1) { $bytes /= 1024; $i++; }
    return round($bytes, $i ? 1 : 0) . ' ' . $u[$i];
}
