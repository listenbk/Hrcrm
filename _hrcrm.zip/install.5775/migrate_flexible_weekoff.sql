-- =====================================================================
--  RG Realty CRM — Flexible Week-Off Management
--  Lets HR AND Team Leaders set a per-employee weekly-off pattern that
--  overrides the company-wide default (Settings → Weekly Offs).
--  ADD-ONLY. No existing data is modified. Safe to run once (idempotent).
-- =====================================================================
SET NAMES utf8mb4;

-- NULL/empty = employee follows the company default (`weekly_offs` setting).
-- Non-empty = comma list of weekday numbers (0=Sunday..6=Saturday), same
-- format as the company default, e.g. '0' or '0,3'.
ALTER TABLE `employees`
  ADD COLUMN IF NOT EXISTS `week_off_days` VARCHAR(20) NULL AFTER `shift_id`;

-- Permission: manage/adjust employee week-offs.
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES ('Manage Week-Offs','weekoff.manage','Attendance')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Grant to Super Admin (1), HR/Admin (2) and Team Leader (4).
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions` WHERE slug='weekoff.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug='weekoff.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 4, id FROM `permissions` WHERE slug='weekoff.manage';
