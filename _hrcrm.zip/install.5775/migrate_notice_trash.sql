-- =====================================================================
--  RG Realty CRM — Notice soft-delete (Trash), manual archive & restore
--  Safe to run once on an existing rg_realty_crm database.
-- =====================================================================
SET NAMES utf8mb4;

ALTER TABLE `notices`
  ADD COLUMN `is_archived`   TINYINT(1)   NOT NULL DEFAULT 0 AFTER `is_pinned`,
  ADD COLUMN `deleted_at`    DATETIME     DEFAULT NULL AFTER `updated_at`,
  ADD COLUMN `deleted_by`    INT UNSIGNED DEFAULT NULL AFTER `deleted_at`,
  ADD COLUMN `delete_reason` VARCHAR(255) DEFAULT NULL AFTER `deleted_by`;

CREATE INDEX `idx_notice_deleted` ON `notices` (`deleted_at`);
