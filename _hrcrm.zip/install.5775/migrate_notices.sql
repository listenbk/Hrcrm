-- =====================================================================
--  RG Realty CRM — Notice Board / Announcements
--  Adds notices, per-notice selected targets, read tracking and the
--  notices.manage permission. Safe to run once.
-- =====================================================================
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `notices` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`         VARCHAR(200) NOT NULL,
  `message`       TEXT         NOT NULL,
  `priority`      ENUM('Normal','Important','Urgent') NOT NULL DEFAULT 'Normal',
  `audience_type` ENUM('all','employees','hr','department','branch','selected') NOT NULL DEFAULT 'all',
  `audience_value` VARCHAR(150) DEFAULT NULL,   -- department id, or branch/office name
  `attachment`    VARCHAR(255) DEFAULT NULL,
  `is_pinned`     TINYINT(1)   NOT NULL DEFAULT 0,
  `publish_date`  DATE         NOT NULL,
  `expiry_date`   DATE         DEFAULT NULL,
  `created_by`    INT UNSIGNED DEFAULT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_notice_pub` (`publish_date`),
  KEY `idx_notice_exp` (`expiry_date`),
  KEY `idx_notice_pin` (`is_pinned`),
  CONSTRAINT `fk_notice_creator` FOREIGN KEY (`created_by`) REFERENCES `users`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Explicitly selected recipients (audience_type = 'selected')
CREATE TABLE IF NOT EXISTS `notice_targets` (
  `id`        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `notice_id` BIGINT UNSIGNED NOT NULL,
  `user_id`   INT UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notice_target` (`notice_id`,`user_id`),
  KEY `idx_nt_user` (`user_id`),
  CONSTRAINT `fk_nt_notice` FOREIGN KEY (`notice_id`) REFERENCES `notices`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nt_user`   FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Read receipts
CREATE TABLE IF NOT EXISTS `notice_reads` (
  `id`        BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `notice_id` BIGINT UNSIGNED NOT NULL,
  `user_id`   INT UNSIGNED NOT NULL,
  `read_at`   DATETIME     NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_notice_read` (`notice_id`,`user_id`),
  KEY `idx_nr_user` (`user_id`),
  CONSTRAINT `fk_nr_notice` FOREIGN KEY (`notice_id`) REFERENCES `notices`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_nr_user`   FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permission: create / edit / send notices (HR + Super Admin)
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
 ('Manage Notice Board','notices.manage','Notice Board')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions` WHERE slug='notices.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug='notices.manage';
