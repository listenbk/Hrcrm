-- =====================================================================
--  RG Realty CRM — Overtime & Extra Pay Management
--  Adds overtime records, day-type rate policies, OT settings and
--  overtime view/approve permissions. Safe to run once.
-- =====================================================================
SET NAMES utf8mb4;

-- 1) Day-type overtime rate policies (multipliers) --------------------
CREATE TABLE IF NOT EXISTS `overtime_rates` (
  `id`         INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `day_type`   VARCHAR(40)  NOT NULL,
  `label`      VARCHAR(80)  NOT NULL,
  `multiplier` DECIMAL(4,2) NOT NULL DEFAULT 1.00,
  `is_active`  TINYINT(1)   NOT NULL DEFAULT 1,
  `sort_order` INT          NOT NULL DEFAULT 0,
  `created_at` TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ot_daytype` (`day_type`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `overtime_rates` (`day_type`,`label`,`multiplier`,`sort_order`) VALUES
 ('normal','Regular Working Day',1.00,1),
 ('weekly_off','Weekly Off',1.50,2),
 ('sunday','Sunday',1.50,3),
 ('public_holiday','Public Holiday',2.00,4),
 ('festival','Festival Holiday',2.00,5),
 ('emergency','Emergency Work',1.50,6),
 ('night','Night Work',1.50,7),
 ('client_visit','Client / Site Visit',1.00,8),
 ('special_project','Special Project',1.25,9)
ON DUPLICATE KEY UPDATE `label`=VALUES(`label`);

-- 2) Overtime records -------------------------------------------------
CREATE TABLE IF NOT EXISTS `overtime` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`    INT UNSIGNED NOT NULL,
  `attendance_id`  BIGINT UNSIGNED DEFAULT NULL,
  `ot_date`        DATE         NOT NULL,
  `standard_out`   DATETIME     DEFAULT NULL,   -- office closing for that day
  `actual_out`     DATETIME     DEFAULT NULL,   -- server-generated checkout
  `actual_minutes` INT          NOT NULL DEFAULT 0,   -- raw minutes beyond close
  `actual_hours`   DECIMAL(6,2) NOT NULL DEFAULT 0,   -- after rounding rule
  `approved_hours` DECIMAL(6,2) NOT NULL DEFAULT 0,   -- manager-approved
  `day_type`       VARCHAR(40)  NOT NULL DEFAULT 'normal',
  `multiplier`     DECIMAL(4,2) NOT NULL DEFAULT 1.00,
  `hourly_rate`    DECIMAL(10,2) NOT NULL DEFAULT 0,
  `amount`         DECIMAL(12,2) NOT NULL DEFAULT 0,   -- approved_hours*rate*mult
  `employee_reason` TEXT        DEFAULT NULL,
  `work_performed` TEXT         DEFAULT NULL,
  `project_name`   VARCHAR(150) DEFAULT NULL,
  `hr_remark`      VARCHAR(255) DEFAULT NULL,
  `hr_by`          INT UNSIGNED DEFAULT NULL,
  `hr_at`          DATETIME     DEFAULT NULL,
  `manager_remark` VARCHAR(255) DEFAULT NULL,
  `approved_by`    INT UNSIGNED DEFAULT NULL,
  `approved_at`    DATETIME     DEFAULT NULL,
  `include_in_payroll` TINYINT(1) NOT NULL DEFAULT 1,
  `status`         ENUM('Detected','Pending Approval','HR Reviewed','Approved','Partially Approved','Rejected','Paid')
                     NOT NULL DEFAULT 'Detected',
  `payroll_id`     BIGINT UNSIGNED DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_ot_emp_date` (`employee_id`,`ot_date`),
  KEY `idx_ot_status` (`status`),
  KEY `idx_ot_date` (`ot_date`),
  CONSTRAINT `fk_ot_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 3) Overtime settings ------------------------------------------------
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('ot_enabled','1'),
 ('ot_min_minutes','30'),
 ('ot_rate_mode','salary'),            -- 'fixed' or 'salary'
 ('ot_fixed_hourly','150'),
 ('ot_monthly_standard_hours','200'),
 ('ot_rounding','nearest30'),          -- none|nearest15|nearest30|down|up
 ('ot_max_daily_hours','5'),
 ('ot_max_monthly_hours','60')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;

-- 4) Permissions ------------------------------------------------------
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
 ('View Overtime','overtime.view','Overtime'),
 ('Approve Overtime','overtime.approve','Overtime'),
 ('Configure Overtime','overtime.config','Settings')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Super Admin: all (cosmetic — has_perm grants super_admin everything)
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions`;

-- HR: can VIEW/recommend overtime (final approval stays with Manager)
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug = 'overtime.view';
