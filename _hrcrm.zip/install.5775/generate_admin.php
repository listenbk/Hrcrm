<?php
/**
 * One-time setup: (re)generate verifiable password hashes for the seeded
 * accounts, since the SQL ships with a placeholder hash.
 *
 * 1. Import rg_realty_crm.sql via phpMyAdmin.
 * 2. Open  http://localhost/rg_crm/install/generate_admin.php  in a browser.
 * 3. Log in, then DELETE this /install folder (or the file) before going live.
 *
 * You can change the default password here before running.
 */
require_once __DIR__ . '/../includes/bootstrap.php';

$DEFAULT_PASSWORD = 'Admin@123';   // change me before running if you like

$accounts = [
    'superadmin@rgrealty.com',
    'hr@rgrealty.com',
    'amit@rgrealty.com',
    'priya@rgrealty.com',
    'rahul@rgrealty.com',
];

$done = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $pw = (string)param('password', $DEFAULT_PASSWORD, 'POST');
    if (strlen($pw) < 6) {
        $err = 'Password must be at least 6 characters.';
    } else {
        $hash = password_hash($pw, PASSWORD_DEFAULT);
        foreach ($accounts as $email) {
            $n = q("UPDATE users SET password_hash=?, failed_attempts=0, locked_until=NULL WHERE email=?", [$hash, $email])->rowCount();
            if ($n) $done[] = $email;
        }
    }
}
?>
<!DOCTYPE html><html><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>RG Realty CRM — Setup</title>
<link rel="stylesheet" href="<?= url('assets/css/style.css') ?>"></head>
<body style="background:#0b1220">
<div class="auth-wrap">
<div class="auth-card" style="width:min(560px,94vw)">
  <div class="auth-logo">RG Realty CRM</div>
  <div class="auth-sub">First-time password setup</div>

  <?php if (!empty($err)): ?><div class="alert alert-error"><?= e($err) ?></div><?php endif; ?>

  <?php if ($done): ?>
    <div class="alert alert-success">Passwords set for <?= count($done) ?> account(s).</div>
    <p>You can now log in with:</p>
    <ul>
      <li><b>Super Admin:</b> superadmin@rgrealty.com</li>
      <li><b>HR / Admin:</b> hr@rgrealty.com</li>
      <li><b>Employees:</b> amit@rgrealty.com, priya@rgrealty.com, rahul@rgrealty.com</li>
    </ul>
    <div class="alert alert-error mt-2">⚠️ Security: delete the <code>/install</code> folder now.</div>
    <a class="btn btn-lg" href="<?= url('auth/login.php') ?>">Go to Login</a>
  <?php else: ?>
    <form method="post">
      <div class="form-group">
        <label>Password to set for all seeded accounts</label>
        <input type="text" name="password" value="<?= e($DEFAULT_PASSWORD) ?>" required>
        <div class="help">This sets the same password for the 2 admin and 3 sample employee accounts. Change each user's password later from Users.</div>
      </div>
      <button class="btn btn-lg" type="submit">Generate &amp; Apply</button>
    </form>
  <?php endif; ?>
</div>
</div>
</body></html>
