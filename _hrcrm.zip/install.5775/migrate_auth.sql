-- =====================================================================
--  RG Realty CRM — Auth hardening migration
--  Adds: username/auth_version/last_activity, hr_admin role slug,
--  remember-me tokens, password resets, granular config permissions,
--  and the HR-vs-SuperAdmin permission split.
--  Safe to run once on an existing rg_realty_crm database.
-- =====================================================================
SET NAMES utf8mb4;

-- 1) users: new auth columns -----------------------------------------
ALTER TABLE `users`
  ADD COLUMN `username`     VARCHAR(60)  NULL AFTER `role_id`,
  ADD COLUMN `auth_version` INT UNSIGNED NOT NULL DEFAULT 1 AFTER `must_change_pw`,
  ADD COLUMN `last_activity` DATETIME    NULL AFTER `last_login_ip`,
  ADD UNIQUE KEY `uq_users_username` (`username`);

-- 2) role slug: admin -> hr_admin ------------------------------------
UPDATE `roles` SET `slug`='hr_admin' WHERE `slug`='admin';

-- 3) remember-me tokens ----------------------------------------------
CREATE TABLE IF NOT EXISTS `auth_tokens` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`        INT UNSIGNED NOT NULL,
  `selector`       CHAR(24)     NOT NULL,
  `validator_hash` CHAR(64)     NOT NULL,   -- sha256 of validator
  `expires_at`     DATETIME     NOT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_auth_selector` (`selector`),
  KEY `idx_auth_user` (`user_id`),
  CONSTRAINT `fk_auth_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 4) password reset tokens -------------------------------------------
CREATE TABLE IF NOT EXISTS `password_resets` (
  `id`          BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id`     INT UNSIGNED NOT NULL,
  `selector`    CHAR(24)     NOT NULL,
  `token_hash`  CHAR(64)     NOT NULL,
  `expires_at`  DATETIME     NOT NULL,
  `used_at`     DATETIME     NULL,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_reset_selector` (`selector`),
  KEY `idx_reset_user` (`user_id`),
  CONSTRAINT `fk_reset_user` FOREIGN KEY (`user_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- 5) new granular permissions ----------------------------------------
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
 ('Manage Employee Login Credentials','employees.credentials','Employees'),
 ('Configure Salary Components','config.salary_components','Settings'),
 ('Configure Leave Types','config.leave_types','Settings'),
 ('Permanently Delete Records','records.delete','Administration')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Ensure Super Admin (role 1) holds every permission row (cosmetic;
-- has_perm() already grants super_admin everything).
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions`;

-- 6) Rebuild HR (role 2) permission set: operational only ------------
DELETE FROM `role_permissions` WHERE `role_id`=2;
INSERT INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE `slug` IN (
    'dashboard.view',
    'employees.view','employees.create','employees.edit','employees.credentials',
    'attendance.view','attendance.manage','attendance.manual',
    'leaves.view','leaves.approve',
    'payroll.view','payroll.manage',
    'advances.view','advances.manage',
    'reports.view'
  );
-- HR is intentionally NOT granted: employees.delete, records.delete,
-- config.*, customfields.manage, holidays.manage, settings.manage,
-- users.manage, roles.manage, audit.view (all Super-Admin only).

-- 7) new settings -----------------------------------------------------
INSERT INTO `settings` (`setting_key`,`setting_value`) VALUES
 ('session_timeout_minutes','30'),
 ('remember_me_days','30')
ON DUPLICATE KEY UPDATE `setting_value`=`setting_value`;
