<?php
require_once __DIR__ . '/../includes/bootstrap.php';
$id = (int)param('id', 0);
require_perm($id ? 'employees.edit' : 'employees.create');

$emp = null;
if ($id) {
    $emp = fetch_one("SELECT * FROM employees WHERE id=?", [$id]);
    if (!$emp) { flash_error('Employee not found.'); redirect('admin/employees.php'); }
}

$depts   = fetch_all("SELECT id,name FROM departments WHERE is_active=1 ORDER BY name");
$desigs  = fetch_all("SELECT id,name FROM designations WHERE is_active=1 ORDER BY name");
$shifts  = fetch_all("SELECT id,name,start_time,end_time FROM shifts WHERE is_active=1 ORDER BY name");
// Reporting manager = an HR or Team Leader user account
$mgrs    = fetch_all(
    "SELECT u.id, u.name, r.name AS role_name FROM users u JOIN roles r ON r.id=u.role_id
     WHERE r.slug IN ('hr_admin','team_leader') AND u.is_active=1
     ORDER BY r.name, u.name");

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $f = $_POST;
    $fullName = trim($f['full_name'] ?? '');
    $email    = trim($f['email'] ?? '');
    $errors = [];
    if ($fullName === '') $errors[] = 'Full name is required.';
    if ($email !== '' && !valid_email($email)) $errors[] = 'Invalid email address.';

    // Employee ID (emp_code) can be changed on edit; must stay unique.
    $newCode = trim($f['emp_code'] ?? '');
    if ($id && $newCode !== '' && $newCode !== $emp['emp_code']) {
        if ((int)fetch_col("SELECT COUNT(*) FROM employees WHERE emp_code=? AND id<>?", [$newCode, $id]) > 0) {
            $errors[] = 'Employee ID "' . e($newCode) . '" is already in use.';
        }
    }

    // Photo upload
    $photo = $emp['photo'] ?? null;
    if (!empty($_FILES['photo']['name'])) {
        $up = handle_upload($_FILES['photo'], 'photos', ['jpg','jpeg','png','gif']);
        if ($up) $photo = $up;
    }

    if (!$errors) {
        $data = [
            'full_name'      => $fullName,
            'photo'          => $photo,
            'mobile'         => trim($f['mobile'] ?? ''),
            'email'          => $email,
            'address'        => trim($f['address'] ?? ''),
            'dob'            => $f['dob'] ?: null,
            'joining_date'   => $f['joining_date'] ?: null,
            'department_id'  => $f['department_id'] ?: null,
            'designation_id' => $f['designation_id'] ?: null,
            'shift_id'       => $f['shift_id'] ?: null,
            'reporting_manager_id' => $f['reporting_manager_id'] ?: null,
            'employment_type'=> trim($f['employment_type'] ?? 'Full Time'),
            'office_location'=> trim($f['office_location'] ?? ''),
            'basic_salary'   => (float)($f['basic_salary'] ?? 0),
            'salary_structure'=> trim($f['salary_structure'] ?? ''),
            'bank_name'      => trim($f['bank_name'] ?? ''),
            'bank_account'   => trim($f['bank_account'] ?? ''),
            'bank_ifsc'      => trim($f['bank_ifsc'] ?? ''),
            'upi_id'         => trim($f['upi_id'] ?? ''),
            'pan'            => trim($f['pan'] ?? ''),
            'aadhaar'        => trim($f['aadhaar'] ?? ''),
            'emergency_name' => trim($f['emergency_name'] ?? ''),
            'emergency_phone'=> trim($f['emergency_phone'] ?? ''),
            'emergency_relation'=> trim($f['emergency_relation'] ?? ''),
            'status'         => in_array($f['status'] ?? 'Active', ['Active','Inactive','Resigned','Terminated'], true) ? $f['status'] : 'Active',
            'notes'          => trim($f['notes'] ?? ''),
        ];

        if ($id) {
            if ($newCode !== '') $data['emp_code'] = $newCode;   // allow Employee ID change
            $set = implode(',', array_map(fn($k) => "`$k`=?", array_keys($data)));
            q("UPDATE employees SET $set WHERE id=?", array_merge(array_values($data), [$id]));
            audit_log('employee_edited', 'employee', $id, "Edited {$fullName}", $emp, $data);
            $recId = $id;
        } else {
            $data['emp_code'] = next_emp_code();
            // Create login account if password provided
            $userId = null;
            $loginPw = trim($f['login_password'] ?? '');
            if ($email !== '' && $loginPw !== '') {
                if (fetch_col("SELECT COUNT(*) FROM users WHERE email=?", [$email]) == 0) {
                    q("INSERT INTO users (role_id,name,email,password_hash,is_active) VALUES (3,?,?,?,1)",
                      [$fullName, $email, password_hash($loginPw, PASSWORD_DEFAULT)]);
                    $userId = (int)insert_id();
                }
            }
            $data['user_id'] = $userId;
            $cols = implode(',', array_map(fn($k) => "`$k`", array_keys($data)));
            $ph   = implode(',', array_fill(0, count($data), '?'));
            q("INSERT INTO employees ($cols) VALUES ($ph)", array_values($data));
            $recId = (int)insert_id();
            set_setting('emp_code_next', (int)setting('emp_code_next', 1) + 1);
            audit_log('employee_created', 'employee', $recId, "Created {$fullName} ({$data['emp_code']})", null, $data);
        }

        save_custom_fields('employee', (int)$recId, $_POST);
        flash_success('Employee saved successfully.');
        redirect('admin/employee_view.php?id=' . $recId);
    } else {
        $emp = array_merge($emp ?? [], $f);
        flash_error(implode(' ', $errors));
    }
}

$cfValues = $id ? custom_field_values('employee', $id) : [];
$pageTitle = $id ? 'Edit Employee' : 'Add Employee';
$activeNav = $id ? 'employees' : 'employee_add';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2><?= $id ? 'Edit Employee' : 'Add Employee' ?></h2>
    <div class="breadcrumb"><a href="<?= url('admin/employees.php') ?>">Employees</a> / <?= $id ? e($emp['emp_code'] ?? '') : 'New' ?></div></div>
</div>

<form method="post" enctype="multipart/form-data">
  <?= csrf_field() ?>
  <div class="grid cols-2">
    <div class="card"><div class="card-head"><h3>Basic Information</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Full Name <span class="req">*</span></label>
          <input type="text" name="full_name" value="<?= e($emp['full_name'] ?? '') ?>" required></div>
        <div class="form-group"><label>Employee ID</label>
          <?php if ($id): ?>
            <input type="text" name="emp_code" value="<?= e($emp['emp_code'] ?? '') ?>">
            <div class="help">Editable — must stay unique.</div>
          <?php else: ?>
            <input type="text" value="Auto-generated (<?= e(next_emp_code()) ?>)" disabled>
          <?php endif; ?>
        </div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Mobile</label><input type="tel" name="mobile" value="<?= e($emp['mobile'] ?? '') ?>"></div>
        <div class="form-group"><label>Email</label><input type="email" name="email" value="<?= e($emp['email'] ?? '') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Date of Birth</label><input type="date" name="dob" value="<?= e($emp['dob'] ?? '') ?>"></div>
        <div class="form-group"><label>Joining Date</label><input type="date" name="joining_date" value="<?= e($emp['joining_date'] ?? '') ?>"></div>
      </div>
      <div class="form-group"><label>Address</label><textarea name="address"><?= e($emp['address'] ?? '') ?></textarea></div>
      <div class="form-group"><label>Profile Photo</label><input type="file" name="photo" accept="image/*">
        <?php if (!empty($emp['photo'])): ?><div class="help">Current: <?= e($emp['photo']) ?></div><?php endif; ?></div>
    </div></div>

    <div class="card"><div class="card-head"><h3>Job Details</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Department</label><select name="department_id"><option value="">—</option>
          <?php foreach ($depts as $d): ?><option value="<?= $d['id'] ?>" <?= ($emp['department_id']??'')==$d['id']?'selected':'' ?>><?= e($d['name']) ?></option><?php endforeach; ?>
        </select></div>
        <div class="form-group"><label>Designation</label><select name="designation_id"><option value="">—</option>
          <?php foreach ($desigs as $d): ?><option value="<?= $d['id'] ?>" <?= ($emp['designation_id']??'')==$d['id']?'selected':'' ?>><?= e($d['name']) ?></option><?php endforeach; ?>
        </select></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Shift</label><select name="shift_id"><option value="">Company default (office times)</option>
          <?php foreach ($shifts as $sh): ?><option value="<?= $sh['id'] ?>" <?= ($emp['shift_id']??'')==$sh['id']?'selected':'' ?>><?= e($sh['name'].' ('.substr($sh['start_time'],0,5).'–'.substr($sh['end_time'],0,5).')') ?></option><?php endforeach; ?>
        </select><div class="help">Drives late/early, auto-checkout & overtime for this employee. Manage in <a href="<?= url('admin/shifts.php') ?>">Shifts</a>.</div></div>
        <div class="form-group"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Reporting Manager <span class="help" style="display:inline;font-weight:400">(HR / Team Leader)</span></label><select name="reporting_manager_id"><option value="">—</option>
          <?php foreach ($mgrs as $m): ?><option value="<?= $m['id'] ?>" <?= ($emp['reporting_manager_id']??'')==$m['id']?'selected':'' ?>><?= e($m['name'].' — '.$m['role_name']) ?></option><?php endforeach; ?>
        </select></div>
        <div class="form-group"><label>Employment Type</label>
          <select name="employment_type">
            <?php foreach (['Full Time','Part Time','Contract','Intern','Probation'] as $t): ?>
            <option <?= ($emp['employment_type']??'Full Time')===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Office / Location</label><input type="text" name="office_location" value="<?= e($emp['office_location'] ?? '') ?>"></div>
        <div class="form-group"><label>Status</label><select name="status">
          <?php foreach (['Active','Inactive','Resigned','Terminated'] as $s): ?>
          <option <?= ($emp['status']??'Active')===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?>
        </select></div>
      </div>
    </div></div>
  </div>

  <div class="grid cols-2 mt-2">
    <div class="card"><div class="card-head"><h3>Salary &amp; Bank</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Basic Salary (₹)</label><input type="number" step="0.01" name="basic_salary" value="<?= e($emp['basic_salary'] ?? 0) ?>"></div>
        <div class="form-group"><label>Salary Structure</label><input type="text" name="salary_structure" value="<?= e($emp['salary_structure'] ?? '') ?>" placeholder="e.g. Standard"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>Bank Name</label><input type="text" name="bank_name" value="<?= e($emp['bank_name'] ?? '') ?>"></div>
        <div class="form-group"><label>Account No.</label><input type="text" name="bank_account" value="<?= e($emp['bank_account'] ?? '') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>IFSC</label><input type="text" name="bank_ifsc" value="<?= e($emp['bank_ifsc'] ?? '') ?>"></div>
        <div class="form-group"><label>UPI ID</label><input type="text" name="upi_id" value="<?= e($emp['upi_id'] ?? '') ?>"></div>
      </div>
      <div class="form-row">
        <div class="form-group"><label>PAN</label><input type="text" name="pan" value="<?= e($emp['pan'] ?? '') ?>"></div>
        <div class="form-group"><label>Aadhaar / Reference</label><input type="text" name="aadhaar" value="<?= e($emp['aadhaar'] ?? '') ?>"></div>
      </div>
    </div></div>

    <div class="card"><div class="card-head"><h3>Emergency &amp; Notes</h3></div><div class="card-body">
      <div class="form-row">
        <div class="form-group"><label>Emergency Contact Name</label><input type="text" name="emergency_name" value="<?= e($emp['emergency_name'] ?? '') ?>"></div>
        <div class="form-group"><label>Emergency Phone</label><input type="tel" name="emergency_phone" value="<?= e($emp['emergency_phone'] ?? '') ?>"></div>
      </div>
      <div class="form-group"><label>Relation</label><input type="text" name="emergency_relation" value="<?= e($emp['emergency_relation'] ?? '') ?>"></div>
      <div class="form-group"><label>Notes</label><textarea name="notes"><?= e($emp['notes'] ?? '') ?></textarea></div>

      <?php if (!$id): ?>
      <div class="form-group"><label>Login Password (optional)</label>
        <input type="text" name="login_password" placeholder="Set to create an employee login">
        <div class="help">If set (with an email), an Employee login account is created automatically.</div></div>
      <?php endif; ?>
    </div></div>
  </div>

  <?php $cf = render_custom_fields('employee', $cfValues); if ($cf): ?>
  <div class="card mt-2"><div class="card-head"><h3>Custom Fields</h3></div>
    <div class="card-body"><div class="form-row-3"><?= $cf ?></div></div></div>
  <?php endif; ?>

  <div class="flex gap mt-3">
    <button class="btn btn-lg" type="submit" style="width:auto">💾 Save Employee</button>
    <a class="btn btn-outline" href="<?= url('admin/employees.php') ?>">Cancel</a>
  </div>
</form>

<?php require __DIR__ . '/../templates/footer.php'; ?>
