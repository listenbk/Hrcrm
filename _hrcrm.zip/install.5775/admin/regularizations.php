<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('attendance.regularize');
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $rid    = (int)param('id', 0, 'POST');
    $act    = param('do', '', 'POST');
    $remark = trim((string)param('review_remark', '', 'POST'));
    $reg = fetch_one("SELECT * FROM attendance_regularizations WHERE id=?", [$rid]);

    if ($reg && $reg['status'] === 'Pending' && in_array($act, ['approve','reject'], true)) {
        if ($act === 'approve') {
            // Apply the correction to the attendance row for that date.
            $eid = (int)$reg['employee_id'];
            $date = $reg['att_date'];
            $att = fetch_one("SELECT * FROM attendance WHERE employee_id=? AND att_date=?", [$eid, $date]);
            $newIn  = $reg['req_check_in']  ?: ($att['check_in']  ?? null);
            $newOut = $reg['req_check_out'] ?: ($att['check_out'] ?? null);

            $workingMinutes = 0;
            if ($newIn && $newOut) {
                $workingMinutes = max(0, (int)round((strtotime($newOut) - strtotime($newIn)) / 60));
            }
            // Resolve a sensible status when we have times.
            $statusId = $att['status_id'] ?? null;
            if ($newIn) {
                $halfAfter = (int)setting('half_day_after_minutes', 120);
                $fullDay   = (int)setting('full_day_minutes', 480);
                if ($newOut && $workingMinutes < $halfAfter && att_status('absent'))      $statusId = att_status('absent')['id'];
                elseif ($newOut && $workingMinutes < ($fullDay/2) && att_status('half_day')) $statusId = att_status('half_day')['id'];
                elseif (att_status('present'))                                             $statusId = att_status('present')['id'];
            }

            if ($att) {
                q("UPDATE attendance SET check_in=?, check_out=?, working_minutes=?, status_id=?, is_manual=1,
                     is_auto_checkout=0, admin_remark=CONCAT_WS(' | ', NULLIF(admin_remark,''), ?) WHERE id=?",
                  [$newIn, $newOut, $workingMinutes, $statusId, 'Regularized (approved)', $att['id']]);
            } else {
                q("INSERT INTO attendance (employee_id, att_date, check_in, check_out, working_minutes, status_id, is_manual, admin_remark)
                   VALUES (?,?,?,?,?,?,1,?)",
                  [$eid, $date, $newIn, $newOut, $workingMinutes, $statusId, 'Regularized (approved)']);
            }
            q("UPDATE attendance_regularizations SET status='Approved', reviewed_by=?, review_remark=?, reviewed_at=NOW() WHERE id=?",
              [$me['id'], $remark, $rid]);
            audit_log('regularization_approved','attendance',$eid,"Approved regularization for ".fmt_date($date));

            $u = fetch_col("SELECT user_id FROM employees WHERE id=?", [$eid]);
            if ($u) notify((int)$u, 'regularization_approved', 'Regularization approved',
                'Your attendance correction for '.fmt_date($date).' was approved.', url('employee/regularize.php'));
            flash_success('Regularization approved and attendance updated.');
        } else {
            q("UPDATE attendance_regularizations SET status='Rejected', reviewed_by=?, review_remark=?, reviewed_at=NOW() WHERE id=?",
              [$me['id'], $remark, $rid]);
            audit_log('regularization_rejected','attendance',(int)$reg['employee_id'],"Rejected regularization for ".fmt_date($reg['att_date']));
            $u = fetch_col("SELECT user_id FROM employees WHERE id=?", [(int)$reg['employee_id']]);
            if ($u) notify((int)$u, 'regularization_rejected', 'Regularization rejected',
                'Your attendance correction for '.fmt_date($reg['att_date']).' was rejected.', url('employee/regularize.php'));
            flash_success('Regularization rejected.');
        }
    }
    redirect('admin/regularizations.php');
}

$status = (string)param('status', 'Pending');
$where = in_array($status, ['Pending','Approved','Rejected'], true) ? "WHERE r.status=?" : "WHERE 1";
$args  = in_array($status, ['Pending','Approved','Rejected'], true) ? [$status] : [];
$rows = fetch_all(
  "SELECT r.*, e.full_name, e.emp_code, u.name AS reviewer
   FROM attendance_regularizations r
   JOIN employees e ON e.id=r.employee_id
   LEFT JOIN users u ON u.id=r.reviewed_by
   $where ORDER BY r.created_at DESC LIMIT 200", $args);
$pendingCount = (int)fetch_col("SELECT COUNT(*) FROM attendance_regularizations WHERE status='Pending'");

$pageTitle='Attendance Regularization'; $activeNav='regularizations';
require __DIR__ . '/../templates/header.php';
function reg_pill(string $s): string {
    $m=['Pending'=>'pill-warning','Approved'=>'pill-success','Rejected'=>'pill-danger'];
    return '<span class="pill '.($m[$s]??'pill-muted').'">'.e($s).'</span>';
}
?>
<div class="page-head"><div><h2>Attendance Regularization</h2>
  <div class="breadcrumb"><?= $pendingCount ?> pending</div></div>
  <form method="get"><select name="status" onchange="this.form.submit()">
    <?php foreach(['Pending','Approved','Rejected','All'] as $s): $v=$s==='All'?'':$s; ?>
      <option value="<?= $v ?>" <?= $status===$v||($s==='All'&&!in_array($status,['Pending','Approved','Rejected'],true))?'selected':'' ?>><?= $s ?></option>
    <?php endforeach; ?></select></form></div>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Date</th><th>Requested In</th><th>Requested Out</th><th>Reason</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr>
      <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
      <td><?= fmt_date($r['att_date']) ?></td>
      <td><?= $r['req_check_in']?fmt_date($r['req_check_in'],'h:i A'):'—' ?></td>
      <td><?= $r['req_check_out']?fmt_date($r['req_check_out'],'h:i A'):'—' ?></td>
      <td class="text-muted"><?= e($r['reason']) ?></td>
      <td><?= reg_pill($r['status']) ?><?php if($r['reviewer']): ?><div class="text-muted" style="font-size:11px">by <?= e($r['reviewer']) ?></div><?php endif; ?></td>
      <td class="text-right"><?php if($r['status']==='Pending'): ?>
        <button class="btn btn-sm btn-success" data-modal="regModal" onclick='regForm(<?= json_encode(["id"=>$r["id"],"do"=>"approve","name"=>$r["full_name"],"date"=>$r["att_date"]]) ?>)'>Approve</button>
        <button class="btn btn-sm btn-danger" data-modal="regModal" onclick='regForm(<?= json_encode(["id"=>$r["id"],"do"=>"reject","name"=>$r["full_name"],"date"=>$r["att_date"]]) ?>)'>Reject</button>
      <?php else: ?><span class="text-muted" style="font-size:11px"><?= $r['review_remark']?e($r['review_remark']):'—' ?></span><?php endif; ?></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="7" class="empty">No requests.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="regModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="regTitle">Review Request</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="id" id="reg_id"><input type="hidden" name="do" id="reg_do">
    <p class="text-muted" id="reg_info"></p>
    <div class="form-group"><label>Remark (optional)</label><input type="text" name="review_remark"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn" id="reg_submit">Confirm</button></div>
</form></div></div>
<script>function regForm(o){document.getElementById('reg_id').value=o.id;document.getElementById('reg_do').value=o.do;
  document.getElementById('regTitle').textContent=(o.do==='approve'?'Approve':'Reject')+' Regularization';
  document.getElementById('reg_info').textContent=o.name+' — '+o.date;
  var b=document.getElementById('reg_submit');b.textContent=o.do==='approve'?'Approve & Update':'Reject';
  b.className='btn '+(o.do==='approve'?'btn-success':'btn-danger');}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
