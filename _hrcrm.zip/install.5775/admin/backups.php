<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/backup_lib.php';
require_perm('backups.manage');

// Secure download (must run before any HTML output).
$dl = (string)param('download', '');
if ($dl !== '') {
    $path = db_backup_path($dl);
    if ($path) {
        audit_log('backup_downloaded','backup',null, basename($path));
        header('Content-Type: application/gzip');
        header('Content-Disposition: attachment; filename="' . basename($path) . '"');
        header('Content-Length: ' . filesize($path));
        readfile($path);
        exit;
    }
    flash_error('Backup file not found.');
    redirect('admin/backups.php');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    if ($act === 'run') {
        [$ok, $msg] = db_backup_run();
        $ok ? flash_success($msg) : flash_error($msg);
        audit_log('backup_created','backup',null,$ok ? $msg : 'FAILED: '.$msg);
    } elseif ($act === 'delete') {
        $name = (string)param('name', '', 'POST');
        if (db_backup_delete($name)) { audit_log('backup_deleted','backup',null,basename($name)); flash_success('Backup deleted.'); }
        else flash_error('Could not delete that backup.');
    }
    redirect('admin/backups.php');
}

$backups = db_backup_list();
$keep    = (int)setting('backup_keep', 14);
$totalSz = array_sum(array_column($backups, 'size'));
$pageTitle='Database Backups'; $activeNav='backups';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Database Backups</h2>
  <div class="breadcrumb"><?= count($backups) ?> backup(s) · <?= e(db_human_size($totalSz)) ?> · keeping newest <?= $keep ?></div></div>
  <form method="post" data-confirm="Create a full database backup now?">
    <?= csrf_field() ?><input type="hidden" name="do" value="run">
    <button class="btn">💾 Backup Now</button></form>
</div>

<div class="alert alert-info">Backups are stored on the server under <code>storage/backups/</code> and pruned to the newest <?= $keep ?>.
  Download important ones to keep them off-server. Schedule <code>cron/backup_db.php</code> daily for automatic backups.</div>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Backup File</th><th>Created</th><th class="num">Size</th><th></th></tr></thead>
  <tbody><?php foreach($backups as $b): ?>
    <tr>
      <td><b><?= e($b['name']) ?></b></td>
      <td class="text-muted"><?= fmt_date(date('Y-m-d H:i:s', $b['time']), 'd M Y h:i A') ?></td>
      <td class="num"><?= e(db_human_size($b['size'])) ?></td>
      <td class="text-right">
        <a class="btn btn-sm btn-outline" href="?download=<?= urlencode($b['name']) ?>">⬇️ Download</a>
        <form method="post" style="display:inline" data-confirm="Delete this backup permanently?">
          <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="name" value="<?= e($b['name']) ?>">
          <button class="btn btn-sm btn-danger">Delete</button></form>
      </td>
    </tr>
  <?php endforeach; if(!$backups): ?><tr><td colspan="4" class="empty">No backups yet. Click “Backup Now”.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
