<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('assets.manage');   // HR + Super Admin only (server-side)
$me = current_user();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');

    if ($act === 'save') {
        $id     = (int)param('id', 0, 'POST');
        $type   = trim((string)param('asset_type', '', 'POST'));
        $brand  = trim((string)param('brand', '', 'POST'));
        $model  = trim((string)param('model', '', 'POST'));
        $serial = trim((string)param('serial_no', '', 'POST'));
        $pdate  = param('purchase_date', '', 'POST') ?: null;
        $cond   = trim((string)param('condition', 'Good', 'POST')) ?: 'Good';
        $remarks= trim((string)param('remarks', '', 'POST'));
        if ($type === '') { flash_error('Asset type is required.'); redirect('admin/assets.php'); }
        if ($id) {
            q("UPDATE assets SET asset_type=?, brand=?, model=?, serial_no=?, purchase_date=?, `condition`=?, remarks=? WHERE id=?",
              [$type,$brand,$model,$serial,$pdate,$cond,$remarks,$id]);
            audit_log('asset_edited','asset',$id,"Edited asset $type");
            flash_success('Asset updated.');
        } else {
            $code = next_asset_code();
            q("INSERT INTO assets (asset_code,asset_type,brand,model,serial_no,purchase_date,`condition`,status,remarks,created_by)
               VALUES (?,?,?,?,?,?,?, 'Available', ?, ?)",
              [$code,$type,$brand,$model,$serial,$pdate,$cond,$remarks,$me['id']]);
            audit_log('asset_created','asset',insert_id(),"Created asset $code ($type)");
            flash_success("Asset $code added.");
        }
        redirect('admin/assets.php');
    }

    if ($act === 'allocate') {
        [$ok,$msg] = allocate_asset(
            (int)param('asset_id',0,'POST'), (int)param('employee_id',0,'POST'),
            param('allocation_date',date('Y-m-d'),'POST') ?: date('Y-m-d'),
            trim((string)param('condition','Good','POST')) ?: 'Good',
            trim((string)param('remark','','POST')), (int)$me['id']);
        $ok ? flash_success($msg) : flash_error($msg);
        redirect('admin/assets.php');
    }

    if ($act === 'return') {
        [$ok,$msg] = return_asset(
            (int)param('asset_id',0,'POST'),
            trim((string)param('new_status','Available','POST')),
            trim((string)param('return_condition','Good','POST')) ?: 'Good',
            trim((string)param('return_remark','','POST')), (int)$me['id'],
            param('return_date',date('Y-m-d'),'POST') ?: date('Y-m-d'));
        $ok ? flash_success($msg) : flash_error($msg);
        redirect('admin/assets.php');
    }

    if ($act === 'status') {
        // Direct status change for non-allocated assets (Repair/Retired/etc.)
        $id=(int)param('id',0,'POST'); $st=trim((string)param('status','','POST'));
        $asset=fetch_one("SELECT * FROM assets WHERE id=?", [$id]);
        $allowed=['Available','Under Repair','Damaged','Lost','Retired'];
        if ($asset && $asset['status']!=='Allocated' && in_array($st,$allowed,true)) {
            q("UPDATE assets SET status=? WHERE id=?", [$st,$id]);
            audit_log('asset_status','asset',$id,"Status → $st for {$asset['asset_code']}");
            flash_success("Status updated to $st.");
        } else {
            flash_error('Cannot change status (an allocated asset must be returned first).');
        }
        redirect('admin/assets.php');
    }
}

$sum = asset_summary();
$pending = fetch_all(
  "SELECT rr.*, a.asset_code, a.asset_type, e.full_name, e.emp_code
   FROM asset_return_requests rr JOIN assets a ON a.id=rr.asset_id JOIN employees e ON e.id=rr.employee_id
   WHERE rr.status='Pending' ORDER BY rr.created_at DESC");

$q      = trim((string)param('q',''));
$typeF  = (string)param('type','');
$statusF= (string)param('status','');
$where=['1=1']; $args=[];
if ($q!==''){ $where[]="(a.asset_code LIKE ? OR a.serial_no LIKE ? OR a.brand LIKE ? OR a.model LIKE ? OR e.emp_code LIKE ? OR e.full_name LIKE ?)";
  $like="%$q%"; array_push($args,$like,$like,$like,$like,$like,$like); }
if ($typeF!==''){ $where[]="a.asset_type=?"; $args[]=$typeF; }
if ($statusF!==''){ $where[]="a.status=?"; $args[]=$statusF; }
$assets = fetch_all(
  "SELECT a.*, e.emp_code, e.full_name FROM assets a LEFT JOIN employees e ON e.id=a.assigned_employee_id
   WHERE ".implode(' AND ',$where)." ORDER BY a.asset_code DESC", $args);

// Everyone except resigned/terminated staff (shows Employee ID for selection)
$emps = fetch_all("SELECT id, emp_code, full_name, status FROM employees WHERE status NOT IN ('Resigned','Terminated') ORDER BY emp_code");

$pageTitle='Asset Management'; $activeNav='assets';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>🖥️ Asset Management</h2><div class="breadcrumb"><?= $sum['total'] ?> asset(s)</div></div>
  <button class="btn" data-modal="assetModal" onclick="assetForm()">➕ Add Asset</button>
</div>

<div class="grid cols-4 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-brand">📦</div><div><div class="label">Total Assets</div><div class="value"><?= $sum['total'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div><div><div class="label">Available</div><div class="value"><?= $sum['Available'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">📲</div><div><div class="label">Allocated</div><div class="value"><?= $sum['Allocated'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">🛠️</div><div><div class="label">Under Repair</div><div class="value"><?= $sum['Under Repair'] ?></div></div></div></div>
</div>
<div class="grid cols-3 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-slate">↩️</div><div><div class="label">Returned</div><div class="value"><?= $sum['Returned'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">⚠️</div><div><div class="label">Damaged / Lost</div><div class="value"><?= $sum['damaged_lost'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-slate">🚫</div><div><div class="label">Retired</div><div class="value"><?= $sum['Retired'] ?></div></div></div></div>
</div>

<?php if ($pending): ?>
<div class="card mb-2" style="border-left:4px solid var(--warning)">
  <div class="card-head"><h3>📥 Pending Return Requests (<?= count($pending) ?>)</h3></div>
  <div class="table-wrap"><table class="data">
    <thead><tr><th>Asset</th><th>Employee</th><th>Reason</th><th>Requested</th><th></th></tr></thead>
    <tbody><?php foreach($pending as $p): ?>
      <tr><td><b><?= e($p['asset_code']) ?></b> · <?= e($p['asset_type']) ?></td>
      <td><?= e($p['full_name']) ?> (<?= e($p['emp_code']) ?>)</td>
      <td class="text-muted"><?= e($p['reason'] ?: '—') ?></td>
      <td class="text-muted"><?= fmt_date($p['created_at'],'d M Y') ?></td>
      <td class="text-right"><button class="btn btn-sm btn-success" data-modal="returnModal"
        onclick='returnForm(<?= json_encode(["asset_id"=>$p["asset_id"],"asset_code"=>$p["asset_code"],"who"=>$p["full_name"]]) ?>)'>Receive &amp; Return</button></td></tr>
    <?php endforeach; ?></tbody>
  </table></div>
</div>
<?php endif; ?>

<form method="get" class="filters">
  <div class="form-group"><label>Search</label><input type="search" name="q" value="<?= e($q) ?>" placeholder="Code, serial, brand, employee"></div>
  <div class="form-group"><label>Type</label><select name="type"><option value="">All</option>
    <?php foreach(asset_types() as $t): ?><option <?= $typeF===$t?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>Status</label><select name="status"><option value="">All</option>
    <?php foreach(['Available','Allocated','Under Repair','Damaged','Lost','Retired'] as $st): ?><option <?= $statusF===$st?'selected':'' ?>><?= $st ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Asset ID</th><th>Type / Brand</th><th>Serial / IMEI</th><th>Assigned To</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($assets as $a): ?>
    <tr>
      <td><b><?= e($a['asset_code']) ?></b><div class="text-muted" style="font-size:11px"><?= e($a['condition']) ?></div></td>
      <td><?= e($a['asset_type']) ?><div class="text-muted" style="font-size:11px"><?= e(trim($a['brand'].' '.$a['model'])) ?: '—' ?></div></td>
      <td class="text-muted"><?= e($a['serial_no'] ?: '—') ?></td>
      <td><?= $a['full_name'] ? e($a['full_name']).' <span class="text-muted">('.e($a['emp_code']).')</span>' : '<span class="text-muted">—</span>' ?>
        <?php if($a['allocation_date']): ?><div class="text-muted" style="font-size:11px">since <?= fmt_date($a['allocation_date']) ?></div><?php endif; ?></td>
      <td><span class="pill <?= asset_status_pill($a['status']) ?>"><?= e($a['status']) ?></span></td>
      <td class="text-right" style="white-space:nowrap">
        <a class="btn btn-sm btn-outline" href="<?= url('admin/asset_view.php?id='.$a['id']) ?>">View</a>
        <?php if($a['status']==='Available'): ?>
          <button class="btn btn-sm" data-modal="allocModal" onclick='allocForm(<?= json_encode(["asset_id"=>$a["id"],"asset_code"=>$a["asset_code"],"type"=>$a["asset_type"],"condition"=>$a["condition"]]) ?>)'>Allocate</button>
        <?php elseif($a['status']==='Allocated'): ?>
          <button class="btn btn-sm btn-warning" data-modal="returnModal" onclick='returnForm(<?= json_encode(["asset_id"=>$a["id"],"asset_code"=>$a["asset_code"],"who"=>$a["full_name"]]) ?>)'>Return</button>
        <?php endif; ?>
      </td>
    </tr>
  <?php endforeach; if(!$assets): ?><tr><td colspan="6" class="empty">No assets found. Click “Add Asset” to create one.</td></tr><?php endif; ?></tbody>
</table></div></div>

<!-- Add/Edit Asset modal -->
<div class="modal-overlay" id="assetModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="assetTitle">Add Asset</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="as_id">
    <div class="form-row">
      <div class="form-group"><label>Asset Type <span class="req">*</span></label><select name="asset_type" id="as_type" required>
        <?php foreach(asset_types() as $t): ?><option><?= $t ?></option><?php endforeach; ?></select></div>
      <div class="form-group"><label>Condition</label><select name="condition" id="as_cond">
        <?php foreach(asset_conditions() as $c): ?><option><?= $c ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Brand</label><input type="text" name="brand" id="as_brand"></div>
      <div class="form-group"><label>Model</label><input type="text" name="model" id="as_model"></div>
    </div>
    <div class="form-row">
      <div class="form-group"><label>Serial No. / IMEI</label><input type="text" name="serial_no" id="as_serial"></div>
      <div class="form-group"><label>Purchase Date</label><input type="date" name="purchase_date" id="as_pdate"></div>
    </div>
    <div class="form-group"><label>Remarks</label><input type="text" name="remarks" id="as_remarks"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save Asset</button></div>
</form></div></div>

<!-- Allocate modal -->
<div class="modal-overlay" id="allocModal"><div class="modal"><form method="post" data-confirm="Allocate this asset to the selected employee?">
  <div class="modal-head"><h3>Allocate Asset</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="allocate"><input type="hidden" name="asset_id" id="al_asset">
    <p class="text-muted">Asset: <b id="al_code"></b></p>
    <div class="form-group"><label>Employee (by ID / name) <span class="req">*</span></label><select name="employee_id" required>
      <option value="">— Select employee —</option>
      <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>"><?= e($em['emp_code'].' — '.$em['full_name'].($em['status']!=='Active'?' ('.$em['status'].')':'')) ?></option><?php endforeach; ?></select></div>
    <div class="form-row">
      <div class="form-group"><label>Allocation Date</label><input type="date" name="allocation_date" value="<?= date('Y-m-d') ?>"></div>
      <div class="form-group"><label>Condition</label><select name="condition" id="al_cond"><?php foreach(asset_conditions() as $c): ?><option><?= $c ?></option><?php endforeach; ?></select></div>
    </div>
    <div class="form-group"><label>Remarks</label><input type="text" name="remark"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-success">Allocate</button></div>
</form></div></div>

<!-- Return modal -->
<div class="modal-overlay" id="returnModal"><div class="modal"><form method="post" data-confirm="Record this asset as returned to company inventory?">
  <div class="modal-head"><h3>Return Asset</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="return"><input type="hidden" name="asset_id" id="rt_asset">
    <p class="text-muted">Asset <b id="rt_code"></b> from <b id="rt_who"></b> → back to company inventory.</p>
    <div class="form-row">
      <div class="form-group"><label>New Status</label><select name="new_status">
        <?php foreach(['Available','Under Repair','Damaged','Lost','Retired'] as $st): ?><option><?= $st ?></option><?php endforeach; ?></select></div>
      <div class="form-group"><label>Return Date</label><input type="date" name="return_date" value="<?= date('Y-m-d') ?>"></div>
    </div>
    <div class="form-group"><label>Condition on Return</label><select name="return_condition"><?php foreach(asset_conditions() as $c): ?><option><?= $c ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Remarks</label><input type="text" name="return_remark"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn btn-warning">Confirm Return</button></div>
</form></div></div>

<script>
function assetForm(d){d=d||{};document.getElementById('assetTitle').textContent=d.id?'Edit Asset':'Add Asset';
  as_id.value=d.id||'';as_type.value=d.asset_type||'Mobile';as_cond.value=d.condition||'Good';
  as_brand.value=d.brand||'';as_model.value=d.model||'';as_serial.value=d.serial_no||'';as_pdate.value=d.purchase_date||'';as_remarks.value=d.remarks||'';}
function allocForm(d){al_asset.value=d.asset_id;al_code.textContent=d.asset_code+' · '+d.type;if(d.condition)al_cond.value=d.condition;}
function returnForm(d){rt_asset.value=d.asset_id;rt_code.textContent=d.asset_code;rt_who.textContent=d.who||'the employee';}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
