<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_admin();

$today = date('Y-m-d');
$thisMonth = date('Y-m');

// Employee counters
$totalEmp  = (int)fetch_col("SELECT COUNT(*) FROM employees WHERE is_staff=0");
$activeEmp = (int)fetch_col("SELECT COUNT(*) FROM employees WHERE status='Active' AND is_staff=0");
$newEmp    = (int)fetch_col("SELECT COUNT(*) FROM employees WHERE is_staff=0 AND joining_date >= (CURRENT_DATE - INTERVAL 30 DAY)");

$att = attendance_dashboard($today);

// Payroll counters (this month)
$monthlyPayroll = (float)fetch_col("SELECT COALESCE(SUM(net_salary),0) FROM payroll WHERE pay_month=?", [$thisMonth]);
$salaryPaid     = (float)fetch_col("SELECT COALESCE(SUM(paid_amount),0) FROM payroll WHERE pay_month=?", [$thisMonth]);
$salaryPending  = (float)fetch_col("SELECT COALESCE(SUM(pending_amount),0) FROM payroll WHERE pay_month=?", [$thisMonth]);
$emiRecovered   = (float)fetch_col("SELECT COALESCE(SUM(amount),0) FROM emi_schedules WHERE status='Paid' AND due_month=?", [$thisMonth]);
$outstandingAdv = (float)fetch_col("SELECT COALESCE(SUM(balance_amount),0) FROM employee_advances WHERE status='Active'");

// Live attendance table
$live = fetch_all(
    "SELECT e.emp_code, e.full_name, a.check_in, a.check_out, a.working_minutes, a.late_minutes,
            a.early_minutes, a.admin_remark, s.name AS status_name, s.color
     FROM employees e
     LEFT JOIN attendance a ON a.employee_id=e.id AND a.att_date=?
     LEFT JOIN attendance_statuses s ON s.id=a.status_id
     WHERE e.status='Active' AND e.is_staff=0
     ORDER BY e.full_name", [$today]);

// Pending approvals (Approval Centre summary)
$pendingLeavesCount = (int)fetch_col("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'");
$pendingOTCount = (int)fetch_col("SELECT COUNT(*) FROM overtime WHERE status IN ('Detected','Pending Approval','HR Reviewed')");

// Chart: last 14 days present / late
$trend = [];
for ($i = 13; $i >= 0; $i--) {
    $d = date('Y-m-d', strtotime("-$i day"));
    $present = (int)fetch_col(
        "SELECT COUNT(*) FROM attendance a WHERE a.att_date=? AND a.check_in IS NOT NULL", [$d]);
    $late = (int)fetch_col("SELECT COUNT(*) FROM attendance WHERE att_date=? AND late_minutes>0", [$d]);
    $trend[] = ['label' => date('d M', strtotime($d)), 'present' => $present, 'late' => $late];
}

// Chart: headcount by department (active, non-staff)
$deptRows = fetch_all(
    "SELECT COALESCE(d.name,'No Dept') AS name, COUNT(*) c
     FROM employees e LEFT JOIN departments d ON d.id=e.department_id
     WHERE e.status='Active' AND e.is_staff=0
     GROUP BY d.name ORDER BY c DESC");

// Chart: payroll net cost + OT hours, last 6 months
$payTrend = [];
for ($i = 5; $i >= 0; $i--) {
    $m = date('Y-m', strtotime("first day of -$i month"));
    $net = (float)fetch_col("SELECT COALESCE(SUM(net_salary),0) FROM payroll WHERE pay_month=?", [$m]);
    $otH = (float)fetch_col("SELECT COALESCE(SUM(actual_hours),0) FROM overtime WHERE DATE_FORMAT(ot_date,'%Y-%m')=?", [$m]);
    $payTrend[] = ['label' => date('M y', strtotime($m.'-01')), 'net' => round($net,2), 'ot' => round($otH,1)];
}

$pageTitle = 'Dashboard'; $activeNav = 'dashboard';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head">
  <div><h2>Welcome back, <?= e(explode(' ', $u['name'])[0]) ?> 👋</h2>
    <div class="breadcrumb"><?= fmt_date($today, 'l, d F Y') ?> · <span id="liveClock"></span></div>
  </div>
  <a class="btn" href="<?= url('admin/payroll_generate.php') ?>">⚙️ Generate Payroll</a>
</div>

<?php require __DIR__ . '/../templates/notices_widget.php'; ?>

<!-- Employee stats -->
<div class="grid cols-4">
  <div class="card"><div class="stat"><div class="icon bg-brand">👥</div>
    <div><div class="label">Total Employees</div><div class="value"><?= $totalEmp ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div>
    <div><div class="label">Active</div><div class="value"><?= $activeEmp ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🆕</div>
    <div><div class="label">New (30 days)</div><div class="value"><?= $newEmp ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-violet">🏦</div>
    <div><div class="label">Outstanding Advances</div><div class="value" style="font-size:19px"><?= money($outstandingAdv) ?></div></div></div></div>
</div>

<!-- Attendance stats -->
<h3 class="mt-3" style="margin-bottom:12px">Today's Attendance</h3>
<div class="grid cols-4">
  <div class="card"><div class="stat"><div class="icon bg-green">🟢</div>
    <div><div class="label">Present</div><div class="value"><?= $att['present'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏰</div>
    <div><div class="label">Late</div><div class="value"><?= $att['late'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">🔴</div>
    <div><div class="label">Not Checked In</div><div class="value"><?= $att['not_checked_in'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🌴</div>
    <div><div class="label">On Leave</div><div class="value"><?= $att['leave'] ?></div></div></div></div>
</div>

<div class="grid cols-3 mt-2">
  <div class="card"><div class="stat"><div class="icon bg-slate">💼</div>
    <div><div class="label">Currently Working</div><div class="value"><?= $att['working'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-pink">🚪</div>
    <div><div class="label">Early Leave</div><div class="value"><?= $att['early'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-brand">↩️</div>
    <div><div class="label">Checked Out</div><div class="value"><?= $att['checked_out'] ?></div></div></div></div>
</div>

<!-- Payroll stats -->
<h3 class="mt-3" style="margin-bottom:12px">Payroll · <?= fmt_date($today, 'F Y') ?></h3>
<div class="grid cols-4">
  <div class="card"><div class="stat"><div class="icon bg-brand">💰</div>
    <div><div class="label">Monthly Payroll</div><div class="value" style="font-size:18px"><?= money($monthlyPayroll) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✔️</div>
    <div><div class="label">Salary Paid</div><div class="value" style="font-size:18px"><?= money($salaryPaid) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">⌛</div>
    <div><div class="label">Salary Pending</div><div class="value" style="font-size:18px"><?= money($salaryPending) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-violet">📆</div>
    <div><div class="label">EMI Recovered</div><div class="value" style="font-size:18px"><?= money($emiRecovered) ?></div></div></div></div>
</div>

<!-- Approval Centre -->
<h3 class="mt-3" style="margin-bottom:12px">Pending Approvals</h3>
<div class="grid cols-2">
  <a class="card" href="<?= url('admin/leaves.php') ?>" style="text-decoration:none;color:inherit"><div class="stat"><div class="icon bg-amber">📝</div>
    <div><div class="label">Leave Requests</div><div class="value"><?= $pendingLeavesCount ?></div></div></div></a>
  <a class="card" href="<?= url('admin/overtime.php') ?>" style="text-decoration:none;color:inherit"><div class="stat"><div class="icon bg-blue">⏱️</div>
    <div><div class="label">Overtime Requests</div><div class="value"><?= $pendingOTCount ?></div></div></div></a>
</div>

<!-- Chart + live table -->
<div class="grid cols-2 mt-3">
  <div class="card">
    <div class="card-head"><h3>Attendance Trend (14 days)</h3></div>
    <div class="card-body"><canvas id="trendChart" height="150"></canvas></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>Leave Requests Pending</h3>
      <a class="btn btn-sm btn-outline" href="<?= url('admin/leaves.php') ?>">View all</a></div>
    <div class="card-body">
      <?php
      $pend = fetch_all("SELECT lr.*, e.full_name, lt.name AS type_name FROM leave_requests lr
        JOIN employees e ON e.id=lr.employee_id JOIN leave_types lt ON lt.id=lr.leave_type_id
        WHERE lr.status='Pending' ORDER BY lr.created_at DESC LIMIT 6");
      if (!$pend): ?><div class="empty">No pending leave requests 🎉</div><?php else: ?>
      <div class="table-wrap"><table class="data">
        <thead><tr><th>Employee</th><th>Type</th><th>Dates</th><th>Days</th></tr></thead>
        <tbody><?php foreach ($pend as $p): ?>
          <tr><td><?= e($p['full_name']) ?></td><td><?= e($p['type_name']) ?></td>
          <td><?= fmt_date($p['start_date']) ?> → <?= fmt_date($p['end_date']) ?></td>
          <td><?= e($p['total_days']) ?></td></tr>
        <?php endforeach; ?></tbody>
      </table></div>
      <?php endif; ?>
    </div>
  </div>
</div>

<!-- Analytics charts -->
<div class="grid cols-2 mt-3">
  <div class="card">
    <div class="card-head"><h3>Headcount by Department</h3></div>
    <div class="card-body"><canvas id="deptChart" height="150"></canvas></div>
  </div>
  <div class="card">
    <div class="card-head"><h3>Payroll Cost &amp; Overtime (6 months)</h3></div>
    <div class="card-body"><canvas id="payChart" height="150"></canvas></div>
  </div>
</div>

<div class="card mt-3">
  <div class="card-head"><h3><span class="dot-live"></span>Live Employee Attendance</h3>
    <a class="btn btn-sm btn-outline" href="<?= url('admin/attendance_today.php') ?>">Full view</a></div>
  <div class="table-wrap">
    <table class="data">
      <thead><tr><th>Employee</th><th>Check In</th><th>Status</th><th>Working Hours</th><th>Check Out</th><th>Remarks</th></tr></thead>
      <tbody>
      <?php foreach ($live as $r): ?>
        <tr>
          <td><b><?= e($r['full_name']) ?></b><div class="text-muted" style="font-size:11px"><?= e($r['emp_code']) ?></div></td>
          <td><?= $r['check_in'] ? fmt_date($r['check_in'], 'h:i A') : '—' ?>
              <?php if ($r['late_minutes']>0): ?><span class="pill pill-warning">+<?= $r['late_minutes'] ?>m</span><?php endif; ?></td>
          <td><?php if ($r['status_name']): ?>
              <span class="badge" style="background:<?= e($r['color']) ?>"><?= e($r['status_name']) ?></span>
              <?php else: ?><span class="pill pill-muted">Not marked</span><?php endif; ?></td>
          <td><?= $r['working_minutes'] ? fmt_hm((int)$r['working_minutes']) : ($r['check_in'] && !$r['check_out'] ? '<span class="text-muted">In progress…</span>' : '—') ?></td>
          <td><?= $r['check_out'] ? fmt_date($r['check_out'], 'h:i A') : '—' ?></td>
          <td class="text-muted"><?= e($r['admin_remark'] ?: '—') ?></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php
$labels = json_encode(array_column($trend, 'label'));
$present = json_encode(array_column($trend, 'present'));
$lateD  = json_encode(array_column($trend, 'late'));
$deptLabels = json_encode(array_column($deptRows, 'name'));
$deptData   = json_encode(array_map('intval', array_column($deptRows, 'c')));
$payLabels  = json_encode(array_column($payTrend, 'label'));
$payNet     = json_encode(array_column($payTrend, 'net'));
$payOt      = json_encode(array_column($payTrend, 'ot'));
$curSym     = json_encode(setting('currency_symbol', '₹'));
$extraScript = <<<HTML
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
<script>
var PALETTE=['#0f766e','#2563eb','#f59e0b','#db2777','#7c3aed','#16a34a','#dc2626','#0891b2','#ca8a04','#4f46e5'];
new Chart(document.getElementById('trendChart'),{
  type:'bar',
  data:{labels:$labels,datasets:[
    {label:'Present',data:$present,backgroundColor:'#0f766e',borderRadius:5},
    {label:'Late',data:$lateD,backgroundColor:'#f59e0b',borderRadius:5}
  ]},
  options:{plugins:{legend:{position:'bottom'}},scales:{y:{beginAtZero:true,ticks:{precision:0}}}}
});
var dc=document.getElementById('deptChart');
if(dc) new Chart(dc,{
  type:'doughnut',
  data:{labels:$deptLabels,datasets:[{data:$deptData,backgroundColor:PALETTE}]},
  options:{plugins:{legend:{position:'right'}}}
});
var pc=document.getElementById('payChart');
if(pc) new Chart(pc,{
  data:{labels:$payLabels,datasets:[
    {type:'bar',label:'Net Payroll ('+$curSym+')',data:$payNet,backgroundColor:'#2563eb',borderRadius:5,yAxisID:'y'},
    {type:'line',label:'Overtime (hrs)',data:$payOt,borderColor:'#f59e0b',backgroundColor:'#f59e0b',tension:0.3,yAxisID:'y1'}
  ]},
  options:{plugins:{legend:{position:'bottom'}},scales:{
    y:{beginAtZero:true,position:'left'},
    y1:{beginAtZero:true,position:'right',grid:{drawOnChartArea:false}}
  }}
});
</script>
HTML;
require __DIR__ . '/../templates/footer.php';
