<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('audit.view');

$search = trim((string)param('q',''));
$userId = (int)param('user', 0);
$action = trim((string)param('action',''));
$from   = trim((string)param('from',''));
$to     = trim((string)param('to',''));
$export = param('export','');

$where = []; $args = [];
if ($search !== '') { $where[] = "(a.action LIKE ? OR a.description LIKE ? OR u.name LIKE ?)"; $like="%$search%"; array_push($args,$like,$like,$like); }
if ($userId > 0)    { $where[] = "a.user_id = ?"; $args[] = $userId; }
if ($action !== '') { $where[] = "a.action = ?"; $args[] = $action; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$from)) { $where[] = "a.created_at >= ?"; $args[] = "$from 00:00:00"; }
if (preg_match('/^\d{4}-\d{2}-\d{2}$/',$to))   { $where[] = "a.created_at <= ?"; $args[] = "$to 23:59:59"; }
$whereSql = $where ? ('WHERE '.implode(' AND ', $where)) : '';

// CSV export (all matching rows, capped for safety).
if ($export === 'csv') {
    $rows = fetch_all("SELECT a.created_at, u.name AS user_name, a.action, a.entity, a.entity_id, a.description, a.ip_address
        FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id $whereSql ORDER BY a.created_at DESC LIMIT 10000", $args);
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment; filename="audit_logs.csv"');
    $out = fopen('php://output','w');
    fputcsv($out, ['Date/Time','User','Action','Entity','Entity ID','Description','IP']);
    foreach ($rows as $r) fputcsv($out, [$r['created_at'],$r['user_name']?:'System',$r['action'],$r['entity'],$r['entity_id'],$r['description'],$r['ip_address']]);
    fclose($out); exit;
}

[$limit,$offset,$page]=paginate(30);
$total=(int)fetch_col("SELECT COUNT(*) FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id $whereSql",$args);
$rows=fetch_all("SELECT a.*, u.name AS user_name FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
  $whereSql ORDER BY a.created_at DESC LIMIT $limit OFFSET $offset",$args);
$pages=max(1,(int)ceil($total/$limit));

$users   = fetch_all("SELECT id,name FROM users ORDER BY name");
$actions = fetch_all("SELECT DISTINCT action FROM audit_logs ORDER BY action");

$pageTitle='Audit Logs'; $activeNav='audit';
require __DIR__ . '/../templates/header.php';
$qs = $_GET; unset($qs['export'],$qs['page']);
?>
<div class="page-head"><div><h2>Audit Logs</h2><div class="breadcrumb"><?= $total ?> entries</div></div>
  <a class="btn btn-outline" href="?<?= e(http_build_query(array_merge($qs,['export'=>'csv']))) ?>">⬇️ Export CSV</a></div>

<form method="get" class="filters">
  <div class="form-group"><label>Search</label><input type="search" name="q" value="<?= e($search) ?>" placeholder="Action, user, description"></div>
  <div class="form-group"><label>User</label><select name="user"><option value="0">All</option>
    <?php foreach($users as $usr): ?><option value="<?= $usr['id'] ?>" <?= $userId==$usr['id']?'selected':'' ?>><?= e($usr['name']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>Action</label><select name="action"><option value="">All</option>
    <?php foreach($actions as $a): ?><option value="<?= e($a['action']) ?>" <?= $action===$a['action']?'selected':'' ?>><?= e($a['action']) ?></option><?php endforeach; ?></select></div>
  <div class="form-group"><label>From</label><input type="date" name="from" value="<?= e($from) ?>"></div>
  <div class="form-group"><label>To</label><input type="date" name="to" value="<?= e($to) ?>"></div>
  <div class="form-group"><button class="btn btn-outline">Filter</button>
    <a class="btn btn-sm" href="<?= url('admin/audit_logs.php') ?>" style="margin-left:6px">Reset</a></div>
</form>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>User</th><th>Action</th><th>Entity</th><th>Description</th><th>IP</th><th>Date/Time</th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><?= e($r['user_name'] ?: 'System') ?></td>
    <td><span class="pill pill-info"><?= e($r['action']) ?></span></td>
    <td><?= e($r['entity'] ?: '—') ?><?= $r['entity_id']?' #'.$r['entity_id']:'' ?></td>
    <td class="text-muted"><?= e($r['description'] ?: '—') ?></td>
    <td class="text-muted"><?= e($r['ip_address'] ?: '—') ?></td>
    <td class="text-muted"><?= fmt_date($r['created_at'],'d M Y h:i A') ?></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No logs match your filters.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php if($pages>1): ?><div class="flex gap mt-2" style="justify-content:center">
  <?php for($p=max(1,$page-3);$p<=min($pages,$page+3);$p++): ?>
    <a class="btn btn-sm <?= $p==$page?'':'btn-outline' ?>" href="?<?= e(http_build_query(array_merge($_GET,['page'=>$p]))) ?>"><?= $p ?></a>
  <?php endfor; ?></div><?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
