<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('shifts.manage');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $act = param('do', '', 'POST');
    if ($act === 'save') {
        $sid   = (int)param('id', 0, 'POST');
        $name  = trim((string)param('name', '', 'POST'));
        $start = trim((string)param('start_time', '', 'POST')) ?: '10:30';
        $end   = trim((string)param('end_time', '', 'POST')) ?: '19:00';
        $active= param('is_active', 0, 'POST') ? 1 : 0;
        if ($name !== '') {
            if ($sid) {
                q("UPDATE shifts SET name=?, start_time=?, end_time=?, is_active=? WHERE id=?",
                  [$name, $start.':00', $end.':00', $active, $sid]);
                audit_log('shift_edited','shift',$sid,$name);
            } else {
                q("INSERT INTO shifts (name, start_time, end_time, is_active) VALUES (?,?,?,?)",
                  [$name, $start.':00', $end.':00', $active]);
                audit_log('shift_created','shift',insert_id(),$name);
            }
            flash_success('Shift saved.');
        } else {
            flash_error('Shift name is required.');
        }
    } elseif ($act === 'delete') {
        $sid = (int)param('id', 0, 'POST');
        $inUse = (int)fetch_col("SELECT COUNT(*) FROM employees WHERE shift_id=?", [$sid]);
        if ($inUse > 0) {
            flash_error("Cannot delete — {$inUse} employee(s) are assigned this shift. Reassign them first.");
        } else {
            q("DELETE FROM shifts WHERE id=?", [$sid]);
            audit_log('shift_deleted','shift',$sid);
            flash_success('Shift deleted.');
        }
    }
    redirect('admin/shifts.php');
}

$rows = fetch_all("SELECT s.*, (SELECT COUNT(*) FROM employees e WHERE e.shift_id=s.id) emp_count FROM shifts s ORDER BY s.name");
$pageTitle='Shifts'; $activeNav='shifts';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Shift Management</h2>
  <div class="breadcrumb">Assign shifts to employees in <b>Add / Edit Employee</b>. Employees with no shift use the company office times.</div></div>
  <button class="btn" data-modal="shiftModal" onclick="shiftForm()">➕ Add Shift</button></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Name</th><th>Start</th><th>End</th><th>Employees</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach ($rows as $r): ?>
    <tr><td><b><?= e($r['name']) ?></b></td>
    <td><?= e(substr($r['start_time'],0,5)) ?></td>
    <td><?= e(substr($r['end_time'],0,5)) ?></td>
    <td><?= (int)$r['emp_count'] ?></td>
    <td><span class="pill <?= $r['is_active']?'pill-success':'pill-muted' ?>"><?= $r['is_active']?'Active':'Inactive' ?></span></td>
    <td class="text-right">
      <button class="btn btn-sm btn-outline" data-modal="shiftModal"
        onclick='shiftForm(<?= json_encode(["id"=>$r["id"],"name"=>$r["name"],"start"=>substr($r["start_time"],0,5),"end"=>substr($r["end_time"],0,5),"is_active"=>$r["is_active"]]) ?>)'>Edit</button>
      <form method="post" style="display:inline" data-confirm="Delete this shift?">
        <?= csrf_field() ?><input type="hidden" name="do" value="delete"><input type="hidden" name="id" value="<?= $r['id'] ?>">
        <button class="btn btn-sm btn-danger">Delete</button></form>
    </td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No shifts yet.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="shiftModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3 id="shiftTitle">Add Shift</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="save"><input type="hidden" name="id" id="shift_id">
    <div class="form-group"><label>Name <span class="req">*</span></label><input type="text" name="name" id="shift_name" required placeholder="e.g. Morning / Night"></div>
    <div class="form-row">
      <div class="form-group"><label>Start Time</label><input type="time" name="start_time" id="shift_start" value="10:30"></div>
      <div class="form-group"><label>End Time</label><input type="time" name="end_time" id="shift_end" value="19:00"></div>
    </div>
    <div class="form-group"><label class="switch"><input type="checkbox" name="is_active" id="shift_active" checked> Active</label></div>
    <div class="help">Start/End drive late, early, auto-checkout and overtime for employees on this shift. Grace and half/full-day rules stay global.</div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>
function shiftForm(d){d=d||{};
  document.getElementById('shiftTitle').textContent=d.id?'Edit Shift':'Add Shift';
  document.getElementById('shift_id').value=d.id||'';
  document.getElementById('shift_name').value=d.name||'';
  document.getElementById('shift_start').value=d.start||'10:30';
  document.getElementById('shift_end').value=d.end||'19:00';
  document.getElementById('shift_active').checked=d.id?d.is_active==1:true;
}
</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
