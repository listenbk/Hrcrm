<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_perm('assets.manage');
$me = current_user();
$id = (int)param('id', 0);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id  = (int)param('id', 0, 'POST');
    $act = param('do', '', 'POST');
    if ($act === 'allocate') {
        [$ok,$msg]=allocate_asset($id,(int)param('employee_id',0,'POST'),
            param('allocation_date',date('Y-m-d'),'POST') ?: date('Y-m-d'),
            trim((string)param('condition','Good','POST')) ?: 'Good',
            trim((string)param('remark','','POST')),(int)$me['id']);
        $ok?flash_success($msg):flash_error($msg);
    } elseif ($act === 'return') {
        [$ok,$msg]=return_asset($id,trim((string)param('new_status','Available','POST')),
            trim((string)param('return_condition','Good','POST')) ?: 'Good',
            trim((string)param('return_remark','','POST')),(int)$me['id'],
            param('return_date',date('Y-m-d'),'POST') ?: date('Y-m-d'));
        $ok?flash_success($msg):flash_error($msg);
    } elseif ($act === 'edit') {
        q("UPDATE assets SET asset_type=?, brand=?, model=?, serial_no=?, purchase_date=?, `condition`=?, remarks=? WHERE id=?",
          [trim((string)param('asset_type','','POST')),trim((string)param('brand','','POST')),trim((string)param('model','','POST')),
           trim((string)param('serial_no','','POST')),param('purchase_date','','POST')?:null,
           trim((string)param('condition','Good','POST')),trim((string)param('remarks','','POST')),$id]);
        audit_log('asset_edited','asset',$id,'Edited asset details'); flash_success('Asset updated.');
    }
    redirect('admin/asset_view.php?id='.$id);
}

$a = fetch_one("SELECT a.*, e.emp_code, e.full_name FROM assets a LEFT JOIN employees e ON e.id=a.assigned_employee_id WHERE a.id=?", [$id]);
if (!$a) { flash_error('Asset not found.'); redirect('admin/assets.php'); }
$history = fetch_all(
  "SELECT h.*, ab.name AS alloc_by_name, rb.name AS recv_by_name
   FROM asset_allocations h
   LEFT JOIN users ab ON ab.id=h.allocated_by
   LEFT JOIN users rb ON rb.id=h.received_by
   WHERE h.asset_id=? ORDER BY h.id DESC", [$id]);
$emps = fetch_all("SELECT id, emp_code, full_name, status FROM employees WHERE status NOT IN ('Resigned','Terminated') ORDER BY emp_code");

$pageTitle='Asset · '.$a['asset_code']; $activeNav='assets';
require __DIR__ . '/../templates/header.php';
function kv($k,$v){ echo '<div style="padding:7px 0;border-bottom:1px solid var(--border)"><div class="text-muted" style="font-size:11px">'.e($k).'</div><div style="font-weight:600">'.e($v?:'—').'</div></div>'; }
?>
<div class="page-head">
  <div><h2><?= e($a['asset_code']) ?> · <?= e($a['asset_type']) ?></h2>
    <div class="breadcrumb"><a href="<?= url('admin/assets.php') ?>">Assets</a> / <?= e($a['asset_code']) ?></div></div>
  <span class="pill <?= asset_status_pill($a['status']) ?>" style="font-size:13px;padding:6px 14px"><?= e($a['status']) ?></span>
</div>

<div class="grid cols-3">
  <div class="card"><div class="card-head"><h3>Details</h3></div><div class="card-body">
    <?php kv('Asset ID',$a['asset_code']); kv('Type',$a['asset_type']); kv('Brand / Model',trim($a['brand'].' '.$a['model']));
    kv('Serial / IMEI',$a['serial_no']); kv('Purchase Date',fmt_date($a['purchase_date'])); kv('Condition',$a['condition']);
    kv('Remarks',$a['remarks']); ?>
  </div></div>

  <div class="card"><div class="card-head"><h3>Current Allocation</h3></div><div class="card-body">
    <?php if($a['status']==='Allocated'): ?>
      <?php kv('Assigned To',$a['full_name'].' ('.$a['emp_code'].')'); kv('Allocation Date',fmt_date($a['allocation_date'])); ?>
      <form method="post" data-confirm="Record this asset as returned to company inventory?"><?= csrf_field() ?>
        <input type="hidden" name="do" value="return"><input type="hidden" name="id" value="<?= $id ?>">
        <h4 class="mt-2">Return to Inventory</h4>
        <div class="form-row">
          <div class="form-group"><label>New Status</label><select name="new_status"><?php foreach(['Available','Under Repair','Damaged','Lost','Retired'] as $st): ?><option><?= $st ?></option><?php endforeach; ?></select></div>
          <div class="form-group"><label>Return Date</label><input type="date" name="return_date" value="<?= date('Y-m-d') ?>"></div>
        </div>
        <div class="form-group"><label>Condition</label><select name="return_condition"><?php foreach(asset_conditions() as $c): ?><option <?= $c===$a['condition']?'selected':'' ?>><?= $c ?></option><?php endforeach; ?></select></div>
        <div class="form-group"><label>Remarks</label><input type="text" name="return_remark"></div>
        <button class="btn btn-warning">↩️ Confirm Return</button>
      </form>
    <?php elseif($a['status']==='Available'): ?>
      <form method="post" data-confirm="Allocate this asset to the selected employee?"><?= csrf_field() ?>
        <input type="hidden" name="do" value="allocate"><input type="hidden" name="id" value="<?= $id ?>">
        <div class="form-group"><label>Employee <span class="req">*</span></label><select name="employee_id" required>
          <option value="">— Select —</option>
          <?php foreach($emps as $em): ?><option value="<?= $em['id'] ?>"><?= e($em['emp_code'].' — '.$em['full_name'].($em['status']!=='Active'?' ('.$em['status'].')':'')) ?></option><?php endforeach; ?></select></div>
        <div class="form-row">
          <div class="form-group"><label>Date</label><input type="date" name="allocation_date" value="<?= date('Y-m-d') ?>"></div>
          <div class="form-group"><label>Condition</label><select name="condition"><?php foreach(asset_conditions() as $c): ?><option <?= $c===$a['condition']?'selected':'' ?>><?= $c ?></option><?php endforeach; ?></select></div>
        </div>
        <div class="form-group"><label>Remarks</label><input type="text" name="remark"></div>
        <button class="btn btn-success">📲 Allocate</button>
      </form>
    <?php else: ?>
      <p class="text-muted">This asset is <b><?= e($a['status']) ?></b> and not currently allocated.</p>
    <?php endif; ?>
  </div></div>

  <div class="card"><div class="card-head"><h3>Edit Asset</h3></div><div class="card-body">
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="edit"><input type="hidden" name="id" value="<?= $id ?>">
      <div class="form-group"><label>Type</label><select name="asset_type"><?php foreach(asset_types() as $t): ?><option <?= $t===$a['asset_type']?'selected':'' ?>><?= $t ?></option><?php endforeach; ?></select></div>
      <div class="form-row">
        <div class="form-group"><label>Brand</label><input type="text" name="brand" value="<?= e($a['brand']) ?>"></div>
        <div class="form-group"><label>Model</label><input type="text" name="model" value="<?= e($a['model']) ?>"></div>
      </div>
      <div class="form-group"><label>Serial / IMEI</label><input type="text" name="serial_no" value="<?= e($a['serial_no']) ?>"></div>
      <div class="form-row">
        <div class="form-group"><label>Purchase Date</label><input type="date" name="purchase_date" value="<?= e($a['purchase_date']) ?>"></div>
        <div class="form-group"><label>Condition</label><select name="condition"><?php foreach(asset_conditions() as $c): ?><option <?= $c===$a['condition']?'selected':'' ?>><?= $c ?></option><?php endforeach; ?></select></div>
      </div>
      <div class="form-group"><label>Remarks</label><input type="text" name="remarks" value="<?= e($a['remarks']) ?>"></div>
      <button class="btn">💾 Save</button>
    </form>
  </div></div>
</div>

<div class="card mt-2"><div class="card-head"><h3>📜 Allocation History</h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Employee</th><th>Allocated</th><th>By</th><th>Cond. (out)</th><th>Returned</th><th>Received By</th><th>Cond. (in)</th><th>Status</th></tr></thead>
  <tbody><?php foreach($history as $h): ?>
    <tr>
      <td><b><?= e($h['employee_name'] ?: '—') ?></b><div class="text-muted" style="font-size:11px"><?= e($h['emp_code']) ?></div></td>
      <td><?= fmt_date($h['allocation_date']) ?></td>
      <td class="text-muted"><?= e($h['alloc_by_name'] ?: '—') ?></td>
      <td><?= e($h['allocation_condition'] ?: '—') ?><?php if($h['allocation_remark']): ?><div class="text-muted" style="font-size:11px"><?= e($h['allocation_remark']) ?></div><?php endif; ?></td>
      <td><?= $h['return_date']?fmt_date($h['return_date']):'—' ?></td>
      <td class="text-muted"><?= e($h['recv_by_name'] ?: '—') ?></td>
      <td><?= e($h['return_condition'] ?: '—') ?><?php if($h['return_remark']): ?><div class="text-muted" style="font-size:11px"><?= e($h['return_remark']) ?></div><?php endif; ?></td>
      <td><span class="pill <?= $h['status']==='Active'?'pill-info':'pill-muted' ?>"><?= e($h['status']) ?></span></td>
    </tr>
  <?php endforeach; if(!$history): ?><tr><td colspan="8" class="empty">No allocation history yet.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
