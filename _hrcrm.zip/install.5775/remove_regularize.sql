-- =====================================================================
--  RG Realty CRM — REMOVE the Attendance Regularization feature
--  Run this only if a previous build already created the feature.
--  It drops the regularization request table and its permission.
--
--  SAFE: it does NOT touch the `attendance` table or any attendance
--  records. Attendance rows that were previously corrected via the
--  feature keep their values — only the request log and permission go.
-- =====================================================================
SET NAMES utf8mb4;

-- 1) Remove the request table (request history only; not attendance data).
DROP TABLE IF EXISTS `attendance_regularizations`;

-- 2) Remove the permission grants, then the permission itself.
DELETE rp FROM `role_permissions` rp
  JOIN `permissions` p ON p.id = rp.permission_id
  WHERE p.slug = 'attendance.regularize';

DELETE FROM `permissions` WHERE slug = 'attendance.regularize';
