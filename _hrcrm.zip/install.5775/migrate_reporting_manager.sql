-- =====================================================================
--  RG Realty CRM — Reporting Manager = HR or Team Leader
--  Repoints employees.reporting_manager_id from employees(id) to
--  users(id), so an employee reports to an HR or Team Leader account.
--  Safe to run once.
-- =====================================================================
SET NAMES utf8mb4;

-- Drop the old FK to employees and clear stale values (they referenced
-- employee ids under the previous meaning).
ALTER TABLE `employees` DROP FOREIGN KEY `fk_emp_mgr`;
UPDATE `employees` SET `reporting_manager_id` = NULL;

-- Point the reporting manager at a user account (HR / Team Leader / Manager).
ALTER TABLE `employees`
  ADD CONSTRAINT `fk_emp_mgr` FOREIGN KEY (`reporting_manager_id`)
  REFERENCES `users`(`id`) ON DELETE SET NULL;
