<?php
/**
 * Daily database backup (gzipped SQL under storage/backups).
 *
 * Schedule once a day (e.g. 02:00) via Hostinger Cron:
 *   /usr/bin/php  /home/USER/domains/rgrealty.in/public_html/hrcrm/cron/backup_db.php
 *
 * Optional URL trigger (only if a `cron_key` is set in settings):
 *   wget -q -O /dev/null "https://hrcrm.rgrealty.in/cron/backup_db.php?key=YOURKEY"
 *
 * Keeps the newest N backups (setting `backup_keep`, default 14).
 */

$inc = __DIR__ . '/../includes/';
require_once __DIR__ . '/../config/config.php';
require_once $inc . 'db.php';
require_once $inc . 'settings.php';
require_once $inc . 'functions.php';
require_once $inc . 'backup_lib.php';

$isCli = (PHP_SAPI === 'cli');
if (!$isCli) {
    header('Content-Type: text/plain');
    $key = (string)($_GET['key'] ?? '');
    $expected = (string)setting('cron_key', '');
    if ($expected === '' || !hash_equals($expected, $key)) {
        http_response_code(403);
        echo "Forbidden. Set a 'cron_key' in settings and pass ?key=... , or run this via CLI.\n";
        exit;
    }
}

[$ok, $msg, $file] = db_backup_run();
$line = date('c') . ' backup_db ' . json_encode(['ok'=>$ok,'msg'=>$msg,'file'=>$file]);
echo $line . "\n";
@file_put_contents(APP_ROOT . '/storage/cron.log', $line . "\n", FILE_APPEND);
