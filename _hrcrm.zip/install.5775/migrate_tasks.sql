-- =====================================================================
--  RG Realty CRM — Task Manager & Daily Reporting
--  ADD-ONLY migration. Reuses the existing employees/users/roles tables.
--  No existing data is modified. Safe to run once (idempotent).
-- =====================================================================
SET NAMES utf8mb4;

-- Tasks assigned to employees by Admin / HR / Team Leader.
CREATE TABLE IF NOT EXISTS `tasks` (
  `id`             BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `title`          VARCHAR(180) NOT NULL,
  `description`    TEXT         DEFAULT NULL,
  `priority`       ENUM('Low','Medium','High','Urgent') NOT NULL DEFAULT 'Medium',
  `status`         ENUM('Pending','In Progress','Completed') NOT NULL DEFAULT 'Pending',
  `assigned_to`    INT UNSIGNED NOT NULL,                 -- employees.id
  `assigned_by`    INT UNSIGNED DEFAULT NULL,             -- users.id (assigner)
  `assign_date`    DATE         NOT NULL,
  `due_date`       DATE         DEFAULT NULL,
  `admin_remark`   VARCHAR(255) DEFAULT NULL,             -- note from assigner
  `employee_remark`VARCHAR(255) DEFAULT NULL,             -- note from employee
  `completed_at`   DATETIME     DEFAULT NULL,
  `created_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`     TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_task_emp` (`assigned_to`),
  KEY `idx_task_status` (`status`),
  KEY `idx_task_due` (`due_date`),
  CONSTRAINT `fk_task_emp` FOREIGN KEY (`assigned_to`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- End-of-Day / daily reports submitted by employees. One per employee per day.
CREATE TABLE IF NOT EXISTS `daily_reports` (
  `id`           BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`  INT UNSIGNED NOT NULL,
  `report_date`  DATE         NOT NULL,
  `summary`      TEXT         NOT NULL,                   -- what was done today
  `blockers`     TEXT         DEFAULT NULL,               -- issues / blockers
  `hours_worked` DECIMAL(4,1) DEFAULT NULL,
  `created_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`   TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_report_emp_day` (`employee_id`,`report_date`),
  KEY `idx_report_date` (`report_date`),
  CONSTRAINT `fk_report_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permission: manage/assign tasks and view all tasks + reports.
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES ('Manage Tasks','tasks.manage','Tasks')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Grant to Super Admin (1), HR/Admin (2) and Team Leader (4).
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions` WHERE slug='tasks.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug='tasks.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 4, id FROM `permissions` WHERE slug='tasks.manage';
