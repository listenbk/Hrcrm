-- =====================================================================
--  RG Realty CRM — Asset Management
--  Adds asset inventory, permanent allocation history, employee return
--  requests and the assets.manage permission. Only ADDS tables/rows —
--  existing data and modules are untouched. Safe to run once.
-- =====================================================================
SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS `assets` (
  `id`            INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_code`    VARCHAR(40)  NOT NULL,                 -- e.g. AST0001
  `asset_type`    VARCHAR(60)  NOT NULL,
  `brand`         VARCHAR(100) DEFAULT NULL,
  `model`         VARCHAR(100) DEFAULT NULL,
  `serial_no`     VARCHAR(120) DEFAULT NULL,             -- Serial / IMEI
  `purchase_date` DATE         DEFAULT NULL,
  `condition`     VARCHAR(40)  NOT NULL DEFAULT 'Good',
  `status`        ENUM('Available','Allocated','Returned','Under Repair','Damaged','Lost','Retired')
                    NOT NULL DEFAULT 'Available',
  `assigned_employee_id` INT UNSIGNED DEFAULT NULL,      -- current holder
  `allocation_date` DATE       DEFAULT NULL,
  `return_date`   DATE         DEFAULT NULL,
  `remarks`       TEXT         DEFAULT NULL,
  `created_by`    INT UNSIGNED DEFAULT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updated_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_asset_code` (`asset_code`),
  KEY `idx_asset_status` (`status`),
  KEY `idx_asset_type` (`asset_type`),
  KEY `idx_asset_emp` (`assigned_employee_id`),
  CONSTRAINT `fk_asset_emp` FOREIGN KEY (`assigned_employee_id`) REFERENCES `employees`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permanent allocation history (never deleted on return/reassign)
CREATE TABLE IF NOT EXISTS `asset_allocations` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id`      INT UNSIGNED NOT NULL,
  `employee_id`   INT UNSIGNED DEFAULT NULL,             -- SET NULL if employee later deleted
  `emp_code`      VARCHAR(40)  DEFAULT NULL,             -- snapshot (survives employee deletion)
  `employee_name` VARCHAR(150) DEFAULT NULL,             -- snapshot
  `allocated_by`  INT UNSIGNED DEFAULT NULL,             -- HR user
  `allocation_date` DATE       NOT NULL,
  `allocation_condition` VARCHAR(40) DEFAULT NULL,
  `allocation_remark`    VARCHAR(255) DEFAULT NULL,
  `return_date`   DATE         DEFAULT NULL,
  `return_condition` VARCHAR(40) DEFAULT NULL,
  `return_remark` VARCHAR(255) DEFAULT NULL,
  `received_by`   INT UNSIGNED DEFAULT NULL,             -- HR user who took it back
  `status`        ENUM('Active','Returned') NOT NULL DEFAULT 'Active',
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_alloc_asset` (`asset_id`),
  KEY `idx_alloc_emp` (`employee_id`),
  KEY `idx_alloc_status` (`status`),
  CONSTRAINT `fk_alloc_asset` FOREIGN KEY (`asset_id`) REFERENCES `assets`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_alloc_emp`   FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Employee-initiated return requests
CREATE TABLE IF NOT EXISTS `asset_return_requests` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `asset_id`      INT UNSIGNED NOT NULL,
  `allocation_id` BIGINT UNSIGNED DEFAULT NULL,
  `employee_id`   INT UNSIGNED NOT NULL,
  `reason`        VARCHAR(255) DEFAULT NULL,
  `status`        ENUM('Pending','Completed','Rejected') NOT NULL DEFAULT 'Pending',
  `handled_by`    INT UNSIGNED DEFAULT NULL,
  `handled_at`    DATETIME     DEFAULT NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_arr_status` (`status`),
  KEY `idx_arr_asset` (`asset_id`),
  CONSTRAINT `fk_arr_asset` FOREIGN KEY (`asset_id`) REFERENCES `assets`(`id`) ON DELETE CASCADE,
  CONSTRAINT `fk_arr_emp`   FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permission (HR + Super Admin)
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES ('Manage Assets','assets.manage','Assets')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions` WHERE slug='assets.manage';
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug='assets.manage';
