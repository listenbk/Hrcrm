-- =====================================================================
--  RG Realty CRM — Improvements batch
--  Features: Shift Management (#11), Attendance Regularization (#4),
--            and new permissions for Backups (#1) and Regularization.
--  ADD-ONLY. No existing data is modified. Safe to run once (idempotent).
-- =====================================================================
SET NAMES utf8mb4;

-- ---------- #11 Shift Management -------------------------------------
CREATE TABLE IF NOT EXISTS `shifts` (
  `id`          INT UNSIGNED NOT NULL AUTO_INCREMENT,
  `name`        VARCHAR(80)  NOT NULL,
  `start_time`  TIME         NOT NULL DEFAULT '10:30:00',
  `end_time`    TIME         NOT NULL DEFAULT '19:00:00',
  `is_active`   TINYINT(1)   NOT NULL DEFAULT 1,
  `created_at`  TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_shift_name` (`name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- A "General" shift matching the current default office hours (example row).
INSERT INTO `shifts` (`name`,`start_time`,`end_time`,`is_active`)
  VALUES ('General (10:30-19:00)','10:30:00','19:00:00',1)
ON DUPLICATE KEY UPDATE `name`=`name`;

-- Optional per-employee shift. NULL = use global company office times (no change).
ALTER TABLE `employees`
  ADD COLUMN IF NOT EXISTS `shift_id` INT UNSIGNED NULL AFTER `designation_id`;

-- Ensure the auto-checkout flag exists (also created by the auto-checkout
-- update). Harmless if already present — keeps this batch self-contained.
ALTER TABLE `attendance`
  ADD COLUMN IF NOT EXISTS `is_auto_checkout` TINYINT(1) NOT NULL DEFAULT 0 AFTER `is_manual`;

-- ---------- #4 Attendance Regularization ----------------------------
CREATE TABLE IF NOT EXISTS `attendance_regularizations` (
  `id`            BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  `employee_id`   INT UNSIGNED NOT NULL,
  `att_date`      DATE         NOT NULL,
  `req_check_in`  DATETIME     NULL,
  `req_check_out` DATETIME     NULL,
  `reason`        VARCHAR(255) NOT NULL,
  `status`        ENUM('Pending','Approved','Rejected') NOT NULL DEFAULT 'Pending',
  `reviewed_by`   INT UNSIGNED NULL,
  `review_remark` VARCHAR(255) NULL,
  `reviewed_at`   DATETIME     NULL,
  `created_at`    TIMESTAMP    NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  KEY `idx_reg_emp` (`employee_id`),
  KEY `idx_reg_status` (`status`),
  KEY `idx_reg_date` (`att_date`),
  CONSTRAINT `fk_reg_emp` FOREIGN KEY (`employee_id`) REFERENCES `employees`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------- New permissions -----------------------------------------
INSERT INTO `permissions` (`name`,`slug`,`module`) VALUES
  ('Manage Shifts','shifts.manage','Employees'),
  ('Approve Attendance Regularization','attendance.regularize','Attendance'),
  ('Manage Backups','backups.manage','Administration')
ON DUPLICATE KEY UPDATE `name`=VALUES(`name`);

-- Grant to Super Admin (role 1): all three.
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 1, id FROM `permissions` WHERE slug IN ('shifts.manage','attendance.regularize','backups.manage');

-- Grant to HR/Admin (role 2): shifts + regularization (NOT backups).
INSERT IGNORE INTO `role_permissions` (`role_id`,`permission_id`)
  SELECT 2, id FROM `permissions` WHERE slug IN ('shifts.manage','attendance.regularize');
