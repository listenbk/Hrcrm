<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp = current_employee() ?: ensure_staff_employee(current_user());
if (!$emp) { flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $date   = (string)param('att_date', '', 'POST');
    $inT    = trim((string)param('req_check_in', '', 'POST'));
    $outT   = trim((string)param('req_check_out', '', 'POST'));
    $reason = trim((string)param('reason', '', 'POST'));

    $errors = [];
    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $errors[] = 'Choose a valid date.';
    if ($date > date('Y-m-d')) $errors[] = 'You cannot regularize a future date.';
    if ($reason === '') $errors[] = 'Please provide a reason.';
    if ($inT === '' && $outT === '') $errors[] = 'Enter a requested check-in and/or check-out time.';

    // No duplicate pending request for the same date.
    if (!$errors) {
        $dup = (int)fetch_col("SELECT COUNT(*) FROM attendance_regularizations WHERE employee_id=? AND att_date=? AND status='Pending'", [$emp['id'], $date]);
        if ($dup) $errors[] = 'You already have a pending request for that date.';
    }

    if (!$errors) {
        $reqIn  = $inT  !== '' ? "$date $inT:00"  : null;
        $reqOut = $outT !== '' ? "$date $outT:00" : null;
        q("INSERT INTO attendance_regularizations (employee_id, att_date, req_check_in, req_check_out, reason)
           VALUES (?,?,?,?,?)", [$emp['id'], $date, $reqIn, $reqOut, $reason]);
        notify_roles(['super_admin','hr_admin'], 'regularization_request', 'Attendance regularization request',
            $emp['full_name'].' requested a correction for '.fmt_date($date).'.', url('admin/regularizations.php'));
        flash_success('Regularization request submitted for approval.');
    } else {
        flash_error(implode(' ', $errors));
    }
    redirect('employee/regularize.php');
}

$rows = fetch_all(
  "SELECT r.*, u.name AS reviewer FROM attendance_regularizations r
   LEFT JOIN users u ON u.id=r.reviewed_by
   WHERE r.employee_id=? ORDER BY r.created_at DESC LIMIT 60", [$emp['id']]);

$pageTitle='Attendance Regularization'; $activeNav='regularize';
require __DIR__ . '/../templates/header.php';
function reg_pill(string $s): string {
    $m=['Pending'=>'pill-warning','Approved'=>'pill-success','Rejected'=>'pill-danger'];
    return '<span class="pill '.($m[$s]??'pill-muted').'">'.e($s).'</span>';
}
?>
<div class="page-head"><div><h2>Attendance Regularization</h2>
  <div class="breadcrumb">Request a correction for a missed or wrong check-in / check-out (e.g. auto check-out).</div></div></div>

<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>New Request</h3></div><div class="card-body">
    <form method="post"><?= csrf_field() ?>
      <div class="form-group"><label>Date <span class="req">*</span></label>
        <input type="date" name="att_date" max="<?= date('Y-m-d') ?>" value="<?= date('Y-m-d') ?>" required></div>
      <div class="form-row">
        <div class="form-group"><label>Correct Check-In</label><input type="time" name="req_check_in"></div>
        <div class="form-group"><label>Correct Check-Out</label><input type="time" name="req_check_out"></div>
      </div>
      <div class="help mb-2">Fill the time(s) that need fixing. Leave one blank to change only the other.</div>
      <div class="form-group"><label>Reason <span class="req">*</span></label>
        <textarea name="reason" required placeholder="Why does this need correcting?"></textarea></div>
      <button class="btn">Submit Request</button>
    </form>
  </div></div>

  <div class="card"><div class="card-head"><h3>My Requests</h3></div>
  <div class="table-wrap"><table class="data">
    <thead><tr><th>Date</th><th>In</th><th>Out</th><th>Status</th><th>Reviewer</th></tr></thead>
    <tbody><?php foreach($rows as $r): ?>
      <tr>
        <td><?= fmt_date($r['att_date']) ?><div class="text-muted" style="font-size:11px"><?= e($r['reason']) ?></div></td>
        <td><?= $r['req_check_in']?fmt_date($r['req_check_in'],'h:i A'):'—' ?></td>
        <td><?= $r['req_check_out']?fmt_date($r['req_check_out'],'h:i A'):'—' ?></td>
        <td><?= reg_pill($r['status']) ?><?php if($r['review_remark']): ?><div class="text-muted" style="font-size:11px"><?= e($r['review_remark']) ?></div><?php endif; ?></td>
        <td class="text-muted"><?= e($r['reviewer'] ?: '—') ?></td>
      </tr>
    <?php endforeach; if(!$rows): ?><tr><td colspan="5" class="empty">No requests yet.</td></tr><?php endif; ?></tbody>
  </table></div></div>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
