<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp=current_employee();
if(!$emp){ flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $act=param('do','','POST');
    if ($act==='profile') {
        // employees may update only permitted fields
        $mobile=trim((string)param('mobile','','POST'));
        $address=trim((string)param('address','','POST'));
        $emName=trim((string)param('emergency_name','','POST'));
        $emPhone=trim((string)param('emergency_phone','','POST'));
        $emRel=trim((string)param('emergency_relation','','POST'));
        $photo=$emp['photo'];
        if(!empty($_FILES['photo']['name'])){ $up=handle_upload($_FILES['photo'],'photos',['jpg','jpeg','png','gif']); if($up)$photo=$up; }
        q("UPDATE employees SET mobile=?,address=?,emergency_name=?,emergency_phone=?,emergency_relation=?,photo=? WHERE id=?",
          [$mobile,$address,$emName,$emPhone,$emRel,$photo,$emp['id']]);
        flash_success('Profile updated.');
    } elseif ($act==='password') {
        $cur=(string)param('current','','POST'); $new=(string)param('new','','POST'); $conf=(string)param('confirm','','POST');
        if (!password_verify($cur,$u['password_hash'])) flash_error('Current password is incorrect.');
        elseif (strlen($new)<6) flash_error('New password must be at least 6 characters.');
        elseif ($new!==$conf) flash_error('New passwords do not match.');
        else { q("UPDATE users SET password_hash=? WHERE id=?",[password_hash($new,PASSWORD_DEFAULT),$u['id']]);
               bump_auth_version((int)$u['id']);
               audit_log('password_changed','user',$u['id'],'Self password change'); flash_success('Password changed.'); }
    }
    redirect('employee/profile.php');
}
$emp=current_employee();
$pageTitle='My Profile'; $activeNav='profile';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>My Profile</h2></div></div>
<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>Editable Details</h3></div><div class="card-body">
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?><input type="hidden" name="do" value="profile">
      <div class="form-group text-center"><div class="avatar" style="width:80px;height:80px;font-size:30px;margin:0 auto 10px">
        <?php if($emp['photo']): ?><img src="<?= url('uploads/'.$emp['photo']) ?>"><?php else: ?><?= e(strtoupper(substr($emp['full_name'],0,1))) ?><?php endif; ?></div>
        <input type="file" name="photo" accept="image/*"></div>
      <div class="form-group"><label>Mobile</label><input type="tel" name="mobile" value="<?= e($emp['mobile']) ?>"></div>
      <div class="form-group"><label>Address</label><textarea name="address"><?= e($emp['address']) ?></textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Emergency Name</label><input type="text" name="emergency_name" value="<?= e($emp['emergency_name']) ?>"></div>
        <div class="form-group"><label>Emergency Phone</label><input type="tel" name="emergency_phone" value="<?= e($emp['emergency_phone']) ?>"></div>
      </div>
      <div class="form-group"><label>Relation</label><input type="text" name="emergency_relation" value="<?= e($emp['emergency_relation']) ?>"></div>
      <button class="btn">💾 Update Profile</button>
    </form>
  </div></div>

  <div class="card"><div class="card-head"><h3>Read-only Information</h3></div><div class="card-body">
    <p><b>Employee ID:</b> <?= e($emp['emp_code']) ?></p>
    <p><b>Email:</b> <?= e($emp['email']) ?></p>
    <p><b>Joining Date:</b> <?= fmt_date($emp['joining_date']) ?></p>
    <p><b>Basic Salary:</b> <?= money($emp['basic_salary']) ?></p>
    <p class="help">To change these, contact HR.</p>
    <hr style="border:none;border-top:1px solid var(--border);margin:16px 0">
    <h4>Change Password</h4>
    <form method="post"><?= csrf_field() ?><input type="hidden" name="do" value="password">
      <div class="form-group"><label>Current Password</label>
        <div class="pwd-wrap"><input type="password" name="current" required>
        <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
      <div class="form-row">
        <div class="form-group"><label>New Password</label>
          <div class="pwd-wrap"><input type="password" name="new" required>
          <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
        <div class="form-group"><label>Confirm</label>
          <div class="pwd-wrap"><input type="password" name="confirm" required>
          <button type="button" class="pwd-toggle" tabindex="-1" aria-label="Show password">Show</button></div></div>
      </div>
      <button class="btn btn-outline">🔒 Change Password</button>
    </form>
  </div></div>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
