<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp = current_employee() ?: ensure_staff_employee(current_user());
if (!$emp) { flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $date     = (string)param('report_date', date('Y-m-d'), 'POST');
    $summary  = trim((string)param('summary', '', 'POST'));
    $blockers = trim((string)param('blockers', '', 'POST'));
    $hoursRaw = trim((string)param('hours_worked', '', 'POST'));
    $hours    = $hoursRaw === '' ? null : max(0, min(24, (float)$hoursRaw));

    if (!preg_match('/^\d{4}-\d{2}-\d{2}$/',$date) || $date > date('Y-m-d')) {
        flash_error('Choose a valid date (not in the future).');
    } elseif ($summary === '') {
        flash_error('Please write a short summary of your day.');
    } else {
        // One report per employee per day — insert or update.
        q("INSERT INTO daily_reports (employee_id, report_date, summary, blockers, hours_worked)
           VALUES (?,?,?,?,?)
           ON DUPLICATE KEY UPDATE summary=VALUES(summary), blockers=VALUES(blockers), hours_worked=VALUES(hours_worked)",
          [$emp['id'], $date, $summary, ($blockers ?: null), $hours]);
        audit_log('daily_report_submitted','daily_report',null,"EOD report for ".fmt_date($date));
        $reportMsg = $emp['full_name'].' submitted an EOD report for '.fmt_date($date).'.';
        // Reporting requests are routed to the employee's assigned Team Leader.
        notify_employee_tl((int)$emp['id'], 'daily_report', 'End-of-Day report submitted', $reportMsg, url('admin/task_reports.php'));
        notify_roles(['super_admin','hr_admin'], 'daily_report', 'End-of-Day report submitted', $reportMsg, url('admin/task_reports.php'));
        flash_success('End-of-Day report saved.');
    }
    redirect('employee/report.php');
}

$today = date('Y-m-d');
$todayReport = fetch_one("SELECT * FROM daily_reports WHERE employee_id=? AND report_date=?", [$emp['id'], $today]);
$history = fetch_all("SELECT * FROM daily_reports WHERE employee_id=? ORDER BY report_date DESC LIMIT 60", [$emp['id']]);

$pageTitle='Daily Report'; $activeNav='my_report';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>End-of-Day Report</h2>
  <div class="breadcrumb">Summarise what you worked on today.</div></div></div>

<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3><?= $todayReport?'Update Today\'s Report':'Submit Today\'s Report' ?></h3></div><div class="card-body">
    <form method="post"><?= csrf_field() ?>
      <div class="form-group"><label>Date</label><input type="date" name="report_date" max="<?= $today ?>" value="<?= $today ?>"></div>
      <div class="form-group"><label>What did you do today? <span class="req">*</span></label>
        <textarea name="summary" rows="5" required placeholder="Tasks completed, calls, meetings, progress…"><?= e($todayReport['summary'] ?? '') ?></textarea></div>
      <div class="form-row">
        <div class="form-group"><label>Blockers / Issues</label><input type="text" name="blockers" value="<?= e($todayReport['blockers'] ?? '') ?>"></div>
        <div class="form-group"><label>Hours Worked</label><input type="number" step="0.5" min="0" max="24" name="hours_worked" value="<?= e($todayReport['hours_worked'] ?? '') ?>"></div>
      </div>
      <button class="btn"><?= $todayReport?'Update Report':'Submit Report' ?></button>
    </form>
  </div></div>

  <div class="card"><div class="card-head"><h3>My Report History</h3></div>
  <div class="table-wrap"><table class="data">
    <thead><tr><th>Date</th><th>Summary</th><th class="num">Hrs</th></tr></thead>
    <tbody><?php foreach($history as $r): ?>
      <tr>
        <td class="text-muted"><?= fmt_date($r['report_date']) ?></td>
        <td style="white-space:pre-wrap;max-width:320px"><?= e(mb_strimwidth($r['summary'],0,160,'…')) ?>
          <?php if($r['blockers']): ?><div class="text-muted" style="font-size:11px">⚠️ <?= e($r['blockers']) ?></div><?php endif; ?></td>
        <td class="num"><?= $r['hours_worked']!==null ? e(rtrim(rtrim(number_format((float)$r['hours_worked'],1),'0'),'.')).'h' : '—' ?></td>
      </tr>
    <?php endforeach; if(!$history): ?><tr><td colspan="3" class="empty">No reports yet.</td></tr><?php endif; ?></tbody>
  </table></div></div>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
