<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp=current_employee();
if(!$emp){ flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }
$advances=fetch_all("SELECT * FROM employee_advances WHERE employee_id=? ORDER BY created_at DESC",[$emp['id']]);
$pageTitle='Advances & EMI'; $activeNav='my_emi';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>My Advances &amp; EMI</h2></div></div>
<?php foreach($advances as $a):
  $emis=fetch_all("SELECT * FROM emi_schedules WHERE advance_id=? ORDER BY installment_no",[$a['id']]); ?>
<div class="card mb-2">
  <div class="card-head"><h3><?= e($a['advance_type']) ?> — <?= money($a['total_amount']) ?></h3>
    <span class="pill <?= ['Active'=>'pill-info','Completed'=>'pill-success','Paused'=>'pill-warning','Cancelled'=>'pill-danger'][$a['status']] ?>"><?= e($a['status']) ?></span></div>
  <div class="card-body">
    <div class="flex gap wrap mb-2">
      <span class="pill pill-muted">EMI: <?= money($a['emi_amount']) ?></span>
      <span class="pill pill-muted">Installments: <?= $a['installments'] ?></span>
      <span class="pill pill-success">Recovered: <?= money($a['recovered_amount']) ?></span>
      <span class="pill pill-danger">Balance: <?= money($a['balance_amount']) ?></span>
    </div>
    <div class="table-wrap"><table class="data">
      <thead><tr><th>#</th><th>Month</th><th class="num">Amount</th><th>Status</th></tr></thead>
      <tbody><?php foreach($emis as $s): ?>
        <tr><td><?= $s['installment_no'] ?></td><td><?= fmt_date($s['due_month'].'-01','M Y') ?></td>
        <td class="num"><?= money($s['amount']) ?></td>
        <td><span class="pill <?= ['Pending'=>'pill-warning','Paid'=>'pill-success','Skipped'=>'pill-muted'][$s['status']] ?>"><?= e($s['status']) ?></span></td></tr>
      <?php endforeach; ?></tbody>
    </table></div>
  </div>
</div>
<?php endforeach; if(!$advances): ?>
  <div class="card"><div class="empty">You have no advances or loans.</div></div>
<?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
