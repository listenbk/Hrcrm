<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp = current_employee() ?: ensure_staff_employee(current_user());
if (!$emp) { flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $id = (int)param('id', 0, 'POST');
    $ot = fetch_one("SELECT * FROM overtime WHERE id=? AND employee_id=?", [$id, $emp['id']]);
    if ($ot && $ot['status'] === 'Detected') {
        $reason  = trim((string)param('employee_reason', '', 'POST'));
        $work    = trim((string)param('work_performed', '', 'POST'));
        $project = trim((string)param('project_name', '', 'POST'));
        if ($reason !== '') {
            q("UPDATE overtime SET employee_reason=?, work_performed=?, project_name=?, status='Pending Approval' WHERE id=?",
              [$reason, $work, $project, $id]);
            $otMsg = $emp['full_name'].' submitted overtime for '.fmt_date($ot['ot_date']).' ('.rtrim(rtrim(number_format($ot['actual_hours'],2),'0'),'.').'h).';
            // Must be routed to the employee's assigned Team Leader for approval.
            notify_employee_tl((int)$emp['id'], 'overtime_request', 'Overtime approval request', $otMsg, url('admin/overtime.php'));
            notify_roles(['super_admin','hr_admin'], 'overtime_request', 'Overtime approval request', $otMsg, url('admin/overtime.php'));
            flash_success('Overtime reason submitted. It has been sent to your Team Leader for approval.');
        } else {
            flash_error('Please provide a reason.');
        }
    }
    redirect('employee/overtime.php');
}

$month = (string)param('month', date('Y-m'));
$s = ot_month_summary((int)$emp['id'], $month);
$start=$month.'-01'; $end=date('Y-m-t',strtotime($start));
$rows = fetch_all("SELECT * FROM overtime WHERE employee_id=? AND ot_date BETWEEN ? AND ? ORDER BY ot_date DESC",
    [$emp['id'],$start,$end]);
$todayOt = fetch_one("SELECT * FROM overtime WHERE employee_id=? AND ot_date=?", [$emp['id'], date('Y-m-d')]);
$todayAtt = fetch_one("SELECT * FROM attendance WHERE employee_id=? AND att_date=?", [$emp['id'], date('Y-m-d')]);
$otManual = ot_manual_enabled() && ot_enabled();
$otOpen   = ($todayOt && !empty($todayOt['ot_check_in']) && empty($todayOt['actual_out']));

$pageTitle='My Overtime'; $activeNav='my_ot';
require __DIR__ . '/../templates/header.php';

function e_ot_pill(string $st): string {
    $m=['Detected'=>'pill-muted','Pending Approval'=>'pill-warning','HR Reviewed'=>'pill-info',
        'Approved'=>'pill-success','Partially Approved'=>'pill-info','Rejected'=>'pill-danger','Paid'=>'pill-success'];
    return '<span class="pill '.($m[$st]??'pill-muted').'">'.e($st).'</span>';
}
?>
<div class="page-head"><div><h2>My Overtime — <?= fmt_date($start,'F Y') ?></h2></div>
  <form method="get"><input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()"></form></div>

<div id="attMsg" class="alert" style="display:none"></div>

<?php if($otManual): ?>
<div class="card mb-2"><div class="card-body flex between wrap" style="gap:12px;align-items:center">
  <div>
    <b>Overtime session</b>
    <div class="text-muted" style="font-size:13px">Overtime is counted only from a separate Overtime Check-In, available from <?= e(fmt_date(date('Y-m-d').' '.setting('ot_checkin_after','20:00'),'h:i A')) ?> onward. Requests are sent to your assigned Team Leader for approval.</div>
  </div>
  <div>
    <?php if($otOpen): ?>
      <span class="pill pill-info">OT running since <?= fmt_date($todayOt['ot_check_in'],'h:i A') ?></span>
      <button class="btn btn-warning" style="width:auto" onclick="attendanceAction('ot_check_out',this)">⏹️ Overtime Check-Out</button>
    <?php elseif($todayOt): ?>
      <span class="pill pill-muted">Today's OT recorded: <?= rtrim(rtrim(number_format((float)$todayOt['actual_hours'],2),'0'),'.') ?>h</span>
    <?php elseif(!$todayAtt || empty($todayAtt['check_out'])): ?>
      <span class="pill pill-muted">Finish normal attendance (check out) first</span>
    <?php else: ?>
      <button class="btn btn-success" style="width:auto" onclick="attendanceAction('ot_check_in',this)">▶️ Overtime Check-In</button>
    <?php endif; ?>
  </div>
</div></div>
<?php endif; ?>

<div class="grid cols-4 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-brand">⏱️</div><div><div class="label">Today's OT</div><div class="value" style="font-size:20px"><?= $todayOt?rtrim(rtrim(number_format($todayOt['actual_hours'],2),'0'),'.').'h':'0h' ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">📅</div><div><div class="label">This Month (actual)</div><div class="value" style="font-size:20px"><?= rtrim(rtrim(number_format($s['actual_hours'],2),'0'),'.') ?>h</div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div><div><div class="label">Approved Earnings</div><div class="value" style="font-size:18px"><?= money($s['approved_amount']) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏳</div><div><div class="label">Expected (pending)</div><div class="value" style="font-size:18px"><?= money($s['expected_amount']) ?></div></div></div></div>
</div>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Date</th><th>Day Type</th><th>Out</th><th class="num">Actual</th><th class="num">Approved</th><th class="num">Amount</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr>
      <td><?= fmt_date($r['ot_date']) ?></td>
      <td><span class="pill pill-muted"><?= e(ot_day_type_label($r['day_type'])) ?></span></td>
      <td class="text-muted" style="font-size:12px"><?= $r['actual_out']?fmt_date($r['actual_out'],'h:i A'):'—' ?></td>
      <td class="num"><?= rtrim(rtrim(number_format($r['actual_hours'],2),'0'),'.') ?>h</td>
      <td class="num"><?= $r['approved_hours']>0?rtrim(rtrim(number_format($r['approved_hours'],2),'0'),'.').'h':'—' ?></td>
      <td class="num"><?= $r['amount']>0?money($r['amount']):($r['status']==='Detected'||$r['status']==='Pending Approval'||$r['status']==='HR Reviewed'?'<span class="text-muted">~'.money(ot_expected_amount($r)).'</span>':'—') ?></td>
      <td><?= e_ot_pill($r['status']) ?></td>
      <td class="text-right"><?php if($r['status']==='Detected'): ?>
        <button class="btn btn-sm" data-modal="otModal" onclick='otForm(<?= json_encode(["id"=>$r["id"],"date"=>$r["ot_date"],"hours"=>$r["actual_hours"]]) ?>)'>Submit Reason</button>
      <?php else: echo '—'; endif; ?></td>
    </tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="8" class="empty"><?= ot_manual_enabled()
      ? 'No overtime this month. After you finish your normal attendance, use Overtime Check-In on your dashboard to start a separate overtime session.'
      : 'No overtime this month. Overtime is detected automatically when you check out after office closing time.' ?></td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="otModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Submit Overtime Reason</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="id" id="ot_id">
    <p class="text-muted" id="ot_info"></p>
    <div class="form-group"><label>Reason <span class="req">*</span></label><textarea name="employee_reason" required placeholder="Why did you work extra hours?"></textarea></div>
    <div class="form-group"><label>Work Performed</label><input type="text" name="work_performed"></div>
    <div class="form-group"><label>Client / Project</label><input type="text" name="project_name"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Submit for Approval</button></div>
</form></div></div>
<script>function otForm(o){document.getElementById('ot_id').value=o.id;
  document.getElementById('ot_info').textContent='Overtime on '+o.date+' — '+(+o.hours)+' hours.';}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
