<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp=current_employee() ?: ensure_staff_employee(current_user());
if(!$emp){ flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }
$month=(string)param('month',date('Y-m'));
[$y,$mn]=array_map('intval',explode('-',$month));
$m=monthly_attendance((int)$emp['id'],$y,$mn);
$rows=fetch_all("SELECT a.*, s.name AS status_name,s.color FROM attendance a LEFT JOIN attendance_statuses s ON s.id=a.status_id
  WHERE a.employee_id=? AND a.att_date BETWEEN ? AND ? ORDER BY a.att_date DESC",[$emp['id'],$m['start'],$m['end']]);
$pageTitle='My Attendance'; $activeNav='my_att';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>My Attendance — <?= fmt_date($month.'-01','F Y') ?></h2></div>
  <form method="get"><input type="month" name="month" value="<?= e($month) ?>" onchange="this.form.submit()"></form></div>
<div class="grid cols-4 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-green">🟢</div><div><div class="label">Present</div><div class="value"><?= $m['totals']['present'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">🔴</div><div><div class="label">Absent</div><div class="value"><?= $m['totals']['absent'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🌴</div><div><div class="label">Leave</div><div class="value"><?= $m['totals']['leave'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-amber">⏰</div><div><div class="label">Late</div><div class="value"><?= $m['totals']['late'] ?></div></div></div></div>
</div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Date</th><th>Check In</th><th>Check Out</th><th>Working Hrs</th><th>Late/Early</th><th>Status</th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><?= fmt_date($r['att_date'],'d M Y (D)') ?></td>
    <td><?= $r['check_in']?fmt_date($r['check_in'],'h:i A'):'—' ?></td>
    <td><?= $r['check_out']?fmt_date($r['check_out'],'h:i A'):'—' ?></td>
    <td><?= $r['working_minutes']?fmt_hm((int)$r['working_minutes']):'—' ?></td>
    <td><?php if($r['late_minutes']>0)echo '<span class="pill pill-warning">Late '.$r['late_minutes'].'m</span> ';
            if($r['early_minutes']>0)echo '<span class="pill pill-info">Early '.$r['early_minutes'].'m</span>';
            if(!$r['late_minutes']&&!$r['early_minutes'])echo '—'; ?></td>
    <td><?= $r['status_name']?'<span class="badge" style="background:'.e($r['color']).'">'.e($r['status_name']).'</span>':'—' ?></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No records this month.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
