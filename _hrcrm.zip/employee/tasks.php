<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp = current_employee() ?: ensure_staff_employee(current_user());
if (!$emp) { flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    $tid    = (int)param('id', 0, 'POST');
    $status = param('status', '', 'POST');
    $remark = trim((string)param('employee_remark', '', 'POST'));
    // Only the assignee may update their own task.
    $task = fetch_one("SELECT * FROM tasks WHERE id=? AND assigned_to=?", [$tid, $emp['id']]);
    if ($task && in_array($status, task_statuses(), true)) {
        $completed = ($status === 'Completed');
        q("UPDATE tasks SET status=?, employee_remark=?,
             completed_at=".($completed ? "IF(completed_at IS NULL, NOW(), completed_at)" : "NULL")." WHERE id=?",
          [$status, $remark, $tid]);
        audit_log('task_status_updated','task',$tid,"Status → {$status}");
        if ($completed && !empty($task['assigned_by'])) {
            notify((int)$task['assigned_by'],'task_completed','Task completed',
                "{$emp['full_name']} completed: {$task['title']}.", url('admin/tasks.php'));
        }
        flash_success('Task updated.');
    } else {
        flash_error('Could not update that task.');
    }
    redirect('employee/tasks.php');
}

$fStatus = (string)param('status', '');
$where = "WHERE t.assigned_to=?"; $args = [$emp['id']];
if (in_array($fStatus, task_statuses(), true)) { $where .= " AND t.status=?"; $args[] = $fStatus; }
$tasks = fetch_all(
  "SELECT t.*, u.name AS assigned_by_name FROM tasks t LEFT JOIN users u ON u.id=t.assigned_by
   $where ORDER BY (t.status='Completed'), t.due_date IS NULL, t.due_date ASC, t.id DESC", $args);
$c = task_counts_for_employee((int)$emp['id']);

$pageTitle='My Tasks'; $activeNav='my_tasks';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>My Tasks</h2><div class="breadcrumb"><?= $c['open'] ?> open · <?= $c['Completed'] ?> completed</div></div>
  <form method="get"><select name="status" onchange="this.form.submit()">
    <option value="">All</option><?php foreach(task_statuses() as $s): ?><option value="<?= $s ?>" <?= $fStatus===$s?'selected':'' ?>><?= $s ?></option><?php endforeach; ?>
  </select></form></div>

<div class="grid cols-3 mb-2">
  <div class="card"><div class="stat"><div class="icon bg-amber">🕗</div><div><div class="label">Pending</div><div class="value"><?= $c['Pending'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-blue">🔄</div><div><div class="label">In Progress</div><div class="value"><?= $c['In Progress'] ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✅</div><div><div class="label">Completed</div><div class="value"><?= $c['Completed'] ?></div></div></div></div>
</div>

<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Task</th><th>Priority</th><th>Assigned</th><th>Due</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($tasks as $t): ?>
    <tr>
      <td><b><?= e($t['title']) ?></b>
        <?php if($t['description']): ?><div class="text-muted" style="font-size:12px;white-space:pre-wrap"><?= e($t['description']) ?></div><?php endif; ?>
        <?php if($t['admin_remark']): ?><div class="text-muted" style="font-size:11px">📌 <?= e($t['admin_remark']) ?></div><?php endif; ?></td>
      <td><?= task_priority_pill($t['priority']) ?></td>
      <td class="text-muted"><?= fmt_date($t['assign_date']) ?><div class="text-muted" style="font-size:11px">by <?= e($t['assigned_by_name'] ?: '—') ?></div></td>
      <td><?= $t['due_date'] ? (task_is_overdue($t) ? '<span class="pill pill-danger">'.fmt_date($t['due_date']).'</span>' : fmt_date($t['due_date'])) : '—' ?></td>
      <td><?= task_status_pill($t['status']) ?></td>
      <td class="text-right">
        <button class="btn btn-sm btn-outline" data-modal="upModal" onclick='upForm(<?= json_encode(["id"=>$t["id"],"title"=>$t["title"],"status"=>$t["status"],"employee_remark"=>$t["employee_remark"]], JSON_HEX_APOS|JSON_HEX_QUOT) ?>)'>Update</button>
      </td>
    </tr>
  <?php endforeach; if(!$tasks): ?><tr><td colspan="6" class="empty">No tasks assigned yet.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="upModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Update Task</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="id" id="up_id">
    <p class="text-muted" id="up_title"></p>
    <div class="form-group"><label>Status</label><select name="status" id="up_status"><?php foreach(task_statuses() as $s): ?><option><?= $s ?></option><?php endforeach; ?></select></div>
    <div class="form-group"><label>Remark / Update</label><textarea name="employee_remark" id="up_remark" placeholder="Progress note for your manager"></textarea></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Save</button></div>
</form></div></div>
<script>function upForm(t){document.getElementById('up_id').value=t.id;
  document.getElementById('up_title').textContent=t.title;
  document.getElementById('up_status').value=t.status||'Pending';
  document.getElementById('up_remark').value=t.employee_remark||'';}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
