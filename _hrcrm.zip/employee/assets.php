<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp = current_employee() ?: ensure_staff_employee(current_user());
if (!$emp) { flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    csrf_verify();
    if (param('do','','POST') === 'return_request') {
        $assetId = (int)param('asset_id', 0, 'POST');
        $reason  = trim((string)param('reason', '', 'POST'));
        // Must be an asset currently allocated to THIS employee (server-side ownership check)
        $asset = fetch_one("SELECT * FROM assets WHERE id=? AND assigned_employee_id=? AND status='Allocated'", [$assetId, $emp['id']]);
        if (!$asset) {
            flash_error('You can only request return of an asset currently assigned to you.');
        } else {
            $exists = (int)fetch_col("SELECT COUNT(*) FROM asset_return_requests WHERE asset_id=? AND employee_id=? AND status='Pending'", [$assetId, $emp['id']]);
            if ($exists) {
                flash_error('A return request for this asset is already pending.');
            } else {
                $alloc = fetch_col("SELECT id FROM asset_allocations WHERE asset_id=? AND status='Active' ORDER BY id DESC LIMIT 1", [$assetId]);
                q("INSERT INTO asset_return_requests (asset_id, allocation_id, employee_id, reason) VALUES (?,?,?,?)",
                  [$assetId, $alloc ?: null, $emp['id'], $reason]);
                $retMsg = $emp['full_name'].' requested to return '.$asset['asset_code'].' ('.$asset['asset_type'].').';
                notify_roles(['super_admin','hr_admin'], 'asset_return_request', 'Asset return request', $retMsg, url('admin/assets.php'));
                notify_employee_tl((int)$emp['id'], 'asset_return_request', 'Asset return request', $retMsg, url('admin/assets.php'));
                flash_success('Return request submitted to HR.');
            }
        }
    }
    redirect('employee/assets.php');
}

$current = fetch_all("SELECT * FROM assets WHERE assigned_employee_id=? AND status='Allocated' ORDER BY allocation_date DESC", [$emp['id']]);
$pendReq = [];
foreach (fetch_all("SELECT asset_id FROM asset_return_requests WHERE employee_id=? AND status='Pending'", [$emp['id']]) as $r) $pendReq[(int)$r['asset_id']]=true;
$history = fetch_all(
  "SELECT h.*, a.asset_code, a.asset_type FROM asset_allocations h JOIN assets a ON a.id=h.asset_id
   WHERE h.employee_id=? ORDER BY h.id DESC", [$emp['id']]);

$pageTitle='My Assets'; $activeNav='my_assets';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>🖥️ My Assets</h2>
  <div class="breadcrumb">Company assets currently assigned to you</div></div></div>

<div class="card mb-2"><div class="card-head"><h3>Currently Assigned</h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Asset ID</th><th>Type / Brand</th><th>Serial / IMEI</th><th>Assigned On</th><th>Condition</th><th></th></tr></thead>
  <tbody><?php foreach($current as $a): ?>
    <tr>
      <td><b><?= e($a['asset_code']) ?></b></td>
      <td><?= e($a['asset_type']) ?><div class="text-muted" style="font-size:11px"><?= e(trim($a['brand'].' '.$a['model'])) ?: '—' ?></div></td>
      <td class="text-muted"><?= e($a['serial_no'] ?: '—') ?></td>
      <td><?= fmt_date($a['allocation_date']) ?></td>
      <td><?= e($a['condition']) ?></td>
      <td class="text-right"><?php if(isset($pendReq[(int)$a['id']])): ?>
        <span class="pill pill-warning">Return requested</span>
      <?php else: ?>
        <button class="btn btn-sm btn-outline" data-modal="reqModal" onclick='reqForm(<?= json_encode(["id"=>$a["id"],"code"=>$a["asset_code"]]) ?>)'>Request Return</button>
      <?php endif; ?></td>
    </tr>
  <?php endforeach; if(!$current): ?><tr><td colspan="6" class="empty">No assets are currently assigned to you.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="card"><div class="card-head"><h3>📜 My Asset History</h3></div>
<div class="table-wrap"><table class="data">
  <thead><tr><th>Asset</th><th>Allocated</th><th>Returned</th><th>Condition (in)</th><th>Status</th></tr></thead>
  <tbody><?php foreach($history as $h): ?>
    <tr><td><b><?= e($h['asset_code']) ?></b> · <?= e($h['asset_type']) ?></td>
    <td><?= fmt_date($h['allocation_date']) ?></td>
    <td><?= $h['return_date']?fmt_date($h['return_date']):'—' ?></td>
    <td><?= e($h['return_condition'] ?: '—') ?></td>
    <td><span class="pill <?= $h['status']==='Active'?'pill-info':'pill-muted' ?>"><?= $h['status']==='Active'?'In use':'Returned' ?></span></td></tr>
  <?php endforeach; if(!$history): ?><tr><td colspan="5" class="empty">No asset history yet.</td></tr><?php endif; ?></tbody>
</table></div></div>

<div class="modal-overlay" id="reqModal"><div class="modal"><form method="post">
  <div class="modal-head"><h3>Request Asset Return</h3><button type="button" class="modal-close" data-close-modal>&times;</button></div>
  <div class="modal-body"><?= csrf_field() ?><input type="hidden" name="do" value="return_request"><input type="hidden" name="asset_id" id="rq_id">
    <p class="text-muted">Asset: <b id="rq_code"></b></p>
    <div class="alert alert-info">This notifies HR to collect the asset. You cannot transfer it to another employee — it must be returned to company inventory.</div>
    <div class="form-group"><label>Reason / Note</label><input type="text" name="reason" placeholder="e.g. No longer needed / leaving project"></div>
  </div>
  <div class="modal-foot"><button type="button" class="btn btn-outline" data-close-modal>Cancel</button><button class="btn">Submit Request</button></div>
</form></div></div>
<script>function reqForm(d){rq_id.value=d.id;rq_code.textContent=d.code;}</script>
<?php require __DIR__ . '/../templates/footer.php'; ?>
