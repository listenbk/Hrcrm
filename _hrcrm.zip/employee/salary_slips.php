<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp=current_employee();
if(!$emp){ flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }
$rows=fetch_all("SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_month DESC",[$emp['id']]);
$pageTitle='Salary Slips'; $activeNav='my_slips';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>My Salary Slips</h2></div></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Month</th><th class="num">Gross</th><th class="num">Deductions</th><th class="num">Net Salary</th><th>Status</th><th></th></tr></thead>
  <tbody><?php foreach($rows as $r): ?>
    <tr><td><b><?= fmt_date($r['pay_month'].'-01','F Y') ?></b></td>
    <td class="num"><?= money($r['gross_earnings']) ?></td><td class="num"><?= money($r['total_deductions']) ?></td>
    <td class="num"><b><?= money($r['net_salary']) ?></b></td>
    <td><span class="pill <?= $r['status']==='Paid'?'pill-success':'pill-warning' ?>"><?= e($r['status']) ?></span></td>
    <td class="text-right"><a class="btn btn-sm" href="<?= url('employee/salary_slip.php?id='.$r['id']) ?>" target="_blank">🧾 View / Download</a></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No salary slips available yet.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
