<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp=current_employee() ?: ensure_staff_employee(current_user());
if(!$emp){ flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }
$rows=fetch_all("SELECT lr.*, lt.name AS type_name, lt.color FROM leave_requests lr JOIN leave_types lt ON lt.id=lr.leave_type_id
  WHERE lr.employee_id=? ORDER BY lr.created_at DESC",[$emp['id']]);
$pageTitle='Leave History'; $activeNav='leave_history';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Leave History</h2></div>
  <a class="btn" href="<?= url('employee/leave_apply.php') ?>">📝 Apply for Leave</a></div>
<div class="card"><div class="table-wrap"><table class="data">
  <thead><tr><th>Type</th><th>Dates</th><th>Days</th><th>Reason</th><th>Status</th><th>Remark</th></tr></thead>
  <tbody><?php foreach($rows as $r):
    $pill=['Approved'=>'pill-success','Rejected'=>'pill-danger','Pending'=>'pill-warning'][$r['status']]; ?>
    <tr><td><span class="badge" style="background:<?= e($r['color']) ?>"><?= e($r['type_name']) ?></span></td>
    <td><?= fmt_date($r['start_date']) ?> → <?= fmt_date($r['end_date']) ?><?= $r['is_half_day']?' (Half)':'' ?></td>
    <td><?= e($r['total_days']) ?></td><td class="text-muted"><?= e($r['reason'] ?: '—') ?></td>
    <td><span class="pill <?= $pill ?>"><?= e($r['status']) ?></span></td>
    <td class="text-muted"><?= e($r['admin_remark'] ?: '—') ?></td></tr>
  <?php endforeach; if(!$rows): ?><tr><td colspan="6" class="empty">No leave requests yet.</td></tr><?php endif; ?></tbody>
</table></div></div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
