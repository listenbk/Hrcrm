<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp=current_employee() ?: ensure_staff_employee(current_user());
if(!$emp){ flash_error('No employee profile linked.'); redirect('employee/dashboard.php'); }

if ($_SERVER['REQUEST_METHOD']==='POST') {
    csrf_verify();
    $typeId=(int)param('leave_type_id',0,'POST');
    $start=param('start_date','','POST'); $end=param('end_date','','POST');
    $half=param('is_half_day',0,'POST')?1:0;
    $reason=trim((string)param('reason','','POST'));
    $emergency=trim((string)param('emergency_reason','','POST'));
    $contact=trim((string)param('contact_during_leave','','POST'));
    $errors=[];
    if(!$typeId)$errors[]='Select a leave type.';
    if(!$start||!$end)$errors[]='Select start and end dates.';
    if($start&&$end&&$end<$start)$errors[]='End date cannot be before start date.';
    if(!$errors){
        $days = $half ? 0.5 : (max(1,(int)((strtotime($end)-strtotime($start))/86400)+1));
        $doc=null;
        if(!empty($_FILES['document']['name'])){ $doc=handle_upload($_FILES['document'],'leaves',['jpg','jpeg','png','pdf','doc','docx']); }
        q("INSERT INTO leave_requests (employee_id,leave_type_id,start_date,end_date,is_half_day,total_days,reason,emergency_reason,contact_during_leave,document)
           VALUES (?,?,?,?,?,?,?,?,?,?)",
          [$emp['id'],$typeId,$start,$end,$half,$days,$reason,$emergency,$contact,$doc]);
        $leaveMsg = $emp['full_name'].' requested leave '.fmt_date($start).' → '.fmt_date($end).'. Either a Team Leader or HR can approve.';
        notify_leave_approvers('leave_request','New leave request',$leaveMsg,url('admin/leaves.php'));
        // Also route directly to the employee's own assigned Team Leader.
        notify_employee_tl((int)$emp['id'], 'leave_request', 'New leave request', $leaveMsg, url('admin/leaves.php'));
        audit_log('leave_applied','leave',insert_id(),"{$emp['full_name']} applied leave");
        flash_success('Leave request submitted for approval.');
        redirect('employee/leave_history.php');
    }
    flash_error(implode(' ',$errors));
}
$types=fetch_all("SELECT * FROM leave_types WHERE is_active=1 ORDER BY name");
$balances=[];
foreach(fetch_all("SELECT * FROM leave_balances WHERE employee_id=? AND year=?",[$emp['id'],date('Y')]) as $b) $balances[$b['leave_type_id']]=$b;
$pageTitle='Apply for Leave'; $activeNav='leave_apply';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Apply for Leave</h2></div></div>
<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>New Leave Request</h3></div><div class="card-body">
    <form method="post" enctype="multipart/form-data"><?= csrf_field() ?>
      <div class="form-group"><label>Leave Type <span class="req">*</span></label><select name="leave_type_id" required>
        <option value="">— Select —</option>
        <?php foreach($types as $t): ?><option value="<?= $t['id'] ?>"><?= e($t['name']) ?><?= $t['is_paid']?'':' (Unpaid)' ?></option><?php endforeach; ?></select></div>
      <div class="form-row">
        <div class="form-group"><label>Start Date <span class="req">*</span></label><input type="date" name="start_date" required></div>
        <div class="form-group"><label>End Date <span class="req">*</span></label><input type="date" name="end_date" required></div>
      </div>
      <div class="form-group"><label class="switch"><input type="checkbox" name="is_half_day" value="1"> Half day</label></div>
      <div class="form-group"><label>Reason</label><textarea name="reason"></textarea></div>
      <div class="form-group"><label>Emergency Reason (if any)</label><input type="text" name="emergency_reason"></div>
      <div class="form-group"><label>Contact During Leave</label><input type="text" name="contact_during_leave"></div>
      <div class="form-group"><label>Supporting Document</label><input type="file" name="document"></div>
      <button class="btn">📤 Submit Request</button>
    </form>
  </div></div>
  <div class="card"><div class="card-head"><h3>My Leave Balance (<?= date('Y') ?>)</h3></div><div class="card-body">
    <table class="data"><thead><tr><th>Type</th><th>Entitlement</th><th>Used</th><th>Remaining</th></tr></thead><tbody>
    <?php foreach($types as $t): $b=$balances[$t['id']]??null; $ent=(float)($b['entitlement']??$t['annual_quota']); $used=(float)($b['used']??0); ?>
      <tr><td><?= e($t['name']) ?></td><td><?= $ent ?></td><td><?= $used ?></td><td><b><?= $ent-$used ?></b></td></tr>
    <?php endforeach; ?></tbody></table>
  </div></div>
</div>
<?php require __DIR__ . '/../templates/footer.php'; ?>
