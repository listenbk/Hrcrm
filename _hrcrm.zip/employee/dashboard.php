<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_login();
$emp = current_employee();
if (!$emp) { flash_error('No employee profile is linked to your account. Contact HR.'); }

$today=date('Y-m-d'); $ym=date('Y-m');
$todayAtt = $emp ? fetch_one("SELECT a.*, s.name AS status_name,s.color FROM attendance a LEFT JOIN attendance_statuses s ON s.id=a.status_id WHERE a.employee_id=? AND a.att_date=?",[$emp['id'],$today]) : null;

// Overtime (manual-session) state for today.
$otManual = ot_manual_enabled() && ot_enabled();
$otToday  = ($emp && $otManual) ? fetch_one("SELECT * FROM overtime WHERE employee_id=? AND ot_date=?", [$emp['id'],$today]) : null;
$otOpen   = ($otToday && !empty($otToday['ot_check_in']) && empty($otToday['actual_out']));

$mSummary = $emp ? payroll_attendance_summary((int)$emp['id'],$ym) : ['present'=>0,'absent'=>0,'leavePaid'=>0,'leaveUnpaid'=>0,'late'=>0];
$lastPay = $emp ? fetch_one("SELECT * FROM payroll WHERE employee_id=? ORDER BY pay_month DESC LIMIT 1",[$emp['id']]) : null;
$pendingPay = $emp ? (float)fetch_col("SELECT COALESCE(SUM(pending_amount),0) FROM payroll WHERE employee_id=?",[$emp['id']]) : 0;
$advBalance = $emp ? (float)fetch_col("SELECT COALESCE(SUM(balance_amount),0) FROM employee_advances WHERE employee_id=? AND status='Active'",[$emp['id']]) : 0;
$pendingLeaves = $emp ? (int)fetch_col("SELECT COUNT(*) FROM leave_requests WHERE employee_id=? AND status='Pending'",[$emp['id']]) : 0;
$leaveUsed = $emp ? (float)fetch_col("SELECT COALESCE(SUM(used),0) FROM leave_balances WHERE employee_id=? AND year=?",[$emp['id'],date('Y')]) : 0;

$pageTitle='Dashboard'; $activeNav='dashboard';
require __DIR__ . '/../templates/header.php';
?>
<div class="page-head"><div><h2>Hello, <?= e(explode(' ',$u['name'])[0]) ?> 👋</h2>
  <div class="breadcrumb"><?= fmt_date($today,'l, d F Y') ?> · <span id="liveClock"></span></div></div></div>

<?php require __DIR__ . '/../templates/notices_widget.php'; ?>

<?php if(!$emp): ?><div class="alert alert-error">Your login is not linked to an employee record yet.</div><?php else: ?>

<div id="attMsg" class="alert" style="display:none"></div>

<div class="grid cols-2">
  <div class="card"><div class="card-head"><h3>Today's Attendance</h3>
    <?php if($todayAtt && $todayAtt['status_name']): ?><span class="badge" style="background:<?= e($todayAtt['color']) ?>"><?= e($todayAtt['status_name']) ?></span><?php endif; ?></div>
    <div class="card-body text-center">
      <div class="flex between wrap" style="text-align:center">
        <div style="flex:1"><div class="text-muted">Check In</div><div style="font-size:22px;font-weight:800"><?= $todayAtt&&$todayAtt['check_in']?fmt_date($todayAtt['check_in'],'h:i A'):'—' ?></div></div>
        <div style="flex:1"><div class="text-muted">Working</div><div class="hours-big" style="font-size:26px"><?= $todayAtt?fmt_hm((int)$todayAtt['working_minutes']):'0h 0m' ?></div></div>
        <div style="flex:1"><div class="text-muted">Check Out</div><div style="font-size:22px;font-weight:800"><?= $todayAtt&&$todayAtt['check_out']?fmt_date($todayAtt['check_out'],'h:i A'):'—' ?></div></div>
      </div>
      <div class="mt-3">
        <?php if(!$todayAtt || !$todayAtt['check_in']): ?>
          <button class="btn btn-lg" style="width:auto" onclick="attendanceAction('check_in',this)">🟢 Check In</button>
        <?php elseif(!$todayAtt['check_out']):
          $minCk=(int)setting('min_checkout_minutes',30);
          $remain=(strtotime($todayAtt['check_in'])+$minCk*60)-time(); ?>
          <button class="btn btn-lg btn-danger" style="width:auto" id="checkoutBtn" data-unlock="<?= max(0,$remain) ?>" <?= $remain>0?'disabled':'' ?> onclick="attendanceAction('check_out',this)">🔴 Check Out</button>
          <?php if($remain>0): ?><div class="mt-1"><span class="pill pill-warning" id="checkoutMsg">⏳ Checkout will be available <?= $minCk ?> minutes after check-in</span></div><?php endif; ?>
          <?php if($todayAtt['late_minutes']>0): ?><div class="mt-1"><span class="pill pill-warning">You were <?= $todayAtt['late_minutes'] ?> min late</span></div><?php endif; ?>
        <?php else: ?>
          <div class="pill pill-success" style="font-size:14px;padding:8px 16px">✔️ Attendance complete for today</div>
          <?php if(!empty($todayAtt['is_auto_checkout'])): ?>
            <div class="mt-1"><span class="pill pill-warning">🕖 Auto Check-Out at <?= fmt_date($todayAtt['check_out'],'h:i A') ?></span></div>
          <?php endif; ?>
        <?php endif; ?>
      </div>

      <?php if($otManual && $todayAtt && $todayAtt['check_out']): ?>
      <div class="mt-3" style="border-top:1px solid var(--border);padding-top:14px">
        <div class="text-muted" style="font-size:13px;margin-bottom:8px">⏱️ Overtime (separate session)</div>
        <?php if($otOpen): ?>
          <div class="pill pill-info" style="font-size:13px;padding:6px 12px">OT running since <?= fmt_date($otToday['ot_check_in'],'h:i A') ?></div>
          <div class="mt-2"><button class="btn btn-warning" style="width:auto" onclick="attendanceAction('ot_check_out',this)">⏹️ Overtime Check-Out</button></div>
        <?php elseif($otToday): ?>
          <div class="pill pill-muted" style="font-size:13px;padding:6px 12px">OT recorded: <?= rtrim(rtrim(number_format((float)$otToday['actual_hours'],2),'0'),'.') ?>h</div>
          <div class="mt-1"><a class="btn btn-sm btn-outline" href="<?= url('employee/overtime.php') ?>">Submit reason / view</a></div>
        <?php else: ?>
          <button class="btn btn-success" style="width:auto" onclick="attendanceAction('ot_check_in',this)">▶️ Overtime Check-In</button>
          <div class="help mt-1">Available from <?= e(fmt_date(date('Y-m-d').' '.setting('ot_checkin_after','20:00'),'h:i A')) ?> onward. Sent to your Team Leader for approval.</div>
        <?php endif; ?>
      </div>
      <?php endif; ?>
    </div>
  </div>

  <div class="card"><div class="card-head"><h3>This Month</h3></div><div class="card-body">
    <div class="grid cols-3" style="gap:12px">
      <div class="text-center"><div class="hours-big" style="font-size:26px"><?= $mSummary['present'] ?></div><div class="text-muted">Present</div></div>
      <div class="text-center"><div class="hours-big" style="font-size:26px;color:var(--danger)"><?= $mSummary['absent'] ?></div><div class="text-muted">Absent</div></div>
      <div class="text-center"><div class="hours-big" style="font-size:26px;color:var(--warning)"><?= $mSummary['late'] ?></div><div class="text-muted">Late</div></div>
      <div class="text-center"><div class="hours-big" style="font-size:26px;color:var(--info)"><?= $mSummary['leavePaid']+$mSummary['leaveUnpaid'] ?></div><div class="text-muted">Leaves</div></div>
      <div class="text-center"><div class="hours-big" style="font-size:26px"><?= $leaveUsed ?></div><div class="text-muted">Used (yr)</div></div>
      <div class="text-center"><div class="hours-big" style="font-size:26px"><?= $pendingLeaves ?></div><div class="text-muted">Pending</div></div>
    </div>
  </div></div>
</div>

<div class="grid cols-4 mt-2">
  <div class="card"><div class="stat"><div class="icon bg-brand">💰</div><div><div class="label">Current Basic</div><div class="value" style="font-size:18px"><?= money($emp['basic_salary']) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-green">✔️</div><div><div class="label">Last Salary</div><div class="value" style="font-size:18px"><?= $lastPay?money($lastPay['net_salary']):'—' ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-red">⌛</div><div><div class="label">Pending Salary</div><div class="value" style="font-size:18px"><?= money($pendingPay) ?></div></div></div></div>
  <div class="card"><div class="stat"><div class="icon bg-violet">🏦</div><div><div class="label">Advance Balance</div><div class="value" style="font-size:18px"><?= money($advBalance) ?></div></div></div></div>
</div>

<div class="flex gap mt-3 wrap">
  <a class="btn btn-outline" href="<?= url('employee/leave_apply.php') ?>">📝 Apply for Leave</a>
  <a class="btn btn-outline" href="<?= url('employee/attendance.php') ?>">🕐 My Attendance</a>
  <a class="btn btn-outline" href="<?= url('employee/overtime.php') ?>">⏱️ My Overtime</a>
  <a class="btn btn-outline" href="<?= url('employee/salary_slips.php') ?>">🧾 Salary Slips</a>
</div>
<?php endif; ?>
<?php require __DIR__ . '/../templates/footer.php'; ?>
