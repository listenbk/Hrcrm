<?php
require_once __DIR__ . '/../includes/bootstrap.php';
require_once __DIR__ . '/../includes/slip_render.php';
require_login();
$emp=current_employee();
$id=(int)param('id',0);
// Ensure the payroll belongs to this employee
$own=$emp?fetch_col("SELECT COUNT(*) FROM payroll WHERE id=? AND employee_id=?",[$id,$emp['id']]):0;
if(!$own){ http_response_code(403); die('You can only view your own salary slip.'); }
render_salary_slip($id);
