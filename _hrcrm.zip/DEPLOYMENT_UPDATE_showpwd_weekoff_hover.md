# RG Realty HRCRM — Show Password, Flexible Week-Off, Hover Fix

## 1. Show/Hide Password
Every password field in the CRM (login, reset password, change password, and
all "confirm with your password" delete/edit dialogs) now has a **Show/Hide**
toggle button. Client-side only — no data or validation logic changed.

## 2. Flexible Week-Off Approval
- HR **and** Team Leaders can now set a **custom weekly-off pattern per
  employee** from the new **Attendance → Week-Off Management** page.
- An employee with no custom setting keeps using the company-wide default
  (Settings → Weekly Offs) — nothing changes for anyone until HR/TL
  deliberately sets an override for that person.
- The override is respected everywhere weekly-off matters: attendance
  calendars, auto-absent marking, overtime day-type/multiplier, and payroll
  working-day calculations.
- Every change is audit-logged and the employee is notified.

## 3. Hover UI Fix
Fixed one inconsistent hover state (`.btn-warning`) where hovering kept dark
text on a darkened background, making it hard to read. It now matches every
other button's hover state with white text.

---

## Files to upload (into your live `hrcrm/` folder)

**New**
- `install/migrate_flexible_weekoff.sql`
- `admin/week_offs.php`

**Changed (overwrite existing)**
- `includes/attendance_lib.php`
- `includes/overtime_lib.php`
- `includes/payroll_lib.php`
- `admin/attendance_monthly.php`
- `admin/employee_view.php`
- `admin/attendance_manual.php`
- `admin/notices.php`
- `admin/users.php`
- `employee/profile.php`
- `auth/login.php`
- `auth/reset_password.php`
- `assets/css/style.css`
- `assets/js/app.js`
- `templates/sidebar.php`

Hostinger's extractor won't overwrite existing files — delete the "Changed"
files above on the server first, then extract this ZIP into `hrcrm/`.

## Database change

Import `install/migrate_flexible_weekoff.sql` in phpMyAdmin. It only:
- adds `employees.week_off_days` (nullable — NULL means "use company default"),
- adds the `weekoff.manage` permission, granted to Super Admin, HR, and Team Leader.

No existing table, column, or row is altered. Safe to re-run.

## Post-upload verification
1. Log in — on any password field, click **Show** to confirm it reveals the
   typed password, then **Hide** to mask it again.
2. As HR or a Team Leader, open **Attendance → Week-Off Management**, click
   **Manage** on an employee, tick a different day, and Save — confirm the
   row now shows that day and "Custom". Click **Reset** to confirm it reverts
   to "Company Default".
3. Confirm Attendance, Leave, Payroll, Assets, and Notices still work exactly
   as before for employees who were never given a custom week-off.
