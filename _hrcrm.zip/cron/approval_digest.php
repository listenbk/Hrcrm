<?php
/**
 * Pending-approval digest. Summarises items awaiting action (leave, overtime,
 * overtime) and notifies approvers in-app, plus a best-effort
 * email. If SMTP is later configured, the same email becomes reliable.
 *
 * Schedule daily (e.g. 09:00) via Hostinger Cron:
 *   /usr/bin/php  /home/USER/domains/rgrealty.in/public_html/hrcrm/cron/approval_digest.php
 *
 * Optional URL trigger (needs a `cron_key` in settings):
 *   wget -q -O /dev/null "https://hrcrm.rgrealty.in/cron/approval_digest.php?key=YOURKEY"
 */

$inc = __DIR__ . '/../includes/';
require_once __DIR__ . '/../config/config.php';
require_once $inc . 'db.php';
require_once $inc . 'settings.php';
require_once $inc . 'functions.php';

$isCli = (PHP_SAPI === 'cli');
if (!$isCli) {
    header('Content-Type: text/plain');
    $key = (string)($_GET['key'] ?? '');
    $expected = (string)setting('cron_key', '');
    if ($expected === '' || !hash_equals($expected, $key)) {
        http_response_code(403);
        echo "Forbidden. Set a 'cron_key' in settings and pass ?key=... , or run this via CLI.\n";
        exit;
    }
}

// Count pending items (each table/status guarded so a missing table won't fatal).
function pending_count(string $sql): int {
    try { return (int)fetch_col($sql); } catch (Throwable $e) { return 0; }
}
$leaves = pending_count("SELECT COUNT(*) FROM leave_requests WHERE status='Pending'");
$ot     = pending_count("SELECT COUNT(*) FROM overtime WHERE status='Pending Approval'");
$total  = $leaves + $ot;

if ($total === 0) {
    echo date('c') . " approval_digest nothing_pending\n";
    exit;
}

$base  = rtrim((string)(defined('APP_URL') ? APP_URL : ''), '/');
$lines = [];
if ($leaves) $lines[] = "• {$leaves} leave request(s) pending";
if ($ot)     $lines[] = "• {$ot} overtime request(s) pending";
$summary = implode("\n", $lines);

// In-app notification to approvers.
notify_roles(['super_admin','hr_admin'], 'approval_digest', 'Pending approvals',
    "{$total} item(s) awaiting your action.\n{$summary}", url('admin/leaves.php'));
if ($leaves) {
    notify_roles(['team_leader'], 'approval_digest', 'Pending leave approvals',
        "{$leaves} leave request(s) awaiting your action.", url('admin/leaves.php'));
}

// Best-effort email to active approvers.
$roles = $leaves ? "'super_admin','hr_admin','team_leader'" : "'super_admin','hr_admin'";
$recipients = [];
try {
    $recipients = fetch_all(
        "SELECT u.name, u.email FROM users u JOIN roles r ON r.id=u.role_id
         WHERE r.slug IN ($roles) AND u.is_active=1 AND u.email <> ''");
} catch (Throwable $e) { $recipients = []; }

$company = setting('company_name', 'RG Realty');
$subject = "$company HRCRM — {$total} pending approval(s)";
$sent = 0;
foreach ($recipients as $rcp) {
    $body = "Hello {$rcp['name']},\n\nThere are items awaiting approval in the HRCRM:\n\n{$summary}\n\n"
          . ($base ? "Open: {$base}/admin/leaves.php\n\n" : '')
          . "— {$company} HRCRM";
    if (@mail($rcp['email'], $subject, $body, "From: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'rgrealty.in'))) $sent++;
}

$line = date('c') . ' approval_digest ' . json_encode(['leaves'=>$leaves,'overtime'=>$ot,'emailed'=>$sent]);
echo $line . "\n";
@file_put_contents(APP_ROOT . '/storage/cron.log', $line . "\n", FILE_APPEND);
