<?php
/**
 * Server-side AUTO CHECK-OUT at 7:30 PM (office close + grace).
 *
 * Schedule this once a day at/after 19:30 (Asia/Kolkata) via Hostinger Cron.
 * It is idempotent and never ends a session before the cut-off, so running it
 * more than once a day is completely safe. It does NOT create overtime —
 * overtime requires a separate, employee-initiated Overtime Check-In.
 *
 *  RECOMMENDED (CLI), run at 19:30:
 *    /usr/bin/php  /home/USER/domains/rgrealty.in/public_html/hrcrm/cron/auto_checkout.php
 *
 *  OPTIONAL (URL, only if a `cron_key` is set in the settings table):
 *    wget -q -O /dev/null "https://hrcrm.rgrealty.in/cron/auto_checkout.php?key=YOURKEY"
 *
 *  Optional date override (defaults to today, Asia/Kolkata):
 *    ... auto_checkout.php 2026-09-24        (CLI)
 *    ... auto_checkout.php?...&date=2026-09-24 (URL)
 */

// Load only what's needed — no sessions/headers (safe under cron/CLI).
$inc = __DIR__ . '/../includes/';
require_once __DIR__ . '/../config/config.php';
require_once $inc . 'db.php';
require_once $inc . 'settings.php';
require_once $inc . 'functions.php';
require_once $inc . 'attendance_lib.php';

$isCli = (PHP_SAPI === 'cli');

// Authorization: CLI is always allowed. Web requires a matching, non-empty key.
if (!$isCli) {
    header('Content-Type: text/plain');
    $key = (string)($_GET['key'] ?? '');
    $expected = (string)setting('cron_key', '');
    if ($expected === '' || !hash_equals($expected, $key)) {
        http_response_code(403);
        echo "Forbidden. Set a 'cron_key' in settings and pass ?key=... , or run this via CLI.\n";
        exit;
    }
}

if (setting('auto_checkout_enabled', '1') !== '1') {
    echo "auto-checkout is disabled (auto_checkout_enabled=0)\n";
    exit;
}

// Date to process (Asia/Kolkata via config timezone).
$date = $isCli ? ($argv[1] ?? date('Y-m-d')) : ($_GET['date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');

$result = auto_checkout_open($date);
$line = date('c') . ' auto_checkout ' . json_encode($result);

echo $line . "\n";
@file_put_contents(APP_ROOT . '/storage/cron.log', $line . "\n", FILE_APPEND);
