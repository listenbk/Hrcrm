<?php
/**
 * Daily attendance automation — auto-mark Absent.
 *
 * Run this once a day (after office closing time) via Hostinger Cron Jobs.
 * It is idempotent: running it several times a day is completely safe, and it
 * never marks anyone absent before office closing time on the current day.
 *
 *  RECOMMENDED (CLI):
 *    /usr/bin/php  /home/USER/domains/rgrealty.in/public_html/hrcrm/cron/auto_absent.php
 *
 *  OPTIONAL (URL, only if you set a `cron_key` in the settings table):
 *    wget -q -O /dev/null "https://hrcrm.rgrealty.in/cron/auto_absent.php?key=YOURKEY"
 *
 *  Optional date override (defaults to today, Asia/Kolkata):
 *    ... auto_absent.php 2026-09-21        (CLI)
 *    ... auto_absent.php?...&date=2026-09-21 (URL)
 */

// Load only what's needed — no sessions/headers (safe under cron/CLI).
$inc = __DIR__ . '/../includes/';
require_once __DIR__ . '/../config/config.php';
require_once $inc . 'db.php';
require_once $inc . 'settings.php';
require_once $inc . 'functions.php';
require_once $inc . 'attendance_lib.php';

$isCli = (PHP_SAPI === 'cli');

// Authorization: CLI is always allowed. Web requires a matching, non-empty key.
if (!$isCli) {
    header('Content-Type: text/plain');
    $key = (string)($_GET['key'] ?? '');
    $expected = (string)setting('cron_key', '');
    if ($expected === '' || !hash_equals($expected, $key)) {
        http_response_code(403);
        echo "Forbidden. Set a 'cron_key' in settings and pass ?key=... , or run this via CLI.\n";
        exit;
    }
}

if (setting('auto_absent_enabled', '1') !== '1') {
    echo "auto-absent is disabled (auto_absent_enabled=0)\n";
    exit;
}

// Date to process (Asia/Kolkata via config timezone).
$date = $isCli ? ($argv[1] ?? date('Y-m-d')) : ($_GET['date'] ?? date('Y-m-d'));
if (!preg_match('/^\d{4}-\d{2}-\d{2}$/', $date)) $date = date('Y-m-d');

$result = auto_mark_absent($date);
$line = date('c') . ' auto_absent ' . json_encode($result);

echo $line . "\n";
@file_put_contents(APP_ROOT . '/storage/cron.log', $line . "\n", FILE_APPEND);
